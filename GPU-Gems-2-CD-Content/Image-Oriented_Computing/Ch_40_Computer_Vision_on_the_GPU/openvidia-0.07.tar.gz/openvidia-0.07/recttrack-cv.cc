/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

/*
 * 82% cpu load, 22 fps on a P4 2.4C
 *
 */

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "GenericDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"
#include "FragPipeDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include "FindHighestFilter.h"
#include <assert.h>
#include <iostream>
using namespace std;

// new for the client Komputer stuff
#include "ShmFrame.h"
#include <getopt.h>

// Globals
bool DEBUG=false;
bool DEFAULT_USE_SHM=false;
bool USE_SHM=DEFAULT_USE_SHM;
/// Standalone SHM sends tracking results into shared memory, but
/// receives data from the 1394 source directly.
bool standaloneSHM = false;
int MAX_PCI_HEADS=5;

// Global display object
FragPipeDisplay *d;
Dc1394 *dc1394;
GenericFilter *filter1, *filter2, *filter3, *filter4;
MomentFilter *momentFilter;

/// Window Stuff
int imageWinWidth = 320;
int imageWinHeight = 240;
int imageSrcWidth = 320;
int imageSrcHeight = 240;
int viewBufferNumber = 0;
Window  Orbwin;

// Komputer interface
int client_id =-1;
ShmFrame *shmFrame;
void render_tracking();
void render_filter_tracking();

/*
 * OPENCV STUFF
 */
#include <opencv/cv.h>
#include <math.h>
#define dot(a,b) (a.x*b.x + a.y*b.y)
CvPoint pt[4];
double angle( CvPoint pt1, CvPoint pt2, CvPoint pt0 ) {
    double a;
    pt1.x -= pt0.x;
    pt2.x -= pt0.x;
    pt1.y -= pt0.y;
    pt2.y -= pt0.y;
    a = dot(pt1,pt2)/sqrt((double)dot(pt1,pt1)*dot(pt2,pt2) + 1e-10);
    return a;
}
CvSeq* findSquares4( IplImage* img, CvMemStorage* storage )
{
    CvSeq* contours;
    int i, c, l, N = 12;
    int thresh = 50;
    CvSize sz = cvSize( img->width & -2, img->height & -2 );
    IplImage* timg = cvCloneImage( img ); // make a copy of input image
    IplImage* gray = cvCreateImage( sz, 8, 1 );
    IplImage* pyr = cvCreateImage( cvSize(sz.width/2, sz.height/2), 8, 3 );
    IplImage* tgray;
    // create empty sequence that will contain points -
    // 4 points per square (the square's vertices)
    CvSeq* squares = cvCreateSeq( 0, sizeof(CvSeq), sizeof(CvPoint), storage );

    // select the maximum ROI in the image
    // with the width and height divisible by 2
    cvSetImageROI( timg, cvRect( 0, 0, sz.width, sz.height ));
    //XXX
    //cvSetImageROI(timg, cvRect(10,10, 138,138));

    // down-scale and upscale the image to filter out the noise
    cvPyrDown( timg, pyr, 7 );
    cvPyrUp( pyr, timg, 7 );
    tgray = cvCreateImage( sz, 8, 1 );

    // find squares in every color plane of the image
    for( c = 0; c <=2; c++ )
      {
        // extract the c-th color plane
        cvSetImageCOI( timg, c+1 );
        cvCopy( timg, tgray, 0 );

        // try several threshold levels
        for( l = 0; l < N; l++ )
        {
            // hack: use Canny instead of zero threshold level.
            // Canny helps to catch squares with gradient shading       
            if( l == 0 )
            {
                // apply Canny. Take the upper threshold from slider
                // and set the lower to 0 (which forces edges merging) 
                cvCanny( tgray, gray, 0, thresh, 5 );
                // dilate canny output to remove potential
                // holes between edge segments 
                cvDilate( gray, gray, 0, 1 );
            }
            else
            {
                // apply threshold if l!=0:
                //     tgray(x,y) = gray(x,y) < (l+1)*255/N ? 255 : 0
                cvThreshold( tgray, gray, (l+1)*255/N, 255, CV_THRESH_BINARY );
            }

            // find contours and store them all as a list
            cvFindContours( gray, storage, &contours, sizeof(CvContour),
                CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE );

            // test each contour
            while( contours )
            {
                // approximate contour with accuracy proportional
                // to the contour perimeter
                CvSeq* result = cvApproxPoly( contours, sizeof(CvContour), storage,
                    CV_POLY_APPROX_DP, cvContourPerimeter(contours)*0.02, 0 );
                // square contours should have 4 vertices after approximation
                // relatively large area (to filter out noisy contours)
                // and be convex.
                // Note: absolute value of an area is used because
                // area may be positive or negative - in accordance with the
                // contour orientation
                if( result->total == 4 &&
                    fabs(cvContourArea(result,CV_WHOLE_SEQ)) > 1000 &&
                    cvCheckContourConvexity(result) )
                {
                    double s = 0, t;

                    for( i = 0; i < 5; i++ )
                    {
                        // store all the contour vertices in the buffer
                        pt[i&3] = *(CvPoint*)cvGetSeqElem( result, i, 0 );
                        // and find minimum angle between joint
                        // edges (maximum of cosine)
                        if( i >= 2 )
                        {
                            t = fabs(angle( pt[i&3], pt[(i-2)&3], pt[(i-1)&3]));
                            s = MAX( s, t );
                        }
                    }

                    // if cosines of all angles are small
                    // (all angles are ~90 degree) then write quandrange
                    // vertices to resultant sequence 
                    if( s < 0.3 )
                        for( i = 0; i < 4; i++ )
                            cvSeqPush( squares, pt + i );
                }

                // take the next contour
                contours = contours->h_next;
            }
        }
    }

    // release all the temporary images
    cvReleaseImage( &gray );
    cvReleaseImage( &pyr );
    cvReleaseImage( &tgray );
    cvReleaseImage( &timg );

    return squares;
}

// the function draws all the squares in the image
void drawSquares(IplImage* img, CvSeq* squares )
{
    CvSeqReader reader;
    int i;


    float biggestDiameter=0;

    // initialize reader of the sequence
    cvStartReadSeq( squares, &reader, 0 );

    // read 4 sequence elements at a time (all vertices of a square)
    for( i = 0; i < squares->total; i += 4 )
    {
        CvPoint* rect = pt;
        int count = 4;

        // read 4 vertices
        CV_READ_SEQ_ELEM( pt[0], reader );
        CV_READ_SEQ_ELEM( pt[1], reader );
        CV_READ_SEQ_ELEM( pt[2], reader );
        CV_READ_SEQ_ELEM( pt[3], reader );

        // draw the square as a closed polyline 
        cvPolyLine( img, &rect, &count, 1, 1, CV_RGB(0,255,0), 3, 8 );

	// WRITE THEM TO SHMEM
	// biggest squares, near hand
	CvPoint p=pt[1];
	CvPoint p2=pt[3];
	float diameter=sqrt(powf(p.x-p2.x, 2)+powf(p.y-p2.y,2));
	if(diameter > biggestDiameter) {
	  biggestDiameter=diameter;
	  for(int j=0;j<4;j++) {
	    CvPoint p = pt[j];
	    if(USE_SHM) {
	      shmFrame->Frame->rect_x_320[j]=p.x;
	      shmFrame->Frame->rect_y_240[j]=p.y;
	    }
	  }
	}

    }
}

void process_frame_opencv( unsigned char* buffer) {
  int width=320;
  int height=240;

  unsigned char *procbuf;
  static int fcount; 

  static unsigned char *grey_buf = NULL;
  static unsigned char *undist_buf = NULL;
  static unsigned char *dist_buf = NULL;
  static IplImage*  dist_image=0;
  static IplImage*  undist_image=0;
  static IplImage*  undistMap=0;
         IplImage* img = 0;
	 IplImage* tgray=0;
	 IplImage* timg=0;
	 IplImage* grey_image=0;
         IplImage* pyr = 0;
  float focal_length[2];
  float distortion[4];
  float principal_point[2];
  float camera_matrix[9];
  CvSize size;
  static CvMemStorage* storage = 0;
  //CvSize sz = cvSize( width & -2, height & -2 );

  procbuf = buffer;
  size = cvSize(width,height);

  if( grey_buf == NULL ) grey_buf=(unsigned char*)malloc(width*height);
  if( undist_buf == NULL ) undist_buf=(unsigned char*)malloc(width*height*3);
  if( dist_buf == NULL ) dist_buf=(unsigned char*)malloc(width*height*3);
  if( undist_image == NULL) undist_image = cvCreateImage(size, IPL_DEPTH_8U, 3);
  if( storage == NULL) storage = cvCreateMemStorage(0);
  cvSetImageData(undist_image, procbuf, width*3);
  
  drawSquares(undist_image, findSquares4( undist_image, storage ) ); 

  cvReleaseImage( &dist_image );
  cvReleaseImage( &timg );
  cvReleaseImage( &tgray );
  // clear memory storage - reset free space position
  cvClearMemStorage( storage );
  // try to FREE UNDIST??
  //cvReleaseImage( &undist_image);
}

/*
 * GLUT CALLBACKS
 */
void reshape(int w, int h) {
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);

  //set the fpbuffer to have geometry identical to screen
  d->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  d->deactivate_fpbuffer();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}

void myIdle(){
  usleep(500);
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
         viewBufferNumber = atoi((const char * )&key);
         cout<<"new buffer to view is "<<viewBufferNumber<<endl;
         break;
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
	cout <<"N00B"<<endl;
      }
      break;
    case GLUT_RIGHT_BUTTON : 
      break;
  }
}

/*
 * Interface to work with Dc1394
 */
unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0;
unsigned char* dma_buf_rgb=(unsigned char *)malloc(imageSrcWidth*imageSrcHeight*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(imageSrcWidth*imageSrcHeight*3);
int newdata=0;
/* 
 * Tell function executed in context of Dc1394 thread 
 */
void TellRWMHeCanUseImage(const char *dma_buf_) {
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;

  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;
  uyvy2rgb(dma_buf,dma_buf_rgb,imageSrcWidth*imageSrcHeight);

  //have only one, need two before we do any orbits
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,imageSrcWidth*imageSrcHeight);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }

  newdata=1;
}


/*
 * Check for new work
 */
bool haveWorkToDo() {
  if(!USE_SHM) {
    if(newdata) {
      newdata=0;
      return true;
    } else {
      return false;
    }
  }

  bool retVal=false;
  //task PRE amble :
  //continue or start working case
  if( shmFrame->Frame->requested_chirps > 0 ) {
    //check if we need to update image set
    shmFrame->enterMutex();
    if( shmFrame->Frame->isNew ) {
      if(DEBUG) cerr<<"Received new Frame[0] , id = "<<shmFrame->getID()<<endl;
      //overridde dc1394 areas
      dma_buf_rgb=(unsigned char *)shmFrame->getData();
      //commen out below to not enable visuals
      if(DEBUG) cerr<<"Bound new frame ok "<<endl;
      shmFrame->Frame->requested_chirps=0;
      shmFrame->Frame->isNew = false; 
      retVal=true;
    } else {
      cout <<"old frame"<<endl;
    } 
    shmFrame->leaveMutex();
  } 
  else  {
    usleep(500); //sleep for 1ms. should be okay at 33ms/frame
  }
  return retVal;
}

/*
 * If using Shm, wait for a new frame
 */
void render_tracking() {
  if(haveWorkToDo()) {
    render_filter_tracking();
  }
  /*
   * Let other clients read my results.
   * Hand Locations, and Hand Color Values
   */
  if(USE_SHM || standaloneSHM ) {
    //XXX
  }
}

float foo[720*480*4];
/*
 * render to textures actually does the processing
 */
void render_filter_tracking() {
  process_frame_opencv(dma_buf_rgb);

  d->activate_fpbuffer();
  d->clear_fpbuffer();
  d->reinit_texture(0, imageSrcWidth, imageSrcHeight, dma_buf_rgb);
  d->bindTextureARB0(0);
  if( !USE_SHM ) {
    dc1394->tellThreadDoneWithBuffer();
  }

  //cascade the filters
  /*d->applyFilter(filter1, 0,1);//undistort
  d->clear_fpbuffer();
  d->applyFilter(filter2, 1,2,l,r,t,b );//hsv conv + thresh
  d->applyFilter(filter3, 2,3,l,r,t,b );//morpho
  */
  
  d->deactivate_fpbuffer();

  d->bindTextureARB0(viewBufferNumber);
  d->render();

  //optioanlly read back result
  //readback from screen will be different from pbuffer,choo cho choose 
  //glReadPixels(0,0,320,240,GL_RGB,GL_FLOAT,foo); 
  d->showstats();
  glutSwapBuffers();
} 

/*
 * GL idle callback for tracking
 */
void runTrack(){
  render_tracking();

  glutPostRedisplay();
}

/********************
 Create Shm area
********************/
void createSharedMemoryArea(int id) {
  //create shared memory areas, an image pair 0/1 for each head (card)
  int frame0ID = id*2-2;
  assert(id>=0);
  shmFrame = new ShmFrame(frame0ID);
} 


/********************
 * Parse cmd line options
 ********************/
void posixify(int argc, char * argv[]){} //fill in from orbits version

static struct option long_options[] = {
  {"client", 0, 0, 'c'},
  {"verbose", 0, 0, 'v'},
  {"help", 0, 0, 'h'},
  {0,0,0,0}
};

void printHelp()
{
  cout<<"rectrack. "<<endl; 
  cout<<"  when no client id given it uses 1394 input."<<endl;
  cout<<"  when a client id is used, it reads video from that client area"<<endl;
  cout<<"recttrack options:"<<endl;
  cout<<"   -c --client [id]  \t: run this instance as a client, with given id"<<endl;
  cout<<"   -v --verbose      \t: verbose output"<<endl;
  cout<<"   -h --help         \t: print this help message, and quit"<<endl;
  cout<<" Oh, and use -display :0.1 *before* the above options to run on another screen"<<endl;
  cout<<endl;
}

void parse_cmdline(int argc, char **argv)
{
   char c;
   opterr = 0; /* prevent weird options from causing errors */
   posixify(argc,argv);

   while(1) {
     int this_option_optind = optind ? optind : 1;
     int option_index = 0;
     c = getopt_long (argc, argv, "c:hv:",
                      long_options, &option_index);
     if (c == -1) break;
     switch(c) {

     case 'c' :
       client_id = atoi(optarg);
       if( client_id < 0 || client_id > MAX_PCI_HEADS ) {
         cerr<<"Invalid Client ID "<<client_id<<" requested. aborting."<<endl;
         cerr<<"Client ID must lie in closed interval [0,5]"<<endl;
         exit(1);
       }
       cerr<<"Initializing as client ID "<<client_id<<endl;
       USE_SHM=true;
       break;

     case 'v' : //print help
       DEBUG=true; 
       break;

     case 'h' : //print help
       printHelp();
       exit(0);
       break;

     default :
       cerr<<"WARNING: unknown switch "<<c<<endl;
     }

   }
}



///// MAIN ///////////////////
int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   parse_cmdline(argc,argv);

   if( USE_SHM || standaloneSHM) {
     cout <<"creating shm area"<<endl;
     createSharedMemoryArea(client_id);
     cout <<"done creating shm area"<<endl;
   }


   glutSetWindow(Orbwin);
   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);

   if( !USE_SHM ) {
     dc1394=new Dc1394();
     dc1394->start();
   }

   d=new FragPipeDisplay(8, imageWinWidth, imageWinHeight, Orbwin );

   d->initDisplay();
   d->setImageSize( imageWinWidth,imageWinHeight );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-basic.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?

   //d->activate_fpbuffer();
   //initial texture holds raw data, use Src Image size
   d->init_texture(0, imageSrcWidth, imageSrcHeight, foo);

   //subsequent passes use proceesing size (imageWin)
   d->init_texture4f(1, imageWinWidth, imageWinHeight, foo);
   d->init_texture4f(2, imageWinWidth, imageWinHeight, foo);
   d->init_texture4f(3, imageWinWidth, imageWinHeight, foo);
   d->init_texture4f(4, imageWinWidth, imageWinHeight, foo);
   d->init_texture4f(5, imageWinWidth, imageWinHeight, foo);

   filter1 = new GenericFilter(imageSrcWidth,imageSrcHeight, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-ibot-undistort.cg");
   filter2 = new GenericFilter(imageWinWidth,imageWinHeight, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-rgb2hsv.cg");
   //initial saturation guess. 0.6 good for pyro, 0.4 for ibot
   float thresh[4] = {0.030, 0.40, 0.02, 0.12};
   filter2->setCGParameter("thresh", thresh);
   filter3 = new GenericFilter(imageWinWidth,imageWinHeight, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-erode.cg");

   momentFilter = new MomentFilter(imageWinWidth, imageWinHeight, d->getContext(), d->getProfile() );


   glutDisplayFunc(runTrack);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}
