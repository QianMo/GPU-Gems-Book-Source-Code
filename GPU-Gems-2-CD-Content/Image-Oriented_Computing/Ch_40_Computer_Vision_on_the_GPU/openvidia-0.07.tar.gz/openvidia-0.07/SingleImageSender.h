/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _SINGLEIMAGESENDER_H
#define _SINGLEIMAGESENDER_H

// includes
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include <getopt.h>
#include <assert.h>

#include "GenericCapture.h"
#include "Dc1394Capture.h"
#include "Raw1394Capture.h"
#include "ImlibCapture.h"
#include "Parameters.h"
#include "ShmFrame.h"
#include <iostream>
#include <iomanip>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/shape.h>
using namespace std;

// Give komputer 1 pics
// 
class SingleImageSender {
 private:
  SingleImageSender() {
    cerr<<"DO NOT INSTANTIATE SINGELIMAGESENDER NO-ARG CONSTRUCTOR"<<endl;
  }
    

 protected:
  bool m_DEBUG;
  static const int MAX_PCI_HEADS=5;
  int NUM_PCI_HEADS;
  ShmFrame *head;

  // returns true if this image sender is waiting for shmframe to finish
  bool isProcessing();
  
  // returns -1 if the client is not ready
  void query_client();
  
  void client_tasker(int w, int h, int nch, unsigned char *b);
  

 public:
  SingleImageSender(int client_id);
  ~SingleImageSender();
  // for now initial estimate is ignored
  void sendImage(int width, int height, void* b1);
  
};

#endif
