/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "GenericDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"
#include "FragPipeDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include "BoxApp.h"
#include "Correspond.h"
#include <iostream>
#include "demo.h"
using namespace std;

// Global display object
FragPipeDisplay *d;
Dc1394 *dc1394;
ImlibCapture *im;
GenericFilter *filter1, *filter2, *filter3, *filter4;
MomentFilter *momentFilter;
BoxApp *boxApp;
Correspond *corr;
float result[12] = {0,0,0,0,0,0,0,0,0,0,0,0};


int imageWinWidth = theDemo.getWidth();
int viewbuf = 0;
int imageWinHeight =theDemo.getHeight();
Window  Orbwin;

/******************************************************/

/* The number of our GLUT window */
int window; 
float buffer[14776][9];
/* rotation angle for the triangle. */
float rtri = 0.0f;
float Rx=0.0f;
float Ry=0.0f;
//float Rz=1.2f;
float Rz=1.8f;


/*****************************************************/

///global state
bool useImlib = false;



int numClickCorners = 0;

float gl_x=0.0;
float gl_y=0.0;

void reshape(int w, int h);
void myIdle();
void keyboard (unsigned char key, int x, int y);
void MouseFunc( int button, int state, int x, int y) ;
void drawCircleHelper(float x, float y);
void TellRWMHeCanUseImage(const char *dma_buf_) ;
void idleFunc();

unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(320*240*3);
int framecounter=0;
int newdata=0;
float *foo[320*240*4];

double f = 368.28488;
double ox = 147.54834;
double oy = 126.01673;

double imageWidth = (double)imageWinWidth;
double imageHeight = (double)imageWinHeight;

float oxIm;
float oyIm;
float ozIm;
float buffIm[3]={0.0,0.0,0.0};
float XvecX;
float XvecY;
float XvecZ;
float YvecX;
float YvecY;
float YvecZ;
float ZvecX;
float ZvecY;
float ZvecZ;
int mov=0;

void printProjectionMatrix()
{
  float pmatrix[16]={0};
  glGetFloatv( GL_PROJECTION_MATRIX, pmatrix);
  printf("%5f %5f %5f %5f\n", pmatrix[0], pmatrix[4], pmatrix[8], pmatrix[12]);
  printf("%5f %5f %5f %5f\n", pmatrix[1], pmatrix[5], pmatrix[9], pmatrix[13]);
  printf("%5f %5f %5f %5f\n", pmatrix[2], pmatrix[6], pmatrix[10], pmatrix[14]);
  printf("%5f %5f %5f %5f\n", pmatrix[3], pmatrix[7], pmatrix[11], pmatrix[15]);
}


void render_redirect() {
int i,j;

  ++framecounter;
     if( useImlib )  {
       d->reinit_texture(0, 320, 240, im->getRGBData() );
     }
//      else {
//      d->reinit_texture(0, 320, 240, dma_buf_rgb);
//      }
//    d->bindTextureARB0(0);
//     if (!useImlib) dc1394->tellThreadDoneWithBuffer();
// 
//     //cascade the filters
// 
//     d->applyFilter(filter1, 0,1 ,
//                    -ox, (((double)imageWidth)-ox), 
//                    (((double)imageHeight)-oy), -oy )  ;


  gl_x = oxIm;
  gl_y = oyIm;
  //centers on right click position in cameragl system
  glMatrixMode(GL_MODELVIEW);
  glClear(GL_DEPTH_BUFFER_BIT);
  glLoadIdentity();

  oxIm = result[0];
  oyIm = result[1];
  ozIm = result[2];
  XvecX = result[3];
  XvecY = result[4];
  XvecZ = result[5];
  YvecX = result[6];
  YvecY = result[7];
  YvecZ = result[8];
  ZvecX = result[9];
  ZvecY = result[10];
  ZvecZ = result[11];
  float scalef = 100.0;

  glMatrixMode(GL_MODELVIEW);
  glClear(GL_DEPTH_BUFFER_BIT);
   glLoadIdentity();
//   
	glTranslatef(Rx,Ry-0.3,Rz);//-0.3 because the raw file doesn't have a good center
	 //glTranslatef(0.0,0.0,0.0);//-0.3 because the raw file doesn't have a good center
	 
	//glRotatef(rtri,scalef*ZvecX, scalef*ZvecY,scalef*ZvecZ);
	float Matrice[]={XvecX,XvecY,XvecZ,0,ZvecX,ZvecY, ZvecZ,0,-YvecX,-YvecY,-YvecZ,0,0,0,0,1}; //matrice used for transposition glMultMatrix 
	
	//glMultMatrixf(Matrice);
	//glTranslatef(0,-0.3,0);
	//gluLookAt(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
				//gluLookAt(eyex, eyey, eyez,centerx, centery, centerz,upx, upy, upz)
 
//  glBegin(GL_TRIANGLES);
//	//glColor3f(0.0f,1.0f,0.0f);			// Set The Color To green
// 	for (i=0;i<14776;i++){
////  		glColor3f(0.0, 1.0, 0.0);		// Set The Color To green
// 		for(j=0;j<9;j+=3){
//		glColor3f(1.0f,0.0f,0.0f);			// Set The Color To green
// 		glVertex3f(buffer[i][j],buffer[i][j+1],buffer[i][j+2]);		        // Top of triangle (front)
//
//		}
// 	 }
//
//  glEnd();
           theDemo.onRender(mov);

  //glutSwapBuffers();
}  


///// MAIN ///////////////////

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   
    if(!theDemo.onCreate(argc, argv))
  {
    std::cerr << "Creation of the demo failed." << std::endl;
    return -1;
  }
//    LoadValue("alienman.blend.raw");

   //if an argument is given, assume we are using an image file
   if( argc == 2 ) { 
     cout<<"Using image file: "<<argv[1]<<endl;
     cout<<"Note: currently, image file must be 320x240 resolution"<<endl;
     useImlib = true;
   }
   else {
     useImlib = false;
   }
   
   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(theDemo.getWidth(),theDemo.getHeight());
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);

   corr = new Correspond(imageWinWidth, imageWinHeight );

   //typical problem : can't open imlib without display, yet cant
   // size display without loading image from imlib
   d=new FragPipeDisplay(8, imageWinWidth, imageWinHeight, Orbwin );
   d->initDisplay();

   d->setImageSize( 320,240 );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-basic.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?
   if( useImlib ) { 
     im = new ImlibCapture(0,0);
     im->initCapture(d);
     im->loadFile(argv[1]); 
     assert( im->getRGBWidth() == imageWinWidth );
     assert( im->getRGBHeight() == imageWinHeight );
   }
   else {
     dc1394=new Dc1394();
     dc1394->start();
   }


   //d->activate_fpbuffer();
   d->init_texture(0, 320, 240, foo);
   d->init_texture4f(1, 320, 240, foo);
   d->init_texture4f(2, 320, 240, foo);
   d->init_texture4f(3, 320, 240, foo);
   d->init_texture4f(4, 320, 240, foo);
   d->init_texture4f(5, 320, 240, foo);

   filter1 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-ibot-undistort.cg");
   filter2 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-rgb2hsv.cg");
   float thresh[4] = {0.020, 0.60, 0.02, 0.10};
   filter2->setCGParameter("thresh", thresh);
   filter3 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-erode-optim.cg");

   momentFilter = new MomentFilter(320,240, d->getContext(), d->getProfile() );

   boxApp = new BoxApp();

   glClearColor(1.0,0.0,0.0,0.0);
  glColor3f(1.0,0.0,0.0);
  glPointSize(2.0);

//MotionFunction- anything special here?
//Passive Function- same...

   glutSetWindow(Orbwin);   
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   
    // initialize our demo instance
  if(!theDemo.onInit())
  {
    std::cerr << "Initialization of the demo failed." << std::endl;
    return -1;
  }
   glutMainLoop();
   
   return 0; 
}

void idleFunc()
{
  // redirect to the demo instance
  theDemo.onIdle();
}


////////////////////
////// GLUT CALLBACKS ///////////////
////////////////////
void reshape(int w, int h)
{ //theDemo.setDimension(w, h);
  glutSetWindow(Orbwin);

  glClearColor (01.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  glFrustum(  (((double)imageWidth)-(320.0-ox))/f, -(320.0-ox)/f ,
              (((double)imageHeight)-oy)/f, -oy/f, 
    //          -oy/f, (((double)imageHeight)-oy)/f, 
                f/f,  (f+1000) )  ;

  printProjectionMatrix();
  gluLookAt( 0.0,0.0,0.0,  0,0, f,   0.0,  1.0, 0.0);
  printProjectionMatrix();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
 
  
}


void myIdle(){
  //glutSetWindow(Orbwin);
  //glutPostRedisplay();
  theDemo.onIdle();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
         viewbuf = atoi((const char * )&key);
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case 27:
         theDemo.onShutdown();
         exit(0);
         break;
	 
	 /****TRANSLATION**************/
	case 'Q':
		Rx-=1.0f;
		break;
	case 'q':
		Rx-=0.1f;
		break;
	case 'W':
		Rx+=1.0f;
		break;
	case 'w':
		Rx+=0.1f;
		break;
	case 'E':
		Ry+=1.0f;
		break;
	case 'e':
		Ry+=0.1f;
		break;
	case 'D':
		Ry-=1.0f;
		break;
	case 'd':
		Ry-=0.1f;
		break;
	/****ZOOM**************/
	case 'Z':
		Rz+=1.0f;
		break;
	case 'z':
		Rz+=0.1f;
		break;
	case 'X':
		Rz-=1.0f;
		break;
	case 'x':
		Rz-=0.1f;
		break;
	/****ROTATION**************/	
	case '+':
      rtri+=5.0f;	
      glutPostRedisplay();
	break;
    case '-':
      rtri-=5.0f;	
      glutPostRedisplay();
	break;
    case 'm':
      if(mov!=2)mov++;
      else mov=0;
      break;
	
	default:
		break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        float pixbuf[4] = {0.0};
        cerr << "("<<x<<","<<y<<"):";
        glReadPixels( (float)x,240.0-(float)y, 1,1, GL_RGBA, GL_FLOAT,  pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
        corr->add_point(x,y); 
        numClickCorners++;
        if( numClickCorners%4==0 )  {
          int points[8];
          corr->get_points(points);
          cerr<<"points: "<<points[0]<<" "
                          <<points[1]<<" "
                          <<points[2]<<" "
                          <<points[3]<<" "
                          <<points[4]<<" "
                          <<points[5]<<" "
                          <<points[6]<<" "
                          <<points[7]<<endl;
           char cmdstr[1024];
           //sprintf(cmdstr, "./fuckyou.m %d %d %d %d %d %d %d %d > numbers.txt", points[0], points[1], points[2], points[3], points[4], points[5], 
//points[6], points[7]);
           sprintf(cmdstr, "./planarCoords.m %d %d %d %d %d %d %d %d > numbers.txt", points[0], points[1], points[2], points[3], points[4], points[5], 
points[6], points[7]);
           system(cmdstr);
           FILE *fp = fopen("numbers.txt", "r");
           fscanf(fp, "%f %f %f %f %f %f %f %f %f %f %f %f", &result[0],
                  &result[1], &result[2], &result[3], &result[4],
                  &result[5], &result[6], &result[7], &result[8],
                  &result[9], &result[10], &result[11] );
           cerr<<"result = "<<result[0]<<" "<<
                 result[1]<<" "<<result[2]<<" "<<
                 result[3]<<" "<<result[4]<<" "<<
                 result[5]<<" "<<result[6]<<" "<<
                 result[7]<<" "<<result[8]<<" "<<
                 result[9]<<" "<<result[10]<<" "<<
                 result[11]<<endl;
           fclose(fp);
         }
      }
      break;
    case GLUT_RIGHT_BUTTON : 
     cerr<<"Mouse click, image raster coord: "<<x<<" "<<y<<endl;
     gl_x = ((float)(double)x-ox);
     gl_y = ((float)(double)y-oy); 


      break;
  }
}



/* coords are normalized */
void drawCircleHelper(float x, float y) {
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glColor4f(0.0,0.0,1.0,1.0);
  glPointSize(10.0); //XXX move away.
  //cerr<<"X = "<<HAND_X_COORD<< "  Y="<<HAND_Y_COORD<<endl;
  //cerr<<"X = "<<HAND_X_COORD/320.0<< "  Y="<<HAND_Y_COORD/240.0<<endl;
  glClear(GL_DEPTH_BUFFER_BIT);
  glBegin(GL_POINTS);
  //  glVertex3f(x, y,   1.0 );
    glVertex3f(x, y,   -1.0 );
  glEnd();
}

/* Tell function executed in context of Dc1394 thread */
void TellRWMHeCanUseImage(const char *dma_buf_) {
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;

  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;
  uyvy2rgb(dma_buf,dma_buf_rgb,320*240);

  //have only one, need two before we do any orbits
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }

  newdata=1;
}

