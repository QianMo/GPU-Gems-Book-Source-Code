/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _CORRESPOND_H
#define _CORRESPOND_H


class Correspond {
  private: 
    int width, height;
    int selected_points[8];
    int *points_array_ptr, *last_pos;
    bool has_points;
  public:
    Correspond(int width, int height);
    void add_point(int w, int h);
    void clear_points();
    bool hasPoints();
    void get_points(int *);
   
    int get_left_side();
    float get_left_side_normalized();
    int get_right_side();
    float get_right_side_normalized();
    int get_top_side();
    float get_top_side_normalized();
    int get_bottom_side();
    float get_bottom_side_normalized();
   
    void drawCropLines();
    void drawCropLines(int, int);
    void drawQuad();
    void drawQuad(int,int);

    void render_cropped_texture(int,int);
   
    void drawMaskingQuad(float,float,float,float);
    void getQuadCorners(int cropW, int cropH, float* leftCrop, float* rightCrop, float* topCrop, float* bottomCrop);
    void getCropParams(int cropW, int cropH, int *x, int *y, int *w, int *h);
    void shell_Corr2p(double *);
};

#endif
