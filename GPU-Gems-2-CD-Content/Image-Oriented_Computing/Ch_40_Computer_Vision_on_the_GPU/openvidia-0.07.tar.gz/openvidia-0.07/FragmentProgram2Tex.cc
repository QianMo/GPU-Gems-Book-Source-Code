/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "FragmentProgram2Tex.h"
using namespace std;
#include <iostream>


FragmentProgram2Tex::FragmentProgram2Tex( CGcontext fContext, 
                                       CGprofile fProfile, 
                                       char *FPname, 
                                       GLuint texName1,
                                       GLuint texName2 ) : 
FragmentProgram(fContext,fProfile,FPname,texName1)
{
/*
  cerr << "Loading Program [ " << FPname << " ] ";
  FP = cgCreateProgramFromFile(fContext,
                               CG_SOURCE, FPname,
                               fProfile, "FragmentProgram2Tex", 0);
  cgGLLoadProgram(FP);
  FPtexCoord = cgGetNamedParameter(FP, "fptexCoord");
  FPtexture = cgGetNamedParameter(FP, "FPE1");
  cgGLSetTextureParameter(FPtexture, texName2);
  BoundtexName = texName2;
  cerr << "[ok]" << endl;
  isActive = 0;
  FPprofile = fProfile;
*/
  FPtexCoord2 = cgGetNamedParameter(FP, "fptexCoord2");
  FPtexture2 = cgGetNamedParameter(FP, "FPE2");
  cgGLSetTextureParameter(FPtexture2, texName2);
}

void FragmentProgram2Tex::activate()
{
  cgGLSetTextureParameter(FPtexture, BoundtexName);
  cgGLEnableClientState(FPtexCoord);
  cgGLEnableClientState(FPtexCoord2);
  cgGLEnableProfile(FPprofile);
  cgGLBindProgram(FP);
  isActive = 1;
}

void FragmentProgram2Tex::deactivate()
{
  cgGLDisableProfile( FPprofile );
  isActive = 0;
}

