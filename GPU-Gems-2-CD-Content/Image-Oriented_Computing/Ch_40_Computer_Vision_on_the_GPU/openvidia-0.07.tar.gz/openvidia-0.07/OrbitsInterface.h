/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _ORBITSINTERFACE_H
#define _ORBITSINTERFACE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mat_util.h"
#include "motion.h"
#include "est_pseudo.h"

#ifdef __cplusplus
}
#endif

class OrbitsInterface {
 protected:
	 int m_DEBUG;
  Var **Dts, **Dms, **Dns, *DERIVATIVES, *Derivatives;
  Var *parameters;  //working pairwise parameters
  Var *pcomposed; //composed current parameters
  Var *prev_pcomposed; //composed current parameters
  int M,N,channels; //M,N fullsize
  int downsample_levels; //number of downsamples levels (0=full only)
  void setParams( Var *p, Data *params );
 public:
  OrbitsInterface(int,int,int);
  void setDebug(int i) {m_DEBUG=i;};
  //sets Dt<-Red, Dm<-Green, Dn<-Blue
  void SetDerivatives( float *derivativesImage, int M, int N );
  void setder( int index, float value );
  void resetParams();
  void setDER( int index, float value );
  void solve_system(int);
  void pseudo_estimate( int level );
  void setDt(int level, Data *dtbuffer);
  void setDm(int level, Data *dmbuffer);
  void setDn(int level, Data *dnbuffer);
  float *getParameters(float x[8]);
  double *getParameters(double x[8]);
  int getMaxDownsample_levels() { return downsample_levels; };
  void getDER(float *b);
  void setStartParams( double *params );
};

#endif

