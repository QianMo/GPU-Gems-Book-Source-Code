/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

void FragmentProgram(
    in float2 fptexCoord : TEXCOORD0,
    out float4 colorO       : COLOR0,
    const uniform samplerRECT FPE1 )
{
   int i=0;
   colorO = float4(0.0, 0.0, 0.0, 0.0);
   float4 samp = texRECT(FPE1,fptexCoord);
   //texture coordinates offset by 0.5 
   float m = 240-fptexCoord.y-0.5;
   float n = fptexCoord.x-0.5;
   //render to texture swizzles the components
   float Dt = samp.x;
   float Dn = samp.y;
   float Dm = samp.z;

    float mmDm = m*m*Dm;
    float mnDn = m*n*Dn;
    float mmDm_plus_mnDn = mmDm + mnDn;
    float4 a = { mmDm_plus_mnDn, m*Dm, n*Dm,  Dm};
    float4 b = { mmDm_plus_mnDn, mmDm_plus_mnDn, mmDm_plus_mnDn, mmDm_plus_mnDn};
    colorO =  samp*samp;
    //colorO = float4( m*Dm*m*Dm, n*Dm*m*Dm,m*Dm*Dm,0.0 );
//    colorO = float4( m*Dt*m*Dt, m*Dt*Dt, n*Dt*m*Dt,0.0 );
    //colorO = float4(m,n,1.0,1.0);
    
}
