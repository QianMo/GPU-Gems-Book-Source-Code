/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _PARAMETERS_H
#define _PARAMETERS_H

#ifdef __cplusplus
extern "C" {
#endif
#include "mat_util.h"
#include "pinverse.h"
#include "motion.h" //for pcompose
#ifdef __cplusplus
}
#endif

class Parameters {
  private :
    Data parray[8];
    void makeVar( Var *, Data * );
    float chirpmat[16]; //GL style matrix, column ordered in memory
    float support;
  public :
    //i make these public so they are easy to read out
    Data a11, a12, b1, a21, a22, b2, c1, c2;

    Parameters(Data a11in=1.0, Data a12in=0.0, Data b1in=0.0, Data a21in=0.0,
               Data a22in=1.0, Data b2in=0.0, Data c1in=0.0, Data c2in=0.0);
    void setIdentity();
    void set(Data a11in=1.0, Data a12in=0.0, Data b1in=0.0, Data a21in=0.0,
             Data a22in=1.0, Data b2in=0.0, Data c1in=0.0, Data c2in=0.0 );
    void set(Data *);
    void invert();
    void print();
    void apply(Data x, Data y, Data *newx, Data *newy);
    void apply(Data *newx, Data *newy);
    Data *get();
    void compose(Parameters P);
    float *getAsChirpMat();
    float getVariance();
    float getNorm();
 
    Parameters operator*(Parameters P);
    void setSupport(float );
    float getSupport();
  
};
#endif
