/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "GenericFilter.h"
#include <iostream>

using namespace std;


GenericFilter::GenericFilter( 
			              ///Image Width
			              int w, 
					  ///Image Height
                            int h,
					  ///Current CG context
                             CGcontext fContext,
					  ///Current CG profile
                             CGprofile fProfile , 
					  ///Fragment Program name to be applied
                             char *FPname )
{

  width = w;
  height= h;
  FP = new FragmentProgram( fContext, fProfile, FPname, 0);
}


///Set the programs named paramter to the value.
///Make sure your array of values is right size. 
void GenericFilter::setCGParameter(char *name, float *value )
{
  CGparameter cgp = cgGetNamedParameter(FP->FP, name);
  cgGLSetParameter4fv(cgp, value);
}
void GenericFilter::setCGParameter(char *name, double *value )
{
  CGparameter cgp = cgGetNamedParameter(FP->FP, name);
  cgGLSetParameter4dv(cgp, value);
}


///Set the programs named paramter to the value.
///Make sure your array of values is right size. 
void GenericFilter::setCGParameter4x4(char *name, float *value )
{
  CGparameter cgp = cgGetNamedParameter(FP->FP, name);
  cgGLSetMatrixParameterfc(cgp, value);
}


///Apply this filter to the given texture 
void GenericFilter::applyFilter( GLuint textureID ) {
  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;

  drawFilterQuad(textureID, 0.0, 1.0, 0.0, 1.0);
  //drawFilterQuad(textureID, 0.25, 1.0, 0.25, 1.0);
/*
  glClear(GL_DEPTH_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture( GL_TEXTURE_RECTANGLE_NV, textureID );

  glClearColor(0.0,0.0,0.0,0.0);

  FP->activate();
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, (float)height, dist);
    //glVertex3f( origin, origin+texheight, texdist);
    glVertex3f( origin, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 0.0, dist);
    //glVertex3f( origin, origin, texdist);
    glVertex3f( origin, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,(float)width, 0.0, dist);
    //glVertex3f( origin+texwidth, origin, texdist);
    glVertex3f( origin+texwidth, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,(float)width, (float)height, dist);
    //glVertex3f( origin+texwidth, origin+texheight, texdist);
    glVertex3f( origin+texwidth, origin, texdist);
  glEnd();
  FP->deactivate();
*/
}

///clips to [0,1] float.   0->1 is going up to down ,or left to right
float clip( float x) {
  if( x > 1.0 ) x=1.0;
  if( x < 0.0 ) x=0.0;
  return x;
}

void GenericFilter::applyFilter( GLuint textureID,
                                 float left, float right,
                                 float top, float bottom ) 
{
  drawFilterQuad( textureID, left,right,top,bottom );
}

void GenericFilter::drawFilterQuad( GLuint textureID,
                                 float left, float right,
                                 float top, float bottom ) 
{

  glClear(GL_DEPTH_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture( GL_TEXTURE_RECTANGLE_NV, textureID );

  glClearColor(0.0,0.0,1.0,1.0);
  glClear(GL_COLOR_BUFFER_BIT);


  float tleft = 0;
  float tright = width;
  float ttop = height;
  float tbottom  = 0;
//  float texdist = -1.0;
  float texdist =  368.28488;
  float dist = 0.0;

  FP->activate();
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,tleft, ttop, dist);
    glVertex3f( left, top, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,tleft, tbottom, dist);
    glVertex3f( left, bottom, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,tright, tbottom, dist);
    glVertex3f( right, bottom, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,tright, ttop, dist);
    glVertex3f( right, top, texdist);
  glEnd();
  FP->deactivate();
}
