/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _RAW1394_CAPTURE_H
#define _RAW1394_CAPTURE_H

#include "GenericCapture.h"
#include "GenericDisplay.h"
#include <cc++2/cc++/thread.h>
//#include <thread.h>
       #include <cc++/config.h>
       #include <cc++/exception.h>
       #include <pthread.h>
       #include <semaphore.h>
       #include <time.h>
       #include <signal.h>
      #include <unistd.h>


#include <libraw1394/raw1394.h>
#include <libdc1394/dc1394_control.h>
#include <stdlib.h>
using namespace std;
using namespace ost;


class Raw1394Capture : public GenericCapture, public Thread, public Mutex
{  
 protected:
  const static int DefaultCaptureWidth=320;
  const static int DefaultCaptureHeight=240;
  dc1394_cameracapture camera;
  raw1394handle_t handle;
  void *v1394_uyvy_buf;
  void *v1394_rgb_buf;
  void *v1394_rgb_buf_previous_frame;
  
  unsigned char clip(float pixel_val);
  void Raw1394Capture :: UYVYtoRGB24(unsigned char *s, unsigned char *d, 
                                     int width, int heigth);
 
  
 public:
  unsigned int gainval;
  nodeid_t * camera_nodes;
  Raw1394Capture();
  ~Raw1394Capture();
  void initCapture(GenericDisplay *d);
  void advanceFrame();
  void releaseCap();
  void* getRGBDataPreviousFrame();
  void* getRGBData();
  int getRGBWidth();
  int getRGBHeight();
  void run();
//        void final()
  int get_gain();


};

#endif

