/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "EigenDisplay.h"
#include <assert.h>
#include "nvidia.h"
#include "FragmentProgram.h"

#include <Cg/cgGL.h>
#include <glh/glh_extensions.h>

#include <iostream>
using namespace std;

extern CGparameter E1Texture, E2Texture, someColor, E2texCoord,E1texCoord, colorO, xincrementParam, yincrementParam;
extern CGprofile vProfile;
extern CGprogram fragmentProgram;
extern CGcontext vContext;
float b[320*240*4*8];

EigenDisplay::EigenDisplay(int num_textures, int imageWinWidth, 
                           int imageWinHeight, int win) :
    MultitextureDisplay(num_textures, imageWinWidth, 
                        imageWinHeight, win)
{
  listName = 1;
  glClearColor(0.0, 0.0, 1.0, 1.0);
 
  
 // glShadeModel(GL_FLAT);   //no diff
 // glEnable(GL_CULL_FACE); //no diff
 // glEnable(GL_DEPTH_TEST); //no diff
/*
  glDisable(GL_CULL_FACE);
  glDisable(GL_DEPTH_TEST);
*/
}
  static float readback[30*4*4] = {0.0,0.0,0.0,0.0};
void printPixel(int x, int y, int n) 
{
  
  glReadPixels(x,y,n,1,GL_RGBA,GL_FLOAT, readback);

  //cerr<<"readback["<<x<<"]["<<y<<"]= "<<readback[0]<<", "<<readback[1]<<", ";
  //cerr<<readback[2]<<", "<<readback[3]<<endl;


  assert(readback[3] == 307200);
}
void printPixel(int x, int y) 
{
  
  glReadPixels(x,y,1,1,GL_RGBA,GL_FLOAT, readback);

  cerr<<"readback["<<x<<"]["<<y<<"]= "<<readback[0]<<", "<<readback[1]<<", ";
  cerr<<readback[2]<<", "<<readback[3]<<endl;


  //assert(readback[3] == 307200);




}

void EigenDisplay::init_FP_summation(char *FPname, char *FPname2 )
{
  FP_summation = new FragmentProgram(vContext, vProfile, FPname, texNames[0]);
  FP_sum2 = new FragmentProgram(vContext, vProfile, FPname2, texNames[0]);
}

static void texCoord( float x, float y, float z)
{
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,x,y,z);
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,x,y,z);
    glMultiTexCoord3fARB(GL_TEXTURE2_ARB,x,y,z);
    glMultiTexCoord3fARB(GL_TEXTURE3_ARB,x,y,z);
    glMultiTexCoord3fARB(GL_TEXTURE4_ARB,x,y,z);
}


void EigenDisplay::draw_quad_folded_16tex( int dist,
                                    float texwidth,
                                    float texheight,
                                    float origin, 
                                    float texdist ) 
{
  texheight = texheight/4.0;
  texwidth = texwidth/4.0;
  glBegin(GL_QUADS);
    texCoord(0.0,ImageHeight/4,dist);
    glVertex3f( origin, origin+texheight, texdist);

    texCoord(0.0, 0.0, dist); 
    glVertex3f( origin, origin, texdist);

    texCoord(ImageWidth/4, 0.0, dist); 
    glVertex3f( origin+texwidth, origin, texdist);

    texCoord(ImageWidth/4, ImageHeight/4, dist); 
    glVertex3f( origin+texwidth, origin+texheight, texdist);
  glEnd();
}

///Take current read_buffer(screen or floating point buffer) 
///and split it up, into 16 pieces, and put those
///16 pieces into 16 texture image units, each of which is 1/16 the size of
///the original image.  The copies are put in 16 texture id array,
///starting a split_tex[0] , so pass in an array location or texture IDs
///The blocks are scanned into ARBS in raster order (L/R, U/D)
void EigenDisplay::quarter_quad(int start_tex, 
                                int winWidth, 
                                int winHeight)
{
  ////XXX can this be optimized with a single copytexsubimage then just
  //// bind it to all the texture image units, and use the texcoord arb to
  //// specificy geometry:  pros: less copyxtexsubimage repetitions - probably
  ////   less CPU overhead
  //// cons: copytexsubimage on whole image may stall pipe?  
  ////   over-uses memory - each arb holds more data then it actually uses -
  ////  is this optimized by the GPU though? - can it intelligently cut out
  ////  segments?
  GLuint *split_tex = &texNames[start_tex];
  int Xblock = (int)(winWidth/4.0);
  int Yblock = (int)(winHeight/4.0); 
  //remember the reading occurs in inverse Y axis (0 is bottom)
  //First row of 4 blocks into first 4 ARBS
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, split_tex[0]);
  glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0, 
                       0,0, Xblock, Yblock);
  glActiveTextureARB(GL_TEXTURE1_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, split_tex[1]);
  glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0, 
                       Xblock, 0, Xblock, Yblock);
  glActiveTextureARB(GL_TEXTURE2_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, split_tex[2]);
  glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0, 
                       2*Xblock, 0, Xblock, Yblock);
  glActiveTextureARB(GL_TEXTURE3_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, split_tex[3]);
  glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0, 
                       3*Xblock, 0, Xblock, Yblock);
  glActiveTextureARB(GL_TEXTURE3_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, split_tex[3]);

  //second row
  glActiveTextureARB(GL_TEXTURE4_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, split_tex[4]);
  glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0, 
                       0*Xblock, Yblock, Xblock, Yblock);

  errcheck();

}

void EigenDisplay::bindTexture(int a, int b, int c, int d, int e) 
{
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[a]);
  glActiveTextureARB(GL_TEXTURE1_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[b]);
  glActiveTextureARB(GL_TEXTURE2_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[c]);
  glActiveTextureARB(GL_TEXTURE3_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[d]);
  glActiveTextureARB(GL_TEXTURE4_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[e]);
}
void EigenDisplay::bindTexture0to3(int id) {
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE1_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE2_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE3_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);


}
void EigenDisplay::bindTexture4to7(int id) {
  glActiveTextureARB(GL_TEXTURE4_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE5_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE6_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE7_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
}
void EigenDisplay::bindTexture8to11(int id) {
  glActiveTextureARB(GL_TEXTURE8_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE9_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE10_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE11_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
}
void EigenDisplay::bindTexture12to15(int id) {
  glActiveTextureARB(GL_TEXTURE12_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE13_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE14_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glActiveTextureARB(GL_TEXTURE15_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
}




void EigenDisplay::render_quartered() {
  glMatrixMode(GL_MODELVIEW);  
  glLoadIdentity();

  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;
  texwidth = texwidth/powf(2.0, downsample_level);
  texheight = texheight/powf(2.0, downsample_level);

  cgGLEnableProfile(vProfile);
  FPSimple->activate();
  //these bind textures seem to matter which buffer is active currently
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[16]);
  draw_quad_folded_16tex(dist, texwidth, texheight, origin,texdist);
  cgGLDisableProfile( vProfile );
  FPSimple->deactivate();
  errcheck();
}

void quad_TexCoord_ul(int ImW, int ImH, int dist, int imshift, int imYshift) {
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0,ImH,dist);
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,ImW/2,ImH,dist);
    glMultiTexCoord3fARB(GL_TEXTURE2_ARB,0.0,ImH/2,dist);
    glMultiTexCoord3fARB(GL_TEXTURE3_ARB,ImW/2,ImH/2,dist);
    glMultiTexCoord3fARB(GL_TEXTURE4_ARB,0.0+imshift,ImH,dist);

    glMultiTexCoord3fARB(GL_TEXTURE5_ARB,ImW/2+imshift/2,ImH,dist);
    glMultiTexCoord3fARB(GL_TEXTURE6_ARB,0.0+imshift,ImH/2,dist);
    glMultiTexCoord3fARB(GL_TEXTURE7_ARB,ImW/2+imshift,ImH/2,dist);
}

void quad_TexCoord_ll(int ImW, int ImH, int dist, int imshift, int imYshift) {
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, ImH/2, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,ImW/2, ImH/2, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE2_ARB,0.0, 0.0, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE3_ARB,ImW/2, 0.0, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE4_ARB,0.0+imshift, ImH/2, dist); 

    glMultiTexCoord3fARB(GL_TEXTURE5_ARB,ImW/2+imshift, ImH/2, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE6_ARB,0.0+imshift, 0.0, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE7_ARB,ImW/2+imshift, 0.0, dist); 
}
void quad_TexCoord_lr(int ImW, int ImH, int dist, int imshift, int imYshift) {
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,ImW/2, ImH/2, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,ImW, ImH/2, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE2_ARB,ImW/2, 0.0, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE3_ARB,ImW, 0.0, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE4_ARB,ImW/2+imshift, ImH/2, dist); 

    glMultiTexCoord3fARB(GL_TEXTURE5_ARB,ImW+imshift, ImH/2, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE6_ARB,ImW/2+imshift, 0.0, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE7_ARB,ImW+imshift, 0.0, dist); 
}

void quad_TexCoord_ur(int ImW, int ImH, int dist, int imshift, int imYshift ) {
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,ImW/2, ImH, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,ImW, ImH, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE2_ARB,ImW/2, ImH/2, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE3_ARB,ImW, ImH/2, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE4_ARB,ImW/2+imshift, ImH, dist); 

    glMultiTexCoord3fARB(GL_TEXTURE5_ARB,ImW+imshift, ImH, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE6_ARB,ImW/2+imshift, ImH/2, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE7_ARB,ImW+imshift, ImH/2, dist); 
}
/*
void EigenDisplay::makeDisplayList(int ImW, int ImH, int cols, int rows) 
{
  int dist=0, j=0;
  
  float texwidth = 1/(4.0*20.0); 
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;
  ///multiple of 0.375
  ///epsilon shift , sampling at 0.5 pix.  need shift?
 // float eps=-0.00075*2; 
  float eps=0.0000; 

  glNewList( listName, GL_COMPILE);
  glMatrixMode(GL_MODELVIEW);  
  glLoadIdentity();
  //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glBegin(GL_QUADS);
    for(int i=0 ; i<cols; i++ ) { 
        float xshift = texwidth/2.0*i;
        int imshift = ImW/4*i;
        int imYshift = ImH*j;
        quad_TexCoord_ul( ImW/4, ImH, dist , imshift, imYshift);
        glVertex3f( origin-eps+xshift, origin+texheight/2.0, texdist);

        quad_TexCoord_ll( ImW/4, ImH, dist, imshift, imYshift);
        glVertex3f( origin-eps+xshift, origin, texdist);

        quad_TexCoord_lr( ImW/4, ImH, dist, imshift, imYshift );
        glVertex3f( origin-eps+texwidth/2.0+xshift, origin, texdist);

        quad_TexCoord_ur( ImW/4, ImH, dist, imshift, imYshift );
        glVertex3f( origin-eps+texwidth/2.0+xshift,  
                    origin+texheight/2.0, texdist);
    }
  glEnd();
  glEndList();

  glNewList(sumListName, GL_COMPILE);
  glClear(GL_COLOR_BUFFER_BIT);
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB( GL_TEXTURE0_ARB, 0, ImH, dist ); 
    glVertex3f( origin - eps , origin + 1.0/((float)ImH), texdist);

    glMultiTexCoord3fARB( GL_TEXTURE0_ARB, 0, ImH/2.0, dist ); 
    glVertex3f( origin-eps, origin, texdist);

    glMultiTexCoord3fARB( GL_TEXTURE0_ARB, ImW/20/4/2*cols, ImH/2.0,dist ); 
    glVertex3f( origin-eps+texwidth/4.0*cols, origin, texdist);

    glMultiTexCoord3fARB( GL_TEXTURE0_ARB, ImW/20/4/2*cols, ImH, dist ); 
    glVertex3f( origin-eps+texwidth/4.0*cols, origin+1.0/((float)ImH),texdist);
  glEnd();
  glEndList();
}
*/


void drawFullQuad(int W, int H) 
{  

  int dist=0;
  float texwidth = 1.0; 
  float texheight = 1.0;
  //float texheight = 1.0/16.0;

  float origin = 0.0;
  float texdist=-1.0;

  //float eps=-0.00075; ///epsilon shift , sampling at 0.5 pix.  need sfhit?
  float eps=-0.0000; ///epsilon shift , sampling at 0.5 pix.  need sfhit?
 
  glBegin(GL_QUADS);
   glMultiTexCoord3fARB(GL_TEXTURE0_ARB, 0.0, H, dist);
   glMultiTexCoord3fARB(GL_TEXTURE1_ARB, 0.0, H, dist);
   glMultiTexCoord3fARB(GL_TEXTURE2_ARB, 0.0, H, dist);
   glMultiTexCoord3fARB(GL_TEXTURE3_ARB, 0.0, H, dist);
   glMultiTexCoord3fARB(GL_TEXTURE4_ARB, 0.0, H, dist);
   glVertex3f( origin, origin+texheight, texdist);

   glMultiTexCoord3fARB(GL_TEXTURE0_ARB, 0.0, 0.0, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE1_ARB, 0.0, 0.0, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE2_ARB, 0.0, 0.0, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE3_ARB, 0.0, 0.0, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE4_ARB, 0.0, 0.0, dist); 
   glVertex3f( origin, origin, texdist);

   glMultiTexCoord3fARB(GL_TEXTURE0_ARB, W, 0.0, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE1_ARB, W, 0.0, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE2_ARB, W, 0.0, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE3_ARB, W, 0.0, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE4_ARB, W, 0.0, dist); 
   glVertex3f( origin+texwidth/4.0, origin, texdist);

   glMultiTexCoord3fARB(GL_TEXTURE0_ARB, W, H, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE1_ARB, W, H, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE2_ARB, W, H, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE3_ARB, W, H, dist); 
   glMultiTexCoord3fARB(GL_TEXTURE4_ARB, W, H, dist); 
   glVertex3f( origin+texwidth/4.0, origin+texheight, texdist);
  glEnd();


}
 
void EigenDisplay::makeDisplayList(int W, int H ) {
  float eps = 0;
  int dist=0;
  float texwidth = 1.0; 
  float texheight = 1.0;

  float origin = 0.0;
  float texdist=-1.0;


  for(int  i = 0 ; i< 16; i++ ) {
    float xoffset = i*1.0/640.0+160.0/640.0;
    glNewList(projList[i] , GL_COMPILE);
      //FP_sum2->bind(); 
      glBegin(GL_QUADS);
        glMultiTexCoord3fARB( GL_TEXTURE0_ARB, 0, H, dist ); 
        glVertex3f( origin+xoffset, origin + 1.0/480, texdist);
  
        glMultiTexCoord3fARB( GL_TEXTURE0_ARB, 0, H, dist ); 
        glVertex3f( origin-eps+xoffset, origin, texdist);
  
        glMultiTexCoord3fARB( GL_TEXTURE0_ARB, W/4, H,dist ); 
        glVertex3f( origin-eps+xoffset+ 1.0/640.0, origin, texdist);
  
        glMultiTexCoord3fARB( GL_TEXTURE0_ARB, W/4, H, dist ); 
        glVertex3f( origin-eps+xoffset+ 1.0/640.0, origin + 1.0/480, texdist);
    glEnd();
    glEndList();
  }



  glNewList(listName, GL_COMPILE);
    FPSimple->bind();
    drawFullQuad(W,H);

    render_to_texture( 5, 0, 0, ImageWidth/4, ImageHeight);

    FP_summation->bind(); 
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB( GL_TEXTURE0_ARB, 0, 480, dist ); 
    glVertex3f( origin, origin + 3.0/H, texdist);

    glMultiTexCoord3fARB( GL_TEXTURE0_ARB, 0, 0, dist ); 
    glVertex3f( origin-eps, origin, texdist);

    glMultiTexCoord3fARB( GL_TEXTURE0_ARB, 160, 0,dist ); 
    glVertex3f( origin-eps+ 80.0/640.0, origin, texdist);

    glMultiTexCoord3fARB( GL_TEXTURE0_ARB, 160, 480, dist ); 
    glVertex3f( origin-eps+ 80.0/640.0, origin + 3.0/H, texdist);
  glEnd();
  render_to_texture( 6, 0, ImageHeight-3, 80, 3);
  FP_sum2->bind();


  glEndList();

  glNewList(texIterList, GL_COMPILE) ;

   bindTexture(0,1,2,3,4);
   glCallList(listName);
   glCallList(projList[0]);

   bindTexture(0,7,8,9,10);
   glCallList(listName);
   glCallList(projList[1]);
   bindTexture(0,11,12,13,14);
   glCallList(listName);
   glCallList(projList[2]);
   bindTexture(0,8,12,4,14);
   glCallList(listName);
   glCallList(projList[3]);

   bindTexture(0,4,3,2,1);
   glCallList(listName);
   glCallList(projList[4]);
   bindTexture(0,11,12,14,13);
   glCallList(listName);
   glCallList(projList[5]);
   bindTexture(0,11,12,10,14);
   glCallList(listName);
   glCallList(projList[6]);
   bindTexture(0,8,7,8,10);
   glCallList(listName);
   glCallList(projList[7]);

   bindTexture(0,4,3,2,1);
   glCallList(listName);
   glCallList(projList[8]);
   bindTexture(0,11,12,14,13);
   glCallList(listName);
   glCallList(projList[9]);
   bindTexture(0,11,12,10,14);
   glCallList(listName);
   glCallList(projList[10]);
   bindTexture(0,8,7,8,10);
   glCallList(listName);
   glCallList(projList[11]);



  glEndList();
}
void EigenDisplay::render() {
  float eps=-0.00075; ///epsilon shift , sampling at 0.5 pix.  need sfhit?
  static int f=0;
  if( f== 0 ) FPSimple->activate();
  f=1;
  //glCallList(listName);
  glCallList(texIterList); 
{ struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 90000;
  select(0,0,0,0,&tv);
}
/*
  printPixel(160,ImageHeight-1) ;
  printPixel(161,ImageHeight-1) ;
  printPixel(162,ImageHeight-1) ;
*/
  printPixel(160,ImageHeight-1, 12) ;
}

bool EigenDisplay::checkTextureResidency(int num) 
{
  GLboolean *texstatus = (GLboolean *)malloc(num*sizeof(GLboolean));
  bool retval = true;
  if( glAreTexturesResident(  num,texNames, texstatus )  == GL_TRUE ) return true;
  for( int i=0; i<num; i++ ) {
    if( !texstatus[i] ) {
      cerr<<"texture "<<i<<" is not resident on the graphics memory"<<endl;
      retval = false;
    }
  }
  return retval;
}
