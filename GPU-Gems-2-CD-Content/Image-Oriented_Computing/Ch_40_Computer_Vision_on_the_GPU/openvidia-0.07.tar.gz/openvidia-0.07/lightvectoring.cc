/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "GenericDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"
#include "FragPipeDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include "Correspond.h"
#include "Parameters.h"
#include <iostream>
using namespace std;

// Global display object
FragPipeDisplay *d;
GenericFilter *filter1, *f2q_filter, *q2f_filter;
GenericFilter *filterBlend;
MomentFilter *momentFilter;
Grab_JPEG *writer;
Correspond *corr;
ImlibCapture *im;
unsigned char tmpbuf[2000*1312*4];
float powLookupTable[256*4*4] = {0.0};
char lutname[] = "/usr/local/lookuptables/Kodak_DCS260_response_function";

//int imageWinWidth = 320;
int imageWinWidth = 640;
int viewbuf = 0;
//int imageWinHeight = 240;
int imageWinHeight = 480;
int imageWidth = 2000;
int imageHeight = 1312;
Window  Orbwin;

float BlendAmt = 0.0;

float setBlend( float b )
{
   float blend[4] = {b, 0.0, 0.0, 0.0};
   filterBlend->setCGParameter("BlendFactor", blend);
}
void readlut(char *lutfilename);
void makelut(char *l);



////// GLUT CALLBACKS ///////////////
void reshape(int w, int h)
{
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  //rosco version
  glFrustum(-1.0,1.0,-1.0,1.0,1.0,100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,-1.0,   0.0, 1.0, 0.0);

  //james version
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);

  //set the fpbuffer to have geometry identical to screen
  d->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  ////glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glViewport(0, 0, (GLsizei) imageWidth, (GLsizei) imageHeight);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  d->deactivate_fpbuffer();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case '0': viewbuf = 0; break;
      case '1': viewbuf = 1; break;
      case '2': viewbuf = 2; break;
      case '3': viewbuf = 3; break;
      case '4': viewbuf = 4; break;
      case '5': viewbuf = 5; break;
      case '6': viewbuf = 6; break;
      case '7': viewbuf = 7; break;
      case 27:
         exit(0);
         break;
      case '+' :
         BlendAmt += 0.1; 
         if( BlendAmt > 1.0 ) BlendAmt = 1.0;
         setBlend(BlendAmt);
         cerr<<"Blend : "<<BlendAmt<<endl;
         break;
      case '-' :
         BlendAmt -= 0.1; 
         if( BlendAmt < 0.0 ) BlendAmt = 0.0;
         setBlend(BlendAmt);
         cerr<<"Blend : "<<BlendAmt<<endl;
         break;
      case 'g' :
         glReadPixels( 0, 0, imageWinWidth, imageWinHeight, 
                       GL_RGB, GL_UNSIGNED_BYTE, tmpbuf );
         //generate a filename reflecting settings.
         char filename[256]; 
         sprintf(filename, "Blend_buffer-%d_factor-%0.1f.jpg",
                 viewbuf, BlendAmt );
         cerr<<"Writing file "<<filename<<endl;
         //write file. request invert = true (because of readpixels)
         writer->grab_frame(tmpbuf, imageWinWidth, imageWinHeight,
                       0, filename, true);
         break;
      default:
         break;
   }
}
void TellRWMHeCanUseImage(const char *dma_buf_) {}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        float pixbuf[4] = {0.0};
        cerr << "("<<x<<","<<y<<"):";
        glReadPixels( x, 240-y, 1,1, GL_RGBA, GL_FLOAT,  (void *)pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
 
      }
      break;
    case GLUT_RIGHT_BUTTON : 
      if( state == GLUT_DOWN ) {
      }
      break;
    case GLUT_MIDDLE_BUTTON :
      if( state == GLUT_DOWN ) {
      }
      break;

  }
}

int framecounter=0;
float foo[2000*1312*4];
void render_redirect() {
  ++framecounter;
  d->activate_fpbuffer();
  d->clear_fpbuffer();
    d->bindTextureARB0(7);
    d->bindTextureARB1(0);

    d->applyFilter(filter1, 7,1); //radial

    //d->bindTextureARB1(7);
    //d->applyFilter(f2q_filter, 7,1); //f2q
    //d->applyFilter(q2f_filter, 1,2);
  
  d->deactivate_fpbuffer();

  d->bindTextureARB0(viewbuf);
  d->render();

  d->showstats();
  sched_yield();
  glutSwapBuffers();
}  


///// MAIN ///////////////////

int main(int argc, char** argv)
{
   glutInit(&argc, argv);

   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(0,0);
   Orbwin=glutCreateWindow(argv[0]);

   d=new FragPipeDisplay(18, imageWinWidth, imageWinHeight, Orbwin );

   d->initDisplay();
   d->setImageSize( imageWidth,imageHeight );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-basic.cg", imageWidth, imageHeight); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?

   im = new ImlibCapture();
   im->initCapture((GenericDisplay *)d);
   im->loadFile(argv[1]);


   d->init_texture4f(1,imageWidth, imageHeight, foo);
   d->init_texture(7,imageWidth  ,imageHeight, im->getRGBData() );
   makelut(lutname);
   

   filter1 = new GenericFilter(imageWidth,imageHeight, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-f2q-lut.cg");
   f2q_filter = new GenericFilter(imageWidth,imageHeight, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-f2q.cg");
   float camp[4] = {4.0, 0.15, 0.0, 0.0};
   f2q_filter->setCGParameter("lsparams", camp);

   q2f_filter = new GenericFilter(imageWidth,imageHeight, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-q2f.cg");
   q2f_filter->setCGParameter("lsparams", camp);

   filterBlend = new GenericFilter(imageWidth,imageHeight,d->getContext(), d->getProfile(),
                               "FPsamples/FP-blend.cg");
   setBlend(BlendAmt);
   writer = new Grab_JPEG();

   corr = new Correspond(imageWidth,imageHeight);

  cerr<<"READY        --------------"<<endl;


   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}


void makelut(char *l)
{
   readlut(l);
   float rgbalut[256*4*4];
   for( int i =0; i<256; i++ ) {
     rgbalut[i*4] =   powLookupTable[i]; 
     rgbalut[i*4+1] = powLookupTable[i]; 
     rgbalut[i*4+2] = powLookupTable[i]; 
     rgbalut[i*4+3] = powLookupTable[i]; 
   }
   d->init_texture1f(0, 256, 4, rgbalut);
}

void readlut(char *lutfilename)
{

    // some variables used in reading a text file lut
    FILE *lutfile;
    int lutsize=256;
    float p;
    int i;

    if(lutfilename !=NULL)
      {
        if ((lutfile = fopen(lutfilename, "r")) == NULL)
       {
            fprintf(stderr, "Unable to open %s.\n", lutfilename);
         fclose(lutfile);
            exit(EXIT_FAILURE);
       } 
     else
       { 
         fscanf(lutfile, "%f", &p);
         for (i=0; i<lutsize; i++)
           fscanf(lutfile, "%f", &(powLookupTable[i]));
             
         if (i != lutsize) {
           fprintf(stderr, "Incomplete read of LUT. Numread: %d\n", i);
           fclose(lutfile);
           exit(1);
         }
       }
     fclose(lutfile);
      }
}

