/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "FragPipeDisplay.h"
using namespace std;

extern CGprofile vProfile;
extern CGcontext vContext;



FragPipeDisplay::FragPipeDisplay(int n, int w, int h, int win) 
  : SimpleDisplay(n,w,h,win) 
{
}


void FragPipeDisplay::bindTextureARB1(int texobj )
{
  glActiveTextureARB(GL_TEXTURE1_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[texobj]);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
}

void FragPipeDisplay::bindTextureARB2(int texobj )
{
  glActiveTextureARB(GL_TEXTURE2_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[texobj]);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
}


CGcontext FragPipeDisplay::getContext() { return vContext; }
CGprofile FragPipeDisplay::getProfile() { return vProfile; }

void FragPipeDisplay::applyFilter(GenericFilter *filter, 
                            int t_source, int t_sink) 
{
//  activate_fpbuffer();
  filter->applyFilter(texNames[t_source]);
//note render_to_texture does t_sink object lookup internally
  //render_to_texture(t_sink, 0,0, 320,240);
  render_to_texture(t_sink, 0,0, imageWinWidth,imageWinHeight);
  //render_to_texture(t_sink, 0,0, 640,480);
//  deactivate_fpbuffer();
}

void FragPipeDisplay::applyFilter(GenericFilter *filter, 
                            int t_source, int t_sink,
                            float l, float r, float t, float b) 
{
//  activate_fpbuffer();
  filter->applyFilter(texNames[t_source],l,r,t,b);
//note render_to_texture does t_sink object lookup internally
  //render_to_texture(t_sink, 0,0, 320,240);
  render_to_texture(t_sink, 0,0, imageWinWidth,imageWinHeight);
/*
  int szX = (int)((r-l)*imageWinWidth);
  int szY = (int)((b-t)*imageWinHeight);
  //cerr<<"Sz "<<szX<<" "<<szY<<endl;
  //cerr<<"x,y"<<(int)(l*imageWinWidth)<<" "<<(int)(t*imageWinHeight)<<endl;
  render_to_texture(t_sink, 
                     (int)(l*imageWinWidth), (int)(t*imageWinHeight), 
                     //imageWinWidth,imageWinHeight);
                     szX ,szY);
*/


//  deactivate_fpbuffer();
}

void FragPipeDisplay::applyFilter(GenericFilter *filter, 
                            int t_source, int t_sink,
                            float l, float r, float t, float b, float f) 
{
  filter->applyFilter(texNames[t_source],l,r,t,b,f);
  //note render_to_texture does t_sink object lookup internally
  //render_to_texture(t_sink, 0,0, 320,240);
  render_to_texture(t_sink, 0,0, imageWinWidth,imageWinHeight);
}



void FragPipeDisplay::applySumFilter(MomentFilter *filter, 
                            int t_source, int t_tmp, float *result )
{
  filter->applyFilter(texNames[t_source]);
  //note render_to_texture does t_tmp object lookup internally
  //render_to_texture(t_tmp, 0,0,320,240);
  render_to_texture(t_tmp, 0,0, imageWinWidth,imageWinHeight);
  //bind it for the summator
  bindTextureARB0(t_tmp);
  //do summation, immediately retrieving results
  filter->summer->sumList(result, t_tmp);
}

void FragPipeDisplay::render() {

  glClear(GL_DEPTH_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  FPSimple->activate();
  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;
  //texwidth = texwidth/powf(2.0, downsample_level);
  //texheight = texheight/powf(2.0, downsample_level);
  //cerr<<ImageHeight<<" "<<ImageWidth<<" "<<endl;

   glBegin(GL_QUADS);
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, ImageHeight, dist);
    glVertex3f( origin, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 0.0, dist);
    glVertex3f( origin, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,ImageWidth, 0.0, dist);
    glVertex3f( origin+texwidth, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,ImageWidth, ImageHeight, dist);
    glVertex3f( origin+texwidth, origin+texheight, texdist);
  glEnd();
  FPSimple->deactivate();

}


