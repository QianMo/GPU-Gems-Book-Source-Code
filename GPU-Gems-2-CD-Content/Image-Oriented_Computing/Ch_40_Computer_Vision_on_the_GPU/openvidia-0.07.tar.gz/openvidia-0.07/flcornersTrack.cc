/*
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/
#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <iomanip>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Gl_Window.H>
#include <FL/Fl_Output.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Counter.H>
#include <FL/Fl_Light_Button.H>
//NB: NB: NB: put libopenvidia AFTER the FL include for teh win
#include "libopenvidia.h"
#include <iostream>
void keyboard (unsigned char key, int x, int y);
void MouseFunc( int button, int state, int x, int y) ;
struct timeval tv_start, tv_end;
bool relativeTracking = false;

//This is the pixel position of the point where it is to be displayed.
//normalized axis, raster scan format l/r, up/down
double newX=0.5, newY=0.5;

int elapsedTime(struct timeval *start_time, struct timeval *end_time) {
   return (end_time->tv_sec*1000000+end_time->tv_usec)-
                (start_time->tv_sec*1000000+start_time->tv_usec);

}

void reshape(int w, int h);

#define GL_SZ 2.0
using namespace std;
void drawID();

void IdleCallback(void* pData);

class MyWindow : public Fl_Gl_Window {
  void draw();
  int handle(int);

public:
  MyWindow(int X, int Y, int W, int H, const char *L)
    : Fl_Gl_Window(X, Y, W, H, L) {
  Fl::add_idle(IdleCallback, this); this->mode(FL_RGB8 | FL_DEPTH |FL_ALPHA | FL_DOUBLE); }
  void ddraw() { draw(); }
};

void drawMatches( int numMatches ) ;
void drawCorners() ;
void render_redirect() ;
void init_gl();

void MyWindow::draw() {
  static bool first = true;
  //cerr<<"trying"<<endl;
  //if (!valid()) {
    if( first ) { init_gl(); first = false; }
    render_redirect();
  //}
}

int MyWindow::handle(int x ){
  switch(x) { 
    case FL_KEYDOWN :
      keyboard( *(Fl::event_text()) , 0, 0);
      break;
    case FL_PUSH :
      int button = Fl::event_button();
      int x = Fl::event_x();
      int y = Fl::event_y();
      cerr<<"Button "<<button<<" at "<<x<<","<<y<<endl;
      MouseFunc( button, GLUT_DOWN, x, y) ;
  }
}

Fl_Window *InterfaceWindow;
Fl_Output *ransacOutput, *numMatchedOutput, *numFeatOutput;
Fl_Light_Button *drawMatchesButton;
Fl_Light_Button *drawCornersButton;
Fl_Light_Button *trackingTypeButton;
Fl_Light_Button *rot90tagsButton;
Fl_Counter *corrThreshCounter;
Fl_Input *tagInput;

MyWindow *window;


// Global display object
FragPipeDisplay *d;
Dc1394 *dc1394;
//ImlibCapture *im;
ImlibCapture *lfl;
GenericFilter *filter1, *filter2, *filter3, *filter4;
GenericFilter *magdir, *cannysearch, *tangent, *gaussianX, *gaussianY, *dxdy, *decide;
GenericFilter *derandom;
FragmentProgram *feature, *orientation;
MomentFilter *momentFilter;

Grab_JPEG *grabber;

//   float cannythresh[4] = {10.0, 4.0, 4.0, 4.0};

//works well for the painting image
float cannythresh[4] = {2.0, 4.0, 4.0, 4.0};
float derandomthresh[4] = {0.5, 0.25, 0.25, 0.25};
/// float cornerthresh[4] = {50.0, 0.25, 0.25, 0.25};
float cornerthresh[4] = {11.0, 0.25, 0.25, 0.25};

int imageWinWidth = 320;
int viewbuf = 10;
const int resultBuf = 10;
int imageWinHeight = 240;
Window  Orbwin;

///global state
bool useImlib = true;
float HAND_X_COORD=0.0;
float HAND_Y_COORD=0.0;
void featureSearch(unsigned char *foo, FVRefState &FV);
float corrThresh = 0.6;


unsigned int
halfToFloat (unsigned short y);
void unpack_2half( float in, float *out1, float *out2);

void myIdle();
void TellRWMHeCanUseImage(const char *dma_buf_) ;

unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(320*240*3);
int framecounter=0;
int newdata=0;

unsigned char foo[320*240*4];
int IDcount = 0;
float featureVectorsHalfPacked[240][32][4] = {0.0};
float featureOrientations[240][4][4] = {0.0};

FVRefState FVcurrent, FVprevious, FVreference;
FVRefState FVreferenceB;

//Match array holds the point correspondences in the form
// (x1,y1) -> (x2,y2), ID, age
float matchArray[240][5]={0.0};
Parameters PCumulativeSinceLastRef;

int extractFeatures(FVRefState &FV);
int getOrientation(FVRefState &FV) ;

ProjRANSAC RANSAC(240,320);
void drawTrack( Parameters Pairwise, float x, float y, bool isGood );
void gl_draw_text_normcoord( float x, float y, char *string);
void saveState(FVRefState &state) ;

void storeOldFeatures()
{
  FVprevious = FVcurrent; //copy
  IDcount = FVcurrent.reinit(IDcount); //reset ID numbers
}

void IdleCallback(void* pData)
{
  window->redraw();
}

void render_redirect() {
 
  if(!newdata)  {  struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 1000;
     select(0,0,0,0, &tv);
 return;} 

  ++framecounter;
newdata = 0; 


//  {  struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 100000;
//     select(0,0,0,0, &tv); 
//  }
  

  d->activate_fpbuffer();
  d->clear_fpbuffer();
    if( useImlib )  {
      lfl->advanceFrame();
      d->reinit_texture(0, 320, 240, lfl->getRGBData() );
    }
    else {
      d->reinit_texture(0, 320, 240, dma_buf_rgb);
    }
    d->bindTextureARB0(0);
    if (!useImlib) dc1394->tellThreadDoneWithBuffer();

    //cascade the filters
    d->applyFilter(filter1, 0,1); //texture 1 holds undistorted
    d->applyFilter(filter2, 1,2); //texture 2 holds x deriv
    d->applyFilter(filter3, 1,3); //texture 3 holds y deriv
    
    d->bindTextureARB1(3);        //place texture 3 into unit 1
    d->applyFilter(magdir, 2, 4);  //use texture 2, unit0, result to tex4
    /* buffer 4:     
    colorO.x = dx.x*255.0;
    colorO.y = dy.x*255.0;
    colorO.z = magnitude;
    colorO.w = direction;
    */

    //canny search looks for max in direction of gradient 
    d->applyFilter(cannysearch, 4, 5);  //tex4: magdir, tex5 search result
    //optim fodder, (could collapse canny->tangent into a single prog)
    //d->applyFilter(tangent, 5, 6);  //tex
    d->applyFilter(dxdy, 4, 6);  //tex

    d->applyFilter(gaussianX, 6, 7);  //tex
    d->applyFilter(gaussianY, 7, 8);  //tex

    d->bindTextureARB1(5);        //place canny edgels into texunit 1, flagged
    d->bindTextureARB2(4);         //gradient image into ARB2, no flags,
    d->applyFilter(derandom, 8, 9); //8 has blurred dxdx dydy dxdy
    d->applyFilter(decide, 9, 10); //8 has blurred dxdx dydy dxdy

  d->deactivate_fpbuffer();


  d->bindTextureARB0(viewbuf);
  d->render();

  corrThresh = corrThreshCounter->value();

  //do features
  int numFeat;
  if( viewbuf==resultBuf)  {
    glReadPixels(0,0,320,240,GL_RGB,GL_UNSIGNED_BYTE,foo); 
    storeOldFeatures();
    numFeat = extractFeatures(FVcurrent);
  }


  if( framecounter == 5 ) saveState(FVreference);
  else if (framecounter >5  ) {
    int numMatched;
    PCumulativeSinceLastRef.setIdentity();
///gettimeofday( &tv_start,NULL) ;
    //between 4 - 11 milliseconds
   numMatched = FVcurrent.findCorrespondences( FVreference,
                                               PCumulativeSinceLastRef,
    //                                           320, matchArray );
                                               320, matchArray, corrThresh);

///gettimeofday( &tv_end,NULL) ;
///cerr<<"time "<<elapsedTime(&tv_start, &tv_end)<<" milliseconds"<<endl;

    int support; Parameters Pairwise;
    Pairwise = RANSAC.find_P(matchArray, numMatched, &support); 

    //cerr<<"had "<<support<<"/"<<numMatched<<"/"<<numFeat <<endl;
    // if track is good, update the crosshairs and position
    //if( support >  ) {
    //if( (float)support/(float)numMatched > 0.50 && numMatched > 24 ) {
    if( support > 18 ) {
      drawTrack( Pairwise, FVreference.pos[0], FVreference.pos[1], true );
      //save a 2nd reference frame
      FVreferenceB = FVcurrent;
      FVreferenceB.P = Pairwise;
      double x,y;
      Pairwise.apply((double) FVreference.pos[0],
                     (double) FVreference.pos[1],&x,&y);
      FVreferenceB.pos[0] = (float)x;
      FVreferenceB.pos[1] = (float)y;
    } 
    else {
      numMatched = FVcurrent.findCorrespondences( FVreferenceB,
                                                  PCumulativeSinceLastRef,
                                                  //320, matchArray );
                                                  320, matchArray, corrThresh );
      Parameters Pairwise;
      Pairwise = RANSAC.find_P(matchArray, numMatched, &support); 
      Pairwise = FVreferenceB.P*Pairwise;

      if( support > 18 ) {
        //drawTrack( Pairwise, FVreferenceB.pos[0], FVreferenceB.pos[1], true );
        drawTrack( Pairwise, FVreference.pos[0], FVreference.pos[1], true );

        if( trackingTypeButton->value() )          {
          cerr<<"r";
          FVRefState tmp = FVreference;
          FVreference = FVreferenceB;
          FVreference.P = Pairwise;
          FVreferenceB = tmp;
        }
      }
      else drawTrack( Pairwise, newX, newY, false );
    }
    char output[25];
    sprintf(output, "%d", support);
    ransacOutput->value(output);
    sprintf(output, "%d", numMatched);
    numMatchedOutput->value(output);
    sprintf(output, "%d", numFeat);
    numFeatOutput->value(output);
    if( drawCornersButton->value() ) drawCorners();
    //drawID(); //intensive for all features.
    if( drawMatchesButton->value() ) drawMatches(numMatched);
  }

  d->showstats();

  //use to make videos
  //glReadPixels(0,0,320,240,GL_RGB,GL_UNSIGNED_BYTE,foo);
  //grabber->grab_frame(foo, 320,240, 0, true);

  
}
void drawCorners() {
  //draw corner points onto the image 
  int index=0;
  float depth=-1.0;
  glClear(GL_DEPTH_BUFFER_BIT);
  glColor3f(0.0, 0.0, 1.0);
  glPointSize(GL_SZ);
    glBegin(GL_POINTS);
  while( FVcurrent.corners[index][0] != -1.0 ) {
      glVertex3f(FVcurrent.corners[index][0]/320.0, 
                 FVcurrent.corners[index][1]/240.0, depth);
     
    index++;
  }
    glEnd();

   glBegin(GL_LINES);
   index =0;
  while( FVcurrent.corners[index][0] != -1.0 ) {
      glVertex3f(FVcurrent.corners[index][0]/320.0, 
                 FVcurrent.corners[index][1]/240.0, depth);

      glVertex3f(FVcurrent.corners[index][0]/320.0+
                 FVcurrent.orientation[index][0]*2.0, 

                 FVcurrent.corners[index][1]/240.0+
                 FVcurrent.orientation[index][1]*2.0, 
                 depth);
     
    index++;
  }
    glEnd();



    //drawID();

}

///Draws the age and ID number of the feature.  Font rendering is actually
///really really slow with glut (32 fps -> 24 fps)
void drawID() {
  int index =0;
  char tmpstr[50];
  while( FVcurrent.corners[index][0] != -1.0 ) {
      sprintf(tmpstr, "%d: %d", FVcurrent.Age[index], FVcurrent.ID[index]); 
      glColor3f( 1.0, 1.0, 1.0);
      if(  FVcurrent.Age[index] > 5 ) { 
      glColor3f( 0.0, 1.0, 1.0);
      
      glMatrixMode(GL_MODELVIEW_MATRIX);
      glPushMatrix();
      glClear(GL_DEPTH_BUFFER_BIT);
      glLoadIdentity();
      ///cerr<<"Draw point at "<<(float)cornersArray[index][0]/320.0;
      //glTranslatef( (float)FVcurrent.corners[index][0]/320.0, 
      //               (float)FVcurrent.corners[index][1]/240.0, -1.0);
      glTranslatef( (float)FVcurrent.corners[index][0]/320.0, 
                     (float)FVcurrent.corners[index][1]/240.0, -1.0);
      glScalef(0.018, 0.023, 0.00);
      glfDrawSolidString(tmpstr);
      glPopMatrix();

      }
      index++;
  }
}

void printVector(float *v)
{
  cerr<<"v = ";
  for( int i =0; i<128 ; i++ ) {
    cerr<<setw(6) <<v[i]<<" ";
  }
  cerr<<endl;
}

int remapTable[8][16][2] = { 
 { 10,  9,  8,  7, 11, 3, 2, 6, 12, 4, 1, 5, 13,14,15,16},
 { 8,7,6,5,9,2,1,16,10,3,4,15,11,12,13,14},
 { 7,6,5,16,8,2,1,15,9,3,4,14,10,11,12,13},
 { 5,16,15,14,6,1,4,13,7,2,3,12,8,9,10,11},
 {16,15,14,13,5,1,4,12,6,2,3,11,7,8,9,10},
 {14,13,12,11,15,4,3,10,16,1,2,9,5,6,7,8},
 { 13, 12, 11, 10, 14, 4, 3, 9, 15, 1, 2, 8, 16, 5, 6, 7},
 { 11, 10,  9,  8, 12, 3, 2, 7, 13, 4, 1, 6, 14,15,16, 5},
 };

void reOrderFeatureVector( float *v, int rot) 
{
  float newFV[128] = {0.0};

  for( int i=0; i < 16 ; i++ ) {
    int origOffset =  i;
//whhops made remap table as 1-16, not 0-15
    int remapOffset = ((remapTable[rot][i][1])-1)*8; 
    for( int j = 0; j<8 ; j++ ) {
      newFV[remapOffset+j] = v[origOffset+j];
    }
  }
  //set the input to now be the block rotated feature vector.
/*
  cerr<<"Before block reOrder : "<<endl;
  for( int i=0; i<128 ; i++ ) {
    cerr<<v[i]<<" ";
    if( i%8 == 7 ) cerr<<endl;
  }
*/
  for( int i=0; i<128 ; i++ ) {
    v[i] = newFV[i];
  }
/*
  cerr<<"After block reOrder : "<<endl;
  for( int i=0; i<128 ; i++ ) {
    cerr<<v[i]<<" ";
    if( i%8 == 7 ) cerr<<endl;
  }
*/
 
}

void normalizeFeatureVector( float *v) 
{
  float norm = 0.0;
  for( int i =0; i<128 ; i++ ) {
    norm+=v[i];
  }
  for( int i =0; i<128 ; i++ ) {
    v[i]/=norm;
  }
}

int rotateFeatureVector( float *v )
{
  float histoSum[8]={0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  float maxVal = 0.0;
  int shift = 0;
//  cerr<<"Input ";
  //for each clump of histograms (8 entries, 16 histos in total = 128 elemnts)
  for( int i =0; i<128 ; i++ ) {
    histoSum[i%8] += v[i];
//    cerr<<" "<<v[i];
  }
//  cerr<<endl;
//  cerr<<"Max Histo ";
  for( int i =0 ; i<8 ; i++ ) {
    if( histoSum[i] > maxVal ) {
      maxVal = histoSum[i];
      shift = i;   
    } 
//    cerr<<histoSum[i]<<" ";
  }
//  cerr<<endl;
//  cerr<<"Rotate by "<<shift<<" -->output :";

  for( int i =0; i<128 ; i+=8 ) {
    float tmparray[8] = {0.0};
    for ( int j=i, m=0; m<8 ; m++, j++ )  {
      tmparray[m] = v[ abs((j+shift)%8)+i ];
    }
    for ( int j=i, m=0; m<8 ; m++, j++ )  {
       v[j] = tmparray[m];
//       cerr<<v[j]<<" ";
    }
  }
  return shift;

}

void printMatches ( int numMatches ) {
  for( int i =0; i<numMatches ; i++ ) {
    cerr<<" ["<<matchArray[i][0]<<", "<<matchArray[i][1]<<"] --> [";
    cerr<<matchArray[i][2]<<", "<<matchArray[i][3]<<"]"<<endl;
  }
}

void drawMatches( int numMatches ) {
  glClear(GL_DEPTH_BUFFER_BIT); 
  glColor4f(0.0, 1.0, 0.0, 1.0);
  glLineWidth(GL_SZ);
  glBegin(GL_LINES);
 //   glVertex3f( 0.0, 0.0, -1.0 );
 //   glVertex3f( 1.0, 1.0, -1.0 );
    for( int i=0 ; i<numMatches ; i++ ) { 

      //only draw the first supported projective motion
      if( RANSAC.RANSACSupportArray[i] != 1 ) continue;

      glVertex3f( matchArray[i][0]/320.0, matchArray[i][1]/240.0, -1.0 );
      glVertex3f( matchArray[i][2]/320.0, matchArray[i][3]/240.0, -1.0 );
//    cerr<<" ["<<matchArray[i][0]/320.0<<", "<<matchArray[i][1]/240.0<<"] --> [";
//    cerr<<matchArray[i][2]/320.0<<", "<<matchArray[i][3]/240.0<<"]"<<endl;
    }
  glEnd();

 
}

int getOrientation(FVRefState &FV) 
{
  int numOrientations = 0;
  float ypos = 0.0;
  float depth= -1.0;
  int index=0;

d->activate_fpbuffer();
  glClear(GL_DEPTH_BUFFER_BIT);
  glColor3f(1.0, 0.0, 0.0);
  glPointSize(1.0);

  orientation->activate();
  d->bindTextureARB2(11);       //gaussian 16x16 taps
  d->bindTextureARB1(3);        //place texture dy into unit 1
  d->bindTextureARB0(2);        //place texture dx into unit 0
  glBegin(GL_POINTS);
  //for each 8x8 quad of the 16x16 region of interest
  while( FV.corners[index][0] != -1.0 ) {
      int i=0;
      for( int xoffset=-1 ; xoffset<1 ; xoffset++ ) {
        for( int yoffset=-1 ; yoffset<1 ; yoffset++ ) {
          //send in the top left coordinate of the pixel block area in 
          //question for histogramming
          glMultiTexCoord3fARB(GL_TEXTURE0_ARB, 
                               FV.corners[index][0]+(float)xoffset*8.0,
                               FV.corners[index][1]+(float)yoffset*8.0, 
                               1.0);
          glMultiTexCoord3fARB(GL_TEXTURE1_ARB, 
                               (xoffset+1)*8.0, 
                               (yoffset+1)*8.0,
                               1.0 );
          glVertex3f((float)i/320.0, 1.0-(float)index/240.0, depth);
          i++;
        }
      }
      index++;
  }
  glEnd();

  orientation->deactivate();
  //cerr<<"Calculated "<<index<<" Orientations"<<endl;

  /***********************************************************/
  //read out the orientations using only first 240 for match
  if( FV.numFeatures < 239 ) numOrientations = FV.numFeatures;
  else numOrientations = 239;
  //memset(featureOrientations, 0, 240*sizeof(float));
  memset(featureOrientations, 4, 240*sizeof(float));
  memset(FV.orientation, 2, 240*sizeof(float));
  glReadPixels(0,0,4, numOrientations, GL_RGBA, GL_FLOAT, featureOrientations);
  //glReadPixels(0,0,4, 240, GL_RGBA, GL_FLOAT, FV.orientation );

  index = 0;
  while( FV.corners[index][0] != -1.0 ) {
    FV.orientation[index][0] = featureOrientations[index][0][0] +
                        featureOrientations[index][1][0] +
                        featureOrientations[index][2][0] +
                        featureOrientations[index][3][0] ;

    FV.orientation[index][1] = featureOrientations[index][0][1] +
                        featureOrientations[index][1][1] +
                        featureOrientations[index][2][1] +
                        featureOrientations[index][3][1] ;


    FV.orientation[index][2] = atan2f( FV.orientation[index][1] , 
                                       FV.orientation[index][0] );
    //normalized [0,1.0f] direction
    //FV.orientation[index][2] = FV.orientation[index][2]/(2.0*3.14159)+0.5;
    index++;
  }
/**************
  cerr<<"First orientation is: ";
  cerr<<featureOrientations[1][0][0]<<", ";
  cerr<<featureOrientations[1][0][1]<<", ";
  cerr<<featureOrientations[1][0][2]<<", ";
  cerr<<featureOrientations[1][0][3]<<endl;

  cerr<<featureOrientations[1][1][0]<<", ";
  cerr<<featureOrientations[1][1][1]<<", ";
  cerr<<featureOrientations[1][1][2]<<", ";
  cerr<<featureOrientations[1][1][3]<<endl;

  cerr<<featureOrientations[1][2][0]<<", ";
  cerr<<featureOrientations[1][2][1]<<", ";
  cerr<<featureOrientations[1][2][2]<<", ";
  cerr<<featureOrientations[1][2][3]<<endl;

  cerr<<featureOrientations[1][3][0]<<", ";
  cerr<<featureOrientations[1][3][1]<<", ";
  cerr<<featureOrientations[1][3][2]<<", ";
  cerr<<featureOrientations[1][3][3]<<endl;
*/
}


int drawFeatureVectors(FVRefState &FV) {
  int numFeatures = 0;
  float ypos = 0.0;
  float depth= -1.0;
  int index=0;

d->activate_fpbuffer();
  glClear(GL_DEPTH_BUFFER_BIT);
  glColor3f(1.0, 0.0, 0.0);
  glPointSize(1.0);

  d->bindTextureARB0(9);
  d->bindTextureARB1(11); //gaussian 16x16 taps
  feature->activate();
  glBegin(GL_POINTS);
  //for each point in the array
  while( FV.corners[index][0] != -1.0 ) {
      int i=0;
      for( int xoffset=-2 ; xoffset<2 ; xoffset++ ) {
        for( int yoffset=-2 ; yoffset<2 ; yoffset++ ) {
          //send in the top left coordinate of the pixel block area in 
          //question for histogramming
//          glTexCoord3f(cornersArray[index][0]+(xoffset*4.0), 
//                       cornersArray[index][1]+(yoffset*4.0), 1.0);
          glMultiTexCoord3fARB(GL_TEXTURE0_ARB, 
                                FV.corners[index][0]+xoffset*4.0,
                                FV.corners[index][1]+yoffset*4.0, 
                                1.0);
          glMultiTexCoord3fARB(GL_TEXTURE1_ARB, 
                                 (xoffset+2.0)*4.0, 
                                 (yoffset+2.0)*4.0,
                                 1.0 );

          glMultiTexCoord3fARB(GL_TEXTURE2_ARB, 
                               FV.corners[index][0],
                               FV.corners[index][1],
     // tee hee                          1.0 );
                               FV.orientation[index][2]);
          glColor4f( FV.orientation[index][2], FV.orientation[index][2],
                     FV.orientation[index][2], FV.orientation[index][2]);

          glVertex3f((float)i/320.0, 1.0-(float)index/240.0, depth);

          i++;
        }
      }
      index++;
  }
  glEnd();
  feature->deactivate();
  //cerr<<"Calculated "<<index<<" feature vectors"<<endl;

  /***********************************************************/
  //read out the feature vectors using only first 240 for match
  if( FV.numFeatures < 239 ) numFeatures = FV.numFeatures;
  else numFeatures = 239;
  memset(featureVectorsHalfPacked, 0, 240*32*sizeof(float));
  glReadPixels(0,0, 32, numFeatures, GL_RGBA, GL_FLOAT, featureVectorsHalfPacked );

  //read the buffer. [vector][histobin][rgba compoenent]
  int pos = numFeatures-1;
  //cerr<<"f "<<numFeatures<<": "<<featureVectors[pos][0][0]<<" "<<featureVectors[pos][0][1]<<" ";
  //cerr<<featureVectors[pos][0][2]<<" "<<featureVectors[pos][0][3]<<endl;
  pos = 4;
  float xchan, ychan;

  //unpack 16, 4 valued readback pixels into 128 features
  for( int pos=0 ; pos<numFeatures ; pos++ ) { 
    int k =0;
    for( int j=0 ; j < 16 ; j ++ ) {
      for( int i=0 ; i<4 ; i++ ) {
        unpack_2half( featureVectorsHalfPacked[pos][j][i], 
                      &FV.fvec[pos][k], &FV.fvec[pos][k+1] );
        k+=2;
      }
    }
    //int rotation = rotateFeatureVector( FV.fvec[pos] );
    //reOrderFeatureVector( FV.fvec[pos], rotation );
    ///if( pos == 1 ) printVector(FV.fvec[pos]);
    normalizeFeatureVector( FV.fvec[pos] );
    assert( k== 128 );
  }
  
d->deactivate_fpbuffer();
  return numFeatures;
}

void drawTrack( Parameters Pairwise, float x, float y, bool isGood ) {
 glClear(GL_DEPTH_BUFFER_BIT);
 glLineWidth(2.0);
 //fade just makes it disappear less - if no track it just uses last 
 //position so something is on screen, but it wont do this for more than
 // four consecutive frames before it gives up, this just smoothes over
 //small hiccups in the camera motion.
 //deprecated until coordinating fixed (need to record last position somehow).
 static Parameters Prev = Pairwise;
 static double oldx, oldy;
 static float fade = 0;

 glColor3f(1.0, 1.0, 1.0);
 if( !isGood ) {
   if( fade >= 2.0) return;
   fade+=1.0;
   cerr<<"O";
   Pairwise = Prev; 
   x= oldx, y = oldy;
 }
 else {
    Pairwise.apply( (double)x,(double) y, &newX, &newY );
    fade = 0.0; 
    cerr<<".";
    Prev = Pairwise;
    oldx = x, oldy = y;
  }
/*
////if( Pairwise.getSupport() > 0.3 ) {
    Pairwise.apply( (double)x,(double) y, &newX, &newY );
    fade = 0.0; 
    cerr<<".";
//  }
//  else {
 //   glColor3f(1.0, 0.0, 0.0);
  }
*/
 
  glMatrixMode(GL_MODELVIEW);
  glClear(GL_DEPTH_BUFFER_BIT);
  glPushMatrix();
  glLoadIdentity();
  //Pairwise.setIdentity();
  //NB : this multmatrix places objects at z=1.0 ..
  // im sure there used to be a good reason for this..
  //Pairwise.invert();
  //glMultMatrixf( Pairwise.getAsChirpMat() );
  //glTranslatef(0.5, 0.5, 1.0);
  //glTranslatef(pos[0], pos[1], -1.0);
  glTranslatef(newX, newY, -1.0);
  glScalef(0.03, 0.04, 0.1);
  if( rot90tagsButton->value() ) { glRotatef(90.0, 0.0, 0.0, -1.0);}
 // glColor3f(1.0, 1.0, 1.0);
  glLineWidth(1.0);
  //glfDrawWiredString("Hello World");
  char *tagVal = (char *)tagInput->value();
  glfDrawSolidString(tagVal);
  glPopMatrix();


  

  double topx,topy, bottomx,bottomy, leftx, lefty, rightx, righty;
//  if( !trackingTypeButton->value() ) {
/*
    Pairwise.apply( x, y-0.25, &topx, &topy);
    Pairwise.apply( x, y+0.25, &bottomx, &bottomy);
    Pairwise.apply( x-0.25, y, &leftx, &lefty);
    Pairwise.apply( x+0.25, y, &rightx, &righty);
*/
  //}
//  else {
    x= newX; y =newY;
    topx = x; topy = y-0.25;
    bottomx  =x ; bottomy = y+0.25;
    leftx = x-0.25; lefty = y;
    rightx = x+0.25; righty = y;
//  }
   

  glBegin(GL_LINES);
    //glVertex3f( newX-0.5, newY, -1.0);
   // glVertex3f( newX+0.5, newY, -1.0);
    //glVertex3f( newX, newY-0.5, -1.0);
    //glVertex3f( newX, newY+0.5, -1.0);
    glVertex3f( leftx, lefty, -1.0);
    glVertex3f( rightx, righty,-1.0);
    glVertex3f( topx, topy, -1.0);
    glVertex3f( bottomx, bottomy, -1.0);
  glEnd();


  glClear(GL_DEPTH_BUFFER_BIT);
}
 

// unpacks 2 half (which were packed into the float "in") and 
// palces the results in out1, out2 as floating point (loss of
// precision tho)
void unpack_2half( float in, float *out1, float *out2)
{
  unsigned int *x;
  unsigned int y;
  float input = in;

  //x = (unsigned int *) &(featureVectors[pos][0][0]);
  x = (unsigned int *) &input;
  y = *x;
  //y = y & 0x0000FFFF;

  unsigned short *a;
  unsigned short b,c;

  a = (unsigned short *)&y;
  b =( y >> 16  ) & 0x0000FFFF;
  c =( y >> 0   ) & 0x0000FFFF;

  unsigned int f = halfToFloat( b );
  unsigned int g = halfToFloat( c );

  float *newFloat_b;
  float *newFloat_c;

  newFloat_b = (float *)&f;
  newFloat_c = (float *)&g;

  //cerr << "new float = " << *newFloat_b<<" and "<< *newFloat_c<<endl;
  *out2 = *newFloat_b;
  *out1 = *newFloat_c;
}



int extractFeatures(FVRefState &FV) {
  featureSearch(foo, FV);
  d->bindTextureARB0(1);
  d->render();
  ////drawCorners();
  int num = getOrientation(FV); // returns number of corners
  num = drawFeatureVectors(FV); // returns number of corners
  //drawID();
  return num;
}


void init_track()
{
  IDcount = FVprevious.reinit(IDcount);
}


///// MAIN ///////////////////
int main(int argc, char** argv)
{
  // glutInit(&argc, argv);

  window = new MyWindow(10,10,320,240, "CornersTrack");
  window->end();
  window->show(argc, argv);

  InterfaceWindow = new Fl_Window( 10,300, 320, 120, "Interface");
  ransacOutput = new Fl_Output(64,5,40,20,"RANSAC:");
  numMatchedOutput = new Fl_Output(170,5,40,20, "Matched:");
  numFeatOutput = new Fl_Output(280,5,40,20,"Features:");
  tagInput = new Fl_Input( 60, 50, 200, 20, "Tag:");
  tagInput->value("Tag 1", 5);

  drawMatchesButton = new Fl_Light_Button( 1, 25, 110, 20, "Show Matches" );
  drawMatchesButton->selection_color(FL_GREEN);

  drawCornersButton = new Fl_Light_Button( 111, 25, 110, 20, "Show Corners" );
  drawCornersButton->selection_color(FL_BLUE);
  
  trackingTypeButton = new Fl_Light_Button( 221, 25, 120, 20, "RelativeTrack");
  trackingTypeButton->selection_color(FL_RED);
  
  rot90tagsButton = new Fl_Light_Button( 221, 50, 120, 20, "Rot90 tags");
  rot90tagsButton->selection_color(FL_RED);

  corrThreshCounter = new Fl_Counter( 10, 80, 100,20, "CorrThresh"); 
  corrThreshCounter->value(corrThresh);
  corrThreshCounter->type(FL_SIMPLE_COUNTER);
  corrThreshCounter->bounds(0.3, 1.0);
  corrThreshCounter->step(0.05);
  
  InterfaceWindow->end();
  InterfaceWindow->show(argc, argv);

  //if an argument is given, assume we are using an image file
  if( argc == 2 ) { 
    cout<<"Using image file: "<<argv[1]<<endl;
    cout<<"Note: currently, image file must be 320x240 resolution"<<endl;
    useImlib = true;
  }
  else {
    useImlib = false;
  }
  return Fl::run();

}

void init_gl() {
   //typical problem : can't open imlib without display, yet cant
   // size display without loading image from imlib
   d=new FragPipeDisplay(16, imageWinWidth, imageWinHeight, Orbwin );
   d->initDisplay();

   d->setImageSize( 320,240 );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-basic.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?
     dc1394=new Dc1394();
     dc1394->start();
   grabber = new Grab_JPEG();


   //d->activate_fpbuffer();
   d->init_texture(0, 320, 240, foo);
   d->init_texture4f(1, 320, 240, foo);
   d->init_texture4f(2, 320, 240, foo);
   d->init_texture4f(3, 320, 240, foo);
   d->init_texture4f(4, 320, 240, foo);
   d->init_texture4f(5, 320, 240, foo);
   d->init_texture4f(6, 320, 240, foo);
   d->init_texture4f(7, 320, 240, foo);
   d->init_texture4f(8, 320, 240, foo);
   d->init_texture4f(9, 320, 240, foo);

   d->init_texture4f(10, 320, 240, foo);
   d->init_texture4f(11, 16, 16, taps);
   d->reinit_texture1f(11, 16, 16, taps);

   filter1 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-ibot-undistort.cg");
   filter2 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               //"FPsamples/FP-gaussianderiv-sigma3-x.cg");
                               "FPsamples/FP-gaussianderiv-sigma1-x.cg");
   filter3 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                              // "FPsamples/FP-gaussianderiv-sigma3-y.cg");
                               "FPsamples/FP-gaussianderiv-sigma1-y.cg");
   magdir = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-magdir.cg");
   cannysearch = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               //"FPsamples/FP-canny-search.cg");
                               "FPsamples/FP-canny-search-with-corners.cg");
   cannysearch->setCGParameter( "thresh", cannythresh);
   tangent = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-tangent.cg");
   dxdy = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-dxdy.cg");
   gaussianX = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-gaussian-sigma3-x-rgb.cg");
   gaussianY = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-gaussian-sigma3-y-rgb.cg");
   derandom = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-derandom-corners.cg");
   derandom->setCGParameter( "thresh", derandomthresh);
   feature = new FragmentProgram(d->getContext(), d->getProfile(), 
                               "FPsamples/FP-feature.cg", 1);
   decide = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-decide.cg");
   decide->setCGParameter( "thresh", cornerthresh);


   orientation = new FragmentProgram(d->getContext(),  d->getProfile(),
                                   "FPsamples/FP-orientation.cg", 1);
  cerr<<"Done"<<endl;
   init_track();  //initialize some tracking arrays information
   reshape(320,240);   

     glfInit();
  //glfLoadFont(FONT);
  glfLoadFont("fonts/cricket1.glf");


}







////////////////////
////// GLUT CALLBACKS ///////////////
////////////////////
void reshape(int w, int h)
{
  float SCALE = 1.1;
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  //rosco version
  glFrustum(-1.0,1.0,-1.0,1.0,1.0,100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,-1.0,   0.0, 1.0, 0.0);

  //james version
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);

  //set the fpbuffer to have geometry identical to screen
  d->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  //glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glViewport(0, 0, (GLsizei) 320, (GLsizei) 240);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  d->deactivate_fpbuffer();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

void saveState(FVRefState &state) 
{
  state = FVcurrent;
  cerr<<"*****Saved "<<FVreference.numFeatures<<" features"<<endl;
  state.pos[0] = newX;
  state.pos[1] = newY;
}


//Match array holds the point correspondences in the form
void keyboard (unsigned char key, int x, int y)
{
   switch (key) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
         viewbuf = atoi((const char * )&key);
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case 'A' : 
         viewbuf = 10;
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case 's':
         derandomthresh[0] += 0.01;
         cerr<<"derandomthresh = "<<derandomthresh[0]<<endl;
         derandom->setCGParameter( "thresh", derandomthresh);
         break;
      case 'x':
         derandomthresh[0] -= 0.01;
         cerr<<"derandomthresh = "<<derandomthresh[0]<<endl;
         derandom->setCGParameter( "thresh", derandomthresh);
         break;
      case 'a':
         cannythresh[0] += 0.1;
         cerr<<"cannythresh = "<<cannythresh[0]<<endl;
         cannysearch->setCGParameter( "thresh", cannythresh);
         break;
      case 'z':
         cannythresh[0] -= 0.1;
         cerr<<"cannythresh = "<<cannythresh[0]<<endl;
         cannysearch->setCGParameter( "thresh", cannythresh);
         break;
       case 'd':
         cornerthresh[0] += 1.0;
         cerr<<"cornerthresh = "<<cornerthresh[0]<<endl;
         decide->setCGParameter( "thresh", cornerthresh);
         break;
 
       case 'c':
         cornerthresh[0] -= 1.0;
         cerr<<"cornerthresh = "<<cornerthresh[0]<<endl;
         decide->setCGParameter( "thresh", cornerthresh);
         break;

      case 'r' :  //take a snapshot of the state.
        saveState(FVreference);
        break;
         
    
      case 't' :  //take a snapshot of the state.
        saveState(FVreferenceB);
        break;
         
 
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        float pixbuf[4] = {0.0};
        cerr << "("<<x<<","<<y<<"):";
        glReadPixels( x,240-y, 1,1, GL_RGBA, GL_FLOAT,  pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
      }
      break;
   case GLUT_RIGHT_BUTTON : 
     if( state == GLUT_DOWN ) {
       newX = (float)x/320.0;
       newY = (float)y/240.0;
       saveState(FVreference);
       cerr<<"Moved tag position to "<<FVreference.pos[0];
       cerr<<","<<FVreference.pos[1]<<endl;
     }
     break;
 
   case GLUT_MIDDLE_BUTTON :
    PCumulativeSinceLastRef.setIdentity();
    int numMatched = FVcurrent.findCorrespondences( FVreference, 
                                               PCumulativeSinceLastRef,160.0,
                                               matchArray, corrThresh );

    int support;
    Parameters Pairwise = RANSAC.find_P(matchArray, numMatched, &support);
    if( support < 10 ) break;
    drawTrack( Pairwise, FVreference.pos[0], FVreference.pos[1],true );
    if( drawCornersButton->value() ) drawCorners();
    if( drawMatchesButton->value() ) drawMatches(numMatched);

    break;

  }
}




/* Tell function executed in context of Dc1394 thread */
void TellRWMHeCanUseImage(const char *dma_buf_) {
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;

  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;
  uyvy2rgb(dma_buf,dma_buf_rgb,320*240);

  //have only one, need two before we do any orbits
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }

  newdata=1;
}


//for is RGB 320x240
void featureSearch(unsigned char *foo, FVRefState &FV) {
  int i, j;
  int k=0;
  int numEdges=0;
  FV.numFeatures=0;
  for( i=0 ; i<240 ; i++ ) {
    for( j=0; j<320 ; j++ ) {
      if( foo[k] > 200 ) { 
        FV.corners[FV.numFeatures][0] = j; //rasterized x location
        FV.corners[FV.numFeatures][1] = (240-i); //raster  location
        FV.numFeatures++;
        if( FV.numFeatures > 239 ) {
          fprintf(stderr, "too many corners.\n");
         // break;
          goto breakout;
        }
      }
      else if( foo[k] > 100 ) {
        numEdges++;
      }
      k+=3; //increment by RGB
    }
  }
breakout :
//  fprintf(stderr, "There are %d corners, %d edge pixels\n", numCorners, numEdges);
  //end marker
  FV.corners[FV.numFeatures][0] = -1.0; //normalized x location
  FV.corners[FV.numFeatures][1] = -1.0; //normalized x location
  ///cerr<<"Feature searched "<<FVcurrent.numFeatures<<" features"<<endl;
}



///////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002, Industrial Light & Magic, a division of Lucas
// Digital Ltd. LLC
// 
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
// *       Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
// *       Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
// *       Neither the name of Industrial Light & Magic nor the names of
// its contributors may be used to endorse or promote products derived
// from this software without specific prior written permission. 
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////




//---------------------------------------------------------------------------
//
//	toFloat
//
//	A program to generate the lookup table for half-to-float
//	conversion needed by class half.
//	The program loops over all 65536 possible half numbers,
//	converts each of them to a float, and prints the result.
//
//---------------------------------------------------------------------------


#include <iostream>
#include <iomanip>

using namespace std;

//---------------------------------------------------
// Interpret an unsigned short bit pattern as a half,
// and convert that half to the corresponding float's
// bit pattern.
//---------------------------------------------------

unsigned int
halfToFloat (unsigned short y)
{

    int s = (y >> 15) & 0x00000001;
    int e = (y >> 10) & 0x0000001f;
    int m =  y        & 0x000003ff;

    if (e == 0)
    {
	if (m == 0)
	{
	    //
	    // Plus or minus zero
	    //

	    return s << 31;
	}
	else
	{
	    //
	    // Denormalized number -- renormalize it
	    //

	    while (!(m & 0x00000400))
	    {
		m <<= 1;
		e -=  1;
	    }

	    e += 1;
	    m &= ~0x00000400;
	}
    }
    else if (e == 31)
    {
	if (m == 0)
	{
	    //
	    // Positive or negative infinity
	    //

	    return (s << 31) | 0x7f800000;
	}
	else
	{
	    //
	    // Nan -- preserve sign and significand bits
	    //

	    return (s << 31) | 0x7f800000 | (m << 13);
	}
    }

    //
    // Normalized number
    //

    e = e + (127 - 15);
    m = m << 13;

    //
    // Assemble s, e and m.
    //

    return (s << 31) | (e << 23) | m;
}



void gl_draw_text_normcoord( float x, float y, char *string)
{
    int ww = glutGet( (GLenum)GLUT_WINDOW_WIDTH );
    int wh = glutGet( (GLenum)GLUT_WINDOW_HEIGHT );

    char *p;
    //glColor3f(1.0,1.0,1.0);
    //illegible matrix green 
    //glColor3f( 0.11, 0.37, 0.25);
    glMatrixMode( GL_PROJECTION );
    glPushMatrix();
    glLoadIdentity();
    //ww /= 2;
    //wh /= 2;
    //gluOrtho2D( -(float)ww, (float)ww, -(float)wh, (float)wh );
    //gluOrtho2D( 0, (float)ww, -(float)wh, (float)wh );
    gluOrtho2D( 0, (float)ww, 0.0, (float)wh);
    glMatrixMode( GL_MODELVIEW );
    glPushMatrix();
    glLoadIdentity();

//    glRasterPos2i( x*(float)ww,y*(float)wh );
    glRasterPos2i( (int)x,(int)y );

    for ( p = string; *p; p++ )
          {
        if ( *p == '\n' )
            {
            y = y - 14;
            glRasterPos2i( (int)(ww*x), (int)(wh*y) );
            continue;
            }
        glutBitmapCharacter( GLUT_BITMAP_HELVETICA_18, *p );
          }

//        glutBitmapCharacter( GLUT_BITMAP_HELVETICA_18, 'f');



    glMatrixMode( GL_PROJECTION );
    glPopMatrix();
    glMatrixMode( GL_MODELVIEW );
    glPopMatrix();
}

