/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _PROJRANSAC_H
#define _PROJRANSAC_H

#ifdef __cplusplus
extern "C" {
#endif
#include "mat_util.h"
#include "pinverse.h"
#include "corners2r.h"
#include "corners2d.h"
#include "motion.h" //for pcompose
#ifdef __cplusplus
}
#endif

#define RANSAC_MAX_CORR 240
#define MAX_MOTIONS 10
#include "Parameters.h"

class ProjRANSAC {
  private :
    double srcCorners[8], destCorners[8];
    Var pDechirp, pRechirp, pFinal;
    int M, N;

    double dist( double x1, double y1, double x2, double y2);
    int getSupport( Parameters P,float in_corrArray[240][5],int numCorr,
                    double thresh);

    ///array of correspondences input.  don't touch this, only read it.
//    float **corrArray;
   
    ///number of correspondences input
//    int numCorr;
  
  public :

    /// this is an array of flags.  Each elements flags each element of 
    /// the corrArray. The flag is: -1 = empty. 0=no support, 
    ///  1 = first RANSAC projective paramters, 2=2nd RANSAC parameters...
    int RANSACSupportArray[RANSAC_MAX_CORR];

    ///ransac parameters
    Parameters RANSAC_P[MAX_MOTIONS];

    ///ransac parameters support (the number of points which agree with
    //// this particular projective estimation
    int RANSAC_P_SUPPORT[MAX_MOTIONS];

    /**Constructor, M, N are image sizes in pixels */
    ProjRANSAC(int inM, int inN); 

    Parameters get_P_from_Corr(float m1, float n1, float i1, float j1,
               float m2, float n2, float i2, float j2,
               float m3, float n3, float i3, float j3,
               float m4, float n4, float i4, float j4 );
    Parameters find_P( float correspondences[240][5], int numCorrespondences,
                        int *supportReturn);
    
    

};
#endif
