/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include "libopenvidia.h"
#include <iostream>
using namespace std;

// Global display object
FragPipeDisplay *d;
V4L2 *v4l2;
//pos=[-0.48,-0.4,0.77], rot=[0,0,0], 
GLfloat xrot=0.0f;
GLfloat yrot=0.0f;
GLfloat zrot=0.0f;
GLfloat xinc=0.0f;
GLfloat yinc=0.0f;
GLfloat zinc=0.0f;
/*
GLfloat xp=-0.00;
GLfloat yp=-0.00;
GLfloat zp= 0.00f;
*/

GLfloat xp=-0.48f;
GLfloat yp=-0.44f;
GLfloat zp= 0.77f;


float fL = 0.25, fR = 0.65, fT =0.35, fB = .75;
//float fL = 0.25, fR = 0.75, fT =0.25, fB = .75;

//int viewbuf=1;  
int viewbuf=9;  
int imageWinWidth = 640;
int imageWinHeight = 480;
float foo[640*480*4];
GenericFilter *filter1, *filter2, *filter3, *filter4;
GenericFilter *magdir, *cannysearch, *tangent, *gaussianX, *gaussianY;
GenericFilter *derandom;
   float cannythresh[4] = {10.0, 4.0, 4.0, 4.0};
   float derandomthresh[4] = {0.25, 0.25, 0.25, 0.25};


Window  Orbwin;

////// GLUT CALLBACKS ///////////////

void reshape(int w, int h)
{
  float SCALE = 10.0;
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  //james version
  glFrustum(0.0, 1.0/SCALE,  1.0/SCALE, 0.0,   1.0/SCALE,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);

  //set the fpbuffer to have geometry identical to screen
  d->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) imageWinWidth, (GLsizei) imageWinHeight);
  //glViewport(0, 0, (GLsizei) imageWinWidth/2, (GLsizei) imageWinHeight/2);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  glFrustum(0.0, 1.0/SCALE,  1.0/SCALE, 0.0,   1.0/SCALE,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  d->deactivate_fpbuffer();


  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case 'a' : case '+' :  zp +=0.01; break;
      case 'z' : case '-' :  zp -=0.01; break;
      case 'A' : zp +=0.001; break;
      case 'Z' : zp -=0.001; break;
      case 'h' : xp -=0.01; break;
      case 'l' : xp +=0.01; break;
      case 'j' : yp -=0.01; break;
      case 'k' : yp +=0.01; break;
      case 'q' : zrot += 0.1; break;
      case 'e' : zrot -= 0.1; break;

      case '0': 
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
         viewbuf = atoi((const char * )&key);
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;

        
      case 'p' : 
        cout<<"pos=["<<xp<<","<<yp<<","<<zp<<"], ";
        cout<<"rot=["<<xrot<<","<<yrot<<","<<zrot<<"], ";
        cout<<endl;
        break;

      case 's':
         derandomthresh[0] += 0.01;
         cerr<<"derandomthresh = "<<derandomthresh[0]<<endl;
         derandom->setCGParameter( "thresh", derandomthresh);
         break;
      case 'x':
         derandomthresh[0] -= 0.01;
         cerr<<"derandomthresh = "<<derandomthresh[0]<<endl;
         derandom->setCGParameter( "thresh", derandomthresh);
         break;
      case 'd':
         cannythresh[0] += 0.1;
         cerr<<"cannythresh = "<<cannythresh[0]<<endl;
         cannysearch->setCGParameter( "thresh", cannythresh);
         break;
      case 'c':
         cannythresh[0] -= 0.1;
         cerr<<"cannythresh = "<<cannythresh[0]<<endl;
         cannysearch->setCGParameter( "thresh", cannythresh);
         break;

      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      break;
    case GLUT_RIGHT_BUTTON : 
      break;
  }
}
unsigned char* dma_buf=0;
int newdata=0;

/* Tell function executed in context of Dc1394 thread */
void TellRWMHeCanUseImage(const char *dma_buf_) {
  dma_buf = (unsigned char *)dma_buf_;
  newdata=1;
}


int framecounter=0;

void render_redirect() {
  ++framecounter;

  if(!newdata)  {  struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 1000;
     select(0,0,0,0, &tv);
 return;}

  d->init_texture4c(0, 640, 480, dma_buf);
d->activate_fpbuffer();
d->clear_fpbuffer();

  d->bindTextureARB0(0);

  newdata = 0;
  v4l2->tellThreadDoneWithBuffer();

    d->applyFilter(filter1, 0,1);
/*
    //cascade the filters
    //d->applyFilter(filter1, 0,1, .25, .75, .25, .75); //texture 1 holds undistorted
   // d->applyFilter(filter1, 0,1, fL, fR, fT, fB); //texture 1 holds undistorted
    d->applyFilter(filter2, 1,2, fL, fR, fT, fB); //texture 2 holds x deriv
    d->applyFilter(filter3, 1,3, fL, fR, fT, fB); //texture 3 holds y deriv

    d->bindTextureARB1(3);        //place texture 3 into unit 1

    d->applyFilter(magdir, 2, 4, fL, fR, fT,fB );  //use texture 2, unit0, result to tex4
    d->applyFilter(cannysearch, 4, 5, fL, fR, fT,fB );  //tex4: magdir, tex5 search result
    //optim fodder, (could collapse canny->tangent into a single prog)
    d->applyFilter(tangent, 5, 6, fL, fR, fT,fB );  //tex
    d->applyFilter(gaussianX, 6, 7, fL, fR, fT,fB );  //tex
    d->applyFilter(gaussianY, 7, 8, fL, fR, fT,fB );  //tex

    d->bindTextureARB1(5);        //place canny edgels into texunit 1
    d->bindTextureARB2(0);        //place canny edgels into texunit 1
    //d->applyFilter(derandom, 8, 9, fL, fR, fT,fB );
    d->applyFilter(derandom, 8, 9);
*/

d->deactivate_fpbuffer();

  glMatrixMode(GL_MODELVIEW_MATRIX);
  glLoadIdentity( );
  glTranslatef( xp, yp,  zp);
  glRotatef( xrot, 1.0f, 0.0f, 0.0f); /* Rotate On The X Axis */
  glRotatef( yrot, 0.0f, 1.0f, 0.0f); /* Rotate On The Y Axis */
  glRotatef( zrot, 0.0f, 0.0f, 1.0f); /* Rotate On The Z Axis */


  d->bindTextureARB0(viewbuf);
  d->renderAt();
  d->showstats();

  glutSwapBuffers();
}  


///// MAIN ///////////////////

int main(int argc, char** argv)
{
   glutInit(&argc, argv);

   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);

   v4l2 = new V4L2();
   v4l2->start();
   d=new FragPipeDisplay(10, imageWinWidth, imageWinHeight, Orbwin );
   d->initDisplay();
   d->setImageSize( 640,480 );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-basic.cg");

   d->init_texture(0, 640,480, foo);
   d->init_texture4f(1, 640,480, foo);
   d->init_texture4f(2, 640, 480, foo);   
   d->init_texture4f(3, 640, 480, foo);
   d->init_texture4f(4, 640, 480, foo);
   d->init_texture4f(5, 640, 480, foo);
   d->init_texture4f(6, 640,480, foo);
   d->init_texture4f(7, 640, 480, foo);   
   d->init_texture4f(8, 640, 480, foo);
   d->init_texture4f(9, 640, 480, foo);
   d->init_texture4f(10, 640, 480, foo);
/*   
   filter1 = new  GenericFilter(640,480, d->getContext(), d->getProfile(),
                               "FPsamples/FP-v4l2-endianconvert.cg");
*/
   filter1 = new GenericFilter(640,480, d->getContext(), d->getProfile(),
 //                              "FPsamples/FP-ibot-undistort.cg");
                               "FPsamples/FP-v4l2-endianconvert.cg");
   filter2 = new GenericFilter(640,480, d->getContext(), d->getProfile(),
                               "FPsamples/FP-gaussianderiv-sigma1-x.cg");
   filter3 = new GenericFilter(640,480, d->getContext(), d->getProfile(),
                               "FPsamples/FP-gaussianderiv-sigma1-y.cg");
   magdir = new GenericFilter(640,480, d->getContext(), d->getProfile(),
                               "FPsamples/FP-magdir.cg");

   cannysearch = new GenericFilter(640,480, d->getContext(), d->getProfile(),
                               "FPsamples/FP-canny-search.cg");
   cannysearch->setCGParameter( "thresh", cannythresh);

   tangent = new GenericFilter(640,480, d->getContext(), d->getProfile(),
                               "FPsamples/FP-tangent.cg");
   gaussianX = new GenericFilter(640,480, d->getContext(), d->getProfile(),
                               "FPsamples/FP-gaussian-sigma3-x-rgb.cg");
   gaussianY = new GenericFilter(640,480, d->getContext(), d->getProfile(),
                               "FPsamples/FP-gaussian-sigma3-y-rgb.cg");
   derandom = new GenericFilter(640,480, d->getContext(), d->getProfile(),
                               "FPsamples/FP-canny-overlay.cg");
   derandom->setCGParameter( "thresh", derandomthresh);


   glutSetWindow(Orbwin);
   glutFullScreen();
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}
