/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _SIMPLEDISPLAY_H
#define _SIMPLEDISPLAY_H

#include "GenericDisplay.h"
#include "fpc.h"
#include "FragmentProgram.h"

class SimpleDisplay : public GenericDisplay
{
 public:
  int num_textures;
  GLuint *texNames;
  SimpleDisplay(int num_textures, int imageWinWidth, int imageWinHeight, int win);
  ~SimpleDisplay() {};
  CFPBuffer fpbuffer;
  FragmentProgram *FPSimple;

  // implement the interface
  void initGL();
  void initGL(char *cgfname);
  void init_texture(int id, int width, int height, void *data);
  void reinit_texture(int id, int width, int height, void *data);
  void bindTextures();
  void idleFunc();
  void render();
  //renderAt does not clear out the modelview matrix to identity 
  void renderAt();
  void grabDisplay(float *Dm, float *Dn, float *Dt, float *Da,  int);
  void grabDisplay(unsigned char *Dm, unsigned char *Dn, unsigned char *Dt);
  void sumDisplay(float *R, float *G, float *B, float *A);
  void showstats();

  void activate_fpbuffer();
  void deactivate_fpbuffer();
  void clear_fpbuffer();
  void render_to_texture(int);
  void init_texture4f(int id, int width, int height, void *data);
  void init_texture4c(int id, int width, int height, void *data);
  void reinit_texture1f(int id, int width, int height, void *data) ;
  void SimpleDisplay::drawTexture( GLenum TEXTURE_UNIT ) ;
  void render_to_texture(int, int, int, int, int);
  void render_to_texture_ARB1(int, int, int, int, int);
  void bindTextureARB0(int);

};

#endif

