/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <math.h>
#include <iostream>
#include "tnt.h"
#include "jama_svd.h"
#include "Parameters.h"

int VERBOSE = 0;

//using namespace std;
using namespace TNT;
using namespace JAMA;

#define M 3
#define N 3

int planarCoords(  int x1, int y1,
                   int x2, int y2,
                   int x3, int y3,
                   int x4, int y4,
                   float result[12] )
{
//points: 94 78 180 54 292 142 146 210
//result = 30.4517 -5.01673 368.665 0.922742 
//       -0.250511 0.292902 -0.377607 -0.43537
/*
  int x1 = 94;
  int y1 = 78;
  int x2 =180;
  int y2 = 54;
  int x3 =292;
  int y3 =142;
  int x4 =146;
  int y4 =210;
*/

  int bbox[2][5] = {  {x1, x2, x3, x4, x1}, 
                  {y1, y2, y3, y4, y1} };

  double fl[2] = {368.28488, 369.04519};
  double principal_point[2] = {147.54834, 126.01673};
  double distortion[4] = {-0.4142, 0.40348, -0.00085,
                          0.0009};

  double camera_matrix[9];
  camera_matrix[0] = fl[0];
  camera_matrix[1] = 0;
  camera_matrix[2] = principal_point[0];
  camera_matrix[3] = 0;
  camera_matrix[4] = fl[1];
  camera_matrix[5] = principal_point[1];
  camera_matrix[6] = 0;
  camera_matrix[7] = 0;
  camera_matrix[8] = 1;

  double f = (fl[0] + fl[1])/2.0;

  double Mint[3][3] = {fl[0], 0, principal_point[0],
                      0, fl[1], principal_point[1],
                      0, 0, 1};

  double par[3][4];
  for( int L=0 ; L<=3 ; L++ ) {
    double partmp[2];
    partmp[0] = (bbox[0][L]-bbox[0][L+1]);
    partmp[1] = (bbox[1][L]-bbox[1][L+1]);
/*
    double norm = sqrt(pow( (bbox[0][L]-bbox[0][L+1]),2 ) + 
                       pow( (bbox[1][L]-bbox[1][L+1]),2 ) ) ;
*/
    double norm = sqrt(pow((double) (bbox[0][L]-bbox[0][L+1]),(double)2.0 ) + 
                       pow((double) (bbox[1][L]-bbox[1][L+1]),(double)2.0 ) ) ;
    double t[2];
    t[0] = partmp[0]/norm;
    t[1] = partmp[1]/norm;
    //cerr<<"t ="<<t[0]<<" "<<t[1]<<endl;
   
    par[0][L] = -t[1];
    par[1][L] =  t[0];
    par[2][L] = -bbox[0][L]*par[0][L] + -bbox[1][L]*par[1][L];
  }
  for( int j=0; j<3; j++ ) {
    for( int i=0; i<4; i++ ) {
      //cerr<<par[j][i]<<" ";
    }
    //cerr<<endl;
  }
  double int1[3];
  int1[0] = par[1][0]*par[2][2] - par[2][0]*par[1][2];
  int1[1] = par[2][0]*par[0][2] - par[0][0]*par[2][2];
  int1[2] = par[0][0]*par[1][2] - par[1][0]*par[0][2];
  //cerr<<int1[0]<<endl;
  //cerr<<int1[1]<<endl;
  //cerr<<int1[2]<<endl;

  int1[0]/=int1[2];
  int1[1]/=int1[2];
  int1[2]/=int1[2];

  double int2[3];
  int2[0] = par[1][1]*par[2][3] - par[2][1]*par[1][3];
  int2[1] = par[2][1]*par[0][3] - par[0][1]*par[2][3];
  int2[2] = par[0][1]*par[1][3] - par[1][1]*par[0][3];
   
  int2[0]/=int2[2];
  int2[1]/=int2[2];
  int2[2]/=int2[2];

  //cerr<<"int2"<<endl;
  //cerr<<int2[0]<<endl;
  //cerr<<int2[1]<<endl;
  //cerr<<int2[2]<<endl;
  double planevec1[3] = { int1[0]-principal_point[0], 
                         int1[1]-principal_point[1],
                         f };
  //cerr<<"planevec "<<planevec1[0]<<" "<<planevec1[1]<<" "<<planevec1[2]<<endl;
  double planevecnorm1 = sqrt(
                          planevec1[0]*planevec1[0] +
                          planevec1[1]*planevec1[1] +
                          planevec1[2]*planevec1[2] );
  planevec1[0]/=planevecnorm1;
  planevec1[1]/=planevecnorm1;
  planevec1[2]/=planevecnorm1;
  //cerr<<"planevec "<<planevec1[0]<<" "<<planevec1[1]<<" "<<planevec1[2]<<endl;

  //////////////////
  double planevec2[3] = { int2[0]-principal_point[0], 
                         int2[1]-principal_point[0],
                         f };
  //cerr<<"planevec2 "<<planevec2[0]<<" "<<planevec2[1]<<" "<<planevec2[2]<<endl;
  double planevecnorm2 = sqrt(
                          planevec2[0]*planevec2[0] +
                          planevec2[1]*planevec2[1] +
                          planevec2[2]*planevec2[2] );
  planevec2[0]/=planevecnorm2;
  planevec2[1]/=planevecnorm2;
  planevec2[2]/=planevecnorm2;
  //cerr<<"planevec2 "<<planevec2[0]<<" "<<planevec2[1]<<" "<<planevec2[2]<<endl;

  double n[3] = { planevec1[1]*planevec2[2]-planevec1[2]*planevec2[1],
                 planevec1[2]*planevec2[0]-planevec1[0]*planevec2[2],
                 planevec1[0]*planevec2[1]-planevec1[1]*planevec2[0] };
  double ncrossnorm = sqrt( n[0]*n[0] + n[1]*n[1] + n[2]*n[2] ) ;

  n[0]/=ncrossnorm;
  n[1]/=ncrossnorm;
  n[2]/=ncrossnorm;
  //cerr<<"n = "<<n[0]<<" "<<n[1]<<" "<<n[2]<<endl;
  if( n[2] < 0 ) 
  {
    n[0]*=-1.0;
    n[1]*=-1.0;
    n[2]*=-1.0;
  }
  //cerr<<"n = "<<n[0]<<" "<<n[1]<<" "<<n[2]<<endl;


  double R3[3] = { n[0], n[1], n[2] };

  double R2[3] = {planevec2[0], planevec2[1], planevec2[2]};
  if( R2[1] < 0 ) { R2[0]*=-1.0; R2[1]*=-1.0; R2[2]*=-1.0; }

  double R1[3] = {planevec1[0], planevec1[1], planevec1[2]};
  if( R1[0] < 0 ) { R1[0]*=-1.0; R1[1]*=-1.0; R1[2]*=-1.0; }

  double iR[3][3] = { R1[0], R2[0], R3[0],
                     R1[1], R2[1], R3[1],
                     R1[2], R2[2], R3[2] };
  //cerr<<"iR"<<endl;
  //cerr<<iR[0][0]<<" "<<iR[0][1]<<" "<<iR[0][2]<<endl;
  //cerr<<iR[1][0]<<" "<<iR[1][1]<<" "<<iR[1][2]<<endl;
  //cerr<<iR[2][0]<<" "<<iR[2][1]<<" "<<iR[2][2]<<endl;
if( VERBOSE ) {
  printf("iR before SVD is\n"); 
  for (int i=0; i < M; i++) {
     for (int j=0; j < N; j++)
       printf("%g ", iR[i][j]);
     printf("\n");
  } 
}
 Array2D< double > A(M,N) ;      /* create MxN array; all zeros */
 Array2D< double > SingVal(M,N) ;      /* create MxN array; all zeros */
 Array2D< double > U(M,N) ;      /* create MxN array; all zeros */
 Array2D< double > V(M,N) ;      /* create MxN array; all zeros */
/*
 A[0][0]=  iR[0][0];
 A[0][1]=  iR[1][0];
 A[0][2]=  iR[2][0];
 A[1][0]=  iR[0][1];
 A[1][1]=  iR[1][1];
 A[1][2]=  iR[2][1];
 A[2][0]=  iR[0][2];
 A[2][1]=  iR[1][2];
 A[2][2]=  iR[2][2];
*/

 A[0][0]=  iR[0][0];
 A[0][1]=  iR[0][1];
 A[0][2]=  iR[0][2];
 A[1][0]=  iR[1][0];
 A[1][1]=  iR[1][1];
 A[1][2]=  iR[1][2];
 A[2][0]=  iR[2][0];
 A[2][1]=  iR[2][1];
 A[2][2]=  iR[2][2];


 SVD<double> x(A);

  x.getS( SingVal);
  x.getU( U);
  x.getV( V);
if( VERBOSE ) {
  for (int i=0; i < M; i++) {
     for (int j=0; j < N; j++)
       printf("%g ", SingVal[i][j]);
     printf("\n");
  }   



  printf("\n");
  printf("U is\n");
  for (int i=0; i < M; i++) {
     for (int j=0; j < N; j++)
       printf("%g ", U[i][j]);
     printf("\n");
  } 

     printf("\n");
  printf("V is\n");
  for (int i=0; i < M; i++) {
     for (int j=0; j < N; j++)
       printf("%g ", V[i][j]);
     printf("\n");
  } 
     printf("\n");
}

  double newiR[3][3]= {0.0};
  for( int i=0 ; i<3 ;i++) {
    for( int j=0 ; j<3 ;j++) {
      for( int k=0; k<3; k++ ) {
        newiR[i][j] += U[i][k]*V[j][k];
      }
    }
  }
  if( newiR[0][0] < 0 ) { 
    newiR[0][0] *= -1.0; newiR[1][0] *= -1.0; newiR[2][0] *= -1.0;
  }
  if( newiR[1][1] < 0 ) { 
    newiR[0][1] *= -1.0; newiR[1][1] *= -1.0; newiR[2][1] *= -1.0;
  }
  if( newiR[0][0] < 0 ) { 
    newiR[0][2] *= -1.0; newiR[1][2] *= -1.0; newiR[2][2] *= -1.0;
  }
if( VERBOSE ) {
  printf("newiR is\n");
  for (int i=0; i < M; i++) {
     for (int j=0; j < N; j++)
       printf("%g ", newiR[i][j]);
     printf("\n");
  } 
}
/*
  printf("newiR-normalized is\n");
  for (int i=0; i < M; i++) {
     for (int j=0; j < N; j++) {
        newiR[i][j]/=newiR[2][2];
     }
  } 
*/

/*
  Parameters P( newiR[0][0], newiR[1][0], newiR[2][0],
                newiR[0][1], newiR[1][1], newiR[2][1],
                newiR[0][2], newiR[1][2] );
  P.invert();
  P.print();
*/

  double irInverse[3][3];
  double a=newiR[0][0];
  double b=newiR[0][1];
  double c=newiR[0][2];
  double d=newiR[1][0];
  double e=newiR[1][1];
  double fmat=newiR[1][2];
  double g=newiR[2][0];
  double h=newiR[2][1];
  double i=newiR[2][2];

  double det = (a*e*i + b*fmat*g + d*h*c - g*e*c - a*h*fmat - d*b*i);
  //double det = (a*e + b*fmat*g + d*h*c - g*e*c - a*h*fmat - d*b);
if( VERBOSE ) {
  fprintf(stderr, "det: %f\n", det);
}

  irInverse[0][0] = (e*i - fmat*h) / det;
  irInverse[0][1] = (-b*i + c*h) / det;
  irInverse[0][2] = (b*fmat - c*e) / det;
  irInverse[1][0] = (-d*i + fmat*g) / det;
  irInverse[1][1] = (a*i - c*g) / det;
  irInverse[1][2] = (c*d - a*fmat) / det;
  irInverse[2][0] = (d*h - e*g) / det;
  irInverse[2][1] = (b*g - a*h) / det;
  irInverse[2][2] = (a*e - b*d) / det;
if( VERBOSE) {
  printf("inverseiR is\n");
  for (int i=0; i < M; i++) {
     for (int j=0; j < N; j++)
       printf("%g ", irInverse[i][j]);
     printf("\n");
  } 
}

  a=Mint[0][0];
  b=Mint[0][1];
  c=Mint[0][2];
  d=Mint[1][0];
  e=Mint[1][1];
  fmat=Mint[1][2];
  g=Mint[2][0];
  h=Mint[2][1];
  i=Mint[2][2];

  det = (a*e*i + b*fmat*g + d*h*c - g*e*c - a*h*fmat - d*b*i);
if( VERBOSE ){
  fprintf(stderr, "det: %f\n", det);
}
  double MintInverse[3][3];
  MintInverse[0][0] = (e*i - fmat*h) / det;
  MintInverse[0][1] = (-b*i + c*h) / det;
  MintInverse[0][2] = (b*fmat - c*e) / det;
  MintInverse[1][0] = (-d*i + fmat*g) / det;
  MintInverse[1][1] = (a*i - c*g) / det;
  MintInverse[1][2] = (c*d - a*fmat) / det;
  MintInverse[2][0] = (d*h - e*g) / det;
  MintInverse[2][1] = (b*g - a*h) / det;
  MintInverse[2][2] = (a*e - b*d) / det;

if( VERBOSE ){
  printf("MintInverse is\n");
  for (int i=0; i < M; i++) {
     for (int j=0; j < N; j++)
       printf("%g ", MintInverse[i][j]);
     printf("\n");
  } 
}
  double coordOr[2];
  coordOr[0] = (bbox[0][0] + bbox[0][1] + bbox[0][2] + bbox[0][3])/4.0;
  coordOr[1] = (bbox[1][0] + bbox[1][1] + bbox[1][2] + bbox[1][3])/4.0;
if( VERBOSE ){
  printf("coordOr = %g,  %g\n", coordOr[0], coordOr[1] );
}

  double oxIm = coordOr[0]-principal_point[0];
  double oyIm = coordOr[1]-principal_point[1];
  double ozIm = f;
if( VERBOSE ){
  printf("oxIm = %g\n",oxIm);
  printf("oyIm = %g\n",oyIm);
  printf("ozIm = %g\n",ozIm);
}

  double Xvec[3] = { newiR[0][0], newiR[1][0], newiR[2][0] };
  double Yvec[3] = { -newiR[0][1], -newiR[1][1], -newiR[2][1] };
  double Zvec[3] = { -newiR[0][2], -newiR[1][2], -newiR[2][2] };

if( VERBOSE ){
  printf("Xvec = %g, %g, %g\n", Xvec[0], Xvec[1], Xvec[2]);
  printf("Yvec = %g, %g, %g\n", Yvec[0], Yvec[1], Yvec[2]);
  printf("Zvec = %g, %g, %g\n", Zvec[0], Zvec[1], Zvec[2]);
}

  result[0] = oxIm;
  result[1] = oyIm;
  result[2] = ozIm;
  result[3] = Xvec[0];
  result[4] = Xvec[1];
  result[5] = Xvec[2];

  result[6] = Yvec[0];
  result[7] = Yvec[1];
  result[8] = Yvec[2];

  result[9] = Zvec[0];
  result[10] = Zvec[1];
  result[11] = Zvec[2];
  return 0;
}
