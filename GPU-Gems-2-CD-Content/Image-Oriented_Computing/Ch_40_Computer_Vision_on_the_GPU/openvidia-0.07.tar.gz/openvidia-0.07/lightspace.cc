/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "GenericDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"
#include "FragPipeDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include "Correspond.h"
#include "Parameters.h"
#include <iostream>
using namespace std;

// Global display object
FragPipeDisplay *d;
Dc1394 *dc1394;
GenericFilter *filter1, *filter2, *filter3;
GenericFilter *filterBlend;
MomentFilter *momentFilter;
Grab_JPEG *writer;
Correspond *corr;
ImlibCapture *im;
unsigned char tmpbuf[320*240*4];

int imageWinWidth = 320;
int viewbuf = 0;
int imageWinHeight = 240;
Window  Orbwin;

float BlendAmt = 0.0;

float setBlend( float b )
{
   float blend[4] = {b, 0.0, 0.0, 0.0};
   filterBlend->setCGParameter("BlendFactor", blend);
}



////// GLUT CALLBACKS ///////////////
void reshape(int w, int h)
{
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  //rosco version
  glFrustum(-1.0,1.0,-1.0,1.0,1.0,100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,-1.0,   0.0, 1.0, 0.0);

  //james version
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);

  //set the fpbuffer to have geometry identical to screen
  d->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  d->deactivate_fpbuffer();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case '0': viewbuf = 0; break;
      case '1': viewbuf = 1; break;
      case '2': viewbuf = 2; break;
      case '3': viewbuf = 3; break;
      case '4': viewbuf = 4; break;
      case '5': viewbuf = 5; break;
      case '6': viewbuf = 6; break;
      case '7': viewbuf = 7; break;
      case 27:
         exit(0);
         break;
      case '+' :
         BlendAmt += 0.1; 
         if( BlendAmt > 1.0 ) BlendAmt = 1.0;
         setBlend(BlendAmt);
         cerr<<"Blend : "<<BlendAmt<<endl;
         break;
      case '-' :
         BlendAmt -= 0.1; 
         if( BlendAmt < 0.0 ) BlendAmt = 0.0;
         setBlend(BlendAmt);
         cerr<<"Blend : "<<BlendAmt<<endl;
         break;
      case 'g' :
         glReadPixels( 0, 0, imageWinWidth, imageWinHeight, 
                       GL_RGB, GL_UNSIGNED_BYTE, tmpbuf );
         //generate a filename reflecting settings.
         char filename[256]; 
         sprintf(filename, "Blend_buffer-%d_factor-%0.1f.jpg",
                 viewbuf, BlendAmt );
         cerr<<"Writing file "<<filename<<endl;
         //write file. request invert = true (because of readpixels)
         writer->grab_frame(tmpbuf, imageWinWidth, imageWinHeight,
                       0, filename, true);
         break;
      default:
         break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        float pixbuf[4] = {0.0};
        cerr << "("<<x<<","<<y<<"):";
        glReadPixels( x, 240-y, 1,1, GL_RGBA, GL_FLOAT,  (void *)pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
 
        corr->add_point(x,y); 
      }
      break;
    case GLUT_RIGHT_BUTTON : 
      if( state == GLUT_DOWN ) {
        double p[8];
        float *chirpmat; //danger. werre really affecting internal object
        dc1394->lock();
        corr->shell_Corr2p(p); 
        dc1394->unlock();
        Parameters P(p[0],p[1],p[2],p[3],p[4],p[5],p[6],p[7]);
        P.invert();
        P.print();
        d->setChirpMatParams(P.get()); 
        chirpmat = d->getChirpMat();
        chirpmat[2] = -chirpmat[2];
        chirpmat[6] = -chirpmat[6];
        chirpmat[10] = -chirpmat[10];
          filterBlend->setCGParameter4x4("P", chirpmat);
        chirpmat[2] = -chirpmat[2];
        chirpmat[6] = -chirpmat[6];
        chirpmat[10] = -chirpmat[10];
      }
      break;
    case GLUT_MIDDLE_BUTTON :
      if( state == GLUT_DOWN ) {
        corr->clear_points();
      }
      break;

  }
}
unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(320*240*3);
int newdata=0;
/* Tell function executed in context of Dc1394 thread */
void TellRWMHeCanUseImage(const char *dma_buf_) {
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;

  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;
  uyvy2rgb(dma_buf,dma_buf_rgb,320*240);

  //have only one, need two before we do any orbits
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }

  newdata=1;
}

int framecounter=0;
float *foo[320*240*4];
void render_redirect() {
  ++framecounter;
/*
  if(!newdata)  {  struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 1000;
     select(0,0,0,0, &tv);
 return;}
  newdata = 0; 
*/
  d->activate_fpbuffer();
  d->clear_fpbuffer();
    d->reinit_texture(0, 320, 240, dma_buf_rgb);
    //d->reinit_texture(7, 320, 240, im->getRGBData());
    d->bindTextureARB0(0);
    d->bindTextureARB1(7);
    dc1394->tellThreadDoneWithBuffer();

    //cascade the filters
    d->applyFilter(filter1, 0,1); //radial
    d->bindTextureARB1(7);
    d->applyFilter(filter2, 1,2); //f2q
    d->applyFilter(filter2, 7,5); //f2q

    d->bindTextureARB1(5);
      //the following ops are done in lightspace now
      d->applyFilter(filterBlend, 2, 3);
      //    d->applyFilter(filterb1, 3,4);

    d->applyFilter(filter3, 3,4); //q2f


    //image space blend
    d->bindTextureARB0(1); //use radial undistorted image
    d->bindTextureARB1(7);
    d->applyFilter(filterBlend, 1, 6);

  
  d->deactivate_fpbuffer();

  d->bindTextureARB0(viewbuf);
  d->render();

  d->showstats();
  glutSwapBuffers();
}  


///// MAIN ///////////////////

int main(int argc, char** argv)
{
   glutInit(&argc, argv);

   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);

   dc1394=new Dc1394();
   dc1394->start();
   d=new FragPipeDisplay(18, imageWinWidth, imageWinHeight, Orbwin );

   d->initDisplay();
   d->setImageSize( 320,240 );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-basic.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?

   im = new ImlibCapture();
   im->initCapture((GenericDisplay *)d);
   //im->loadFile("/home/fungja/c007c.ppm");
   im->loadFile(argv[1]);


   //d->activate_fpbuffer();
   d->init_texture(0, 320, 240, foo);
   d->init_texture4f(1, 320, 240, foo);
   d->init_texture4f(2, 320, 240, foo);
   d->init_texture4f(3, 320, 240, foo);
   d->init_texture4f(4, 320, 240, foo);
   d->init_texture4f(5, 320, 240, foo);
   d->init_texture4f(6, 320, 240, foo);
   d->init_texture(7, 320, 240, im->getRGBData() );
   

   filter1 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-ibot-undistort.cg");
   filter2 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-f2q.cg");
   float camp[4] = {4.0, 0.15, 0.0, 0.0};
   filter2->setCGParameter("lsparams", camp);

   filter3 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-q2f.cg");
   filter3->setCGParameter("lsparams", camp);

   filterBlend = new GenericFilter(320,240,d->getContext(), d->getProfile(),
                               "FPsamples/FP-blend.cg");
   setBlend(BlendAmt);
   writer = new Grab_JPEG();

   corr = new Correspond(320,240);

   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}
