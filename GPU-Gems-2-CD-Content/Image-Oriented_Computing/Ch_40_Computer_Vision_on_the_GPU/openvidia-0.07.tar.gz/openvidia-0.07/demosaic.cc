/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "GenericDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"
#include "FragPipeDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include <iostream>
using namespace std;

// Global display object
FragPipeDisplay *d;
ImlibCapture *im;
GenericFilter *filter1, *filter2, *filter3, *filter4;
MomentFilter *momentFilter;

//int imageWidth = 2464;
//int imageHeight = 1632;
int imageWidth = 2482;
int imageHeight = 1648;
int imageWinWidth = imageWidth/2;
int imageWinHeight = imageHeight/2;

int viewbuf = 0;
Window  Orbwin;


///global state
bool useImlib = true;
float HAND_X_COORD=0.0;
float HAND_Y_COORD=0.0;

float zoom=1.0;
float pan_x=0.0;
float pan_y=0.0;




void reshape(int w, int h);
void myIdle();
void keyboard (unsigned char key, int x, int y);
void MouseFunc( int button, int state, int x, int y) ;
void TellRWMHeCanUseImage(const char *dma_buf_){} ;

int framecounter=0;
int newdata=0;
float *foo[2482*1648*4*4];



void render_redirect() {
  ++framecounter;
 //write one version to floating point buffer, full resolution for saving
d->activate_fpbuffer();
  d->bindTextureARB0(0);
  d->bindTextureARB1(1);
  d->bindTextureARB2(2);
  d->applyFilter(filter1, 0, 4);
  //write one version to screen resolution for viewing zoom/pan etc
d->deactivate_fpbuffer();
  d->bindTextureARB0(0);
  d->bindTextureARB1(1);
  d->bindTextureARB2(2);
  d->applyFilter(filter1, 0, 4);
  glutSwapBuffers();
}  


///// MAIN ///////////////////

void usage()
{
  cout<<"keys: +/- zoom, h,j,k,l pan, 'g' grabs and image (full original res)";
  cout<<", q quits"<<endl;
}


int main(int argc, char** argv)
{
   glutInit(&argc, argv);

   //if an argument is given, assume we are using an image file
   cout<<"Using image file: "<<argv[1]<<endl;
   useImlib = true;
   usage();
   
   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(0, 0);
   Orbwin=glutCreateWindow(argv[0]);


   //typical problem : can't open imlib without display, yet cant
   // size display without loading image from imlib
   d=new FragPipeDisplay(8, imageWinWidth, imageWinHeight, Orbwin );
   d->initDisplay();

   if( useImlib ) { 
     im = new ImlibCapture(0,0);
     im->initCapture(d);
     im->loadFile(argv[1]); 
   }
   else {
   }

   assert(im->getRGBWidth()==imageWidth);
   d->setImageSize( imageWidth , imageHeight );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-bayerinterp.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?
   //d->activate_fpbuffer();
   d->init_texture_NPof4(0, imageWidth, imageHeight, im->getRGBData() );

   im->loadFile(argv[2]); 
   d->init_texture_NPof4(1, imageWidth, imageHeight, im->getRGBData() );

   im->loadFile(argv[3]); 
   d->init_texture_NPof4(2, imageWidth, imageHeight, im->getRGBData() );

   d->init_texture4f(3, imageWidth, imageHeight, foo);

   filter1 = new GenericFilter(imageWidth,imageHeight, 
                               d->getContext(), d->getProfile(), 
                               "FPsamples/FP-bayerinterp.cg");
   filter1->turnFlipOn();
   //dont bother setting identity. save paraemter input registers
   //float P0[9] = {1.0, 0.1, 0.01, 0.1, 1.0, 0.10, 0.0, 0.0, 1.0};
   float P1[9] = {0.999791, -0.000230, 0.000013, 
                -0.000023, 0.999489, 0.002925, 
                 0.000025, -0.000612, 1.0};
   float P2[9] = {0.999048, -0.000152, 0.001359, 
                 -0.000317, 0.998526, 0.006465, 
                 -0.000134, -0.001292, 1.0};
   //filter1->setCGParameter3x3("P0", P0);
   filter1->setCGParameter3x3("P1", P1);
   filter1->setCGParameter3x3("P2", P2);
   float dim[4] = { (float)imageWidth, (float)imageHeight, 1.0, 1.0};
   filter1->setCGParameter("dimensions", dim);

  int max_texture_size;
  glGetIntegerv(GL_MAX_TEXTURE_SIZE, &max_texture_size);
  cerr<<"max_texture_size "<<max_texture_size<<endl;


   //read in location settings (zoom, panx, pany) 
   zoom = atof(argv[4]);
   pan_x= atof(argv[5]);
   pan_y= atof(argv[6]);

   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}










////////////////////
////// GLUT CALLBACKS ///////////////
////////////////////
void reshape(int w, int h)
{
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  //james version
  glFrustum( (0.0+pan_x)*zoom, 
             (1.0+pan_x)*zoom,  
             (1.0+pan_y)*zoom, 
             (0.0+pan_y)*zoom,   
             1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);

  //set the fpbuffer to have geometry identical to screen
  d->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  //glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glViewport(0, 0, (GLsizei) imageWidth, (GLsizei) imageHeight);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  d->deactivate_fpbuffer();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();


  glutPostRedisplay();
}



void redraw()
{
  cerr<<"zoom pan_x pan_y: "<<zoom<<" "<<pan_x<<" "<<pan_y<<endl;
  reshape(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT) );
  glutPostRedisplay();
}

void myIdle(){
  //glutSetWindow(Orbwin);
  //glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
         viewbuf = atoi((const char * )&key);
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case '-':
         zoom *= 1.05;
         redraw();
         break;

      case '+':
         zoom *= 1.0/1.05;
         redraw();
         break;

      case 'h':
         pan_x -= 0.05;
         redraw();
         break;

     case 'l':
         pan_x += 0.05;
         redraw();
         break;

     case 'j':
         pan_y += 0.05;
         redraw();
         break;

    case 'k':
         pan_y -= 0.05;
         redraw();
         break;

    case 'g':
        {
        //writes out floating point buffer contents (full image)
        //note, 2480 is used instead of 2482 because of byte boundary problems
        unsigned char pixbuf[2482*1648*2]; 
d->activate_fpbuffer();
        //glReadPixels( 0, glutGet(GLUT_WINDOW_HEIGHT)-240, 320,240,
        //              GL_RED, GL_UNSIGNED_BYTE, pixbuf );
        glReadPixels( 0, 0, 2480,1648,
                      GL_RED, GL_UNSIGNED_BYTE, pixbuf );
d->deactivate_fpbuffer();
        FILE *FP = fopen("latest.pnm", "w");
        //fprintf(FP, "P5\n320\n240\n255\n");
        //fwrite( pixbuf, 320*240,1, FP);
        fprintf(FP, "P5\n2480\n1648\n255\n");
        fwrite( pixbuf, 2480,1648, FP);
        fclose(FP);
        }
        break;

    case 'r':
         cerr<<"Resetting zoom/pan settings."<<endl;
         pan_x = 0.0;
         pan_y = 0.0;
         zoom = 1.0;
         redraw();
         break;

      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        float pixbuf[4] = {0.0};
        cerr << "("<<x<<","<<y<<"):";
        glReadPixels( (float)x,glutGet(GLUT_WINDOW_HEIGHT)-(float)y, 1,1, GL_RGBA, GL_FLOAT,  pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
      }
      break;
    case GLUT_RIGHT_BUTTON : 
      break;
  }
}

