/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _GENERIC_DISPLAY_H
#define _GENERIC_DISPLAY_H

#include <GL/gl.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/shape.h>
#include <iostream>
using namespace std;

// abstract base class
class GenericDisplay {
  Display *disp;
 protected:
  int ImageWidth;  //widht of incoming image being textured
  int ImageHeight; //height of incoming image being textured
  int downsample_level;
  float chirpmat[16];
  int imageWinWidth; //width of display window
  int imageWinHeight; //height of display window
  int winID;
 
  //for framerate statistics 
  int lasttime;
  int fpscounter;
  int fps;

  //for texture folding
  int fraction;

 public:
  // for some reason i cant have no constructor GenericDisplay??
  GenericDisplay(int win) { 
    winID = win; 
    lasttime = 0; 
    fpscounter =0; 
    fps=0;
    //fraction = 30; //TODO XXX this should be checked against the FP fraction
    fraction = 1; //TODO XXX this should be checked against the FP fraction
  };
  virtual ~GenericDisplay() {};
  void initDisplay() {
    //disp=XOpenDisplay(NULL);
    disp=XOpenDisplay(":0.0");
  }

  void setImageSize( int W, int H ) { ImageWidth = W; ImageHeight = H; }
  int getImageWidth() { return ImageWidth; }
  int getImageHeight() { return ImageHeight; }
  int setDownsampleLevel( int newlevel ) 
        { return (downsample_level = newlevel); }
  int getDownsampleLevel() { return downsample_level; }
  //just pass them in with the same order orbits returns


  float *getChirpMat() { return chirpmat; }
  //void setChirpMat(float a11, float a12, float b1, float a21, 
  //                 float a22, float b2, float c1, float c2 ) {
  void setChirpMat(double a11, double a12, double b1, double a21, 
                   double a22, double b2,  double c1, double c2 ) {
    chirpmat[0] = (float)a22;
    chirpmat[4] = (float)a21;
    chirpmat[8] = (float)b2;
    chirpmat[12] =(float)  0;
    chirpmat[1] = (float)a12;
    chirpmat[5] = (float)a11;
    chirpmat[9] = (float)b1;
    chirpmat[13] =(float) 0;
    chirpmat[2] = (float)-c2;
    chirpmat[6] = (float)-c1;
    chirpmat[10]= (float)-1;
    chirpmat[14]= (float)0;
    chirpmat[3] = (float)0;
    chirpmat[7] = (float)0;
    chirpmat[11]= (float)0;
    chirpmat[15]= (float)1;
   }

  void setChirpMatParams( double p[8]) 
  {
    setChirpMat(p[0],p[1],p[2],p[3],
                p[4],p[5],p[6],p[7]);
  }

  void getChirpMatParams( double *p) 
  {
    p[0]=(double)chirpmat[5];
    p[1]=(double)chirpmat[1];
    p[2]=(double)chirpmat[9];
    p[3]=(double)chirpmat[4];
    p[4]=(double)chirpmat[0];
    p[5]=(double)chirpmat[8];
    p[6]=(double)-chirpmat[6];
    p[7]=(double)-chirpmat[2];
  }
  void printChirpMatParams() {
    double p[8];
    getChirpMatParams(p);
    cerr<<p[0]<<", "<<p[1]<<", "<<p[2]<<", "<<p[3]<<", ";
    cerr<<p[4]<<", "<<p[5]<<", "<<p[6]<<", "<<p[7]<<endl;
  }
  virtual void printChirpMat() {};
  void setFraction(int f) { fraction = f;}
  int getFraction() { return fraction; }


  virtual void initGL() {}
  virtual void init_texture(int id, int width, int height, void *data) {}
  virtual void init_texture(int id, int width, int height, int nchans, 
                                       void *data) {}
  virtual void bindTextures() {}
  virtual void idleFunc() {}
  virtual void render() {}
  virtual void render_vid(float,float) {}
  virtual void grabDisplay(float *Dm, float *Dn, float *Dt, float *Da, int) {} 
  virtual void grabDisplay(unsigned char *Dm, unsigned char *Dn, unsigned char *Dt) {} 
  virtual void sumDisplay(float *R, float *G, float *B, float *A) {}
  virtual void showstats(void) {};
  virtual void render_to_texture(int num) {};
  virtual void render_pass(int pass) {};
  virtual void init_texture4f(int id, int width, int height, void *data) {};
  Display* getDisplay() {
    return disp;
  }
  virtual void handle_key(unsigned char key) { 
    cout <<"empty key handler"<<endl; 
  }

};

#endif

