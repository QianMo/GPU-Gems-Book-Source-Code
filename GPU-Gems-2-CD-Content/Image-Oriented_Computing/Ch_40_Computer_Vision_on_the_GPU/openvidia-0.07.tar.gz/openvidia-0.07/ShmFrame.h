/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _SHMFRAME_H
#define _SHMFRAME_H

#include <cc++2/cc++/thread.h>
#include <cc++/config.h>
#include <cc++/exception.h>
#include <semaphore.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <iostream>
#include "Parameters.h"


using namespace std;
using namespace ost;

struct framestruct {
  ///width of the frame
  int width;
  ///height of the frame
  int height;
  ///ID number for misc. use.
  int IDnum;
  ///number of channels (greyscale,color,RGBA etc)
  int channels;
  ///Current transformation parameters.
  ///This is used to transfer initial guess parameters,
  ///and then hold the state of the current estimation afterwards,
  ///as better estimates are calculated.
  Data params[8];
  ///used for parallel orbits.  Server sets requeested chirps to
  ///some number which it wants to client cards to run on this 
  ///image.  Then, the client sees this, and starts running the
  ///estimations, decrementing this each time - both can see
  ///how the work is progressing.  Results are in the params 
  ///member above
  int requested_chirps;
  ///flags if this frame is being placed into Shm, and should be 
  ///considered as a new request for work
  bool isNew;

  /*
   * pass skin tome information to other
   * people reading shmframe
   */
  //could use one int, TOP 16 bits are X, bottom 16 bits are Y
  int hand_x_320;
  int hand_x_640;
  int hand_y_240;
  int hand_y_480;

  // for rect server
  int rect_x_320[4];
  int rect_y_240[4];

  float thresh_x;//X: skin typically H value < 0.02
  float thresh_y;//Y: skin Sat.typically 0.3->0.6 (camera dependent)
  float thresh_z;//Z: variance allowed around Sat. value
  float thresh_w;//W: maximum allowable brightness (value)


  // Finger tracker sets these signals.  Signals are cleared by RWM once it consumes them.
  int MOUSE_SIGNAL;
  int MOUSE_SIGNAL_x_320;
  int MOUSE_SIGNAL_y_240;

};

/** The ShmFrame class encapsulates the inter-GPU communication
    scheme by being essentially a shared object who's state 
    is seen/updated by any interested GPU.  Mostly, it 
    encapsulates the nitty gritty IPC shm instructions.
  */

class ShmFrame : public Mutex {
  private:
    ///Data pointer is stored here so that it is consistent 
    ///between different shared memory users (i.e. each will
    ///see their own internal address here, which points 
    ///always to the same shared memory in the end).
    ///This pointer is shm-alloc'd in the object initialization.
    unsigned char *data;
    bool attachShm();
    bool createShm(int w, int h, int nchans, int ID);
    void initFrameInfo(int w, int h, int nchans, int ID, int req_chirps);
    int ipcid;
    Parameters Params;
  public:
    struct framestruct *Frame;

    ///default constructor attempts to attach to an
    ///assumed exisiting shared memory segments
      ShmFrame(int ipcidin, float b);

    ///construct with args attempts to create appropriate
    /// shared memory segments
    ShmFrame( int ipcidin, int w=320, int h=240, int nchans=3, int ID=-1 );

    /// memcpy the given frame data into shared memory, which locking
    int setFrame(int w, int h, int channels, int IDnum, unsigned char *);
    ///Set the number of chirps the client is requested to do.
    void setRequestedChirps(int r){ Frame->requested_chirps = r; }
    ///Print out the current estimation parameters
    void printParams() { Params.set( Frame->params ); Params.print(); }
    ///Set the current estimation parameters, possibly as an initial
    ///guess
    void setParams(Parameters pin);
    ///get the image data.
    unsigned char *getData() { return data; } 
    ///Set the current frame to the desired parameters
    int setFrame(int w, int h, int nchans, int ID, unsigned char *d,
                 int req_chirp, Parameters Pin);
    ///Get the ID number of the current ShmFrame content.
    int getID(){return Frame->IDnum;};

    /**
     * Returns true if the shmframe is currently processing data
     * Returns false otherwise
     **/
    bool isProcessing();

};


#endif
