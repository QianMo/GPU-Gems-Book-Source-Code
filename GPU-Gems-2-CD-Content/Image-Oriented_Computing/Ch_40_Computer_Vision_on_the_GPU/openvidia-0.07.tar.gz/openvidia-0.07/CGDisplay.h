/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _CGDISPLAY_H
#define _CGDISPLAY_H

#include "GenericDisplay.h"
#include "fpc.h"
#include "FragmentProgram.h"
#include "TextureSummator.h"
#include "Downsampler.h"
#include "RadialUndistort.h"

class CGDisplay : public GenericDisplay
{
  TextureSummator *ts, *ts_down1;
  GLuint renderPassLists[11]; //passes 2-11 inclusive
  GLuint estimationList, DSList;
  bool execListIsCompiled;
  Downsampler *ds;
  RadialUndistort *radialUndistort;

  void compileEstimationList();
  bool fullHessian;

  bool makeHessian;
 public:
  int num_textures;
  GLuint *texNames;
  CGDisplay(int num_textures, int imageWinWidth, int imageWinHeight, int win);
  ~CGDisplay() {};
  CFPBuffer fpbuffer;

  FragmentProgram *FParray[12];

  // implement the interface
  void initGL();
  void init_texture(int id, int width, int height, void *data);
  void bindTextures();
  void idleFunc();
  void render();
  void render_vid(float,float);
  void grabDisplay(float *Dm, float *Dn, float *Dt, float *Da,  int);
  void grabDisplay(unsigned char *Dm, unsigned char *Dn, unsigned char *Dt);
  void sumDisplay(float *R, float *G, float *B, float *A);
  void showstats();

  void activate_fpbuffer();
  void deactivate_fpbuffer();
  void render_to_texture(int);
  void render_pass(int pass) ;
  void init_texture4f(int id, int width, int height, void *data);
  void init_texture_4u(int id, int width, int height, void *data) ;
  void init_texture_grey(int id, int width, int height, void *data) ;
  void CGDisplay::drawTexture( GLenum TEXTURE_UNIT ) ;
  void bindTextureARB0(int texobj ) ;
  void bindTextureARB1(int texobj ) ;
  void bindTextureARB2(int texobj ) ;
  void render_to_texture( int num, int x, int y, int width, int height) ;
  void peek_fpbuffer(int x, int y, int W, int H );
  void show_buffer( int W, int H, float *b);
  void sumTexture(int texnum, float *sum);
  void sumTextureList(int texnum, float *sum); //does the sum using disp list
  void sumTextureList_and_Store(int texnum, int xoffset);
  void getSums(int xoffset, int xnum, float * results);
  void getSums(float * results);
  CGcontext getContext();
  CGprofile getProfile();
  void execEstimation();
  void execEstimationList();

  // OVERRODE SETCHIRPMATPARAMS TO UPDATE H/W AFTER S/W IS CHANGED
  void CGDisplay::setChirpMatParams( double p[8]);
  void setCGchirp();  ///binds the current chirp matrix to CG parameter

  void render_DS(int t1, int t2 ) ;

  void render_DS_ARB0(int t);
  void render_DS_ARB1(int t);

  void Undistort(int t, int t2);
  void useFullHessian(bool setting) { fullHessian = setting; }
  void resetHessian() { makeHessian = true; }
};

#endif

