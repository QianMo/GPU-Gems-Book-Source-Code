/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _GENERIC_CAPTURE_H
#define _GENERIC_CAPTURE_H

#include <GL/gl.h>
#include "GenericDisplay.h"
#include "formats.h"

/*
 * should i use the image.h from GNUav libav, or imlib
 */

// abstract base class
class GenericCapture {

 protected:
  int CaptureWidth;
  int CaptureHeight;
  int CaptureFormat;

 public:
  // c++ says i have to have a constructor - can i make it private then
  GenericCapture() {};
  ~GenericCapture() {};
  virtual void initCapture() {};
  virtual void initCapture(GenericDisplay *d) {};
  virtual void advanceFrame() {};
  virtual void releaseCap() {};
  virtual void* getRGBDataPreviousFrame() {};
  virtual void* getRGBData() {};
  virtual int getRGBWidth() {};
  virtual int getRGBHeight() {};
};

#endif

