/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "Udat.h"
#include <iostream>
using namespace std;
///Given a U.dat U matrix filename, opens it and readies it for reading
///the U.dat file is generated from a set of images using find_matrix 
///from the LEsvd tools
Udat::Udat(char *Udat_filename) {

  if( Udat_filename == NULL ) {
    cerr<<"WARNING, no U matrix data filename given.  Assuming ./U.dat"<<endl;
    Udat_filename = "./U.dat";
  }
  fname = strdup(Udat_filename);
  
  fp = fopen(Udat_filename, "r");
  if( fp == NULL ) { 
    cerr<< "Could not open U data file "<<Udat_filename<<endl;
    exit(1);
    return;
  }
  fscanf(fp, "%d x %d\n", &UdatWidth, &UdatHeight);  

  cout<<"Udat: allocating ";
  cout<<UdatWidth*UdatHeight*sizeof(double)/(1024*1024)<<" Megs for ";
  cout<<Udat_filename<<" U matrix file"<<endl;

  store = (double *)malloc(sizeof(double)*UdatWidth*UdatHeight);
  fread(store,sizeof(double),UdatWidth*UdatHeight,fp);
  fclose(fp);
  isStored = true;
  currentcol = 0;
  sing_values = NULL;
  num_sing_values = -1;
}

///reads singular values file, useful for eigen image reconstruction and
///to determine how many eigen images might be needed for decent
///reconstruction
void Udat::readSVdat(char *SVdat_filename) {
  FILE *sing_file;
  if( SVdat_filename == NULL ) {
    cerr<<"WARNING, no SV matrix data filename given.  Assuming ./SV.dat"<<endl;
    SVdat_filename = "./SV.dat";
  }
  cerr<<"opening "<<SVdat_filename<<endl;
  sing_file = fopen(SVdat_filename, "r");
  if( sing_file == NULL ) {
    cerr<<"could not open singular value data file "<<SVdat_filename<<endl;
  }
  fscanf(sing_file,"%d\n",&num_sing_values);
  if( sing_values != NULL ) {
    cerr<<"Udat: warning: overwriteing singular vals"<<endl;
  }
  else {
    cout<<"Udat: reading "<<num_sing_values<<" singular vals"<<endl;
  }
  sing_values=(double*)malloc(sizeof(double)*num_sing_values);
  fread(sing_values,sizeof(double),num_sing_values,sing_file);
  fclose(sing_file);
}

///Returns the Width of the U.dat file (number of images)
int Udat::getWidth() { return UdatWidth; }

///Returns the Height of the U.dat file (number of pixels in an image)
int Udat::getHeight() { return UdatHeight;}

///Examine the U.dat data, returning the norm of any chosen column.
///returns -1 if the information is no longer in memory
double Udat::getColNorm(int col) {
  double norm=0.0;
  if( !isStored ) return -1.0;
  for( int i=col; i<UdatWidth*UdatHeight; i+=UdatHeight ) {
    norm+=store[i]*store[i];
  }
  norm = sqrt(norm);
  cerr<<"norm of col "<<col<<" is "<<norm<<endl;
  return norm;
}

///becase the U.dat file is typically large, and only need on input it
///can be freed.  After U.dat eigen images are loaded into the graphics
///card, their data resides on the card's RAM, and so this no longer
///needs to be in memory
bool Udat::freeUdat() { 
  if( !isStored ) {
    cerr<<"Udat: Warning- attempt to free unallocated memory aborted"<<endl;
  }
  else {
    free(store); 
    isStored = false; 
  }
  return isStored;
}

///Returns in rgba_buffer 4 columns of the U.dat file, ordered in
///raster format, and starting with column given by startcol
int Udat::getRGBACols( int startcol , float *rgba_buffer )
{
  if( !isStored ) return -1;
  cout <<"retrieving cols ["<<startcol<<","<<startcol+3<<"]";
  cout<<" from "<<fname<<endl;
  int j=0;
  for( int i=startcol; i<UdatWidth*UdatHeight; i+=UdatHeight, j+=4 ) {
    rgba_buffer[j]=(float)store[i];
    rgba_buffer[j+1]=(float)store[i+1];
    rgba_buffer[j+2]=(float)store[i+2];
    rgba_buffer[j+3]=(float)store[i+3];
  }
  return 0;
}
///Returns in rgb_buffer 3 columns of the U.dat file, ordered in
///raster format, and starting with column given by startcol
int Udat::getRGBCols( int startcol , float *rgba_buffer )
{
  if( !isStored ) return -1;
  cout <<"retrieving cols ["<<startcol<<","<<startcol+2<<"]";
  cout<<" from "<<fname<<endl;
  int j=0;
  for( int i=startcol; i<UdatWidth*UdatHeight; i+=UdatHeight, j+=3 ) {
    cerr<<i<<" "<<j<<endl;
    rgba_buffer[j]=(float)store[i];
    rgba_buffer[j+1]=(float)store[i+1];
    rgba_buffer[j+2]=(float)store[i+2];
  }
  return 0;
}

///advances column position.  advances by 3 because get RGB gets 3 channels
void Udat::advanceFrame() 
{
  //currentcol += 3;
  //currentcol %= num_sing_values;
  advanceFrame(3);
}

///advances column position by a given number
///Note this will wrap to avoid errors, but it may not wrap and land on the 
///first eigenvector
void Udat::advanceFrame(int num) 
{
  currentcol += num;
  currentcol %= num_sing_values;
}


int Udat::getRGBWidth() { return 320; }
int Udat::getRGBHeight() { return 240; }

///returns a buffer of RGB unsigned char scaled so that it becomes 0-255 and
///thus looks like an eigen basis image.  used for diagnostic viewing
///NB : THe CALLER MUST FREE MEMORY AFTER IT IS DONE WITH IT
void *Udat::getRGBData() {
  unsigned char *rgb_buffer;

  if( !isStored ) return NULL;
  if( !trySingVals() ) { return NULL; }
  //cout <<"retrieving cols ["<<currentcol<<","<<currentcol+2<<"]";
  //cout<<" from "<<fname<<endl;
  rgb_buffer = (unsigned char*)malloc(UdatWidth*3);
  int j=0;
  for( int i=currentcol; i<UdatWidth*UdatHeight; i+=UdatHeight, j+=3 ) {
    rgb_buffer[j]=(unsigned char)(store[i]*sing_values[currentcol]);
    rgb_buffer[j+1]=(unsigned char)(store[i+1]*sing_values[currentcol+1]);
    rgb_buffer[j+2]=(unsigned char)(store[i+2]*sing_values[currentcol+2]);
  }

  return rgb_buffer;
}


bool Udat::trySingVals() {
  if( sing_values != NULL ) return true;
  else {
    readSVdat(NULL);
    if( sing_values == NULL ) {
      cerr<<"Udat: cannot make eigen images because singular values ";
      cerr<<"(SV.dat file typically) are needed."<<endl;
      return false;
    }
    else {
      cerr<<"Read default SV.dat file for singular values."<<endl;
      return true;
    }
  }
}

///returns singular value for column "col"
float Udat::getSingVal(int col) {
  if( !trySingVals() ) return 0;
  else return sing_values[col];
}

///returns a buffer of RGBA unsigned char scaled so that it becomes 0-255 and
///thus looks like an eigen basis image.  used for diagnostic viewing
///the alpha channel image cannot be seen (disable alpha blending to make sure
///the scrren display doesnt get too funkalicious (unless yer into dat)
///NB : THe CALLER MUST FREE MEMORY AFTER IT IS DONE WITH IT
void *Udat::getRGBAData() {
  unsigned char *rgba_buffer;

  if( !isStored ) return NULL;
  if( !trySingVals() ) { return NULL; }
  //cout <<"retrieving cols ["<<currentcol<<","<<currentcol+2<<"]";
  //cout<<" from "<<fname<<endl;
  rgba_buffer = (unsigned char*)malloc(UdatWidth*4);
  int j=0;
  for( int i=currentcol; i<UdatWidth*UdatHeight; i+=UdatHeight, j+=4 ) {
    rgba_buffer[j]=(unsigned char)(store[i]*sing_values[currentcol]);
    rgba_buffer[j+1]=(unsigned char)(store[i+1]*sing_values[currentcol+1]);
    rgba_buffer[j+2]=(unsigned char)(store[i+2]*sing_values[currentcol+2]);
    //rgba_buffer[j+3]=(unsigned char)(store[i+3]*sing_values[currentcol+3]);
  }

  return rgba_buffer;
}

float *Udat::getColumnData_1f()
{
  return getColumnData_1f(currentcol);
}

//returns float array containng one column
float *Udat::getColumnData_1f(int col) 
{
  float *buf;
  if( !isStored ) return NULL;
  if( !trySingVals() ) { return NULL; }

  buf = (float *)malloc(UdatWidth*sizeof(float));
  int j=0;
  for( int i=col; i<UdatWidth*UdatHeight; i+=UdatHeight, j++ ) { //w vs h?
    buf[j] = (float)store[i]*sing_values[col];
  }
  return buf;
}
  

void *Udat::getRGBAData4f() {
  float *rgb_buffer;

  if( !isStored ) return NULL;
  if( !trySingVals() ) { return NULL; }
  //cout <<"retrieving cols ["<<currentcol<<","<<currentcol+2<<"]";
  //cout<<" from "<<fname<<endl;
  rgb_buffer = (float*)malloc(UdatWidth*4*sizeof(float));
  int j=0;
  for( int i=currentcol; i<UdatWidth*UdatHeight; i+=UdatHeight, j+=4 ) {
    rgb_buffer[j]=(float)(store[i]*sing_values[currentcol]);
    rgb_buffer[j+1]=(float)(store[i+1]*sing_values[currentcol+1]);
    rgb_buffer[j+2]=(float)(store[i+2]*sing_values[currentcol+2]);
    rgb_buffer[j+3]=(float)(store[i+3]*sing_values[currentcol+3]);
  }
  return rgb_buffer;
}


