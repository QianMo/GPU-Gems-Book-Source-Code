/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>

#include "GenericDisplay.h"
#include "CGDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "ImlibCapture.h"
#include "Dc1394Capture.h"
#include "Raw1394Capture.h"
#include "OrbitsInterface.h"
#include "GlutSubWindow.h"
#include "ControlStruct.h"
//#include "mapping.h"
#include "Tracker.h"
#include <iostream>
using namespace std;


//TODO add rendering string
//TODO add capture device string

#define DELAY 55000

// Global display object
GenericDisplay *d;
GenericCapture *gc;
OrbitsInterface *orbits_engine;
Tracker *t;
int use_cg=1;

int imageWinWidth = 320;
int imageWinHeight = 240;
float Dn[320*240];
float Dm[320*240];
float Dt[320*240];
float Da[320*240];

Window  Orbwin;
GlutSubWindow  *DmWin;
ControlStruct cs;


////// FWD DECLARATIONS ////////////
void DmWinDisplay() ;
void calc_motion( float params[8]);


////// UTILITY FUNCTION //////////////

void buffer_sample_float4(float sample[4], float *thebuffer,
                          int X, int Y,
                          int xSize, int ySize, int nchans )
{
  int i=0;
  for( i=0 ; i<nchans; i++ ) {
      sample[i] = thebuffer[Y*xSize*nchans+X*nchans+i];
  }
}

////// GLUT CALLBACKS ///////////////

void reshape(int w, int h)
{
  glutSetWindow(Orbwin);
  ((CGDisplay *)d)->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
//  d->setChirpMat( 1.0, 0.00, 0.0, 0.00, 1.0, 0.0,0.00,0.0); 
 // glMultMatrixf( d->getChirpMat() );
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
  ((CGDisplay *)d)->deactivate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case '0' : 
      case '1' : 
      case '2' : 
      case '3' : 
      case '4' : 
      case '5' : 
      case '6' : 
      case '7' : 
         if( atoi((const char *)&key)>orbits_engine->getMaxDownsample_levels())
         {
           d->setDownsampleLevel(orbits_engine->getMaxDownsample_levels());
         } 
         else {
           d->setDownsampleLevel(atoi((const char *)&key));
         }
         break;
      case 27:
         exit(0);
         break;
      default:
         break;
   }


}


// coz i cant pass member funtion to glutDisplayFunc
/*
 *  Load new images, then call Display object render functions
 */ 
void render_redirect() {
  //TODO: only call 1 init_texture() 

  gc->advanceFrame(); //TESTMODE: COMMENT THIS OUT FOR TESTING
  d->init_texture(1, gc->getRGBWidth(), gc->getRGBHeight(),
           gc->getRGBData());
  d->init_texture(0, gc->getRGBWidth(), gc->getRGBHeight(),
           gc->getRGBDataPreviousFrame());


  glFlush();
  gc->releaseCap();
  d->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
  orbits_engine->resetParams();
  float p[16];
  if( cs.shm.runPseudo ) {
    for(int i=0; i<4; i++ ) {
      d->showstats();
      t->estpchirp();
      orbits_engine->getParameters(p);
      if(cs.shm.applyParams) {
        d->setChirpMat(p[0], p[1], p[2], p[3], p[4],p[5],p[6],p[7]);
      }
    }
    if(cs.shm.useFPBuffer) ((CGDisplay *)d)->deactivate_fpbuffer();
    t->update_track(p);
  }
  d->render_vid(t->getTrackx(), t->getTracky() );
  if( cs.dblbuffer ) glutSwapBuffers();
}  

void DmWinDisplay() 
{
  int readX, readY;
  readX = (int)(imageWinWidth/(pow(2.0,(double)d->getDownsampleLevel()))-1);
  readY = (int)(imageWinHeight/(pow(2.0,(double)d->getDownsampleLevel()))-1) ;
  DmWin->GlutSubWindowSetCurrent();
  if( d->getDownsampleLevel() != 0 ) {
   glClearColor (0.0, 0.0, 1.0, 1.0);
   glClear(GL_COLOR_BUFFER_BIT );
  }
  //glDrawPixels( (imageWinWidth-1), (imageWinHeight-1),
  //              GL_LUMINANCE, GL_FLOAT, Dt );
  glDrawPixels( (readX), (readY),
                GL_LUMINANCE, GL_FLOAT, Dt );
  glutSetWindow(Orbwin);
}

void posixify(int argc, char * argv[]);


//parse options
static struct option long_options[] = {
     {"disabletrack", 0, 0, 'd'},
     {"fullsize", 0, 0, 'f'},
     {"doublebuffer", 0, 0, 'b'},
     {0,0,0,0}
};

void parse_cmdline(int argc, char **argv) 
{
   char c;
   opterr = 0; /* prevent weird options from causing errors */
   posixify(argc,argv);

   while(1) {
     int this_option_optind = optind ? optind : 1;
     int option_index = 0;
     c = getopt_long (argc, argv, "dfb",
                      long_options, &option_index);
     if (c == -1) break;
     switch(c){
     case 'd' :
       cout << "Disabling tracking" << endl;
       cs.unset_useDiagWin();
       cs.unset_grabDisplay();
       cs.unset_runPseudo();
       cs.unset_applyParams();
       break;
     case 'f' : 
       cout << "using 640x480 images" << endl;
       imageWinWidth = 640;
       imageWinHeight = 480;
       break;
     case 'b' :
       cout << "using double buffering" << endl;
       cs.set_dblbuffer();
     }
    
   }
}

void load_defaults()
{      
  cs.unset_useDiagWin();
  cs.set_grabDisplay();
  cs.set_runPseudo();
  cs.set_applyParams();
  cs.unset_dblbuffer();
}


///// MAIN ///////////////////

int main(int argc, char** argv)
{
   load_defaults();
   parse_cmdline(argc,argv);
   //cs.set_useDiagWin();
   cs.print();
   glutInit(&argc, argv);
   if( cs.dblbuffer ) {
     cout <<"Creating Double Buffered Window" << endl;
     glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   } else  {
     cout <<"Creating Single Buffered Window" << endl;
     glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
   }
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);

   if (use_cg) {
     d=new CGDisplay(3, imageWinWidth, imageWinHeight, Orbwin );
   } else {
     d=new GLDisplay(Orbwin);
   }
   //gc=new ImlibCapture();
   //gc=new Dc1394Capture();
   gc=new Raw1394Capture();
   ((Raw1394Capture *)gc)->start();

   d->initDisplay();
   gc->initCapture(d);
   gc->advanceFrame();
   d->setImageSize( gc->getRGBWidth(), gc->getRGBHeight() );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 

   d->initGL();
   d->init_texture(0, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   gc->releaseCap();
   if(use_cg) {
	   gc->advanceFrame();
	   d->init_texture(1, gc->getRGBWidth(), gc->getRGBHeight(),
			                         gc->getRGBData());
        gc->releaseCap();
   }
   d->init_texture4f(2, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   //d->bindTextures();
   d->setDownsampleLevel(1);

   //orbits
   orbits_engine =new OrbitsInterface( 3, imageWinHeight, imageWinWidth );
 
   if(cs.shm.useDiagWin) {
     DmWin=new GlutSubWindow(Orbwin,600,0,imageWinWidth-1,imageWinHeight-1 );
     glutDisplayFunc(DmWinDisplay);
     glutIdleFunc(NULL);
   }
   t=new Tracker((CGDisplay *)d,orbits_engine);

   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMainLoop();
   return 0; 

}
