/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
#include <assert.h>
#include <sched.h>


#include "GenericDisplay.h"
#include "SimpleDisplay.h"
#include "CGDisplay.h"
#include "GLDisplay.h"
#include "OrbitsInterface.h"
#include "Parameters.h"
#include "mapping.h"
#include "ProjPlane.h"
#include "ShmFrame.h"
#include <iostream>
#include <iomanip>
#include <GL/glut.h>

/*
 * for loading hand parms into orbits
 */
#include "nvidia.h"

using namespace std;
bool exec_cpu = false;
bool use_undistort = false;
bool fullHessian = true;
#define NUM_PCI_HEADS 5
#define MAX_PLANES 300

CGDisplay *orbits;
OrbitsInterface *oi;

int downlevel = 0;
bool render_cement =false; //impacts speed greatly
int keyframe = 0;

int num_planes = 2;
int current_plane = 1;
int niter = 6;
int niterreq = 3;
int nitercount = 0;
bool exec_est = true;
bool req_undistort = true; //request undsitort
bool req_downsampling = true; //request downsampling on next iteration
int imageWinWidth = 320;
int imageWinHeight = 240;
float *sums;

int client_id = -1;
int handtracker_id = -1;
ShmFrame *shmFrame0, *shmFrame1, *handFrame;

ProjPlane *planes[MAX_PLANES];
unsigned char *membuf[MAX_PLANES]; //hack. cough cough

Window  mainWindow;

Parameters p,P, gltermP, gltermp;
double ptmp[8];
float samp[4];
float R,G,B,A;
bool requestDownsample =true; 
FragmentProgram *dispFP;
int DEBUG=0;

////// UTILITY FUNCTION //////////////
void buffer_sample_float4(float sample[4], float *thebuffer,
                          int X, int Y,
                          int xSize, int ySize, int nchans )
{
  int i=0;
  for( i=0 ; i<nchans; i++ ) {
      sample[i] = thebuffer[Y*xSize*nchans+X*nchans+i];
  }
}


////// GLUT CALLBACKS ///////////////
void reshape(int w, int h)
{
  float SCALE = 3.0f;///enlarges near plane of frustum
  float borderW =( (float)w/(float)imageWinWidth  - 1.0 )/2.0 ;
  float borderH =( (float)h/(float)imageWinHeight - 1.0 )/2.0 ;

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(1, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  cerr<<"w = "<<w<<endl;
  glFrustum(-borderW/SCALE, (1.0+borderW)/SCALE,  
            (1.0+borderH)/SCALE, -borderH/SCALE,   1.0/SCALE,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glClear(GL_COLOR_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  //make a tasty vanilla frustum for fpbuffer orbits
  //dont alter this.
  orbits->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) 320, (GLsizei) 240);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  orbits->deactivate_fpbuffer();

  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(mainWindow);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y) 
{
  glutSetWindow(mainWindow);
  cout <<"N00B"<<endl;
}

void setMatrix(float *sums) 
{
/*
  cerr<<"RETRIEVED=[";
  for( int i=0 ; i<11*4 ; i++ ) {
    cerr<<sums[i]<<", ";
  } 
  cerr<<"]"<<endl;
*/

  int k=0;
  for( int i=2;  i<=10; i++ ) {
    for( int j=0; j<4 ; j++ ) {
      oi->setDER( OrbitsRGBAmap[i][j], sums[k++]);
    }
  }
  for( int i=0; i<8 ; i++ ) oi->setder(i, sums[k++]);
}


void test_variance( Parameters P, ProjPlane *frame1, ProjPlane *frame2 )
{
  float var;
  var = P.getVariance();

  if( var > 0.2 ) {
    cerr<<"Orbits variance failed. Images "<<frame1->getPlaneName()<<" and ";
    cerr<<frame2->getPlaneName()<<endl;
    P.print();
    exit(1); 
  }
}

// by client we mean "orbits calculator part"
// This is the main estimation/rendering function run the by clients
void render_client() {
  static bool clientHasFrames = false;
  static bool workToDo=false;

  //task PRE amble :
  //continue or start working case
  if( shmFrame1->Frame->requested_chirps > 0 ) {
    //check if we need to update image set
    shmFrame0->enterMutex();
    if( shmFrame0->Frame->isNew ) { 
      if(DEBUG) cerr<<"Received new Frame[0] , id = "<<shmFrame0->getID()<<endl;
      orbits->init_texture(10, shmFrame0->Frame->width, 
                           shmFrame0->Frame->height, shmFrame0->getData() );
      if(DEBUG) cerr<<"Bound new frame ok "<<endl;
      shmFrame0->Frame->isNew = false; 
      // new frames must be undistorted initially
      req_undistort = true;
    }
    shmFrame0->leaveMutex();

    //really an updated image means recalculate the pair.
    //check if we need to update image set
    shmFrame1->enterMutex();
    if( shmFrame1->Frame->isNew ) { 
      if(DEBUG) cerr<<"Received new Frame[1] , id = "<<shmFrame1->getID()<<endl;
      orbits->init_texture(11, shmFrame1->Frame->width, 
                           shmFrame1->Frame->height, shmFrame1->getData() );
      if(DEBUG) cerr<<"Bound new frame ok "<<endl;
      // new frames must be undistorted initially
      req_undistort = true;
      req_downsampling = true;
      shmFrame1->Frame->isNew = false;
      clientHasFrames = true;
      num_planes = 2;
      current_plane = 1;
      //reset because a frame has changed
      orbits->activate_fpbuffer();
      orbits->setChirpMatParams(shmFrame1->Frame->params);
      orbits->setCGchirp();
      orbits->resetHessian();
      if(DEBUG) cerr<<"Seeded estimation with ";
      if(DEBUG) orbits->printChirpMatParams();
      orbits->deactivate_fpbuffer();
      oi->setStartParams(shmFrame1->Frame->params); 
    }
    shmFrame1->leaveMutex();
    
    /*      for( int i=0  ; i<=current_plane ; i++ ) {
	    orbits->bindTextureARB0(planes[i]->getTexNum());
	    planes[i]->draw(false); 
	    }*/


    //turn on estimation engine
    exec_est = true;
  }
  else  { 
    exec_est = false;
    req_undistort = false;
    usleep(500);//sleep for 1ms. should be okay at 33ms/frame
    //sched_yield();//sleep for 1ms. should be okay at 33ms/frame
  }

  //do da wurk, one repetition
  if( exec_est ){
    sums = (float *)malloc(sizeof(float)*4*11);
  
    /*
     * Pull out the HSV values from a handtrackers
     */
    if(handtracker_id != -1) {
      static int slowdown=0;
      if(slowdown++==100) {
	slowdown=0;
	cout<<handFrame->Frame->thresh_x<<" ";
	cout<<handFrame->Frame->thresh_y <<" ";
	cout<<handFrame->Frame->thresh_z <<" ";
	cout<<handFrame->Frame->thresh_w <<endl;
      }  
      /*
       * load them into orbits
       */
      float hsvColor[4] = {handFrame->Frame->thresh_x,
			   handFrame->Frame->thresh_y,
			   handFrame->Frame->thresh_z,
			   handFrame->Frame->thresh_w};
      cgGLSetParameter4fv(someColor, hsvColor);  

    } else {
      float defaultHsvColor[4] = { 0.05, 0.40, 0.9, 0.10 };
      cgGLSetParameter4fv(someColor, defaultHsvColor);  
    }
  
   
    orbits->activate_fpbuffer();
    if( req_undistort ) {//only do undistort once
      orbits->Undistort(10, 7);
      orbits->Undistort(11, 8);
      req_undistort = false;
      //cerr<<"doing undistort "<<endl;
    }
    if( downlevel == 0  ) {
      if( use_undistort ) {
	orbits->bindTextureARB1( 7 ); 
	orbits->bindTextureARB0( 8 );
      }
        else {
          orbits->bindTextureARB1( 10 ); 
          orbits->bindTextureARB0( 11 );
        }
    }
    else if( downlevel == 1 && req_downsampling ) {
      if( use_undistort ) {
	orbits->bindTextureARB1( 7 ); 
	orbits->bindTextureARB0( 8 );
        }
      else {
	orbits->bindTextureARB1( 10 ); 
	orbits->bindTextureARB0( 11 );
      }
      orbits->render_DS_ARB0(5);
      orbits->render_DS_ARB1(6);
      req_downsampling= false; //completed downsampling for these iterations
    }

////    orbits->execEstimationList(); //exec as display list
    //exec as immediate mode, 
    //currently this is necessary for the 
    //faster hessian, because it needs to 
    //dynamically determine if the hessian is 
    //already calculated
    if( !fullHessian ) {
      orbits->execEstimation();
    } else {
      orbits->execEstimationList(); //exec as display list
      sched_yield();
    }

    // {  struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 800; select(0,0,0,0, &tv);
    //}

    orbits->getSums(sums);
    setMatrix(sums) ;
    orbits->deactivate_fpbuffer();
    
    free(sums);
    oi->solve_system(downlevel);
    oi->getParameters(ptmp);
    P.set(ptmp);
    if(DEBUG) P.print();
    orbits->setChirpMatParams(P.get() );
    orbits->setCGchirp();
  }

  //render the current cement
  planes[0]->clear(); //clear out 
  if( clientHasFrames ) {
    planes[current_plane]->P = planes[current_plane-1]->P*P;
  }

  // task POST amble:
  // run this if work was done
  if( exec_est ) {
    // tell shm that one more reptition completed, and set params
    shmFrame1->enterMutex();
    shmFrame1->Frame->requested_chirps--;
    shmFrame1->setParams(P);
    shmFrame1->leaveMutex();
  }


  orbits->showstats();  
  glutSwapBuffers();
  return;
}


void posixify(int argc, char * argv[]); //fill in from orbits version
void posixify(int argc, char * argv[]){} //fill in from orbits version

void printHelp()
{
  cout<<"hwOrbits options:"<<endl;
  cout<<"   -c --client [id]  \t: run this instance as a client, with given id"<<endl;
  cout<<"   -l --level [0,1]  \t: set the downsampling level. 0: 320x240, 1: 160x120"<<endl;
  cout<<"   -d --debug [0,1]  \t: set the debug messages on or off"<<endl;
  cout<<"   -u --undistort    \t: use undistortion for IBOT"<<endl;
  cout<<"   -t --handtracker  \t: connect to a handtracker to mask skintone"<<endl;
  cout<<"   -h --help         \t: print this help message, and quit"<<endl;
  cout<<" WARNING: IF hwOrbits CHUNKS ON STARTUP, run client (IMAGE SENDER) once first."<<endl;
  cout<<" Oh, and use -display :0.1 to before the above options to run on another screen"<<endl;
  cout<<endl;
}

//parse options
static struct option long_options[] = {
  {"client", 0, 0, 'c'},
  {"hEssian", 0, 0, 'e'},
  {"level", 0, 0, 'l'},
  {"debug", 0, 0, 'd'},
  {"undistort", 0, 0, 'u'},
  {"help", 0, 0, 'h'},
  {"handtracker", 0, 0, 't'},
  {0,0,0,0}
};

void parse_cmdline(int argc, char **argv)
{
   char c;
   opterr = 0; /* prevent weird options from causing errors */
   posixify(argc,argv);

   while(1) {
     int this_option_optind = optind ? optind : 1;
     int option_index = 0;
     c = getopt_long (argc, argv, "uc:t:hl:de",
                      long_options, &option_index);
     if (c == -1) break;
     switch(c){
     case 'c' :
       client_id = atoi(optarg);
       if( client_id < 0 || client_id > 5 ) {
         cerr<<"Invalid Client ID "<<client_id<<" requested. aborting."<<endl;
         cerr<<"Client ID must lie in closed interval [0,5]"<<endl;
         exit(1);
       }
       cerr<<"Initializing as client ID "<<client_id<<endl;
       break;
     case 'l' : //downsampling level
       downlevel = atoi(optarg);
       cerr<<"requesting downsample level "<<downlevel<<endl;
       assert(downlevel == 0 || downlevel == 1 );
       break;
     case 'd' : // debug
       DEBUG=atoi(optarg);
       if(DEBUG >1 || DEBUG < 0) {
		cerr<<"Invalid debug flag. Use 0 or 1"<<endl;
		exit(-1);
	  }
	  break;
     case 'u': //radial undistort
       cerr<<"Using radial undistortion"<<endl;
       use_undistort = true;
       break;
     case 'h' : //print help
       printHelp();  exit(0);
       break;
     case 'e' : //request faster non full hessian (reuse simpler hessian)
       fullHessian = false;
       cerr<<"Setting Hessian Re-Use"<<endl;
       break;


     case 't' : //hand tracker information
       handtracker_id = atoi(optarg);
       if( handtracker_id < 0 || handtracker_id > 5 ) {
         cerr<<"Invalid handtracker ID "<<handtracker_id<<" requested. aborting."<<endl;
         cerr<<"handtracker ID must lie in closed interval [0,5]"<<endl;
         exit(-1);
       }
       cerr<<"Initializing as handtracker ID "<<handtracker_id<<endl;
       break;

     defalt :
       cerr<<"WARNING: unknown switch "<<c<<endl;
     }

   }
}


///// MAIN ///////////////////
int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   parse_cmdline(argc, argv); //make sure this occurs after glut parses
   if( client_id == -1 || client_id == 0 ) { 
     cerr << "SHOULD NEVER HAD CLIENT ID 0"<<endl;
     exit(-1);
   }
   
   cerr <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_ALPHA);
   //glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA );
   glutInitWindowSize(imageWinWidth+1024-320, imageWinHeight+768-240);
   glutInitWindowPosition(0, 0);
   char title[50]={'\0'};
   sprintf(title, "%s %d", argv[0], client_id);
   mainWindow=glutCreateWindow(title);

   orbits=new CGDisplay(MAX_PLANES+12, 320,240, mainWindow );
   orbits->initDisplay();
   orbits->setDownsampleLevel(downlevel);
   orbits->setImageSize(320,240);  
   orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
   orbits->useFullHessian( fullHessian );
   orbits->initGL();

   oi = new OrbitsInterface(2, 240, 320);
   if(DEBUG) {
	   cout << "Turning on oribts interface debugging"<<endl;
	   oi->setDebug(DEBUG);
   } else {
	   cout<<"Debugging is not enabled."<<endl;
   }

   //create shared memory areas, an image pair 0/1 for each head (card)
   int frame0ID = client_id*2-2;
   int frame1ID = frame0ID+1;
   shmFrame0 = new ShmFrame(frame0ID);
   shmFrame1 = new ShmFrame(frame1ID);

   //connect to hand frame shm
   if(handtracker_id != -1) {
     cout<<"Connecting to handtracker at id "<<handtracker_id<<endl;
     int handframeShmId = handtracker_id*2-2;
     handFrame = new ShmFrame(handframeShmId);
   }

   //these are for drawing nice pictures
   dispFP = new FragmentProgram( orbits->getContext(), orbits->getProfile(),
                                 "FPestpchirp2m/FP-nop.cg", 0);

   orbits->init_texture(10, imageWinWidth, imageWinHeight,NULL);
   orbits->init_texture(11, imageWinWidth, imageWinHeight,NULL);
   for( int i=0 ; i<num_planes ; i++ ) {
     planes[i] = new ProjPlane(imageWinWidth, imageWinHeight,  dispFP);
     planes[i]->setTexNum(i+10);
   }
   
   orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
   orbits->setCGchirp();
   oi->resetParams(); 

   float *nobuf[320*240*4];
   //storage textures
   orbits->init_texture4f(2, imageWinWidth, imageWinHeight,nobuf);
   orbits->init_texture4f(3, imageWinWidth, imageWinHeight,nobuf);
   orbits->init_texture4f(4, imageWinWidth, imageWinHeight,nobuf);
   orbits->init_texture4f(5, imageWinWidth/2, imageWinHeight/2,nobuf);
   orbits->init_texture4f(6, imageWinWidth/2, imageWinHeight/2,nobuf);
   orbits->init_texture4f(7, imageWinWidth, imageWinHeight,nobuf);
   orbits->init_texture4f(8, imageWinWidth, imageWinHeight,nobuf);

   glutSetWindow(mainWindow);
   glutDisplayFunc(render_client);

   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMainLoop();
   return 0; 
}


