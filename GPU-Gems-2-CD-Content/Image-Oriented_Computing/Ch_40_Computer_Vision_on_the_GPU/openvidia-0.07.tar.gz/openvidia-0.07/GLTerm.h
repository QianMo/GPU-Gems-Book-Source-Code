/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

/* blablabla everything shall be GNU ... blablabla
 * (closest thing to a license from glterm.sf.net
 */
#ifndef _GLTERM_H
#define _GLTERM_H



#include "GenericDisplay.h"
#include <sys/time.h>
#include <sys/types.h>

#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <utmp.h>

#include <pwd.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <GL/glut.h>
#include "glf.h"

#define START_TIMER glutTimerFunc(15, wintext_timer, 0);
#define START_BLINK glutTimerFunc(500, timer_blink, 0);
#define LETTERHEIGHT .04f
#define LETTERWIDTH .04f
#define LETTERSPACEX .001f
#define LETTERSPACEY .03f
#define LETTERSIZE_BEEP .08f
#define MAX_LINES 40
#define MAX_CHARACTERS 75
#define LINELEN 8.8
#define SET_VIEWPOINT
#define START_X 0.0f
#define START_Y 0.0f
#define DEFAULT_FGCOLOR 2
#define DEFAULT_BGCOLOR 0
#define wired

typedef struct char_struct
{
    char character;
    char fgcolor;
    char bgcolor;
}t_char;

typedef struct line_struct
{
    t_char chars[MAX_CHARACTERS];
    char nextchar;
}t_line;

#ifdef wired
#define FONT "./fonts/courier1.glf"
#else
#define FONT "./fonts/chicago1.glf"
#define TEXTURE "awwy2.sgi"
#endif

class GLTerm : public GenericDisplay
{
  
  t_line line[MAX_LINES+1];
  
  int curfgcolor;
  int curbgcolor;
  int gotnewdata;
  int isansi;
  int lastline;
  int lastchar;
  int isansi2;
  int bottom;
  int top;
  pthread_t *console_thread;
  unsigned *teximage;

 public:
  GLTerm(int imageWinWidth, int imageWinHeight, int win);
  ~GLTerm();
 
//new variables
  float glterm_left, glterm_right, glterm_bottom, glterm_top;

  // implement the interface
  void initGL();
  void init_texture(int id, int width, int height, void *data);
  void bindTextures();
  void idleFunc();
  void render();
  void grabDisplay(float *Dm, float *Dn, float *Dt, float *Da,  int);
  void grabDisplay(unsigned char *Dm, unsigned char *Dn, unsigned char *Dt);
  void sumDisplay(float *R, float *G, float *B, float *A);
  void showstats();

  //keyboard
  void handle_key(unsigned char key);

  //glfunctions.c
  int regenerate_gllist();

  // form main.c
  void init_line();
  void clear_line(int lineid);
  void clear_char(int lineid, int charid);
  int AddChar(char *_toAdd);
  t_line *line_is_full();
  int backspace();
  int parseansi(char curchar);
  int add_char_append(char toappend);
  int move_up_x_lines(char *arg);
  int move_down_x_lines(char *arg);
  int remove_beginning_from_curpos();
  int forward_x_letters(char *arg1);
  int ansi_change_graphic(char **args);
  int move_all_lines_up();
  int clear_line_after_lastchar();
  int endansi();
  int LoadTexture(const char*);
};

#endif

