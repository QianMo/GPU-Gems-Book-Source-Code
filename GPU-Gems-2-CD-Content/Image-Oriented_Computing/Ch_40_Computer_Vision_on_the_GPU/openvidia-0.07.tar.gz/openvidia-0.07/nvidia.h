/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _NVIDIA_H
#define _NVIDIA_H

#include <Cg/cgGL.h>

extern CGparameter E1Texture, E2Texture, someColor, E2texCoord,E1texCoord, colorO, xsizeParam, ysizeParam, Pparams;



void init_cg(GLuint *texNames,int ImageWidth, int ImageHeight, float c[16]);
void init_FP(char *, GLuint *texNames,int ImageWidth, int ImageHeight, float c[16]);
void init_FPds1(char *fragmentProgramFile, GLuint *texNames, int ImageWidth, int ImageHeight, float Pmatrix[16]);
void errcheck();
void init_float_pbuffer(int ImageWidth, int ImageHeight) ;
void fpbufferactivate();
void fpbufferdeactivate();
void nv_reset_pchirp(float Pmatrix[16]);
void makeFPpassthru( CGcontext fContext,
                CGprofile fProfile,
                char *FPname,
                GLuint texName0, GLuint texName1 );

#endif
