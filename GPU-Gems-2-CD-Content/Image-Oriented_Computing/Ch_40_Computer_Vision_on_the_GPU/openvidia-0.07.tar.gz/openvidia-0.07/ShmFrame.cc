/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "ShmFrame.h"
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include <assert.h>

#include <iostream>
using namespace std;

#define IPC_INFO_FILE_NAME "/etc/modules"
//#define IPC_DATA_FILE_NAME "/bin/ls"
#define IPC_DATA_FILE_NAME "/etc/fstab"

//make 2 shared memory areas: one for the information about the
//size and type of frame (w,h,depth,etc), and another
//holding the actual frame data

//id should match between creator/user objects to get the same frame

static bool getKey(int id, key_t *infokey, key_t *datakey )
{
  key_t key;

  cerr<<"Generating Info Key based on "<<IPC_INFO_FILE_NAME<<endl;
  if( (key = ftok(IPC_INFO_FILE_NAME, id)) == -1 ) {
    perror("ShmFrame ftok (infokey): ");
    return false;
  }
  cerr<<"INFOKEY IS"<<key<<endl;
  *infokey = key;

  cerr<<"Generating Data Key based on "<<IPC_DATA_FILE_NAME<<endl;
  if( (key = ftok(IPC_DATA_FILE_NAME, id)) == -1 ) {
    perror("ShmFrame ftok (infokey): ");
    return false;
  }
  *datakey = key;

  return true;
}
//todo : changing struct sizes requires changing of  the size
// of shm segment -but if one exists alreay of wrong size, it 
// will be attached and a segmentation fault occurs, so
// we need to check the existing size to make sure the new request
// can be accomodated and re-make the shm segment if necessary.
bool ShmFrame::createShm(int w, int h, int nchans, int ID)
{
  key_t infokey=-1, datakey=-1;
  int infoshmid=-1, datashmid =-1;
  int memsz=-1;
  struct shmid_ds ds;

  //  cerr<<"getting ipcid "<<ipcid<<endl;
  if( !getKey(ipcid, &infokey, &datakey) ) {
    perror("PRE shmget: ");
    return false;
  }
  else {  
    //    cerr<<"get key ok"<<endl;
  }

  assert(infokey != -1 );
  assert(datakey != -1 );
  int infosz = sizeof(struct framestruct);//128*128*4;
  //  infoshmid = shmget(infokey,sizeof(struct framestruct),IPC_CREAT|0644);
  infoshmid = shmget(infokey,infosz,IPC_CREAT|0644);
  if( infoshmid == -1 ) { 
    perror("shmget failed: ");
    cerr<<"Could not shmget info memory"<<endl;
    return false;
  }
  else { 
    //    cerr<<"shmid "<<infoshmid<<endl;
  }

  //Size for Data memory assum char data
  Frame = (struct framestruct *)shmat( infoshmid, NULL, 0);
  initFrameInfo(w, h, nchans, ID, 0);
  memsz = Frame->width*Frame->height*Frame->channels;
  //  cerr<<"requesting "<<memsz<<endl;
  
  if( (int)Frame == -1 ) {
    perror("shmat: ");
    cerr<<"Could not shmat info memory"<<endl;
    return false;
  }
  //  cerr<<"Succesfully made info area"<<endl; 

  //allocate image buffer
  datashmid = shmget(datakey, memsz, IPC_CREAT|0644); 
  if( datashmid == -1 ) { 
    perror("shmget data failed: ");
    return false;
  }
  else {
    //    cerr<<"datashmid "<<datashmid<<endl;
  }
  if( (data = (unsigned char *)shmat( datashmid, NULL, 0)) == NULL ) {
    perror("shmat: ");
    cerr<<"Could not shmat data memory"<<endl;
    return false;
  }
  //  cerr<<"Succesfully made data area"<<endl; 
   
  return true;
}

bool ShmFrame::attachShm()
{
  key_t infokey, datakey;
  int infoshmid=-1, datashmid =-1;
  int memsz=-1;

  cerr<<"getting ipcid "<<ipcid<<endl;
  if( !getKey(ipcid, &infokey, &datakey) ) {
    cerr<<"COUDLD NOT GET KEY"<<endl;
    return false;
  }
  
  int infosz = 100*100*5;
  cerr<<"INFOKEY IS "<<infokey<<endl;
  //  infoshmid = shmget(infokey,infosz,0); ROSCO change 0 to 0644
  infoshmid = shmget(infokey,infosz,IPC_CREAT|0644);
  if( infoshmid == -1 ) { 
    perror("shmget info failed: ");
    cerr<<"XXXXXXXXX Try running glestpchirp2m to create all the memory areas"<<endl;  exit(-1);
    return false;
  }
 
  //assum char data
  Frame = (struct framestruct *)shmat( infoshmid, NULL, 0);
  memsz = Frame->width*Frame->height*Frame->channels;
  cerr<<"attaching sz "<<memsz<<endl;

  if( Frame == NULL ) {
    cerr<<"framestruct error, perror follows"<<endl;
    perror("shmat: ");
    return false;
  }

  //allocate image buffer
  datashmid = shmget(datakey, memsz, 0644); 
  if( datashmid == -1 ) { 
    perror("shmget: ");
    cerr<<"Could not shmget data memory"<<endl;
    return false;
  }
  if( (data = (unsigned char *)shmat( datashmid, NULL, 0)) == NULL ) {
    perror("shmat: ");
    cerr<<"Could not shmat data memory"<<endl;
    return false;
  }
  return true;
}


//changed to double so we call other constructor
ShmFrame::ShmFrame(int ipcidin, float b)
{
  cerr<<"DEPRECATED"<<endl;
  exit(-1);
  int ID=ipcidin*2-2;
  ShmFrame(ipcidin,320,240,3,-1 );

  /*  cerr<<"CREATING SHMFRAME 1 ARG CONSTRUCTOR ID="<<ipcidin<<endl;
  assert ( ipcidin >= 0 ) ;
  ipcid = ipcidin;
  if( !attachShm() ) {
    cerr<<"Could not attach shared memory frame"<<endl;
    cerr<<"Trying to create shmframe"<<endl;

    if( !createShm( 320, 240, 3, ipcidin ) ) {
      cerr<<"Could not create shmframe"<<endl;
      exit(-1);
    }
    return;
  }
  else { 
    cerr<<"Attached image area "<<Frame->IDnum<<":"<<Frame->width<<"x";
    cerr<<Frame->height<<"x"<<Frame->channels;
    cerr<<endl;
  }
  
  Frame->params[0]=1.0;
  Frame->params[1]=0.0;
  Frame->params[2]=0.0;
  Frame->params[3]=0.0;
  Frame->params[4]=1.0;
  Frame->params[5]=0.0;
  Frame->params[6]=0.0;
  Frame->params[7]=0.0;
  Frame->params[8]=0.0;
  */
}


/*
 * Rosco -- this magic constructor actually creates shm
 */
ShmFrame::ShmFrame( int ipcidin, int w, int h, int nchans, int ID)
{
  cerr<<"CREATING SHMFRAME ID="<<ipcidin<<endl;
  
  ipcid = ipcidin;
  if( !createShm( w, h, nchans, ID ) ) {
    cerr<<"Could not create a shared memory frame, id="<<ID<<endl;
    cerr<<"exiting..."<<endl;
    exit(-1);
  }
}



int ShmFrame::setFrame(int w, int h, int nchans, int ID, unsigned char *d)
{
  int sz =  w*h*nchans;

  enterMutex();
    memcpy(data, d, w*h*nchans);
    initFrameInfo(w, h, nchans, ID, 0);
    Frame->isNew = true;
  leaveMutex();

  return sz;
}
int ShmFrame::setFrame(int w, int h, int nchans, int ID, unsigned char *d,
                       int req_chirp, Parameters Pin)
{
  int sz =  w*h*nchans;

  enterMutex();
    memcpy(data, d, w*h*nchans);
    initFrameInfo(w, h, nchans, ID, 0);
    Frame->isNew = true;
    setParams(Pin);
    setRequestedChirps(req_chirp);
  leaveMutex();

  return sz;
}


void ShmFrame::initFrameInfo(int w, int h, int nchans, int ID, int req_chirps)
{
    //set up info as requested
    Frame->width = w;
    Frame->height = h;
    Frame->channels = nchans;
    Frame->IDnum = ID;
    Frame->requested_chirps = req_chirps;
}

void ShmFrame::setParams(Parameters pin)
{
  double *tmp = pin.get();
  for(int i=0;i<8;i++) 
    Frame->params[i]=tmp[i];
}

 
bool ShmFrame::isProcessing() {
      enterMutex();
      if(Frame->requested_chirps > 0) {
	leaveMutex();
	return true;
      }
      leaveMutex();
      return false;
    }
