/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <GL/glut.h>

#include <getopt.h>
#include <assert.h>


#include "GenericDisplay.h"
#include "SimpleDisplay.h"
#include "CGDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394Capture.h"
#include "Raw1394Capture.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "Correspond.h"
//#include "Udat.h"
#include "OrbitsInterface.h"
#include "Parameters.h"
#include "mapping.h"
#include "ProjPlane.h"
#include "ShmFrame.h"
#include <iostream>
#include <iomanip>
using namespace std;

int DEBUG=0;
bool exec_cpu = false;
#define NUM_PCI_HEADS 5
#define MAX_PLANES 300

// Global display object
//GenericDisplay *d;
CGDisplay *orbits;
GenericCapture *gc;
OrbitsInterface *oi, *oicpu;
int use_cg=1;

int downlevel = 0;
bool render_cement =false; //impacts speed greatly
int keyframe = 0;
bool fullHessian = true;

int num_planes = 2;
int current_plane = 1;
int niter = 6;
int niterreq = 3;
int nitercount = 0;
bool exec_est = true;
int imageWinWidth = 320;
int imageWinHeight = 240;
float *sums;
unsigned char whitebuf[320*240*4]= {255};

int client_id = 0;
/*
ShmFrame *head1_0, *head1_1, 
         *head2_0, *head2_1, 
         *head3_0, *head3_1, 
         *head4_0, *head4_1, 
         *head5_0, *head5_1;
*/
ShmFrame *heads[5][2];
ShmFrame *shmFrame0, *shmFrame1;
char filename1[1024]="images/s06.pgm";
char filename2[1024]="images/s04.pgm";


ProjPlane *planes[MAX_PLANES];
unsigned char *membuf[MAX_PLANES]; //hack. cough cough

Window  Orbwin;

////// UTILITY FUNCTION //////////////
void buffer_sample_float4(float sample[4], float *thebuffer,
                          int X, int Y,
                          int xSize, int ySize, int nchans )
{
  int i=0;
  for( i=0 ; i<nchans; i++ ) {
      sample[i] = thebuffer[Y*xSize*nchans+X*nchans+i];
  }
}

void printProjectionMatrix()
{
  float pmatrix[16]={0};
  glGetFloatv( GL_PROJECTION_MATRIX, pmatrix);
  printf("%5f %5f %5f %5f\n", pmatrix[0], pmatrix[4], pmatrix[8], pmatrix[12]);
  printf("%5f %5f %5f %5f\n", pmatrix[1], pmatrix[5], pmatrix[9], pmatrix[13]);
  printf("%5f %5f %5f %5f\n", pmatrix[2], pmatrix[6], pmatrix[10], pmatrix[14]);
  printf("%5f %5f %5f %5f\n", pmatrix[3], pmatrix[7], pmatrix[11], pmatrix[15]);
}

////// GLUT CALLBACKS ///////////////

void reshape(int w, int h)
{
  float SCALE = 3.0f;///enlarges near plane of frustum
  float borderW =( (float)w/(float)imageWinWidth  - 1.0 )/2.0 ;
  float borderH =( (float)h/(float)imageWinHeight - 1.0 )/2.0 ;
  //glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(1, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  cerr<<"w = "<<w<<endl;
  //glFrustum(0.0, (float)w/(float)imageWinWidth/SCALE,  
  //          (float)h/(float)imageWinHeight/SCALE, 0.0,   1.0/SCALE,   100.0);
  glFrustum(-borderW/SCALE, (1.0+borderW)/SCALE,  
            (1.0+borderH)/SCALE, -borderH/SCALE,   1.0/SCALE,   100.0);
  //glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glClear(GL_COLOR_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();


  //make a tasty vanilla frustum for fpbuffer orbits
  //dont alter this.
  orbits->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) 320, (GLsizei) 240);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  orbits->deactivate_fpbuffer();

  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void grabFB()
{
  Grab_JPEG grabber;
  int w,h;
  w =  glutGet(GLUT_WINDOW_WIDTH);
  h =  glutGet(GLUT_WINDOW_HEIGHT);
  unsigned char *readbuf = (unsigned char *)malloc(w*h*4);
  assert(readbuf!=NULL);
  glReadPixels(0,0, w,h, GL_RGB, GL_UNSIGNED_BYTE, readbuf);
  grabber.grab_frame(readbuf,w,h, FORMAT_RGB24);
  free(readbuf);
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);

     switch (key) {
      case 27:
         exit(0);
         break;
      case 'g' :
         grabFB();   
         break;
      case '+' :
         keyframe++;   
         if( keyframe >= num_planes )  keyframe = num_planes-1;
         break;
      case '-' :
         keyframe--;   
         if( keyframe < 0 ) keyframe = 0;
         break;
      default:
         break;
	 }
}

float Dm[320*240*4]={0.0};
float Dn[320*240*4]={0.0};
float Dt[320*240*4]={0.0};
float Da[320*240*4]={0.0};
Parameters p,P;
double ptmp[8];
float samp[4];
float R,G,B,A;


///side note:  using a double precision sum gets be closer! to twhat the
//graphics cards does internally.  float seems less! precise.  !
float sumBuffer( float *b, int x, int y) 
{
  double sum=0.0;
  for( int i=0 ; i<y ; i++ ) {
    for( int j=0 ; j<x ; j++ ) { 
      sum+=(double)b[i*x+j];
    }
  } 
  return (float)sum;
}

void print_DER_matrix(float *A)
{
  for( int i=0; i<8; i++ ) {
    for( int j=0; j<8; j++ ) {
      cerr<<setprecision(5)<<A[i*8+j]<<" ";
    }
    cerr<<endl;
  }
}

void compare_DER_matrices(float *A, float *B)
{
  for( int i=0; i<8; i++ ) {
    for( int j=0; j<8; j++ ) {
      cerr<<setprecision(5)<<fabs((A[i*8+j]-B[i*8+j])/B[i*8+j])<<" ";
    }
    cerr<<endl;
  }
}


///check if there is work to be done.
bool checkShm()
{  
  if( shmFrame1->Frame->requested_chirps > 0 ) {
    return true;
  }
  else 
    return false;
}

void setMatrix(float *sums) 
{
/*
  cerr<<"RETRIEVED=[";
  for( int i=0 ; i<11*4 ; i++ ) {
    cerr<<sums[i]<<", ";
  } 
  cerr<<"]"<<endl;
*/

  int k=0;
  for( int i=2;  i<=10; i++ ) {
    for( int j=0; j<4 ; j++ ) {
      oi->setDER( OrbitsRGBAmap[i][j], sums[k++]);
    }
  }
  for( int i=0; i<8 ; i++ ) oi->setder(i, sums[k++]);
}


void query_client(int GPUnum)
{
if(DEBUG){ 
  cerr<<"Querying head "<<GPUnum+1<<" : "<<heads[GPUnum][1]->Frame->requested_chirps<<" chirps remain.";
  cerr<<" between images "<<heads[GPUnum][0]->Frame->IDnum<<" and ";
  cerr<<heads[GPUnum][1]->Frame->IDnum<<endl;
  cerr<<"Current Estimate: "; heads[GPUnum][1]->printParams();
}
  //record estimate

  if( heads[GPUnum][1]->Frame->IDnum != -1 ) {
 //   cout<<"Replacing "<<heads[GPUnum][1]->Frame->IDnum<<" : "; planes[heads[GPUnum][1]->Frame->IDnum]->P_pairwise.print();
 //   cout<<" with "; heads[GPUnum][1]->printParams();
    planes[heads[GPUnum][1]->Frame->IDnum]->P_pairwise.set( heads[GPUnum][1]->Frame->params );
  }

}



void client_tasker(int w, int h, int nch, int frameID, unsigned char *b, 
                   int w2, int h2, int nch2, int frameID2, unsigned char *b2, int req_chirp, 
                   Parameters current_estimate)
{
  static int GPUnum=-1;

  //move to next GPU circularlys
  if( ++GPUnum  == NUM_PCI_HEADS ) GPUnum=0; 

  query_client(GPUnum);
  heads[GPUnum][0]->setFrame(w,h,nch,frameID,b);
  Parameters IDP; heads[GPUnum][1]->setParams(IDP); //set identity for first frame
  heads[GPUnum][1]->setFrame(w2,h2,nch2,frameID2,b2);
  heads[GPUnum][1]->setParams(current_estimate);
  heads[GPUnum][1]->setRequestedChirps(req_chirp);
if(DEBUG) {
  cerr<<"--------------------------------- "<<endl;
  cerr<<"server sending work out to client "<<GPUnum+1<<endl;
  cerr<<"Frames "<<frameID<<" and "<<frameID2<<" , for "<<req_chirp<<" more chirps"<<endl;
  cerr<<"Current estimate ";  current_estimate.print();
  cerr<<"--------------------------------- "<<endl;
}
}

//recompose all chirps up til frame number lastframe
void recompose_chirps(int firstframe, int lastframe, bool sshh)
{
  //determine Inverse transformation to center coordinates on
  //desired frame
  Parameters Ptmp;
  for( int i=0; i <=firstframe ; i++ ) {
    Ptmp = Ptmp * planes[i]->P_pairwise;
  }

  //initialize the cumulative parameters with inverse
  Ptmp.invert();
  planes[0]->P = Ptmp;
  
  //recompose all the chirps.
  for( int i=1; i <=lastframe ; i++ ) {
    if( !sshh )cout<<endl;
    if( !sshh )cout<<"recompose : "<<i-1<<" to "<<i << " :  ";
    //planes[i]->P = (planes[i-1]->P * planes[i]->P_pairwise).print();
    planes[i]->P = (planes[i-1]->P * planes[i]->P_pairwise);
    if( !sshh )cout<<"norm : ";
    if( !sshh )planes[i]->P.print();
    if( !sshh )cout<<endl;
  }
}

void test_variance( Parameters P, ProjPlane *frame1, ProjPlane *frame2 )
{
  float var;

  var = P.getVariance();

  if( var > 0.2 ) {
    cerr<<"Orbits failed. Images "<<frame1->getPlaneName()<<" and ";
    cerr<<frame2->getPlaneName()<<endl;
    P.print();
    exit(1); 
    
  }

}

bool requestDownsample =true; 

///This is the render/estimation function run by the main sever
void render_server() {

  //orbits->activate_fpbuffer();
/*
     orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
     orbits->setCGchirp();
      orbits->bindTextureARB1( planes[current_plane-1]->getTexNum() ); 
      orbits->bindTextureARB0( planes[current_plane  ]->getTexNum() );

      orbits->render_DS_ARB0(5);
      orbits->render_DS_ARB1(6);

      orbits->bindTextureARB0(5);
      orbits->bindTextureARB1(6);

      orbits->render();
  //orbits->deactivate_fpbuffer();
  orbits->showstats();  
  glutSwapBuffers();
  return;
*/





  if(  exec_est ){
    sums = (float *)malloc(sizeof(float)*4*11);
    orbits->activate_fpbuffer();
      //place desired images into the right texturing units 
      //moving this out would speed things up
/*
      orbits->bindTextureARB1( planes[current_plane-1]->getTexNum() ); 
      orbits->bindTextureARB0( planes[current_plane  ]->getTexNum() );
      orbits->render_DS_ARB0(5);
      orbits->render_DS_ARB1(6);
      orbits->bindTextureARB0(5);
      orbits->bindTextureARB1(6);
      orbits->render();
      orbits->grabDisplay(Dm, Dn, Dt, Da, 1); //needs n/m reversed
      oicpu->setDt(1, Dt);
      oicpu->setDm(1, Dn);//for unknown reason-orbits seems to treat m/n as h/v
      oicpu->setDn(1, Dm);
      oicpu->pseudo_estimate(1);
*/
      if( downlevel == 0 ) {
        orbits->bindTextureARB1( planes[current_plane-1]->getTexNum() ); 
        orbits->bindTextureARB0( planes[current_plane  ]->getTexNum() );
      }
      else if( downlevel == 1 && requestDownsample ) {
        orbits->bindTextureARB1( planes[current_plane-1]->getTexNum() ); 
        orbits->bindTextureARB0( planes[current_plane  ]->getTexNum() );
        orbits->render_DS_ARB0(5);
        orbits->render_DS_ARB1(6);
        requestDownsample = false;
      }
      //exec as immediate mode, 
      //currently this is necessary for the 
      //faster hessian, because it needs to 
      //dynamically determine if the hessian is 
      //already calculated
      if( !fullHessian ) {
        orbits->execEstimation();  
      } else {
        orbits->execEstimationList(); //exec as display list
      }

      orbits->getSums(sums);
      setMatrix(sums) ;
    orbits->deactivate_fpbuffer();
  

    //for( int i=0; i<11*4; i++ ) cerr<<sums[i]<<" ";
    //cerr<<endl;

    free(sums);

    oi->solve_system(downlevel);
    oi->getParameters(ptmp);
    //(exec_cpu)?oicpu->getParameters(ptmp):; //cpu fallback
    P.set(ptmp);
    //P.print();
    orbits->setChirpMatParams(P.get() );
    orbits->setCGchirp();
  }



  test_variance(P, planes[current_plane-1], planes[current_plane  ]);

  //render the current cement
  planes[0]->clear(); //clear out 
  planes[current_plane]->P_pairwise = P; //current pairwise estimate
  planes[current_plane]->P = planes[current_plane-1]->P*P; //cumulative

  for( int i=0 ; i<NUM_PCI_HEADS ; i++ ) { query_client(i); }

  recompose_chirps(keyframe,current_plane,true);

  if( render_cement )  {
    for( int i=0  ; i<=current_plane ; i++ ) {
      orbits->bindTextureARB0(planes[i]->getTexNum());
      planes[i]->draw(false); 
    }
  }



  nitercount++;
  if( nitercount == niter ) {
//    cout<<"CURRENT POSITION "; planes[current_plane]->P.print();
    nitercount=0;
    if( ++current_plane == num_planes ) { //we have reached end of sequence
      current_plane = num_planes-1;
      exec_est = false;
      //reset
      orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
      orbits->setCGchirp();
      oicpu->resetParams(); 
      oi->resetParams(); 
    }
    else { //move onto next image in sequence
//      planes[current_plane]->P = planes[current_plane-1]->P; 
//      planes[current_plane]->P.print(); 
      //reset
      orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
      orbits->setCGchirp(); ///!!! CRITICAL - FORGOT IN OLD DATA SETS I THINK
      orbits->resetHessian();
      oicpu->resetParams(); 
      oi->resetParams();  
      requestDownsample = true;
      //task out OLD frame (curent_plane -1)

      client_tasker(320,240,3,current_plane-2, membuf[current_plane-2],
                   320,240,3,current_plane-1, membuf[current_plane-1],
                    niterreq, P);

    }
  } 


  orbits->showstats();  
  glutSwapBuffers();
  return;
}


//This is the main estimation/rendering function run the by clients
void render_client() {
  static bool clientHasFrames = false;

  //task PRE amble :
  //continue or start working case
  if( shmFrame1->Frame->requested_chirps > 0 ) {
    //check if we need to update image set
    shmFrame0->enterMutex();
    if( shmFrame0->Frame->isNew ) { 
      cerr<<"Received new Frame[0] , id = "<<shmFrame0->getID()<<endl;
      orbits->init_texture(10, shmFrame0->Frame->width, 
                           shmFrame0->Frame->height, shmFrame0->getData() );
      cerr<<"Bound new frame ok "<<endl;
      shmFrame0->Frame->isNew = false; 
    }
    shmFrame0->leaveMutex();

    //really an updated image means recalculate the pair.
    //check if we need to update image set

    shmFrame1->enterMutex();
    if( shmFrame1->Frame->isNew ) { 
      cerr<<"Received new Frame[1] , id = "<<shmFrame1->getID()<<endl;
      orbits->init_texture(11, shmFrame1->Frame->width, 
                           shmFrame1->Frame->height, shmFrame1->getData() );
      cerr<<"Bound new frame ok "<<endl;
      shmFrame1->Frame->isNew = false;
      clientHasFrames = true;
      num_planes = 2;
      current_plane = 1;
      //reset because a frame has changed
    orbits->activate_fpbuffer();
      orbits->setChirpMatParams(shmFrame1->Frame->params);
      orbits->setCGchirp();
      orbits->resetHessian();
      cerr<<"Seeded estimation with ";
      orbits->printChirpMatParams();
    orbits->deactivate_fpbuffer();
      oi->setStartParams(shmFrame1->Frame->params); 
    }
    shmFrame1->leaveMutex();

    //turn on estimation engine
    exec_est = true;
  }
  else  { 
     exec_est = false;
  }


  //do da wurk, one repetition
  if( exec_est ){
    sums = (float *)malloc(sizeof(float)*4*11);
    orbits->activate_fpbuffer();
      //place desired images into the right texturing units
      //orbits->bindTextureARB1( planes[current_plane-1]->getTexNum() ); 
      //orbits->bindTextureARB0( planes[current_plane  ]->getTexNum() );
      orbits->bindTextureARB1( 10 ); 
      orbits->bindTextureARB0( 11 );

      //exec as immediate mode, 
      //currently this is necessary for the 
      //faster hessian, because it needs to 
      //dynamically determine if the hessian is 
      //already calculated
      if( !fullHessian ) {
        orbits->execEstimation();  
      } else {
        orbits->execEstimationList(); //exec as display list
      }


      orbits->getSums(sums);
      setMatrix(sums) ;
    orbits->deactivate_fpbuffer();
  
    //for( int i=0; i<11*4; i++ ) cerr<<sums[i]<<" ";
    //cerr<<endl;

    free(sums);

    oi->solve_system(downlevel);
    oi->getParameters(ptmp);
    //(exec_cpu)?oicpu->getParameters(ptmp):; //cpu fallback
    P.set(ptmp);
    P.print();
    orbits->setChirpMatParams(P.get() );
    orbits->setCGchirp();
  }

  //render the current cement
  planes[0]->clear(); //clear out 
  if( clientHasFrames ) {
    planes[current_plane]->P = planes[current_plane-1]->P*P;
/*
    for( int i=0  ; i<=current_plane ; i++ ) {
      orbits->bindTextureARB0(planes[i]->getTexNum());
 //     cerr<<"drawing tex num "<< planes[i]->getTexNum()<<endl;
      planes[i]->draw(false); 
    }
*/
  }

  // task POST amble:
  // run this if work was done
  if( exec_est ) {
    // tell shm that one more reptition completed, and set params
    shmFrame1->enterMutex();
    shmFrame1->Frame->requested_chirps--;
    shmFrame1->setParams(P);
    shmFrame1->leaveMutex();
  }

  orbits->showstats();  
  glutSwapBuffers();
  return;
}


void posixify(int argc, char * argv[]) {} //fill in from orbits version

void printHelp()
{
  cout<<"glestpchirp2m options:"<<endl;
  cout<<"   -r --render       \t: render the cement as it is built."<<endl;
  cout<<"   -c --client [id]  \t: run this instance as a client, with given id"<<endl;
  cout<<"   -s --serial [n]   \t: do this [n] number of serial iterations."<<endl;
  cout<<"   -p --parallell [n]\t: do this [n] number of parallel iterations."<<endl;
  cout<<"   -l --level [0,1]  \t: set the downsampling level. 0: 320x240, 1: 160x120"<<endl;
  cout<<"   -d --debug [0,1]  \t: turn on debugging"<<endl;
  cout<<"   -h --help         \t: print this help message, and quit"<<endl;
  cout<<endl;
  cout<<"While running, ESC quits, +/- change reference frame"<<endl;
  cout<<" 'g' grabs (window must be even integeter dimensions"<<endl;
  cout<<"Optionally, supply two input image file names"<<endl;
}

//parse options
static struct option long_options[] = {
     {"render", 0, 0, 'r'},
     {"hEssian", 0, 0, 'e'},
     {"client", 0, 0, 'c'},
     {"parallel", 0, 0, 'p'},
     {"serial", 0, 0, 's'},
     {"level", 0, 0, 'l'},
     {"debug", 0, 0, 'd'},
     {"help", 0, 0, 'h'},
     {0,0,0,0}
};

void parse_cmdline(int argc, char **argv)
{
   char c;
   opterr = 0; /* prevent weird options from causing errors */
   //posixify(argc,argv);

   while(1) {
     int this_option_optind = optind ? optind : 1;
     int option_index = 0;
     c = getopt_long (argc, argv, "c:rp:s:hl:de",
                      long_options, &option_index);
     if (c == -1) break;
     switch(c){
     case 'c' :
       client_id = atoi(optarg);
       if( client_id < 0 || client_id > 5 ) {
         cerr<<"Invalid Client ID "<<client_id<<" requested. aborting."<<endl;
         cerr<<"Client ID must lie in closed interval [0,5]"<<endl;
         exit(1);
       }
       cerr<<"Initializing as client ID "<<client_id<<endl;
       break;
     case 'r' : //render cement cumulatively
       render_cement = true;
       break;
     case 'p' : //parallel requests
       niterreq = atoi(optarg);
       cerr<<"requesting "<<niterreq<<" parallel estimations on ";
       cerr<<NUM_PCI_HEADS<<" additional cards"<<endl;
       break;
     case 's' : //parallel requests
       niter = atoi(optarg);
       cerr<<"requesting "<<niter<<" serial estimations"<<endl;
       break;
     case 'l' : //downsampling level
       downlevel = atoi(optarg);
       cerr<<"requesting downsample level "<<downlevel<<endl;
       assert(downlevel == 0 || downlevel == 1 );
       break;
     case 'd' ://debug
       DEBUG=atoi(optarg);
       cerr<<"requesting debug "<<DEBUG<<endl;
       	assert(DEBUG==0||DEBUG==1);
	break;
     case 'e' : //request faster non full hessian (reuse simpler hessian)
       fullHessian = false;  
       cerr<<"Setting Hessian Re-Use"<<endl;
       break;  
     case 'h' : //print help
       printHelp();  exit(0);
       break;
     defalt :
       cerr<<"WARNING: unknown switch "<<c<<endl;
     }

   }

   //after options what happens to non options
   //getopt places all unrecognized options at the end
   if( optind < argc ) {
     if( optind + 1 >= argc ) { 
       cerr<<"Two filenames must be supplied if you specify any"<<endl;
       exit(1);
     } 
     else {
       cerr<<"Filename 1: "<<argv[optind]<<endl;
       cerr<<"Filename 2: "<<argv[optind+1]<<endl;
       strcpy(filename1,argv[optind]);
       strcpy(filename2,argv[optind+1]);
     }
  }
  else {
       cerr<<"Filename 1 (Default): "<<filename1<<endl;
       cerr<<"Filename 2 (Default): "<<filename2<<endl;
  }
}

FragmentProgram *dispFP;

///// MAIN ///////////////////
//unsigned char whitebuf[320*240*4]= {255};
int main(int argc, char** argv)
{
   //ShmFrame f(0);
   for( int i=0; i<320*240*4; i++ ) whitebuf[i]=255;
   glutInit(&argc, argv);
   parse_cmdline(argc, argv); //make sure this occurs after glut parses
   cerr <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_ALPHA);
   glutInitWindowSize(imageWinWidth+1024-320, imageWinHeight+768-240);
   glutInitWindowPosition(0, 0);
   char title[50]={'\0'};
   sprintf(title, "%s %d", argv[0], client_id);
   //Orbwin=glutCreateWindow(title);
   Orbwin=glutCreateWindow(NULL);

   orbits=new CGDisplay(MAX_PLANES+12, 320,240, Orbwin );
   orbits->initDisplay();
   orbits->setDownsampleLevel(downlevel);
   orbits->setImageSize(320,240);  
   orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
   orbits->useFullHessian( fullHessian );
   orbits->initGL();

   gc=new ImlibCapture(100,101);
   gc->initCapture(orbits);
   
   oi = new OrbitsInterface(2, 240, 320);
   if(DEBUG) oi->setDebug(1);
   oicpu = new OrbitsInterface(2, 240, 320);

   //create shared memory areas, an image pair 0/1 for each head (card)
   if( client_id == 0 ) { 
     for( int i=0; i<NUM_PCI_HEADS; i++ ) {
       // this magic constructor actually creates shm
       heads[i][0] = new ShmFrame(i*2, 320, 240, 3, -1);
       heads[i][1] = new ShmFrame(i*2+1, 320, 240, 3, -1);
     }
   }
   else {
     int frame0ID = client_id*2-2;
     int frame1ID = frame0ID+1;
     shmFrame0 = new ShmFrame(frame0ID);
     shmFrame1 = new ShmFrame(frame1ID);
   }

   //these are for drawing nice pictures
   dispFP = new FragmentProgram( orbits->getContext(), orbits->getProfile(),
                                 "FPsamples/FP-nop.cg", 0);
   //load images - server
   if( client_id == 0 ) {
/*
     for( int i=651, j=0; i<750 && j<MAX_PLANES; i+=1, j++ ) {
       char fname[32];
       sprintf(fname, "/home/fungja/movie2/movie%03d.jpg", i);
       //sprintf(fname, "test-jpg/t%03d.ppm", i);
       //sprintf(fname,"/home/rosco/mann-gehry/output001-00000%03d.ppm",i); 
       ((ImlibCapture *)gc)->loadFile( fname );
       orbits->init_texture(10+j, gc->getRGBWidth(),
                            gc->getRGBHeight(),gc->getRGBData() );
       orbits->bindTextureARB0(10+j);
       int imgsz = gc->getRGBWidth()*gc->getRGBHeight()*3;
       // copy the image into a storage buffer, which is used to
       // send copies out to different cards
       membuf[j] = (unsigned char *)malloc(imgsz);
       memcpy(membuf[j], gc->getRGBData(), imgsz);
       num_planes = j+1;

       planes[j] = new ProjPlane(imageWinWidth, imageWinHeight,  dispFP);
       planes[j]->setTexNum(j+10);
       planes[j]->setPlaneName(fname);
     }
     */





     ((ImlibCapture *)gc)->loadFile(filename1);
     orbits->init_texture(10, gc->getRGBWidth(),
                          gc->getRGBHeight(),gc->getRGBData() );
     orbits->bindTextureARB0(10);
     planes[0] = new ProjPlane(imageWinWidth, imageWinHeight,  dispFP);
     planes[0]->setTexNum(10);
     planes[0]->setPlaneName(filename1);
   
     ((ImlibCapture *)gc)->loadFile(filename2);
     orbits->init_texture(11, gc->getRGBWidth(),
                          gc->getRGBHeight(),gc->getRGBData() );
     orbits->bindTextureARB0(11);
     planes[1] = new ProjPlane(imageWinWidth, imageWinHeight,  dispFP);
     planes[1]->setTexNum(11);
     planes[1]->setPlaneName(filename2);
     num_planes = 2;
     int imgsz = gc->getRGBWidth()*gc->getRGBHeight()*3;
     // copy the image into a storage buffer, which is used to
     // send copies out to different cards
     membuf[0] = (unsigned char *)malloc(imgsz);
     memcpy(membuf[0], gc->getRGBData(), imgsz);
     membuf[1] = (unsigned char *)malloc(imgsz);
     memcpy(membuf[1], gc->getRGBData(), imgsz);




   }
   else {
     orbits->init_texture(10, imageWinWidth, imageWinHeight,NULL);
     orbits->init_texture(11, imageWinWidth, imageWinHeight,NULL);
     for( int i=0 ; i<num_planes ; i++ ) {
       planes[i] = new ProjPlane(imageWinWidth, imageWinHeight,  dispFP);
       planes[i]->setTexNum(i+10);
     }

   }

   orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
   orbits->setCGchirp();
   oicpu->resetParams(); 
   oi->resetParams(); 

   //storage textures
   orbits->init_texture4f(2, imageWinWidth, imageWinHeight,NULL);
   orbits->init_texture4f(3, imageWinWidth, imageWinHeight,NULL);
   orbits->init_texture4f(4, imageWinWidth, imageWinHeight,NULL);
   orbits->init_texture4f(5, imageWinWidth/2, imageWinHeight/2,NULL);
   orbits->init_texture4f(6, imageWinWidth/2, imageWinHeight/2,NULL);
/*
    //these are for drawing nice pictures
   dispFP = new FragmentProgram( orbits->getContext(), orbits->getProfile(),
                                 "FPexamples/FP-nop.cg", 0);

   for( int i=0 ; i<num_planes ; i++ ) {
     planes[i] = new ProjPlane(imageWinWidth, imageWinHeight,  dispFP);
                               //orbits->getContext(), orbits->getProfile() );
     planes[i]->setTexNum(i+10);
   }
*/

   glutSetWindow(Orbwin);
   if( client_id == 0 ) {
     glutDisplayFunc(render_server);
   } else {
     glutDisplayFunc(render_client);
   }

   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMainLoop();
   return 0; 
}

void Orbits_Explicit()
{

  float DER_CPU[64];
  float DER_GPU[64];
  float sum[4];
  //reset
  //orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
  //oicpu->resetParams(); 
  //oi->resetParams(); 
/*
 orbits->activate_fpbuffer(); 
  //render deriv 
  orbits->bindTextureARB1(1);
  orbits->bindTextureARB0(0);
  orbits->render();

  //orbits->grabDisplay(Dm, Dn, Dt, Da, 0); //needs n/m reversed
  //    cerr<<"SumR = "<<R<<endl;
  //    cerr<<"SumG = "<<G<<endl;
  //    cerr<<"SumB = "<<B<<endl;
  //    cerr<<"SumA = "<<A<<endl;
  //buffer_sample_float4(samp, Dn, 0, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 1, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 2, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 3, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 317, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 318, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 0, 237, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 1, 237, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dt, 0, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dm, 0, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 0, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Da, 0, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];




 //full buffere readback
  //buffer_sample_float4(samp, Da, 10, 238, 319,239,1 ); cerr<<"Samp :"<<255*samp[0];

  glFlush();
  orbits->render_to_texture( 2, 0, 0, 320, 240 );
  //glutSwapBuffers();
  orbits->deactivate_fpbuffer(); 


  //estpairwise CPU
  if( exec_cpu ) {
    orbits->bindTextureARB1(1);
    orbits->bindTextureARB0(0);
    orbits->render();

    oicpu->setDt(0, Dt);
    oicpu->setDm(0, Dn); //for unknown reason - orbits seems to treat m/n as h/v
    oicpu->setDn(0, Dm);
    //oicpu->pseudo_estimate(0);
  } 

//  oi->getParameters(ptmp);
//  P.set(ptmp);
//  orbits->setChirpMatParams(P.get() );

  //HW estimation passes
  orbits->activate_fpbuffer();
  orbits->bindTextureARB0(2);
  for( int i =2; i <=10 ; i++ ) {
    orbits->bindTextureARB0(2);
    orbits->render_pass(i);

    if(exec_cpu) {
      //CPU Summation
      orbits->grabDisplay(Dm, Dn, Dt, Da, 0); //needs n/m reversed
      buffer_sample_float4(samp, Dt, 0, 238, 319,239,1 ); 
      //cerr<<" Samp:"<<samp[0];
      R = sumBuffer(Dt, 319, 239);
      G = sumBuffer(Dm, 319, 239);
      B = sumBuffer(Dn, 319, 239);
      A = sumBuffer(Da, 319, 239);
     
      cerr<<"Pass "<<i; 
      cerr<<setprecision(5)<<" SumR = "<<R;
      cerr<<setprecision(5)<<" SumG = "<<G;
      cerr<<setprecision(5)<<" SumB = "<<B;
      cerr<<setprecision(5)<<" SumA = "<<A<<endl;
    }
 
    //GPU summation
    orbits->render_to_texture( 3, 0, 0, 320, 240 );
    //orbits->sumTexture(3, sum); //immediate mode sumation, readback result
    //orbits->sumTextureList(3, sum);  //display list summation, readback result
    orbits->sumTextureList_and_Store(3, i-2);//summation and deferred retrieveal
    //orbits->getSums(i-2,1, sum);   //retrieves sums
    
    //cerr<<"GPU=["<<sum[0]<<", "<<sum[1]<<", "<<sum[2]<<", "<<sum[3]<<"]"<<endl;
    //use GPU results:
    R = sum[0]; G = sum[1]; B = sum[2]; A = sum[3];
    

    // set DER matrix for solution

    //oi->setDER( OrbitsRGBAmap[i][0], R);
    //oi->setDER( OrbitsRGBAmap[i][1], G);
    //oi->setDER( OrbitsRGBAmap[i][2], B);
    //oi->setDER( OrbitsRGBAmap[i][3], A);

  }

  orbits->bindTextureARB0(2);
  orbits->render_pass(11);
  if(exec_cpu) {
    //CPU Summation
    orbits->grabDisplay(Dm, Dn, Dt, Da, 0); //needs n/m reversed
    buffer_sample_float4(samp, Dt, 0, 238, 319,239,1 ); 
    //cerr<<" Samp:"<<samp[0];
    R = sumBuffer(Dt, 319, 239);
    G = sumBuffer(Dm, 319, 239);
    B = sumBuffer(Dn, 319, 239);
    A = sumBuffer(Da, 319, 239);
     
    cerr<<"Pass "<<11; 
    cerr<<setprecision(5)<<" SumR = "<<R;
    cerr<<setprecision(5)<<" SumG = "<<G;
    cerr<<setprecision(5)<<" SumB = "<<B;
    cerr<<setprecision(5)<<" SumA = "<<A<<endl;
  }

  //GPU summation
  orbits->render_to_texture( 3, 0, 0, 320, 240 );
  //orbits->sumTexture(3, sum);
  //orbits->sumTextureList(3, sum);
  orbits->sumTextureList_and_Store(3, 11-2);//summation and deferred retrieveal
  //orbits->getSums(11-2,1, sum);   //retrieves sums
  //cerr<<"GPU=["<<sum[0]<<", "<<sum[1]<<", "<<sum[2]<<", "<<sum[3]<<"]"<<endl;
  //use GPU results:
  R = sum[0]; G = sum[1]; B = sum[2]; A = sum[3];
 
  // set DER matrix for solution

  //oi->setder( 0, R);
  //oi->setder( 1, G);
  //oi->setder( 2, B);
  //oi->setder( 3, A);



   
  orbits->bindTextureARB0(2);
  orbits->render_pass(12);
  if(exec_cpu) { 
    //CPU Summation
    orbits->grabDisplay(Dm, Dn, Dt, Da, 0); //needs n/m reversed
    buffer_sample_float4(samp, Dt, 0, 238, 319,239,1 ); 
    //cerr<<" Samp:"<<samp[0];
    R = sumBuffer(Dt, 319, 239);
    G = sumBuffer(Dm, 319, 239);
    B = sumBuffer(Dn, 319, 239);
    A = sumBuffer(Da, 319, 239);
   
    cerr<<"Pass "<<11; 
    cerr<<setprecision(5)<<" SumR = "<<R;
    cerr<<setprecision(5)<<" SumG = "<<G;
    cerr<<setprecision(5)<<" SumB = "<<B;
    cerr<<setprecision(5)<<" SumA = "<<A<<endl;
  }

  //GPU summation
  orbits->render_to_texture( 3, 0, 0, 320, 240 );
  //orbits->sumTexture(3, sum);
  //orbits->sumTextureList(3, sum);
  orbits->sumTextureList_and_Store(3, 12-2);//summation and deferred retrieveal
//  orbits->getSums(12-2,1, sum);   //retrieves sums
  //cerr<<"GPU=["<<sum[0]<<", "<<sum[1]<<", "<<sum[2]<<", "<<sum[3]<<"]"<<endl;
  //use GPU results:
  R = sum[0]; G = sum[1]; B = sum[2]; A = sum[3];
 
  // set DER matrix for solution

  //oi->setder( 4, R);
  //oi->setder( 5, G);
  //oi->setder( 6, B);
  //oi->setder( 7, A);


  sums = (float *)malloc(sizeof(float)*4*11);
  orbits->getSums(0, 11, sums);
  cerr<<"1st estimation"<<endl;
  for( int i=0; i<11*4; i++ ) cerr<<sums[i]<<" ";
  cerr<<endl;
  setMatrix(sums) ;
  free(sums);
  orbits->deactivate_fpbuffer();
  cerr<<"--------------"<<endl<<endl;

*/
}

/*
void verify_to_cpu() {
    orbits->activate_fpbuffer();
      orbits->bindTextureARB1( planes[current_plane-1]->getTexNum() ); 
      orbits->bindTextureARB0( planes[current_plane  ]->getTexNum() );
      orbits->render();
      orbits->grabDisplay(Dm, Dn, Dt, Da, 0); //needs n/m reversed
      oicpu->setDt(0, Dt);
      oicpu->setDm(0, Dn);//for unknown reason-orbits seems to treat m/n as h/v
      oicpu->setDn(0, Dm);
      oicpu->pseudo_estimate(0);
    orbits->deactivate_fpbuffer();
}
*/
