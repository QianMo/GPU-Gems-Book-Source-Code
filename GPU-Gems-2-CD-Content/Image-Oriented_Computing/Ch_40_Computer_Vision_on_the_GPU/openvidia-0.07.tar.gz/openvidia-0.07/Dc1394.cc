/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/
#include "Dc1394.h"
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
using namespace std;
void TellRWMHeCanUseImage(const char *);


Dc1394 :: ~Dc1394() { 
  if(handle!=0) {
    dc1394_release_camera(handle,&camera);
    raw1394_destroy_handle(handle);
  }
  cout << "Destroyed dc1394" << endl;
}

Dc1394 :: Dc1394() {
  bufferUsed=0;
  noDMA = false;
  CaptureWidth = DefaultCaptureWidth;
  CaptureHeight = DefaultCaptureHeight;
  cout <<"Capturing at "<<CaptureWidth<<"x"<<CaptureHeight<<endl; 

  doOHCI();
}


/*
 * Populate handle, camera_nodes
 */
void Dc1394 :: doOHCI() {
  int numNodes;
  int numCameras;
  dc1394_feature_set features;
  dc1394_camerainfo info;

  /*-----------------------------------------------------------------------
   *  Open ohci and asign handle to it
   *-----------------------------------------------------------------------*/
  handle = dc1394_create_handle(0);
  if (handle==NULL)
  {
    fprintf( stderr, "Unable to aquire a raw1394 or video1394 handle\n\n"
             "Please check \n"
	     "  - if the kernel modules `ieee1394',`raw1394' and `ohci1394' are loaded \n"
	     "  - if you have read/write access to /dev/raw1394\n\n");
    cerr<<"killing thread."<<endl;
    int *killer=0;
    int a=*killer;
  }

  
  /*-----------------------------------------------------------------------
   *  get the camera nodes and describe them as we find them
   *-----------------------------------------------------------------------*/
  numNodes = raw1394_get_nodecount(handle);
  camera_nodes = dc1394_get_camera_nodes(handle,&numCameras,1);
  if (numCameras<1) {
    fprintf( stderr, "no cameras found :(\n");
    raw1394_destroy_handle(handle);
  }
  printf("working with the first camera on the bus\n");
  dc1394_get_camera_info(handle,  camera_nodes[0], &info);       
  //if ( !strncmp(info.vendor, "PYRO", 4)  ) {      
  //  cerr<<"ads pyro webcam detected, no DMA support so disabling DMA "<<endl;   
  //  noDMA = true;   
  //}       
   //dc1394_print_camera_info( &info );
  
  /*-----------------------------------------------------------------------
   *  to prevent the iso-transfer bug from raw1394 system, check if
   *  camera is highest node. For details see 
   *  http://linux1394.sourceforge.net/faq.html#DCbusmgmt
   *  and
   *  http://sourceforge.net/tracker/index.php?func=detail&aid=435107&group_id=8157&atid=108157
   *-----------------------------------------------------------------------*/
  if( camera_nodes[0] == numNodes-1)
  {
    fprintf( stderr, "\n"
             "Sorry, your camera is the highest numbered node\n"
             "of the bus, and has therefore become the root node.\n"
             "The root node is responsible for maintaining \n"
             "the timing of isochronous transactions on the IEEE \n"
             "1394 bus.  However, if the root node is not cycle master \n"
             "capable (it doesn't have to be), then isochronous \n"
             "transactions will not work.  The host controller card is \n"
             "cycle master capable, however, most cameras are not.\n"
             "\n"
             "The quick solution is to add the parameter \n"
             "attempt_root=1 when loading the OHCI driver as a \n"
             "module.  So please do (as root):\n"
             "\n"
             "   rmmod ohci1394\n"
             "   insmod ohci1394 attempt_root=1\n"
             "\n"
             "for more information see the FAQ at \n"
             "http://linux1394.sourceforge.net/faq.html#DCbusmgmt\n"
             "\n");
  }
  
  /*-----------------------------------------------------------------------
   *  setup capture
   *-----------------------------------------------------------------------*/
  int mode=-1;       
  switch(CaptureWidth){   
          case 320:       
                  mode=MODE_320x240_YUV422;   
                  cout<<"320x240_YUV422 capture selected"<<endl;       
                  break;       
          case 640:       
                 mode=MODE_640x480_YUV411;    
                 //mode=MODE_640x480_RGB;     
                 cout<<"640x480_YUV411 capture selected"<<endl;   
                 break;   
         default :   
                 cerr<<"unknown capture height"<<endl;       
                 _Exit(-1);    
  }   
      
   if( noDMA ) {     
       printf("Setting up Raw camera capture.\n");      
     if (dc1394_setup_capture(handle,    
                       camera_nodes[0], // camera id    
                       0, // iso channel      
                       FORMAT_VGA_NONCOMPRESSED, //format    
                       //MODE_320x240_YUV422, //mode    
                       mode, //mode      
                       SPEED_400, //max speed      
                       FRAMERATE_30, //framerate   
                       //FRAMERATE_15, //framerate      
                       &camera)!=DC1394_SUCCESS)   
     {     
       fprintf( stderr,"unable to setup camera for single image cap-\n"     
             "check line %d of %s to make sure\n"       
             "that the video mode,framerate and format are\n"     
             "supported by your camera\n",    
             __LINE__,__FILE__);    
       dc1394_release_camera(handle,&camera);      
       raw1394_destroy_handle(handle);   
       //exit(1);    
     }     
   }       
   else {
  if (dc1394_dma_setup_capture(handle,
			       camera_nodes[0], // camera id
			       0, // iso channel
			       FORMAT_VGA_NONCOMPRESSED, //format
                      mode,
	//		       			       MODE_320x240_YUV422, 
			      // MODE_640x480_YUV411,
			      //MODE_640x480_MONO
			      //MODE_640x480_RGB,
			       SPEED_400, //max speed
			       FRAMERATE_30, //framerate
			       3, //num dma buffers
			       0,//dma extra buffers
			       1, //dropframes
			       "/dev/video1394/0", //videodevice
			       &camera)!=DC1394_SUCCESS) 
    {
      fprintf( stderr,"unable to setup camera for dma capture\n"
	       "check line %d of %s to make sure\n"
             "that the video mode,framerate and format are\n"
	       "supported by your camera\n",
	       __LINE__,__FILE__);
      dc1394_release_camera(handle,&camera);
      raw1394_destroy_handle(handle);
    }
  cerr<<"CLOEXEC is "<<fcntl(camera.dma_fd, F_GETFD)<<endl;
  fcntl(camera.dma_fd, F_SETFD, FD_CLOEXEC);
  cerr<<"CLOEXEC is "<<fcntl(camera.dma_fd, F_GETFD)<<endl;
  cerr <<"Dc1394 using rgb24"<<endl;
  }//endif noDMA

  /*-----------------------------------------------------------------------
   *  have the camera start sending us data
   *-----------------------------------------------------------------------*/
  if (dc1394_start_iso_transmission(handle,camera.node)
      !=DC1394_SUCCESS) 
    {
      fprintf( stderr, "unable to start camera iso transmission\n");
      dc1394_release_camera(handle,&camera);
      raw1394_destroy_handle(handle);
      int *killer=0;
      int a=*killer;
    }
}



// Thread runs this method
void Dc1394 :: run() {
  int retval;
  while(1) {
    while(bufferUsed==1) {
     struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 500; 
     select(0,0,0,0, &tv);
    }
    lock();
    if( noDMA ) {
      retval = dc1394_single_capture(handle,&camera);
    }
    else { 
      retval = dc1394_dma_single_capture(&camera) ;
    }
    unlock();
    if( retval != DC1394_SUCCESS ) {
      cerr<< "single frame capture failed"<<endl;
      cerr<<"killing thread."<<endl;
      int *killer=0;
      int a=*killer;
    }
    bufferUsed=1;
    // notify thread he can grab buffer (shouldn't touch it.
    TellRWMHeCanUseImage((const char *)camera.capture_buffer);
    // later: Dc1394->return(pointer p).
    // dc1394_dma_done_with_buffer(&camera);
  }
}

void Dc1394 :: tellThreadDoneWithBuffer() {
  if( !noDMA && bufferUsed != 0 ) dc1394_dma_done_with_buffer(&camera);
  bufferUsed=0;
}
