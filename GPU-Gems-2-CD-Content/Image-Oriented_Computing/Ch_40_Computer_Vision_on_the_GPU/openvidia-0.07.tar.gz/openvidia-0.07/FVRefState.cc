/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "FVRefState.h"
///default constructor,  sets tracked position to be center of image
FVRefState::FVRefState() 
{
  pos[0] = 0.5;
  pos[1] = 0.5;
  for( int i =0 ;i<240 ; i++ ) {
    Age[i] = 0;
  }
}

int FVRefState::reinit(int IDcount) 
{
  int i=0;
  for( i=0 ; i<240; i++ ) {
    ID[i] = IDcount++;
    Age[i] = 0;
  }
  return IDcount+i;
}

int FVRefState::findBestFeatureMatchLocal(
                          //where are the corners
                          float corners[1000][2],
                          float cornersPrev[1000][2],

                          //feature vectors
                          float fvec[240][128],
                          float fvecPrev[240][128],

                          //where to write the matches
                          float match[240][5],

                          int RefFVecAge[240], 
                          //how many elements of the above arrays are 
                          // actually filled
                          int numFeaturesNew,
                          int numFeaturesOld,

                          //Parameters: if we have a guess as to where
                          // the points are (i.e. when we are
                          // comparing to an old reference frame),
                          // then we can use it before we 
                          // restrict the search radius.
                          Parameters Pguess,


                          //search radius to restrict matches to.
                          float searchRadius, 
                          float thresh  )
{
  float THRESH = thresh*thresh;
  int matchArrayIndex = 0;
  float searchRad2 = searchRadius*searchRadius;

  for( int currentF=0 ; currentF<numFeaturesNew ; currentF++ ) {
    float distance1 = 9999; //normalized ,so max is 1
    float distance2 = 9999; //normalized ,so max is 1
    int bestPos = -1;

    float currentX = corners[currentF][0];
    float currentY = corners[currentF][1];


    for( int prevF =0 ; prevF<numFeaturesOld ; prevF++ ) {

       float prevX = cornersPrev[prevF][0];
       float prevY = cornersPrev[prevF][1];

       float dist = (currentX - prevX)*(currentX-prevX) +
                    (currentY - prevY)*(currentY-prevY) ;


      // if( dist > searchRadius) break;

       if( dist < searchRad2 ) {


         float diff = distBetweenFeatures(fvec[currentF],
                                          fvecPrev[prevF]);
         if( diff < distance1 ) {
           distance2 = distance1;
           distance1 = diff;
           bestPos = prevF;
         }

      }

    }

    if( distance1 < THRESH*distance2 ) {
      //match is good.
      match[matchArrayIndex][0] = cornersPrev[bestPos][0];
      match[matchArrayIndex][1] = cornersPrev[bestPos][1];
      match[matchArrayIndex][2] = corners[currentF][0];
      match[matchArrayIndex][3] = corners[currentF][1];
      //record the ID number into the current data array
/*
      FVcurrent.ID[currentF] = FVreference.ID[bestPos];
      FVcurrent.Age[currentF] = FVreference.Age[bestPos]+1;
      match[matchArrayIndex][4] = FVprevious.Age[currentF];
*/
      Age[currentF] = ++RefFVecAge[bestPos];
    
      matchArrayIndex++;
    }

  }
  ///cerr<<"Matched "<<matchArrayIndex<<" features"<<endl;
  //printMatches(matchArrayIndex);
  return matchArrayIndex;
}


///Calculate the distance between feature vectors, euclidean distance,
///128 elements.  MMX routine is included, but #define'd out by 
///Default (define USEMMX to use it, and use -O2 and may conflict with
///some -f gcc optimizations).
inline float FVRefState::distBetweenFeatures( float *v1, float *v2 )
{
  float dist =0.0;
#ifdef USEMMX 
   //not much difference here.  about -0.5 msecs for 200 features (11msecs)
   //total. leaving this out because it conflicts with -O3 optim flag
   int index=0;
   float sum[4] = {0.0, 0.0, 0.0, 0.0};
   while(index < 128)  // run across the row
   {

      __asm__( // instruction             #pipe    comment                  
              "\n\t movups %1,%%xmm0       \t# u  load inim1  "
              "\n\t movups %2,%%xmm1       \t# u  load inim2 "
              "\n\t subps %%xmm0,%%xmm1       \t# u  multiply "
              "\n\t mulps %%xmm1, %%xmm1    \t # square "
              "\n\t movups %3,%%xmm0       \t# u  load inim2 "
              "\n\t addps %%xmm1, %%xmm0        \t # add to runnning sum"
              "\n\t movups %%xmm0,%0       \t# u  store result "
              : "=m" (sum[0])  // this is %0,  output
              : "m" (v1[index]),  // this is %1,  an input
                "m" (v2[index]),   // this is %2,  an input
                "m" (sum[0])    // this is %3,  an input, running sum
      // the "=m" implies it is output.. just "m" is input
      // see the gcc info pages for more details...
      );

    index+=4 ; //note movpd/mulpd are for 2 packed floatprecision vals
  }
  // ok, done with MMX,reset it to normal floating point usage

   __asm__("emms" : : );

  //cerr<<"mmx says "<<sum[0]+sum[1]+sum[2]+sum[3]<<" ";
  dist = sum[0]+sum[1]+sum[2]+sum[3];
#else
  for( int i =0 ; i< 127 ; i++ ) {
    float x = v1[i]-v2[i];
    x = x*x;
    dist += x;
  }
#endif
  ///cerr<<"dist says "<<dist<<endl; 
  return dist;
}

///Primay effect here is to fill in the matchArray variable which
///holds corner correspondences
int FVRefState::findCorrespondences( FVRefState &reference,
                               Parameters guess, float searchRadius, 
                               float matchArray[240][5], float thresh)
{
  
     int FVnumMatched = findBestFeatureMatchLocal(
          corners, reference.corners,
          fvec, reference.fvec,
          matchArray,
          reference.Age,
          numFeatures, reference.numFeatures,
          guess, searchRadius, thresh );
     return FVnumMatched;
}
