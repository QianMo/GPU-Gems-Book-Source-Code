/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _DOWNSAMPLER_H
#define _DOWNSAMPLER_H

#include "FragmentProgram.h"
#include <glh/glh_extensions.h>

///The Downsampler object is used to downsample the 
///current contents of either ARB0 or ARB1, and place the
///resulting downsampled image in a target texture.
///Currently it takes 320x240 textures and downsamples them
///using a 3x3 local average to create a 160x120 texture.
class Downsampler {
     GLuint downsampleListName;
   
     int width;
     int height;
     int fpbwidth, fpbheight;

     bool listIsCompiled;
     
     FragmentProgram *FPdownsampler;
     FragmentProgram *FPdownsamplerARB0;
     FragmentProgram *FPdownsamplerARB1;
     void copyResult(GLuint targTexture);

   public : 
     Downsampler( int w, 
                  int h,
                  int fpw,
                  int fph,
                  CGcontext fContext,
                  CGprofile fProfile );
     //render downsampled version of origtexture into targtexture
     void downSample(GLuint origTexture, GLuint targTexture);
     //render ds version of whats in either ARB1 or ARB0 into target texture
     void downSampleARB0(GLuint targTexture);
     void downSampleARB1(GLuint targTexture);
};

#endif
