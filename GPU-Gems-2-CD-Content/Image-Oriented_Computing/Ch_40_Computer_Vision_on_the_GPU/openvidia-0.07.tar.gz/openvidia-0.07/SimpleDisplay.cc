/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "SimpleDisplay.h"
#include "nvidia.h"

#include <Cg/cgGL.h>
#include <glh/glh_extensions.h>

#include <iostream>
using namespace std;

extern CGparameter E1Texture, E2Texture, someColor, E2texCoord,E1texCoord, colorO, xincrementParam, yincrementParam;
extern CGprofile vProfile;
extern CGprogram fragmentProgram;
extern CGcontext vContext;

static unsigned char whitebuf[320*240*3] = {255};


SimpleDisplay::SimpleDisplay(int num_textures, int w, int h, int win) 
  : GenericDisplay(win)
{
  imageWinWidth = w;
  imageWinHeight = h;
  //downsample_levels : how many times downsampled (0 is orig, 1 is downsmpl 1x)
  downsample_level = 0; 
  this->num_textures=num_textures;
  // create vector to hold textures
  texNames = new GLuint[num_textures+1];
  cerr << "Constructed CGdisplay" << endl;
  
  //initialize chirpmat, have fun figuring out the mod 5 ;) FOOL
  int i;
  for (i=0; i<16; i++ ) { (i%5==0)?chirpmat[i]=1.0:chirpmat[i]=0.0; } //dense!

  for( i=0 ; i<320*240*3; i++ ) whitebuf[i]=255;
 
  fprintf(stderr,"GL_RENDERER   = %s\n", (char *) glGetString(GL_RENDERER));
  fprintf(stderr,"GL_VERSION    = %s\n", (char *) glGetString(GL_VERSION));
  fprintf(stderr,"GL_VENDOR     = %s\n", (char *) glGetString(GL_VENDOR));

}

void SimpleDisplay::initGL() {
  char *cgname="FPsamples/FP-basic.cg";
  initGL(cgname);
}

void SimpleDisplay::initGL(char* cgname) {
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glShadeModel(GL_FLAT);
  glEnable(GL_DEPTH_TEST);
  if( ImageHeight == -1 || ImageWidth == -1 ) {
    cerr<<"error, called initGL without having set image size!"<<endl;
    exit(1);
  }
  init_cg(texNames, ImageWidth, ImageHeight, chirpmat);
  //FPSimple = new FragmentProgram( vContext, vProfile, "FPsamples/FP-basic.cg",
  //  FPSimple = new FragmentProgram( vContext, vProfile, "FPsamples/FP-basic.cg",
  //FPSimple = new FragmentProgram( vContext, vProfile, "FPsamples/FP-pathoSum.cg",
  //  FPSimple = new FragmentProgram( vContext, vProfile, "FPsamples/FP-hacksum.cg",
  FPSimple = new FragmentProgram( vContext, vProfile, cgname,
				  texNames[0] );
  glh_init_extensions("GL_ARB_multitexture");
  glGenTextures(num_textures, texNames);

  cerr<<"Creating Image buffer"<<imageWinWidth<<"x" << imageWinHeight<<"...";
  if (!fpbuffer.create(imageWinWidth, imageWinHeight)) exit(-1);
  cerr << "[ok]" << endl;
}


// should bounds check on id?
void SimpleDisplay::init_texture(int id, int width, int height, void *data) {
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER,
                  //GL_NEAREST); 
                  GL_LINEAR); 
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER,
                  //GL_NEAREST);
                  GL_LINEAR);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGBA,
	       width, height,
	       0, GL_RGB, GL_UNSIGNED_BYTE, data);
	       //0, GL_RGB, GL_UNSIGNED_BYTE, whitebuf);
  //bindTextures();
  errcheck();
}
// should bounds check on id?
void SimpleDisplay::init_texture4c(int id, int width, int height, void *data) {
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER,
                  //GL_NEAREST); 
                  GL_LINEAR); 
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER,
                  //GL_NEAREST);
                  GL_LINEAR);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGBA,
	       width, height,
	       0, GL_RGBA, GL_UNSIGNED_BYTE, data);
	       //0, GL_RGB, GL_UNSIGNED_BYTE, whitebuf);
  //bindTextures();
  errcheck();
}


void SimpleDisplay::reinit_texture(int id, int width, int height, void *data) {
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glTexSubImage2D(GL_TEXTURE_RECTANGLE_NV, 0,0,0,
	       width, height, GL_RGB, GL_UNSIGNED_BYTE, data);
  errcheck();
}

void SimpleDisplay::reinit_texture1f(int id, int width, int height, void *data) {
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glTexSubImage2D(GL_TEXTURE_RECTANGLE_NV, 0,0,0,
            //OMG lol how does anything still wurk
            //width, height, GL_RED, GL_UNSIGNED_BYTE, data);
            width, height, GL_RED, GL_FLOAT, data);
  errcheck();
}



void SimpleDisplay::init_texture4f(int id, int width, int height, void *data) {
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER,
                  //GL_LINEAR);
                  GL_NEAREST);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER,
                  //GL_LINEAR);
                  GL_NEAREST );
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGBA_NV,
            width, height,
            0, GL_RGBA, GL_FLOAT, NULL);
  errcheck();
}
 

void SimpleDisplay::bindTextureARB0(int texobj ) 
{
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[texobj]);
}

//bind textures to texturing units
void SimpleDisplay::bindTextures() {
  //glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glActiveTextureARB(GL_TEXTURE0_ARB);
 // glEnable(GL_TEXTURE_2D);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[0]);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

  glActiveTextureARB(GL_TEXTURE1_ARB);
 // glEnable(GL_TEXTURE_2D);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[0]);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

  glActiveTextureARB(GL_TEXTURE2_ARB);
  errcheck();
 // glEnable(GL_TEXTURE_2D);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[0]);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);


}

void SimpleDisplay::idleFunc() {
  //bindTextures();
  render();
}
void SimpleDisplay::renderAt() {
  //  cout << "render loop" << endl;
  //bindTextures();
  //YUVCConvet: this line essential? 
  //DONTCLEAR THE COLOR BIT.  MAKES IT TOO FUNKY.
  //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glClear(GL_DEPTH_BUFFER_BIT);

  //nv_reset_pchirp(chirpmat);

  cgGLEnableProfile(vProfile);
  FPSimple->activate();

  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;
  texwidth = texwidth/powf(2.0, downsample_level);
  texheight = texheight/powf(2.0, downsample_level);
  //apply projection
//  glMatrixMode(GL_PROJECTION);
//  glPushMatrix(); //save projection matrix before manipulation
//  glMultMatrixf( getChirpMat() );
/*
  cerr<<"rending tex coords r,b are ";
  cerr<<ImageWidth<<" , " <<ImageHeight<<endl;
  cerr<<"texWidth/Height are ";
  cerr<<texwidth<<" , "<<texheight<<endl;
*/

  glBegin(GL_QUADS);
    //glTexCoord3f(0.0, ImageHeight, dist); 
    glTexCoord3f(ImageWidth, ImageHeight, dist); 
    glVertex3f( origin, origin+texheight, texdist);

    //glTexCoord3f(0.0, 0.0, dist); 
    glTexCoord3f(ImageWidth, 0.0, dist); 
    glVertex3f( origin, origin, texdist);

    //glTexCoord3f(ImageWidth, 0.0, dist); 
    glTexCoord3f(0.0, 0.0, dist); 
    glVertex3f( origin+texwidth, origin, texdist);

    //glTexCoord3f(ImageWidth, ImageHeight, dist);
    glTexCoord3f(0.0, ImageHeight, dist);
    glVertex3f( origin+texwidth, origin+texheight, texdist);
  glEnd();

        ///nneed to continue using this in rendering
        ////the cropped texture
  FPSimple->deactivate(); 

  //glFlush(); //ERRANT?
  errcheck();
}


void SimpleDisplay::render() {
  //  cout << "render loop" << endl;
  //bindTextures();
  //YUVCConvet: this line essential? 
  //DONTCLEAR THE COLOR BIT.  MAKES IT TOO FUNKY.
  //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glClear(GL_DEPTH_BUFFER_BIT);

  //nv_reset_pchirp(chirpmat);

  cgGLEnableProfile(vProfile);
  FPSimple->activate();

  glMatrixMode(GL_MODELVIEW);  
  glLoadIdentity();

  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;
  texwidth = texwidth/powf(2.0, downsample_level);
  texheight = texheight/powf(2.0, downsample_level);
  //apply projection
//  glMatrixMode(GL_PROJECTION);
//  glPushMatrix(); //save projection matrix before manipulation
//  glMultMatrixf( getChirpMat() );

  glBegin(GL_QUADS);
    glTexCoord3f(0.0, ImageHeight, dist); 
    glVertex3f( origin, origin+texheight, texdist);

    glTexCoord3f(0.0, 0.0, dist); 
    glVertex3f( origin, origin, texdist);

    glTexCoord3f(ImageWidth, 0.0, dist); 
    glVertex3f( origin+texwidth, origin, texdist);

    glTexCoord3f(ImageWidth, ImageHeight, dist);
    glVertex3f( origin+texwidth, origin+texheight, texdist);
  glEnd();

        ///nneed to continue using this in rendering
        ////the cropped texture
  FPSimple->deactivate(); 

  //glFlush(); //ERRANT?
  errcheck();
}


void SimpleDisplay::grabDisplay(float *Dm, float *Dn, float *Dt,  float *Da,
                            int downsample_level  )
{
  static float *rgba_buffer = NULL;
  int readX, readY;    //amount to read
  int startX, startY;  //starting corner
  int i=0,j=0;

  //read the framebuffer into memory
  if( rgba_buffer == NULL) {
    rgba_buffer = (float *)malloc(sizeof(float)*imageWinWidth*imageWinHeight*4);
  }



  startX = 0;
  startY = (imageWinHeight-(int)(imageWinHeight/(pow(2.0,(double)downsample_level))));
  //startY = 0;


  readX = (int)(imageWinWidth/(pow(2.0,(double)downsample_level))-1);
  readY = (int)(imageWinHeight/(pow(2.0,(double)downsample_level))-1) + startY;
  //readY = imageWinHeight/fraction;

  cout << "reading (" << startX << "," << readX; 
  cout << ") to (" << startY << "," <<readY  <<")" << endl;


 
 //TODO could try partial read pixels, and thread the channel splitting? 
/*
  glReadPixels( startX, startY, readX, readY, 
                GL_RGB, GL_FLOAT, rgba_buffer);
 
  //split out derivatives into 1 channel derivative images 
  //for( i=0 ; i< (imageWinWidth-1) * (imageWinHeight-1) * 4 ;  ) {
  for( i=0 ; i< (imageWinWidth-1) * (imageWinHeight-1) * 3 ;  ) {
    Dm[j]  = rgba_buffer[i++];
    Dn[j]  = rgba_buffer[i++];
    Dt[j]  = rgba_buffer[i++];
    //Dt[j]  = rgba_buffer[i++];
    j++;
  }
*/
//  22 -> 25 fps on 700Mhz+FX5200
  glReadPixels( startX, startY, readX, readY, 
                GL_RED, GL_FLOAT, Dm);
  glReadPixels( startX, startY, readX, readY, 
                GL_GREEN, GL_FLOAT, Dn);
  glReadPixels( startX, startY, readX, readY, 
                GL_BLUE, GL_FLOAT, Dt);
  //glReadPixels( startX, startY, readX, readY, 
  //              GL_ALPHA, GL_FLOAT, Da);

}

//// SUM DISPLAY
//sums the independent channels displayed
void SimpleDisplay::sumDisplay(float *R, float *G, float *B, float *A)
{
  static float *rgba_buffer = NULL;
  register double sumR=0.0, sumG=0.0, sumB=0.0, sumA=0.0;
  int readX, readY;    //amount to read
  int startX, startY;  //starting corner
  int i=0,j=0;

  //read the framebuffer into memory
  if( rgba_buffer == NULL) {
    rgba_buffer = (float *)malloc(sizeof(float)*imageWinWidth*imageWinHeight*4);
  }
  startX = 0;
  startY = imageWinHeight-imageWinHeight/(int)(powf(2.0,downsample_level))/fraction;
  readX = (int)(imageWinWidth/(pow(2.0,(double)downsample_level))-1+1);
  readY = imageWinHeight-1+1;
  //cout << "summing (" << startX << "," << readX; 
  //cout << ") to (" << startY << "," <<readY  <<")" << endl; 
  glReadPixels( startX, startY, readX, readY, GL_RGBA, GL_FLOAT, rgba_buffer);

  //gets [B,G,R,A]
  //MMX Fodder
  for( i=0 ; i< (readX-startX) * (readY-startY) * 4 ;  ) {
    sumR += rgba_buffer[i++];
    sumG += rgba_buffer[i++];
    sumB += rgba_buffer[i++];
    sumA += rgba_buffer[i++];
  }

  *R = sumR; *G = sumG; *B = sumB; *A = sumA;
  //cout << "R="<<sumR<<" G="<<sumG<<" B="<<sumB<<" A="<<sumA<<endl;
  return;
}

void SimpleDisplay::grabDisplay(unsigned char *Dm, unsigned char *Dn, unsigned char *Dt)
{
  static unsigned char *rgba_buffer = NULL;
  int i=0,j=0;

  //read the framebuffer into memory
  if( rgba_buffer == NULL) {
    rgba_buffer = (unsigned char *)malloc( ImageWidth*ImageHeight*4);
  }
  glReadPixels(0,0,ImageWidth,ImageHeight, GL_RGBA,GL_UNSIGNED_BYTE,rgba_buffer);
 
  //split out derivatives into 1 channel derivative images 
  for( i=0 ; i<ImageHeight*ImageHeight*4 ;  ) {
    Dm[j]  = rgba_buffer[i++];
    Dn[j]  = rgba_buffer[i++];
    Dt[j]  = rgba_buffer[i++];
    i++; 
    j++;
  }
}

void SimpleDisplay::activate_fpbuffer() { fpbuffer.activate(); }
void SimpleDisplay::deactivate_fpbuffer() { fpbuffer.deactivate(); }
void SimpleDisplay::clear_fpbuffer() {
  glClearColor(0.0, 0.0, 0.0, 0.0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void SimpleDisplay::showstats(void) {
  int curtime;
  curtime = time(NULL);
  if( lasttime != curtime) {
    fps=fpscounter;
    fpscounter=1;
    lasttime = curtime;
    //cout << "fps = " << fps << "  " << 1.0/((float)fps)*1000 << "msecs. \r";
    cerr << "fps = " << fps << "  " << 1.0/((float)fps)*1000 << "msecs. "<<endl;
//XXX Use proper chirp mat printer
  } else fpscounter++;
}

void SimpleDisplay::render_to_texture(int num) {
  int startX, startY, readX, readY;
  startX = 0;
  startY = (imageWinHeight-(int)(imageWinHeight/(pow(2.0,(double)downsample_level))));

  readX = (int)(imageWinWidth/(pow(2.0,(double)downsample_level)));
  readY = (int)(imageWinHeight/(pow(2.0,(double)downsample_level))) + startY;

  glActiveTextureARB(GL_TEXTURE2_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[num]);
  glCopyTexImage2D( GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGBA_NV, 
                    //0,0,320,240,0 );
                    0,0,imageWinWidth,imageWinHeight,0 );
  //glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0,0,0, 320,240);
  //glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0,startX, startY,
  //                     readX, readY);
  errcheck();
}

void SimpleDisplay::render_to_texture(
     int num, 
     int x, 
     int y, 
     int width, 
     int height) 
{
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[num]);
  //glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0,x,y, width,height);
  glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, x, y,x,y, width,height);
  errcheck();
  FPSimple->activate();
}

void SimpleDisplay::render_to_texture_ARB1(
     int num, 
     int x, 
     int y, 
     int width, 
     int height) 
{
  glActiveTextureARB(GL_TEXTURE1_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[num]);
  glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0,x,y, width,height);
  errcheck();
  FPSimple->activate();
}



void SimpleDisplay::drawTexture( GLenum TEXTURE_UNIT ) 
{
  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;

  //read back texture is already resized.
  texwidth = texwidth/powf(2.0, downsample_level);
  texheight = texheight/powf(2.0, downsample_level);
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB(TEXTURE_UNIT,
                         0.0, 
                         ImageHeight/powf(2.0, downsample_level)/fraction, 
                         dist); 
    glVertex3f( origin, (origin+texheight)/fraction, texdist);

    glMultiTexCoord3fARB(TEXTURE_UNIT,
                         0.0, 
                         0.0/fraction, 
                         dist); 
    glVertex3f( origin, origin/fraction, texdist);

    glMultiTexCoord3fARB(TEXTURE_UNIT,
                         ImageWidth/powf(2.0, downsample_level), 
                         0.0/fraction, 
                         dist); 
    glVertex3f( origin+texwidth, origin/fraction, texdist);

    glMultiTexCoord3fARB(TEXTURE_UNIT,
                         ImageWidth/powf(2.0, downsample_level), 
                         ImageHeight/powf(2.0, downsample_level)/fraction, 
                         dist); 
    glVertex3f( origin+texwidth, (origin+texheight)/fraction, texdist);
  glEnd();
}

static void DiagnoseBuffer(float *rgba_buffer) {
  cerr<<"rgbabuffer[0][0]="<<rgba_buffer[0]<<endl;
  cerr<<"rgbabuffer[0][1]="<<rgba_buffer[1]<<endl;
  cerr<<"rgbabuffer[0][2]="<<rgba_buffer[2]<<endl;
  cerr<<"rgbabuffer[0][3]="<<rgba_buffer[3]<<endl;

  cerr<<"rgbabuffer[0][319]="<<rgba_buffer[319*4+0]<<endl;
  cerr<<"rgbabuffer[0][319]="<<rgba_buffer[319*4+1]<<endl;
  cerr<<"rgbabuffer[0][319]="<<rgba_buffer[319*4+2]<<endl;
  cerr<<"rgbabuffer[0][319]="<<rgba_buffer[310*4+3]<<endl;

  cerr<<"rgbabuffer[0][320]="<<rgba_buffer[320*4+0]<<endl;
  cerr<<"rgbabuffer[0][320]="<<rgba_buffer[320*4+1]<<endl;
  cerr<<"rgbabuffer[0][320]="<<rgba_buffer[320*4+2]<<endl;
  cerr<<"rgbabuffer[0][320]="<<rgba_buffer[320*4+3]<<endl;

  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+0]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+1]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+2]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+3]<<endl;

  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+4*319+0]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+4*319+1]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+4*319+2]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+4*319+3]<<endl;
}
