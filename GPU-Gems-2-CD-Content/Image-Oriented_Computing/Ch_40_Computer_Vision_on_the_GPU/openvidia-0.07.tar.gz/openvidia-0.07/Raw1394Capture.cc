/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "Raw1394Capture.h"
#include <iostream>
#include <stdlib.h>
using namespace std;
using namespace ost;

#define FORMAT_UYVY 6
// support multiple buffers for videorbits

Raw1394Capture :: ~Raw1394Capture() { 
  if(handle!=0) {
    dc1394_release_camera(handle,&camera);
    raw1394_destroy_handle(handle);
  }
  cout << "Destroyed Raw1394 capture" << endl;
}


void Raw1394Capture :: initCapture(GenericDisplay *d) {}

Raw1394Capture :: Raw1394Capture() {
  CaptureWidth = DefaultCaptureWidth;
  CaptureHeight = DefaultCaptureHeight;
  v1394_uyvy_buf = (unsigned char *)malloc( CaptureWidth*CaptureHeight*2);
  // rgb is actually rgb24? - so *3 not *4
  v1394_rgb_buf = (unsigned char *)malloc( CaptureWidth*CaptureHeight*3);
  v1394_rgb_buf_previous_frame = (unsigned char *)malloc( CaptureWidth*CaptureHeight*3);
  cout << "constructed Raw1394Capture" <<endl;
//}
//void Raw1394Capture :: initCapture(GenericDisplay *d) {
  //these values here are kludged in, instead of as arguments
  int width=CaptureWidth;
  int height=CaptureHeight;
  int format=FORMAT_UYVY;
  int tvchannel=0;

  int numNodes;
  int numCameras;
  //nodeid_t * camera_nodes;
  dc1394_feature_set features;

  /*-----------------------------------------------------------------------
   *  Open ohci and asign handle to it
   *-----------------------------------------------------------------------*/
  handle = dc1394_create_handle(0);
  if (handle==NULL)
  {
    fprintf( stderr, "Unable to aquire a raw1394 or video1394 handle\n\n"
             "Please check \n"
	     "  - if the kernel modules `ieee1394',`raw1394' and `ohci1394' are loaded \n"
	     "  - if you have read/write access to /dev/raw1394\n\n");
    //exit(1);
  }

  
  /*-----------------------------------------------------------------------
   *  get the camera nodes and describe them as we find them
   *-----------------------------------------------------------------------*/
  numNodes = raw1394_get_nodecount(handle);
  camera_nodes = dc1394_get_camera_nodes(handle,&numCameras,1);
  fflush(stdout);
  if (numCameras<1)
  {
    fprintf( stderr, "no cameras found :(\n");
    raw1394_destroy_handle(handle);
    //exit(1);
  }
  printf("working with the first camera on the bus\n");
  
  /*-----------------------------------------------------------------------
   *  to prevent the iso-transfer bug from raw1394 system, check if
   *  camera is highest node. For details see 
   *  http://linux1394.sourceforge.net/faq.html#DCbusmgmt
   *  and
   *  http://sourceforge.net/tracker/index.php?func=detail&aid=435107&group_id=8157&atid=108157
   *-----------------------------------------------------------------------*/
  if( camera_nodes[0] == numNodes-1)
  {
    fprintf( stderr, "\n"
             "Sorry, your camera is the highest numbered node\n"
             "of the bus, and has therefore become the root node.\n"
             "The root node is responsible for maintaining \n"
             "the timing of isochronous transactions on the IEEE \n"
             "1394 bus.  However, if the root node is not cycle master \n"
             "capable (it doesn't have to be), then isochronous \n"
             "transactions will not work.  The host controller card is \n"
             "cycle master capable, however, most cameras are not.\n"
             "\n"
             "The quick solution is to add the parameter \n"
             "attempt_root=1 when loading the OHCI driver as a \n"
             "module.  So please do (as root):\n"
             "\n"
             "   rmmod ohci1394\n"
             "   insmod ohci1394 attempt_root=1\n"
             "\n"
             "for more information see the FAQ at \n"
             "http://linux1394.sourceforge.net/faq.html#DCbusmgmt\n"
             "\n");
    //exit( 1);
  }
  
  /*-----------------------------------------------------------------------
   *  setup capture
   *-----------------------------------------------------------------------*/
  printf("Setting up Raw camera capture.\n");
  if (dc1394_setup_capture(handle,
			       camera_nodes[0], // camera id
			       0, // iso channel
			       FORMAT_VGA_NONCOMPRESSED, //format
			       MODE_320x240_YUV422, //mode
			       //MODE_640x480_MONO,
			       //MODE_640x480_RGB,
			       SPEED_400, //max speed
			       FRAMERATE_30, //framerate
			       //FRAMERATE_15, //framerate
			       &camera)!=DC1394_SUCCESS) 
    {
      fprintf( stderr,"unable to setup camera-\n"
	       "check line %d of %s to make sure\n"
	       "that the video mode,framerate and format are\n"
	       "supported by your camera\n",
	       __LINE__,__FILE__);
      dc1394_release_camera(handle,&camera);
      raw1394_destroy_handle(handle);
      //exit(1);
    }
  
  /*-----------------------------------------------------------------------
   *  have the camera start sending us data
   *-----------------------------------------------------------------------*/
  if (dc1394_start_iso_transmission(handle,camera.node)
      !=DC1394_SUCCESS) 
    {
      fprintf( stderr, "unable to start camera iso transmission\n");
      dc1394_release_camera(handle,&camera);
      raw1394_destroy_handle(handle);
      //exit(1);
    }
}


void Raw1394Capture::run() {
  while(1) {
    if (dc1394_single_capture(handle,&camera)!=DC1394_SUCCESS) 
    {
      fprintf( stderr, "unable to capture a frame\n");
      dc1394_release_camera(handle,&camera);
      raw1394_destroy_handle(handle);
      return;
    }
    ENTER_CRITICAL
    memcpy(v1394_uyvy_buf,(const char *)camera.capture_buffer,CaptureWidth*CaptureHeight*2);
    LEAVE_CRITICAL
  }
}

void Raw1394Capture :: advanceFrame() {
/*
  if (dc1394_dma_single_capture(&camera)!=DC1394_SUCCESS) {
    fprintf( stderr, "unable to capture a frame\n");
    return;
  }
*/
/*
  if (dc1394_single_capture(handle,&camera)!=DC1394_SUCCESS) 
  {
    fprintf( stderr, "unable to capture a frame\n");
    dc1394_release_camera(handle,&camera);
    raw1394_destroy_handle(handle);
    return;
  }
*/

  
  //320x230x2, 2 is for yuv422
  // I could do away with this memcpy and put it straight into RGB
/*
  memcpy(v1394_uyvy_buf,(const char *)camera.capture_buffer,CaptureWidth*CaptureHeight*2);
*/
  //dc1394_dma_done_with_buffer(&camera);
  ENTER_CRITICAL
}

void Raw1394Capture::releaseCap() {
  LEAVE_CRITICAL
}


int Raw1394Capture :: get_gain() {
  int retval=0;
  retval = dc1394_get_exposure(handle, camera_nodes[0], &(this->gainval));
  cerr<<"retval "<<retval<<endl; fflush(stderr);
  cerr<<"gainval "<<gainval<<endl; fflush(stderr);
  //gainval = retval;
}



// Must call this after getRGBData since the other function has a sideeffect
// of swiveling the buffer pointers
void* Raw1394Capture :: getRGBDataPreviousFrame() {
  return v1394_rgb_buf_previous_frame;
}

void* Raw1394Capture :: getRGBData() {
  void *tmp;
  // swivel the buffer pointers
  tmp = v1394_rgb_buf_previous_frame;
  v1394_rgb_buf_previous_frame = v1394_rgb_buf;
  v1394_rgb_buf = tmp;

  UYVYtoRGB24((unsigned char *)v1394_uyvy_buf,(unsigned char *)v1394_rgb_buf,CaptureWidth,CaptureHeight);
  return v1394_rgb_buf;
}

int Raw1394Capture :: getRGBWidth() {
  return CaptureWidth;
}

int Raw1394Capture :: getRGBHeight() {
  return CaptureHeight;
}

unsigned char Raw1394Capture::clip(float pixel_val) {
  if (pixel_val >= 255) {
    return 255;
  } else if (pixel_val <= 0){ 
    return 0;
  } else {
    return (unsigned char)(pixel_val);
  }
}

void Raw1394Capture :: UYVYtoRGB24(unsigned char *s, unsigned char *d, int width, int height) {
    int i,j;
    unsigned char y0,u,y1,v,r1,r2,b1,b2,g1,g2;
    
    for(i=0; i<height; i++)
      {
	for(j=0; j<width*2; j+=4)
	  {
	    u = *s++;
	    y0  = *s++;
          v   = *s++;
          y1  = *s++;
                                                                                
          b1 = clip(1.164*(y0-16)+2.018*(u-128));
          g1 = clip(1.164*(y0-16)-0.813*(v-128)-0.391*(u-128));
          r1 = clip(1.164*(y0-16)+1.596*(v-128));
                                                                                
          b2 = clip(1.164*(y1-16)+2.018*(u-128));
          g2 = clip(1.164*(y1-16)-0.813*(v-128)-0.391*(u-128));
          r2 = clip(1.164*(y1-16)+1.596*(v-128));
                                                                                
          *d++ = r1;
          *d++ = g1;
          *d++ = b1;
          *d++ = r2;
          *d++ = g2;
          *d++ = b2;
        }
    }
}
