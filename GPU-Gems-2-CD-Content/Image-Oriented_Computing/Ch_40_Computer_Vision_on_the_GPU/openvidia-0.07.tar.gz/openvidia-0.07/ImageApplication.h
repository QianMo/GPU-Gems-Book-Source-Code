/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _IMAGEAPPLICATION_H
#define _IMAGEAPPLICATION_H

#include "ApplicationRenderer.h"
#include "ImlibCapture.h"

class ImageApplication : public ApplicationRenderer
{
 private:
  bool isInitialized;
  int x,y,width,height;
  ImlibCapture *imlibcapture;
  char *fname;
  GLuint imgTex;
  bool useAlpha;
 public:
  ImageApplication(char* fname);
  ~ImageApplication();
  
  // this will do a bunch of GL calls.
  void render();
};

#endif
