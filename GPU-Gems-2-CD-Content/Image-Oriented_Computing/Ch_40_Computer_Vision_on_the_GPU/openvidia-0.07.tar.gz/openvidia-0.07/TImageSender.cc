/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "TImageSender.h"

using namespace std;

/*
 * Threaded version of Image Sender
 */
TImageSender::TImageSender() : ImageSender() {
  b1_full=false;
  b1_backup=(unsigned char*)malloc(320*240*3);
}

TImageSender::~TImageSender() {
  //do nothing
}

// just dump the estimates to the card.  fill in the most recent
// completed estimates
void TImageSender::sendImages(int width, int height, 
			      void* b1, void*b2, 
			      int reqChirp, Parameters initialEstimate,
			      Parameters* converged, int* partial) {

  int GPUnum=0;
  if(isProcessing(GPUnum)) {
    //save b1, use with the later b2
    b1_full=true;
    memcpy(b1_backup, b1, 320*240*3*sizeof(unsigned char));

    //return the partial estimate
    query_client(GPUnum, &partialEstimate);
    converged->set(partialEstimate.get());
    *partial=1;
  } else {
    query_client(GPUnum, &newestEstimate);
    converged->set(newestEstimate.get());
    *partial=0;

    // every 7th frame is a flush
    // task new frames
    if(b1_full) {
      b1=b1_backup;
      b1_full=false;
    }
    client_tasker(GPUnum, 320,240,3,1, (unsigned char*) b1,
		  320,240,3,2, (unsigned char*) b2,
		  reqChirp, initialEstimate);
  }

}

void TImageSender::run() {
  cerr <<"DEPRECATED"<<endl;

  int GPUnum=0;
  while(1) {
    // wait till data is done
    while(isProcessing(GPUnum)) {
      struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 500;
      select(0,0,0,0, &tv);
      //  usleep(100);
    }

    ENTER_CRITICAL
      query_client(GPUnum, &newestEstimate);
    LEAVE_CRITICAL  
    //sleep until we get new data
    //    while(!isProcessing(GPUnum)) {
    //  usleep(500);
    // }
  }

}

