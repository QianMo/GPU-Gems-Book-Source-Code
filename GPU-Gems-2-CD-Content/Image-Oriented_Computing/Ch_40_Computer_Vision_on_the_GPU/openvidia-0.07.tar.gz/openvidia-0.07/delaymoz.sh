#!/bin/sh

/bin/sleep 10
/usr/bin/mozilla-firefox --display :4 
