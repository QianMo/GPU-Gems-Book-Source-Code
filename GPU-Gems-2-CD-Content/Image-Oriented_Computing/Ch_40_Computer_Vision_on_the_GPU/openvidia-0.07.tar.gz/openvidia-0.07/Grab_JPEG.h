/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef GRAB_JPEG
#define GRAB_JPEG

#include <GL/glut.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <file.h>
#include <sys/time.h>
#include <time.h>
//extern "c" stuff to link c->c++
//Need to add this to wrap jpeglib.h for C++
#ifdef __cplusplus
extern "C" {
#endif

#include <jpeglib.h>

#ifdef __cplusplus
}
#endif


#include <dirent.h>

struct memory_buffer {
     JOCTET    *start_addr;
     int position;
     int size;
};


class Grab_JPEG {
    FILE *get_next_file(int fieldflag);
    long init_vindex();
    long find_highest_vindex(char *dir, char *match);
    struct memory_buffer            jpegbuf;
    struct jpeg_compress_struct     jcinfo;
    struct jpeg_error_mgr           jerr;
    void init_JPEG_TO_DISK(int,int);

  public :
    int vindex;
    int grab_frame( unsigned char *vid_buf, int width, int height, int format);
    int grab_frame( unsigned char *vid_buf, int width, int height, int format,
                    bool invert);
    int grab_frame(unsigned char *vid_buf, 
                      int width, 
                      int height, 
                      int format,
                      char *fname, bool invert);
    void grab_frameGL(int width, int height);
    void grab_frameGL(int width, int height, bool invert);
    Grab_JPEG();

};

#endif
