/*
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/
#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <iomanip>
/*
#include "GenericDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"
#include "FragPipeDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include "taps.h"
#include "ProjRANSAC.h"
*/
#include "libopenvidia.h"
#include <iostream>
#define GL_SZ 5.0
using namespace std;

// Global display object
FragPipeDisplay *d;
Dc1394 *dc1394;
ImlibCapture *im;
GenericFilter *filter1, *filter2, *filter3, *filter4;
GenericFilter *magdir, *cannysearch, *tangent, *gaussianX, *gaussianY, *dxdy, *decide;
GenericFilter *derandom;
FragmentProgram *feature;
MomentFilter *momentFilter;

Grab_JPEG *grabber;

//   float cannythresh[4] = {10.0, 4.0, 4.0, 4.0};

//works well for the painting image
   float cannythresh[4] = {2.0, 4.0, 4.0, 4.0};
   float derandomthresh[4] = {0.5, 0.25, 0.25, 0.25};
  /// float cornerthresh[4] = {50.0, 0.25, 0.25, 0.25};
   float cornerthresh[4] = {11.0, 0.25, 0.25, 0.25};

int imageWinWidth = 320;
int viewbuf = 10;
const int resultBuf = 10;
int imageWinHeight = 240;
Window  Orbwin;

int  numCorners=0;
int  numCornersPrev=0;
int numFeatures=0;
int numFeaturesReference=-1; //initialization

///global state
bool useImlib = true;
float HAND_X_COORD=0.0;
float HAND_Y_COORD=0.0;
void featureSearch(unsigned char *foo);


unsigned int
halfToFloat (unsigned short y);
void unpack_2half( float in, float *out1, float *out2);

void reshape(int w, int h);
void myIdle();
void keyboard (unsigned char key, int x, int y);
void MouseFunc( int button, int state, int x, int y) ;
void drawFingerTip();
void doMoment();
void drawCircleHelper(float x, float y);
void TellRWMHeCanUseImage(const char *dma_buf_) ;

unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(320*240*3);
int framecounter=0;
int newdata=0;

unsigned char foo[320*240*4];
//feature vectors as returned from the card, 8 16-bit floats packed 
//into 128 elements
float featureVectorsHalfPacked[240][32][4] = {0.0};

//Featurevectors holds the 128 element feature vector at each corner.
float featureVectors[240][128] = {0.0};
//Corners array tells us where the corners are.  They correspond line by
// line to each feature in the featureVectors array
float cornersArray[1000][2];
//unique identifier to track this particular point.
int ID[240];
int IDcount = 0;
int Age[240] = {0};

//previous iterations results
float featureVectorsPrev[240][128] = {0.0};
float cornersArrayPrev[1000][2];
int prevID[240];
int prevAge[240] = {0};

//reference state, when requested.
float featureVectorsReference[240][128] = {0.0};
float cornersArrayReference[1000][2];
int IDReference[240] = {0};
int AgeReference[240] = {0};
double posReference[2] = {0.5,0.5};
double posPrev[2] = {0.5,0.5};

//Match array holds the point correspondences in the form
// (x1,y1) -> (x2,y2), ID, age
float matchArray[240][5]={0.0};

double pos[2] = {0.5, 0.5};
Parameters PCumulativeSinceLastRef;
///float featureVector[1000][8];

int examineFeatures();

ProjRANSAC RANSAC(240,320);
void drawTrack( Parameters Pairwise );
void gl_draw_text_normcoord( float x, float y, char *string);
void saveReferenceState();
void saveReferenceStatePrev();
////searches local x,y neighbourhood for best match
int findBestFeatureMatchLocal(  
                          //where are the corners
                          float corners[1000][2], 
                          float cornersPrev[1000][2], 
 
                          //feature vectors
                          float fvec[240][128],
                          float fvecPrev[240][128],
 
                          //where to write the matches
                          float match[240][5],

                          //how many elements of the above arrays are 
                          // actually filled
                          int numFeaturesNew, 
                          int numFeaturesOld,
 
                          //Parameters: if we have a guess as to where
                          // the points are (i.e. when we are
                          // comparing to an old reference frame),
                          // then we can use it before we 
                          // restrict the search radius.
                          Parameters Pguess, 
 
                         
                          //search radius to restrict matches to.
                          float searchRadius  ) ;

void render_redirect() {
  ++framecounter;

  if(!newdata)  {  struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 1000;
     select(0,0,0,0, &tv);
 return;} 
newdata = 0; 


//  {  struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 100000;
//     select(0,0,0,0, &tv); 
//  }
  

  d->activate_fpbuffer();
  d->clear_fpbuffer();
    if( useImlib )  {
      d->reinit_texture(0, 320, 240, im->getRGBData() );
    }
    else {
      d->reinit_texture(0, 320, 240, dma_buf_rgb);
    }
    d->bindTextureARB0(0);
    if (!useImlib) dc1394->tellThreadDoneWithBuffer();

    //cascade the filters
    d->applyFilter(filter1, 0,1); //texture 1 holds undistorted
    d->applyFilter(filter2, 1,2); //texture 2 holds x deriv
    d->applyFilter(filter3, 1,3); //texture 3 holds y deriv
    
    d->bindTextureARB1(3);        //place texture 3 into unit 1
    d->applyFilter(magdir, 2, 4);  //use texture 2, unit0, result to tex4
    /* buffer 4:     
    colorO.x = dx.x*255.0;
    colorO.y = dy.x*255.0;
    colorO.z = magnitude;
    colorO.w = direction;
    */

    //canny search looks for max in direction of gradient 
    d->applyFilter(cannysearch, 4, 5);  //tex4: magdir, tex5 search result
    //optim fodder, (could collapse canny->tangent into a single prog)
    //d->applyFilter(tangent, 5, 6);  //tex
    d->applyFilter(dxdy, 4, 6);  //tex

    d->applyFilter(gaussianX, 6, 7);  //tex
    d->applyFilter(gaussianY, 7, 8);  //tex

    d->bindTextureARB1(5);        //place canny edgels into texunit 1, flagged
    d->bindTextureARB2(4);         //gradient image into ARB2, no flags,
    d->applyFilter(derandom, 8, 9); //8 has blurred dxdx dydy dxdy
    d->applyFilter(decide, 9, 10); //8 has blurred dxdx dydy dxdy

    //doMoment();//intensive. Not GFX card efficient utilization, but it works.
  d->deactivate_fpbuffer();


  d->bindTextureARB0(viewbuf);
  d->render();
  //////drawFingerTip();


  //do features
  int numFeat;
  if( viewbuf==resultBuf)  {
    glReadPixels(0,0,320,240,GL_RGB,GL_UNSIGNED_BYTE,foo); 
    numFeat = examineFeatures();
  }

  if( framecounter == 5 ) saveReferenceState();
  //else if (framecounter %3 == 0 && support > 30 ) {
  else if (framecounter >5  ) {
int numMatched;
     PCumulativeSinceLastRef.setIdentity();
     numMatched = findBestFeatureMatchLocal( cornersArray,
                                              cornersArrayReference,
                                              featureVectors,
                                              featureVectorsReference,
                                              matchArray,
                                              numCorners, 
                                              numFeaturesReference,
                                              PCumulativeSinceLastRef,
                   ///sems to work best with a large window of opportunity
                                              155.0 ) ;
    int support; Parameters Pairwise;

    Pairwise = RANSAC.find_P(matchArray, numMatched, &support); 

    //cerr<<"had "<<support<<"/"<<numMatched<<"/"<<numFeat <<endl;
    ///Pairwise.print();
    // if track is good, update the crosshairs and position
    if( support > 4 ) {
      //PCumulativeSinceLastRef.setIdentity();
      pos[0] = posReference[0];
      pos[1] = posReference[1];
      drawTrack( Pairwise );
      posPrev[0] = pos[0];
      posPrev[1] = pos[1];
    } 
  }

    

  d->showstats();
  glutSwapBuffers();

  //use to make videos
  //glReadPixels(0,0,320,240,GL_RGB,GL_UNSIGNED_BYTE,foo);
  //grabber->grab_frame(foo, 320,240, 0, true);
  
}
void drawCorners() {
  //draw corner points onto the image 
  int index=0;
  float depth=-1.0;
  glClear(GL_DEPTH_BUFFER_BIT);
  glColor3f(0.0, 0.0, 1.0);
  glPointSize(GL_SZ);
    glBegin(GL_POINTS);
  while( cornersArray[index][0] != -1.0 ) {
      glVertex3f(cornersArray[index][0]/320.0, cornersArray[index][1]/240.0, depth);
     
    index++;
  }

    glEnd();

}

///Draws the age and ID number of the feature.  Font rendering is actually
///really really slow with glut (32 fps -> 24 fps)
void drawID() {
  int index =0;
  char tmpstr[50];
  while( cornersArray[index][0] != -1.0 ) {
      sprintf(tmpstr, "%d: %d", Age[index], ID[index]); 
      glColor3f( 1.0, 1.0, 1.0);
      if( Age[index] > 15 ) { glColor3f( 0.0, 1.0, 1.0);
      
      //if( RANSAC.RANSACSupportArray[index] != 1 ) glColor3f(1.0,0.0,0.0);
      //else glColor3f( 1.0, 1.0, 1.0);
      gl_draw_text_normcoord( cornersArray[index][0], 
                              240.0-cornersArray[index][1],tmpstr);
      }
      index++;
  }
}

void printVector(float *v)
{
  for( int i =0; i<128 ; i++ ) {
    cerr<<setw(6) <<v[i]<<" ";
  }
  cerr<<endl;
}

void normalizeFeatureVector( float *v) 
{
  float norm = 0.0;
  for( int i =0; i<128 ; i++ ) {
    norm+=v[i];
  }
  for( int i =0; i<128 ; i++ ) {
    v[i]/=norm;
  }

}

float distBetweenFeatures( float *v1, float *v2 ) 
{
  float dist = 0.0; 
  for( int i =0 ; i< 127 ; i++ ) {
    float x = v1[i]-v2[i];
    x = x*x;
    dist += x;
  }
  return dist;
}

void printMatches ( int numMatches ) {
  for( int i =0; i<numMatches ; i++ ) {
    cerr<<" ["<<matchArray[i][0]<<", "<<matchArray[i][1]<<"] --> [";
    cerr<<matchArray[i][2]<<", "<<matchArray[i][3]<<"]"<<endl;
  }
}

void drawMatches( int numMatches ) {
  glClear(GL_DEPTH_BUFFER_BIT); 
  glColor4f(0.0, 1.0, 0.0, 1.0);
  glLineWidth(GL_SZ);
  glBegin(GL_LINES);
 //   glVertex3f( 0.0, 0.0, -1.0 );
 //   glVertex3f( 1.0, 1.0, -1.0 );
    for( int i=0 ; i<numMatches ; i++ ) { 

      //only draw the first supported projective motion
      if( RANSAC.RANSACSupportArray[i] != 1 ) continue;

      glVertex3f( matchArray[i][0]/320.0, matchArray[i][1]/240.0, -1.0 );
      glVertex3f( matchArray[i][2]/320.0, matchArray[i][3]/240.0, -1.0 );
//    cerr<<" ["<<matchArray[i][0]/320.0<<", "<<matchArray[i][1]/240.0<<"] --> [";
//    cerr<<matchArray[i][2]/320.0<<", "<<matchArray[i][3]/240.0<<"]"<<endl;
    }
  glEnd();

 
}

////searches local x,y neighbourhood for best match
int findBestFeatureMatchLocal(  
                          //where are the corners
                          float corners[1000][2], 
                          float cornersPrev[1000][2], 
 
                          //feature vectors
                          float fvec[240][128],
                          float fvecPrev[240][128],
 
                          //where to write the matches
                          float match[240][5],

                          //how many elements of the above arrays are 
                          // actually filled
                          int numFeaturesNew, 
                          int numFeaturesOld,
 
                          //Parameters: if we have a guess as to where
                          // the points are (i.e. when we are
                          // comparing to an old reference frame),
                          // then we can use it before we 
                          // restrict the search radius.
                          Parameters Pguess, 
 
                         
                          //search radius to restrict matches to.
                          float searchRadius  ) 
{
  float THRESH = 0.4*0.4;
  int matchArrayIndex = 0;
  float searchRad2 = searchRadius*searchRadius;

  for( int currentF=0 ; currentF<numFeaturesNew ; currentF++ ) {
    float distance1 = 9999; //normalized ,so max is 1
    float distance2 = 9999; //normalized ,so max is 1
    int bestPos = -1;

    float currentX = corners[currentF][0];
    float currentY = corners[currentF][1];


    for( int prevF =0 ; prevF<numFeaturesOld ; prevF++ ) {

       float prevX = cornersPrev[prevF][0];
       float prevY = cornersPrev[prevF][1];
       
       float dist = (currentX - prevX)*(currentX-prevX) + 
                    (currentY - prevY)*(currentY-prevY) ; 

 
      // if( dist > searchRadius) break;
       if( dist < searchRad2 ) {

         float diff = distBetweenFeatures(fvec[currentF],
                                          fvecPrev[prevF]);
         if( diff < distance1 ) {
           distance2 = distance1;
           distance1 = diff;
           bestPos = prevF;
         }
       }
    }
  
    if( distance1 < THRESH*distance2 ) {
      //match is good.
      match[matchArrayIndex][0] = cornersPrev[bestPos][0];
      match[matchArrayIndex][1] = cornersPrev[bestPos][1];
      match[matchArrayIndex][2] = corners[currentF][0];
      match[matchArrayIndex][3] = corners[currentF][1];
      //record the ID number into the current data array
      ID[currentF] = prevID[bestPos];
      Age[currentF] = prevAge[bestPos]+1;
      match[matchArrayIndex][4] = Age[currentF];
      matchArrayIndex++;
    }
 
  }
  ///cerr<<"Matched "<<matchArrayIndex<<" features"<<endl;
  //printMatches(matchArrayIndex);
  return matchArrayIndex;
}


////searches local x,y neighbourhood for best match
int findBestFeatureMatchLocal(  
                          int numFeaturesNew, 
                          int numFeaturesOld,
                          float searchRadius  ) 
{
  float THRESH = 0.4*0.4;
  int matchArrayIndex = 0;
  float searchRad2 = searchRadius*searchRadius;

  for( int currentF=0 ; currentF<numFeaturesNew ; currentF++ ) {
    float distance1 = 9999; //normalized ,so max is 1
    float distance2 = 9999; //normalized ,so max is 1
    int bestPos = -1;

    float currentX = cornersArray[currentF][0];
    float currentY = cornersArray[currentF][1];


    for( int prevF =0 ; prevF<numFeaturesOld ; prevF++ ) {

       float prevX = cornersArrayPrev[prevF][0];
       float prevY = cornersArrayPrev[prevF][1];
  
       float dist = (currentX - prevX)*(currentX-prevX) + 
                    (currentY - prevY)*(currentY-prevY) ; 
 
      // if( dist > searchRadius) break;
       if( dist < searchRad2 ) {

         float diff = distBetweenFeatures(featureVectors[currentF],
                                          featureVectorsPrev[prevF]);
         if( diff < distance1 ) {
           distance2 = distance1;
           distance1 = diff;
           bestPos = prevF;
         }
       }
    }
  
    if( distance1 < THRESH*distance2 ) {
      //match is good.
      matchArray[matchArrayIndex][0] = cornersArrayPrev[bestPos][0];
      matchArray[matchArrayIndex][1] = cornersArrayPrev[bestPos][1];
      matchArray[matchArrayIndex][2] = cornersArray[currentF][0];
      matchArray[matchArrayIndex][3] = cornersArray[currentF][1];
      //record the ID number into the current data array
      ID[currentF] = prevID[bestPos];
      Age[currentF] = prevAge[bestPos]+1;
      matchArray[matchArrayIndex][4] = Age[currentF];
      matchArrayIndex++;
    }
 
  }
  ///cerr<<"Matched "<<matchArrayIndex<<" features"<<endl;
  //printMatches(matchArrayIndex);
  return matchArrayIndex;
}

int drawFeatureVectors() {

  float ypos = 0.0;
  float depth= -1.0;
  int index=0;

d->activate_fpbuffer();
  glClear(GL_DEPTH_BUFFER_BIT);
  glColor3f(1.0, 0.0, 0.0);
  glPointSize(1.0);

  d->bindTextureARB0(9);
  d->bindTextureARB1(11); //gaussian 16x16 taps
  feature->activate();
  glBegin(GL_POINTS);
  //for each point in the array
  while( cornersArray[index][0] != -1.0 ) {
      int i=0;
      for( int xoffset=-1 ; xoffset<3 ; xoffset++ ) {
        for( int yoffset=-1 ; yoffset<3 ; yoffset++ ) {
          //send in the top left coordinate of the pixel block area in 
          //question for histogramming

//          glTexCoord3f(cornersArray[index][0]+(xoffset*4.0), 
//                       cornersArray[index][1]+(yoffset*4.0), 1.0);

          glMultiTexCoord3fARB(GL_TEXTURE0_ARB, 
                                cornersArray[index][0]+xoffset*4.0,
                                cornersArray[index][1]+yoffset*4.0, 
                                1.0);
          glMultiTexCoord3fARB(GL_TEXTURE1_ARB, 
                                 (xoffset+1.0)*4.0, 
                                 (yoffset+1.0)*4.0,
                                 1.0 );

          glVertex3f((float)i/320.0, 1.0-(float)index/240.0, depth);

          i++;
        }
      }
      index++;
  }
  glEnd();
  feature->deactivate();
  //cerr<<"Calculated "<<index<<" feature vectors"<<endl;

  /***********************************************************/
  //read out the feature vectors
  if( numCorners < 240 ) numFeatures = numCorners;
  else numFeatures = 240;
  memset(featureVectorsHalfPacked, 0, 240*32*sizeof(float));
  glReadPixels(0,0, 32, numFeatures, GL_RGBA, GL_FLOAT, featureVectorsHalfPacked );

  //read the buffer. [vector][histobin][rgba compoenent]
  int pos = numFeatures-1;
  //cerr<<"f "<<numFeatures<<": "<<featureVectors[pos][0][0]<<" "<<featureVectors[pos][0][1]<<" ";
  //cerr<<featureVectors[pos][0][2]<<" "<<featureVectors[pos][0][3]<<endl;
  pos = 4;
  float xchan, ychan;
/*
  unpack_2half( featureVectors[pos][0][0], &xchan, &ychan );
  cerr<<"[ "<< xchan <<" "<< ychan ;
  unpack_2half( featureVectors[pos][0][1], &xchan, &ychan );
  cerr<<" "<< xchan <<" "<< ychan ;
  unpack_2half( featureVectors[pos][0][2], &xchan, &ychan );
  cerr<<" "<< xchan <<" "<< ychan ;;
  unpack_2half( featureVectors[pos][0][3], &xchan, &ychan );
  cerr<<" "<< xchan <<" "<< ychan << " ] " << endl;
*/
  //unpack 16, 4 valued readback pixels into 128 features
  for( int pos=0 ; pos<numFeatures ; pos++ ) { 
    int k =0;
    for( int j=0 ; j < 16 ; j ++ ) {
      for( int i=0 ; i<4 ; i++ ) {
        unpack_2half( featureVectorsHalfPacked[pos][j][i], 
                      &featureVectors[pos][k], &featureVectors[pos][k+1] );
        k+=2;
      }
    }
    normalizeFeatureVector( featureVectors[pos] );
    //if( pos == 2 ) printVector(featureVectors[pos]);
    assert( k== 128 );
/*
      unpack_2half( featureVectorsHalfPacked[pos][0][1], 
                    &featureVectors[pos][2], &featureVectors[pos][3] );

      unpack_2half( featureVectorsHalfPacked[pos][0][2], 
                    &featureVectors[pos][4], &featureVectors[pos][5] );

      unpack_2half( featureVectorsHalfPacked[pos][0][3], 
                    &featureVectors[pos][6], &featureVectors[pos][7] );
*/


  }
  
  /*****************************************************************/
  ////int numMatched = findBestFeatureMatch( numCorners, numCornersPrev) ;
  //int numMatched = findBestFeatureMatchLocal( numCorners, numCornersPrev,
  //                                            15.0 ) ;
/*
  Parameters IDparams;
  int numMatched = findBestFeatureMatchLocal( cornersArray,
                                              cornersArrayPrev,
                                              featureVectors,
                                              featureVectorsPrev,
                                              matchArray,
                                              numCorners, 
                                              numCornersPrev,
                                              IDparams, //send an identity
                                              15.0 ) ;

 XXX
*/
d->deactivate_fpbuffer();
  int support;
  return numCorners;
}

void drawTrack( Parameters Pairwise ) {
  ///Pairwise.print();
  glClear(GL_DEPTH_BUFFER_BIT);
  glLineWidth(2.0);
  if( Pairwise.getSupport() > 0.3 ) {
    Pairwise.apply( &pos[0], &pos[1]);   
    glColor3f(0.4, 0.6, 0.9);
  }
  else {
    glColor3f(1.0, 0.0, 0.0);
  }
/*
  double posabs[2] = {0.5, 0.5};
  PCumulativeSinceLastRef.apply( &posabs[0], &posabs[1] );
  
  glBegin(GL_LINES);
    glVertex3f( posabs[0]-0.5, posabs[1], -1.0);
    glVertex3f( posabs[0]+0.5, posabs[1], -1.0);
    glVertex3f( posabs[0], posabs[1]-0.5, -1.0);
    glVertex3f( posabs[0], posabs[1]+0.5, -1.0);
  glEnd();
*/

/*

  glBegin(GL_LINES);
    glVertex3f( pos[0]-0.5, pos[1], -1.0);
    glVertex3f( pos[0]+0.5, pos[1], -1.0);
    glVertex3f( pos[0], pos[1]-0.5, -1.0);
    glVertex3f( pos[0], pos[1]+0.5, -1.0);
  glEnd();

*/

 glLineWidth(4.0);
  glBegin(GL_LINES);
    glVertex3f(pos[0], pos[1], -1.0);
    glVertex3f(pos[0]+0.15, pos[1]-0.15, -1.0);
    glVertex3f(pos[0]+0.15, pos[1]-0.15, -1.0);
    glVertex3f(pos[0]+0.15+0.15, pos[1]-0.15, -1.0);
  glEnd();
 glColor3f(0.0, 0.0, 4.0);
 //glEnable(GL_BLEND);
 //glBlendFunc(GL_ONE_MINUS_SRC_COLOR, GL_ONE);
 //glBlendFunc(GL_ONE_MINUS_DST_COLOR, GL_ONE_MINUS_SRC_COLOR);
 //glBlendFunc(GL_SRC_COLOR, GL_ONE_MINUS_DST_COLOR);
 gl_draw_text_normcoord( 320.0*(pos[0]+0.15), 240.0*(1.0-(pos[1]-0.16)), "Internet Access Point");
// glDisable(GL_BLEND);
}
 

// unpacks 2 half (which were packed into the float "in") and 
// palces the results in out1, out2 as floating point (loss of
// precision tho)
void unpack_2half( float in, float *out1, float *out2)
{
  unsigned int *x;
  unsigned int y;
  float input = in;

  //x = (unsigned int *) &(featureVectors[pos][0][0]);
  x = (unsigned int *) &input;
  y = *x;
  //y = y & 0x0000FFFF;

  unsigned short *a;
  unsigned short b,c;

  a = (unsigned short *)&y;
  b =( y >> 16  ) & 0x0000FFFF;
  c =( y >> 0   ) & 0x0000FFFF;

  unsigned int f = halfToFloat( b );
  unsigned int g = halfToFloat( c );

  float *newFloat_b;
  float *newFloat_c;

  newFloat_b = (float *)&f;
  newFloat_c = (float *)&g;

  //cerr << "new float = " << *newFloat_b<<" and "<< *newFloat_c<<endl;
  *out2 = *newFloat_b;
  *out1 = *newFloat_c;
}

void storeOldFeatures()
{
  memcpy( prevID, ID, 240*sizeof(int));
  memcpy( prevAge, Age, 240*sizeof(int));
  memcpy( featureVectorsPrev, featureVectors, 240*128*sizeof(float) );
  memcpy( cornersArrayPrev, cornersArray, 1000*2*sizeof(float) );
  numCornersPrev = numCorners;
  //make some new ID numbers;  if a match is found to the previous
  //frame with and existing ID'd vector this number is overwritten,
  //otherwise it can serve to be used to seed a new ID.
  for( int i=0 ; i<240; i++ ) {
    ID[i] = IDcount++;
    Age[i] = 0;
  }
}



int examineFeatures() {
  storeOldFeatures();
  featureSearch(foo);
  d->bindTextureARB0(1);
  d->render();
  ////drawCorners();
  int num = drawFeatureVectors(); // returns number of corners
  ////drawID();
  return num;
  
}


void init_track()
{
  for( int i=0; i<240 ; i++ ) 
  { 
    prevID[i] = IDcount++;
  }
}


///// MAIN ///////////////////

int main(int argc, char** argv)
{
   glutInit(&argc, argv);

   //if an argument is given, assume we are using an image file
   if( argc == 2 ) { 
     cout<<"Using image file: "<<argv[1]<<endl;
     cout<<"Note: currently, image file must be 320x240 resolution"<<endl;
     useImlib = true;
   }
   else {
     useImlib = false;
   }
   
   cout <<"Creating Double Buffered Window" << endl;
   //glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH | GLUT_ALPHA);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH );
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);


   //typical problem : can't open imlib without display, yet cant
   // size display without loading image from imlib
   d=new FragPipeDisplay(16, imageWinWidth, imageWinHeight, Orbwin );
   d->initDisplay();

   d->setImageSize( 320,240 );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-basic.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?
   if( useImlib ) { 
     im = new ImlibCapture(0,0);
     im->initCapture(d);
     im->loadFile(argv[1]); 
     assert( im->getRGBWidth() == imageWinWidth );
     assert( im->getRGBHeight() == imageWinHeight );
   }
   else {
     dc1394=new Dc1394();
     dc1394->start();
   }
   grabber = new Grab_JPEG();


   //d->activate_fpbuffer();
   d->init_texture(0, 320, 240, foo);
   d->init_texture4f(1, 320, 240, foo);
   d->init_texture4f(2, 320, 240, foo);
   d->init_texture4f(3, 320, 240, foo);
   d->init_texture4f(4, 320, 240, foo);
   d->init_texture4f(5, 320, 240, foo);
   d->init_texture4f(6, 320, 240, foo);
   d->init_texture4f(7, 320, 240, foo);
   d->init_texture4f(8, 320, 240, foo);
   d->init_texture4f(9, 320, 240, foo);
   d->init_texture4f(10, 320, 240, foo);
   d->init_texture4f(11, 16, 16, taps);
   d->reinit_texture1f(11, 16, 16, taps);

   filter1 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-ibot-undistort.cg");
   filter2 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               //"FPsamples/FP-gaussianderiv-sigma3-x.cg");
                               "FPsamples/FP-gaussianderiv-sigma1-x.cg");
   filter3 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                              // "FPsamples/FP-gaussianderiv-sigma3-y.cg");
                               "FPsamples/FP-gaussianderiv-sigma1-y.cg");
   magdir = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-magdir.cg");

   cannysearch = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               //"FPsamples/FP-canny-search.cg");
                               "FPsamples/FP-canny-search-with-corners.cg");
   cannysearch->setCGParameter( "thresh", cannythresh);

   tangent = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-tangent.cg");
   dxdy = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-dxdy.cg");
   gaussianX = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-gaussian-sigma3-x-rgb.cg");
   gaussianY = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-gaussian-sigma3-y-rgb.cg");
   derandom = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-derandom-corners.cg");
   derandom->setCGParameter( "thresh", derandomthresh);
   feature = new FragmentProgram(d->getContext(), d->getProfile(), 
                               "FPsamples/FP-feature.cg", 1);
   decide = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-decide.cg");
   decide->setCGParameter( "thresh", cornerthresh);
  cerr<<"Done"<<endl;


   
   init_track();  //initialize some tracking arrays information

   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}










////////////////////
////// GLUT CALLBACKS ///////////////
////////////////////
void reshape(int w, int h)
{
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  //rosco version
  glFrustum(-1.0,1.0,-1.0,1.0,1.0,100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,-1.0,   0.0, 1.0, 0.0);

  //james version
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);

  //set the fpbuffer to have geometry identical to screen
  d->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  d->deactivate_fpbuffer();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

//save the reference state, when requested.
void saveReferenceState()
{
  for( int i=0; i <240 ; i++ ) {
    IDReference[i] = ID[i];
    AgeReference[i] = Age[i];
    memcpy( featureVectorsReference[i], featureVectors[i], 128*sizeof(float) );
    cornersArrayReference[i][0] = cornersArray[i][0];
    cornersArrayReference[i][1] = cornersArray[i][1];
  }
  numFeaturesReference = numFeatures;
  posReference[0] = pos[0];
  posReference[1] = pos[1];
  cerr<<"*****Saved "<<numFeaturesReference<<" features as reference state"<<endl;
  fprintf(stderr,"\a");
  PCumulativeSinceLastRef.setIdentity();
}

//save the reference state as the previous state, when requested.
void saveReferenceStatePrev()
{
  for( int i=0; i <240 ; i++ ) {
    IDReference[i] = prevID[i];
    AgeReference[i] = prevAge[i];
    memcpy( featureVectorsReference[i], featureVectorsPrev[i], 128*sizeof(float) );
    cornersArrayReference[i][0] = cornersArrayPrev[i][0];
    cornersArrayReference[i][1] = cornersArrayPrev[i][1];
  }
  numFeaturesReference = numFeatures;
  posReference[0] = pos[0];
  posReference[1] = pos[1];
  cerr<<"****************************Saved PREV"<<numFeaturesReference<<" features as reference state"<<endl;
  PCumulativeSinceLastRef.setIdentity();
}


//Match array holds the point correspondences in the form
void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
         viewbuf = atoi((const char * )&key);
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case 'A' : 
         viewbuf = 10;
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case 's':
         derandomthresh[0] += 0.01;
         cerr<<"derandomthresh = "<<derandomthresh[0]<<endl;
         derandom->setCGParameter( "thresh", derandomthresh);
         break;
      case 'x':
         derandomthresh[0] -= 0.01;
         cerr<<"derandomthresh = "<<derandomthresh[0]<<endl;
         derandom->setCGParameter( "thresh", derandomthresh);
         break;
      case 'a':
         cannythresh[0] += 0.1;
         cerr<<"cannythresh = "<<cannythresh[0]<<endl;
         cannysearch->setCGParameter( "thresh", cannythresh);
         break;
      case 'z':
         cannythresh[0] -= 0.1;
         cerr<<"cannythresh = "<<cannythresh[0]<<endl;
         cannysearch->setCGParameter( "thresh", cannythresh);
         break;
       case 'd':
         cornerthresh[0] += 1.0;
         cerr<<"cornerthresh = "<<cornerthresh[0]<<endl;
         decide->setCGParameter( "thresh", cornerthresh);
         break;
 
       case 'c':
         cornerthresh[0] -= 1.0;
         cerr<<"cornerthresh = "<<cornerthresh[0]<<endl;
         decide->setCGParameter( "thresh", cornerthresh);
         break;

      case 'r' :  //take a snapshot of the state.
        saveReferenceState();
        break;
         
    
 
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        float pixbuf[4] = {0.0};
        cerr << "("<<x<<","<<y<<"):";
        glReadPixels( x,240-y, 1,1, GL_RGBA, GL_FLOAT,  pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
      }
      break;
   case GLUT_RIGHT_BUTTON : 
     if( state == GLUT_DOWN ) {
       pos[0] = (float)x/320.0;
       pos[1] = (float)y/240.0;
       saveReferenceState();
     }
     break;
  
   case GLUT_MIDDLE_BUTTON :
     ///PCumulativeSinceLastRef.print();
     ///PCumulativeSinceLastRef.invert();
     PCumulativeSinceLastRef.setIdentity();
     int numMatched = findBestFeatureMatchLocal( cornersArray,
                                              cornersArrayReference,
                                              featureVectors,
                                              featureVectorsReference,
                                              matchArray,
                                              numCorners, 
                                              numFeaturesReference,
                                              PCumulativeSinceLastRef,
                   ///sems to work best with a large window of opportunity
                                              155.0 ) ;
    int support;
    Parameters Pairwise = RANSAC.find_P(matchArray, numMatched, &support);
    if( support < 10 ) break;
    PCumulativeSinceLastRef.setIdentity();
    pos[0] = posReference[0];
    pos[1] = posReference[1];
    drawTrack( Pairwise );
   // drawMatches(numMatched);

    break;
  }
}


///helper functions

void drawFingerTip()
{
  drawCircleHelper(HAND_X_COORD/320.0, HAND_Y_COORD/240.0);
}

void  doMoment()
{
    float result[4] = {0.0};
    d->applySumFilter(momentFilter, 3, 4, result );
    //cerr<<"M = ["<<result[0]<<", "<<result[1]<<", ";
    //cerr<<result[2]<<", "<<result[3];
    //cerr<<" M_x = "<<result[1]/result[0]<<", M_y = "<<result[2]/result[0]<<endl;
    HAND_X_COORD=result[1]/result[0];
    HAND_Y_COORD=result[2]/result[0];
    //cerr<<"Avg S : "<<result[3]/result[0]<<endl;
   
    //make sure that enough pixels are actually recognized as skin
    //if( result[0] < 320*240*0.05 || result[0] > 320*240*0.75 ) {
    if( result[0] > 320*240*0.75 || result[0] < 0.001*320*240) {
      //cerr<<"bad stats"<<endl;
      return;
    }
    float thresh[4] = {result[3]/result[0], result[3]/result[0], 0.008, 0.1};
    filter2->setCGParameter("thresh", thresh);
    //cerr<<"window: "<<1.5*sqrt(result[0])<<endl;
}

/* coords are normalized */
void drawCircleHelper(float x, float y) {
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glColor4f(0.0,0.0,1.0,1.0);
  glPointSize(10.0); //XXX move away.
  //cerr<<"X = "<<HAND_X_COORD<< "  Y="<<HAND_Y_COORD<<endl;
  //cerr<<"X = "<<HAND_X_COORD/320.0<< "  Y="<<HAND_Y_COORD/240.0<<endl;
  glClear(GL_DEPTH_BUFFER_BIT);
  glBegin(GL_POINTS);
  //  glVertex3f(x, y,   1.0 );
    glVertex3f(x, y,   -1.0 );
  glEnd();
}

/* Tell function executed in context of Dc1394 thread */
void TellRWMHeCanUseImage(const char *dma_buf_) {
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;

  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;
  uyvy2rgb(dma_buf,dma_buf_rgb,320*240);

  //have only one, need two before we do any orbits
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }

  newdata=1;
}

/** Everything from here on in is feature point characterization */

//for is RGB 320x240
void featureSearch(unsigned char *foo) {
  int i, j;
  int k=0;
  int numEdges=0;
  numCorners=0;
  for( i=0 ; i<240 ; i++ ) {
    for( j=0; j<320 ; j++ ) {
      if( foo[k] > 200 ) { 
        cornersArray[numCorners][0] = j; //rasterized x location
        cornersArray[numCorners][1] = (240-i); //raster  location
        numCorners++;
        if( numCorners > 998 ) {
          fprintf(stderr, "too many corners.\n");
          break;
        }
      }
      else if( foo[k] > 100 ) {
        numEdges++;
      }
      k+=3; //increment by RGB
    }
  }
//  fprintf(stderr, "There are %d corners, %d edge pixels\n", numCorners, numEdges);
  //end marker
  cornersArray[numCorners][0] = -1.0; //normalized x location
  cornersArray[numCorners][1] = -1.0; //normalized x location
}



///////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002, Industrial Light & Magic, a division of Lucas
// Digital Ltd. LLC
// 
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
// *       Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
// *       Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
// *       Neither the name of Industrial Light & Magic nor the names of
// its contributors may be used to endorse or promote products derived
// from this software without specific prior written permission. 
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////




//---------------------------------------------------------------------------
//
//	toFloat
//
//	A program to generate the lookup table for half-to-float
//	conversion needed by class half.
//	The program loops over all 65536 possible half numbers,
//	converts each of them to a float, and prints the result.
//
//---------------------------------------------------------------------------


#include <iostream>
#include <iomanip>

using namespace std;

//---------------------------------------------------
// Interpret an unsigned short bit pattern as a half,
// and convert that half to the corresponding float's
// bit pattern.
//---------------------------------------------------

unsigned int
halfToFloat (unsigned short y)
{

    int s = (y >> 15) & 0x00000001;
    int e = (y >> 10) & 0x0000001f;
    int m =  y        & 0x000003ff;

    if (e == 0)
    {
	if (m == 0)
	{
	    //
	    // Plus or minus zero
	    //

	    return s << 31;
	}
	else
	{
	    //
	    // Denormalized number -- renormalize it
	    //

	    while (!(m & 0x00000400))
	    {
		m <<= 1;
		e -=  1;
	    }

	    e += 1;
	    m &= ~0x00000400;
	}
    }
    else if (e == 31)
    {
	if (m == 0)
	{
	    //
	    // Positive or negative infinity
	    //

	    return (s << 31) | 0x7f800000;
	}
	else
	{
	    //
	    // Nan -- preserve sign and significand bits
	    //

	    return (s << 31) | 0x7f800000 | (m << 13);
	}
    }

    //
    // Normalized number
    //

    e = e + (127 - 15);
    m = m << 13;

    //
    // Assemble s, e and m.
    //

    return (s << 31) | (e << 23) | m;
}



void gl_draw_text_normcoord( float x, float y, char *string)
{
    int ww = glutGet( (GLenum)GLUT_WINDOW_WIDTH );
    int wh = glutGet( (GLenum)GLUT_WINDOW_HEIGHT );

    char *p;
    //glColor3f(1.0,1.0,1.0);
    //illegible matrix green 
    //glColor3f( 0.11, 0.37, 0.25);
    glMatrixMode( GL_PROJECTION );
    glPushMatrix();
    glLoadIdentity();
    //ww /= 2;
    //wh /= 2;
    //gluOrtho2D( -(float)ww, (float)ww, -(float)wh, (float)wh );
    //gluOrtho2D( 0, (float)ww, -(float)wh, (float)wh );
    gluOrtho2D( 0, (float)ww, 0.0, (float)wh);
    glMatrixMode( GL_MODELVIEW );
    glPushMatrix();
    glLoadIdentity();

//    glRasterPos2i( x*(float)ww,y*(float)wh );
    glRasterPos2i( (int)x,(int)y );

    for ( p = string; *p; p++ )
          {
        if ( *p == '\n' )
            {
            y = y - 14;
            glRasterPos2i( (int)(ww*x), (int)(wh*y) );
            continue;
            }
        glutBitmapCharacter( GLUT_BITMAP_HELVETICA_18, *p );
          }

//        glutBitmapCharacter( GLUT_BITMAP_HELVETICA_18, 'f');



    glMatrixMode( GL_PROJECTION );
    glPopMatrix();
    glMatrixMode( GL_MODELVIEW );
    glPopMatrix();
}

