/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "Udat.h"
#include <iostream>
#include <sys/time.h>
#include <time.h>



int main()
{
static struct timeval start_time, end_time;
  float *eigs[50];
  int i=0;
  int j=0;
  float sumx=0.0, sumy=0.0, sumz=0.0, sumw=0.0;
 
  //Udat *U = new Udat("U.dat");
  Udat *U = new Udat(NULL);

  //U->readSVdat("SV.dat");
  U->readSVdat(NULL);
  U->getColNorm(0);
  U->getColNorm(1);
  U->getColNorm(2);
  for( i=0; i<50; i++ ) { 
    eigs[i] = (float *)U->getRGBAData4f();
    U->advanceFrame();
  }
  gettimeofday(&start_time,NULL);
  for (i=0 ;i<48; i++ ) {
   for( j=0 ; j<320*240*4; j+=4 ) {
   sumx+=eigs[0][j]*eigs[i][j];
   sumy+=eigs[0][j+1]*eigs[i][j+1];
   sumz+=eigs[0][j+2]*eigs[i][j+2];
   sumw+=eigs[0][j+3]*eigs[i][j+3];
   }
  }
 gettimeofday(&end_time,NULL);
 cout<<"time "<<(end_time.tv_sec*1000000+end_time.tv_usec)-
                (start_time.tv_sec*1000000+start_time.tv_usec) <<endl;
//101 msecs on a Athlon XP 2800+ 
 cout<<"sum "<<sumx<<sumy<<sumz<<sumw<<endl;
  float *A, *B;
  gettimeofday(&start_time,NULL);
  for (i=0 ;i<50; i++ ) {
   for( j=0 ; j<320*240*4; j+=4 ) {
     A = &(eigs[0][j]); B=&(eigs[i][j]);
     sumx += *A**B; A++; B++;
     sumy += *A**B; A++; B++;
     sumz += *A**B; 
   //sumx+=eigs[0][j]*eigs[i][j]; 
   //sumy+=eigs[0][j+1]*eigs[i][j+1];
   //sumz+=eigs[0][j+2]*eigs[i][j+2];
   }
  }
 gettimeofday(&end_time,NULL);
 //cout<<"time "<<(end_time.tv_sec*1000000+end_time.tv_usec)-
 //               (start_time.tv_sec*1000000+start_time.tv_usec) <<endl;
//101 msecs on a Athlon XP 2800+ 
 cout<<"sum "<<sumx<<sumy<<sumz<<endl;
   U->freeUdat();
}
