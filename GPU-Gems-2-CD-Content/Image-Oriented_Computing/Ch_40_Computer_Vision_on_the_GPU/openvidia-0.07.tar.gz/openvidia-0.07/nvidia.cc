/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "nvidia.h"
using namespace std;


//#include <Cg/cgGL.h>
#include <GL/gl.h>
#include <GL/glx.h>
#include <GL/glu.h>

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#define GLH_EXT_SINGLE_FILE
#ifdef GL_EXT_texture_rectangle
#define GL_TEXTURE_RECTANGLE_NV GL_TEXTURE_RECTANGLE_EXT
#endif
#include <glh/glh_nveb.h>
#include <glh/glh_extensions.h>
#include <glh/glh_obs.h>
#include <glh/glh_glut.h>
#include <glh/glh_convenience.h>
#include <shared/nv_png.h>
#include <shared/array_texture.h>
#include <shared/data_path.h>
#include <shared/nv_dds.h>

#define REQUIRED_EXTENSIONS "GL_ARB_texture_compression " \
                            "GL_EXT_texture_compression_s3tc " \
                            "GL_NV_texture_rectangle " \
                            "GL_NV_vertex_program " \
                            "GL_NV_fragment_program " \
                            "GL_EXT_blend_color " \
                            "GLX_NV_float_buffer " \
                            "GLX_SGIX_fbconfig " \
                            "GLX_SGIX_pbuffer "

//#include "fpc.h"
//#include "../float_pbuffer_lnx_class/fpc.h"
 
//CFPBuffer fpbuffer;
CGcontext vContext;
char fragmentProgramFile2[256]="FP-pass-2.cg";
float constantColor[4] = {1.0, 1.0, 1.0, 1.0};
double outputColor[4] = {0.0,0.0,0.0,0.0};
float xsize,ysize;
CGparameter E1Texture, E2Texture, someColor, E2texCoord,E1texCoord, colorO, xsizeParam, ysizeParam, Pparams;
CGprofile vProfile;
CGprogram fragmentProgram, FPpt, FPds1;
CGparameter FPpttexCoord0, FPpttexture0, FPpttexCoord1, FPpttexture1;

CGprogram fragmentProgram2;
CGparameter FP2texCoord, FP2texture;

static GLenum errCode;
const GLubyte *errString;
int internal_ImageWidth=-1;
int internal_ImageHeight=-1;
/*
void init_float_pbuffer(int ImageWidth, int ImageHeight) 
{
    cerr<<"Creating Image buffer" << ImageWidth << "x" << ImageHeight << "...";
    if (!fpbuffer.create(ImageWidth, ImageHeight))
        exit(-1);
    cerr << "[ok]" << endl;
}

void fpbufferactivate() { fpbuffer.activate(); }
void fpbufferdeactivate() { fpbuffer.deactivate(); }
*/
void createFragmentProgram2(GLuint *texNames);


/*
 * Check if cg or gl set the error code 
 */
void errcheck() {

  if ((errCode = glGetError()) != GL_NO_ERROR) {
    errString = gluErrorString(errCode);
    fprintf (stderr, "OpenGL Error: %s\n", errString);
    exit(1);
  }

}

/*
 * A callback function for cg to use when it encounters an error
 */
void cgErrorCallback(void) {
    CGerror LastError = cgGetError();

    if(LastError)
    {
        const char *Listing = cgGetLastListing(vContext);
        printf("\n---------------------------------------------------\n");
        printf("%s\n\n", cgGetErrorString(LastError));
        printf("%s\n", Listing);
        printf("---------------------------------------------------\n");
        printf("Cg error, exiting...\n");
        exit(0);
    }
}

/*
 * Initialize the cg graphics hardware and set up parameters
 * for fragment program
 */
void init_cg(GLuint *texNames, int ImageWidth, int ImageHeight, float Pmatrix[16]) {

    if (!glh_init_extensions(REQUIRED_EXTENSIONS))
    {
        printf("Unable to load the following extension(s): %s\n\nExiting...\n",
               glh_get_unsupported_extensions());
        exit(-1);
    }

   if (cgGLIsProfileSupported(CG_PROFILE_FP30)) {
        vProfile = CG_PROFILE_FP30;
        cerr<<"Hardware supports fragment programs: Using CG_PROFILE_FP30"<<endl;
    }
    else {
        cout<<"CG_PROFILE_FP30 not supported, exiting..."<<endl;
        exit(0);
    }
   
    if (!glh_extension_supported("GL_EXT_texture_rectangle") &&
        !glh_extension_supported("GL_NV_texture_rectangle"))
    {
      cerr << "Video card does not support texture rectangles" << endl << endl
	   << "Press <enter> to quit." << endl;
      char buff[10];
      cin.getline(buff, 10);
      exit(0);
    }
    cgSetErrorCallback(cgErrorCallback);

    // Multitexture stuff

    glh_init_extensions("GL_ARB_multitexture");
    glActiveTextureARB(GL_TEXTURE0_ARB);

    
    fprintf(stderr, "Creating cg Context (cgCreateContext())...");
    vContext = cgCreateContext();
    fprintf(stderr, "[ok]\n");
}

void init_FP(char *fragmentProgramFile, GLuint *texNames, int ImageWidth, int ImageHeight, float Pmatrix[16]) {
    // create the vertex program
    fprintf(stderr, "Creating Program...%s",fragmentProgramFile);
    fragmentProgram = cgCreateProgramFromFile(vContext,
                                       CG_SOURCE, fragmentProgramFile,
                                       //vProfile, NULL, NULL);
                                       vProfile, "FragmentProgram", 0);
    fprintf(stderr, "[ok]\n");
    xsize=(float)ImageWidth;
    ysize=(float)ImageHeight;
    cerr<<"xsize, ysize "<<xsize<<" "<<ysize<<endl;

    fprintf(stderr, "Loading Program...");
    cgGLLoadProgram(fragmentProgram);
    fprintf(stderr, "[ok]\n");
    fprintf(stderr, "Getting Parameters...");
    E1texCoord = cgGetNamedParameter(fragmentProgram, "E1texCoord");
    E2texCoord = cgGetNamedParameter(fragmentProgram, "E2texCoord");
    E1Texture = cgGetNamedParameter(fragmentProgram, "E1");
    E2Texture = cgGetNamedParameter(fragmentProgram, "E2");
    someColor = cgGetNamedParameter(fragmentProgram, "SomeColor");
    colorO = cgGetNamedParameter(fragmentProgram, "colorO");
    //Pparams = cgGetNamedParameter(fragmentProgram, "P");
    Pparams = cgGetNamedParameter(fragmentProgram, "P");

    xsizeParam = cgGetNamedParameter(fragmentProgram, "xsize");
    ysizeParam = cgGetNamedParameter(fragmentProgram, "ysize");

    cgGLSetParameter1f( xsizeParam, xsize);
    cgGLSetParameter1f( ysizeParam, ysize);

    // Set parameters that don't change:
    // They can be set only once because of parameter shadowing.
    //cgGLSetTextureParameter(E1Texture, textureImage);
    //cgGLSetTextureParameter(E2Texture, textureImage);
    cgGLSetTextureParameter(E1Texture, texNames[0]);
    cgGLSetTextureParameter(E2Texture, texNames[1]);
    cgGLSetParameter4fv(someColor, constantColor);  
    //set matrix, row order floating point
    cgGLSetMatrixParameterfr(Pparams, Pmatrix);
    fprintf(stderr, "[ok]\n");
//    createFragmentProgram2(texNames);
}

void init_FPds1(char *fragmentProgramFile, GLuint *texNames, int ImageWidth, int ImageHeight, float Pmatrix[16]) {
    // create the vertex program
    fprintf(stderr, "Creating Program...%s",fragmentProgramFile);
    FPds1 = cgCreateProgramFromFile(vContext,
                                     CG_SOURCE, fragmentProgramFile,
                                     vProfile, "FragmentProgram", 0);
    fprintf(stderr, "[ok]\n");
    xsize=(float)ImageWidth;
    ysize=(float)ImageHeight;
    cerr<<"xsize, ysize "<<xsize<<" "<<ysize<<endl;

    fprintf(stderr, "Loading Program...");
    cgGLLoadProgram(FPds1);
    fprintf(stderr, "[ok]\n");
    fprintf(stderr, "Getting Parameters...");
    E1texCoord = cgGetNamedParameter(FPds1, "E1texCoord");
    E2texCoord = cgGetNamedParameter(FPds1, "E2texCoord");
    E1Texture = cgGetNamedParameter(FPds1, "E1");
    E2Texture = cgGetNamedParameter(FPds1, "E2");
    someColor = cgGetNamedParameter(FPds1, "SomeColor");
    colorO = cgGetNamedParameter(FPds1, "colorO");
    //Pparams = cgGetNamedParameter(fragmentProgram, "P");
    Pparams = cgGetNamedParameter(FPds1, "P");

    xsizeParam = cgGetNamedParameter(FPds1, "xsize");
    ysizeParam = cgGetNamedParameter(FPds1, "ysize");

    cgGLSetParameter1f( xsizeParam, xsize);
    cgGLSetParameter1f( ysizeParam, ysize);

    // Set parameters that don't change:
    // They can be set only once because of parameter shadowing.
    //cgGLSetTextureParameter(E1Texture, textureImage);
    //cgGLSetTextureParameter(E2Texture, textureImage);
    cgGLSetTextureParameter(E1Texture, texNames[0]);
    cgGLSetTextureParameter(E2Texture, texNames[1]);
    cgGLSetParameter4fv(someColor, constantColor);
    //set matrix, row order floating point
    cgGLSetMatrixParameterfr(Pparams, Pmatrix);
    fprintf(stderr, "[ok]\n");
//    createFragmentProgram2(texNames);
}


void createFragmentProgram2(GLuint *texNames)
{
    fragmentProgram2 = cgCreateProgramFromFile(vContext,
                                       CG_SOURCE, fragmentProgramFile2,
                                       vProfile, "FragmentProgram2", 0);
 
    fprintf(stderr, "Loading Program [%s]  ");
    cgGLLoadProgram(fragmentProgram2);
    FP2texCoord = cgGetNamedParameter(fragmentProgram2, "fp2texCoord");
    FP2texture = cgGetNamedParameter(fragmentProgram2, "FP2E1");
    //cgGLSetTextureParameter(FP2texture, texNames[2]);
    cgGLSetTextureParameter(FP2texture, texNames[0]);
    fprintf(stderr, "[ok]\n");
}

void nv_reset_pchirp(float Pmatrix[16])
{
    cgGLSetMatrixParameterfc(Pparams, Pmatrix);
}

void makeFPpassthru( CGcontext fContext,
                CGprofile fProfile,
                char *FPname,
                GLuint texName0, GLuint texName1 )
{
  cerr << "Loading Program [ " << FPname << " ] ";
  FPpt = cgCreateProgramFromFile(fContext,
                               CG_SOURCE, FPname,
                               fProfile, "FragmentProgram", 0);
  cgGLLoadProgram(FPpt);
  FPpttexCoord0 = cgGetNamedParameter(FPpt, "fptexCoord0");
  FPpttexture0 = cgGetNamedParameter(FPpt, "FPE0");
  FPpttexCoord1 = cgGetNamedParameter(FPpt, "fptexCoord1");
  FPpttexture1 = cgGetNamedParameter(FPpt, "FPE1");
  cgGLSetTextureParameter(FPpttexture0, texName0);
  cgGLSetTextureParameter(FPpttexture1, texName1);
  cerr << "[ok]" << endl;
}
