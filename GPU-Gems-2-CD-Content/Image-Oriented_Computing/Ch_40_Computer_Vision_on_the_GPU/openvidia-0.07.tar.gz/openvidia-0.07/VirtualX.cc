/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "VirtualX.h"

/*
 * Simple version.  Replaced by XApp.cc
 *
 */

#include <stdlib.h> //for system
#include <stdio.h> //fopen
#include <unistd.h>//fork
#include <iostream> //cout? 
#include <sys/types.h>//fork
#include <sys/shm.h>
#include <string.h> //memcpy
#include <math.h>

//lots of useful utils for sending key events
//creating shm images etc...
//look at source for xmg - magnifying glass for X
//http://www.mit.edu/afs/athena/system/pmax_ul4/srvd.74/usr/sipb/src/xmg-0.9.1/xmg.c
#include <X11/extensions/XTest.h>
#include <X11/XWDFile.h>
#include <X11/extensions/XShm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#ifndef roundup
#define roundup(x, y) ((((x)+((y)-1))/(y))*(y))
#endif

// The following header
//http://www.dcs.ed.ac.uk/home/mxr/gfx/2d/XWD.txt
//or File /usr/X11R6/include/X11/XWDFile.h
// has strucrts to manipulate XWD.


/*
 * a bunch of stuff in this file could be redundant. I tried to use
 * XWDFile.h stuff, but then aborted and now i do manual parsing
 * fo the xwd shmem.
 */

using namespace std;

void VirtualX::writeToRGBBuf(unsigned char *rgb) {
  cout <<"shmattting..."<<endl;

  static unsigned char *shim=(unsigned char*)shmat(shmatid, NULL, SHM_RDONLY);
  cout<<"smatted."<<endl;
  if(shim<=0) {
    cerr<<"shm failed. address is "<<(int)shim<<endl;
    exit(-1);
  }
	//	xwd+=sizeof(XWDFileHeader);

	unsigned char* p=shim;

	//The following tries to get a header.
	//I determined none exists in SHMEM
	//XWDFileHeader *header=(XWDFileHeader *)p;
	//p+=sizeof(XWDFileHeader);
	//CARD32 rosco=header->pixmap_depth;
	//cout<<"rosco="<<(int)rosco<<endl;

	  p+=167*4;
	  for(int i=0;i<320*240;i++) {
	    //	    cout<<"i="<<i<<" ";
	    *rgb++=*p++;
	    *rgb++=*p++;
	    *rgb++=*p++;
	    *p++;
	    p+=4;
	    
	    if(i%320==0) {
	      while(true) {
	      // check if the coming up line is black
	      int sum=0;
	      for(int j=0;j<20;j++) {
		sum+=*(p+j);
	      }
	      if(sum<10){
//		cout <<"line "<<i/320<<" is blank"<<endl;
		//skip one decimated line, *2 twice?
		p+=(320*4*2);
	      } else {
		//not empty line
		break;
	      }
	      }
	    }

	  }
	  return;
	  


  for(int i=0;i<240;i++) {
    for(int j=0;j<320;j++) {
      XWDColor *c=(XWDColor*)p;

      // r=39582 g=145 b=39582 r=39582 g=145 b=39582 
      // LOOKS LIKE: R << 8 and G << 8
      //HACK: r is 0 or 65535
      //      cout<<" r="<<(int) ((char) c->red) <<" "<<c->green<<" "<<c->blue;
      //      cout<<" r=" << (c->red>>8) <<" "<< (c->green) <<" "<< (c->blue>>8);
      //      *rgb++=c->red;//nice o its own.
      //*rgb++=c->green;
      //*rgb++=c->blue;// >> 8;
      *rgb++=*p++;
      *rgb++=*p++;
      *rgb++=*p++;
      *p++;
      p+=4;
      // skipping 1 32, reading one 32.
      //      p+=sizeof(CARD32)*2;//CARD32
    }
    p+=4*320;
    //1 times is hack since we can only go 137 times
    //0.5 213
    //    p+=(sizeof(XWDColor)+sizeof(CARD32)*2)*320/4;
  }
  
}


//req screen should be 2
//XXX not using arguments right now
VirtualX::VirtualX(int reqScreenId, int *screenId, int *shmid) {
  char cmdstr[1024];
  char *tmpFileName="xvfbshmem.tmp";
  char buffer[64];
  
  // start without access control
  //XXX todo screen size
  //Xvfb :2 -screen 0 320x240x8 -ac -fbdir /r/curr/fb-dir/
  // use 640x480, decimate horiz by 2, again
  sprintf(cmdstr, "Xvfb :2 -screen 0 640x480x24 -ac -shmem 2>%s", tmpFileName);
  cout <<"executing "<<cmdstr<<"..."<<endl;

  int pid=fork();
  if(pid<0) {
    cerr<<"unable to fork. exiting..."<<endl;
    exit(-1);
  }
  if(pid==0) {
    //parent thread
  } else {
    /*
     * Forked child should live on if parent exits
     */
    system(cmdstr);
    sleep(2);//wait for xvfb
    cerr<<"starting clock"<<endl;
    //system("xlogo -display :2.0&");
    //system("xview /r/curr/IMAGES/box.pnm -display :2.0&");
    system("mozilla-firefox --display :2.0&");
    exit(0);
  }
  //output is of the form screen 2 shmid 3899424
  FILE *f=fopen(tmpFileName, "r");
  if(f==NULL) {
    cerr<<"Could not open temp shmemid file. Exiting..."<<endl;
    exit(-1);
  }
  /*  int i=fread(buffer, 1, 21, f);
  buffer[21]='\0';
  cout <<"FILE CONTENTS!--read "<<i<<" bytes"<<endl;
  fprintf(stderr, "%s\n",buffer);
  */
  char buf1[64];
  char buf2[64];
  int screenidTmp, shmidTmp;
  fscanf(f, "%s %d %s %d", buf1, buf2, &screenidTmp, &shmidTmp);
  cout <<"SHMID XVFB=="<<shmidTmp<<endl;
  shmatid=shmidTmp;
}
