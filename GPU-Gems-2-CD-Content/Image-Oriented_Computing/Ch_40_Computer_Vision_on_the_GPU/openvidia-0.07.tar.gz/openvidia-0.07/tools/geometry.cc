#include <math.h>
#include "geometry.h"

bool isPointInside(int x,int y,int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4) {
  
  // X is across, Y is downwards
  // so posotive slope is downwards to right
  // Dont divide by zero.
  float yslopeT = x2!=x1? (1.0*(y2-y1))/(x2-x1) : (1.0*(y2-y1))/0.001;
  float yslopeB = x3!=x4? (1.0*(y3-y4))/(x3-x4) : (1.0*(y3-y4))/0.001;
  float xslopeL = y1!=y4? 1.0*(x4-x1)/(y4-y1) : (x4-x1)/0.001;
  float xslopeR = y3!=y2? 1.0*(x3-x2)/(y3-y2) : (x3-x2)/0.001;
  
  //check if we are in bounding box, if not break early.
  if( x > fmaxf(fmaxf(fmaxf(x1,x2),x3),x4) ||
      x < fmin(fmin(fmin(x1,x2),x3),x4) ||
      y > fmax(fmax(fmax(y1,y2),y3),y4) ||
      y < fmin(fmin(fmin(y1,y2),y3),y4) ) {
    return false;
  }
  
  // below top line, above bottom line
  // to right of left line, to left of right line
  if( y >= y1+(x-x1)*yslopeT  &&
      y <= y4+(x-x4)*yslopeB  &&
      x >= x1+(y-y1)*xslopeL  &&
      x <= x2+(y-y2)*xslopeR  ) {
    return true;
  } else {
    return false;
  }
}
