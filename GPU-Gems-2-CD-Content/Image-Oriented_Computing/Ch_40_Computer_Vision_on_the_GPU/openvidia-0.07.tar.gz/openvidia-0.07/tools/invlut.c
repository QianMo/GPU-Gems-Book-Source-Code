/* inverts a lookup table, creates a 10000 element inverse lookup
   table.  To use this table, take your [0,1] lightpsace value,
   multiply it by 10000, then use the result to index into this
   table, which will return you a value from [0,255]

   given q in [0,1] lightspace

   f = invlut[ q*10000 ] ;

   where
   f in [0,255] imagespace

   for inverse lookups on graphics hardware, this inverse lut
   is encoded into a 100x100 floating point texture.  

   given ql = q*100;
   row is whole part of ql
   column fractional remainder*100, rounded to int

*/


#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <fcntl.h>
#include <assert.h>
#include <zlib.h>
#include <ctype.h>

#define SIZE 100*100
#define LUTSIZE 256

void readlut(char *lutfilename, double powLookupTable[LUTSIZE]);




int main(int argc, char *argv[]) 
{
  double lut[LUTSIZE];
  double invlut[SIZE];
  int invlutindex=0;
  int lutindex=0;
  if( argc < 2 ) { 
    fprintf(stderr, "please give lut.\n");
    exit(1);
  }
  readlut( argv[1], lut );
 

  for( lutindex = 0; lutindex<LUTSIZE ; lutindex++ ) {
    double cutpoint = ((lut[lutindex+1] - lut[lutindex])/2.0)+lut[lutindex];
    double currentval = lut[lutindex];
    //printf("cutpoint %g %g %g \n", lut[lutindex+1], lut[lutindex], cutpoint);
    while( invlutindex < (int)(cutpoint*SIZE)  ) {
      invlut[invlutindex] = (double)lutindex;
//      printf("invlut[%d] %g \n",invlutindex,  invlut[invlutindex]);
      printf("%g \n",invlut[invlutindex]);
      invlutindex++;
      if( invlutindex > SIZE-1 ) goto finish;
    }
  }
finish:
  printf("complete.\n");
}



/* ===================================================================== */
/* Readlut - reads a given lookup table. */
/* ===================================================================== */
void readlut(char *lutfilename, double powLookupTable[LUTSIZE])
{
  /* some variables used in reading a text file lut */
  FILE *lutfile;
  int lutsize=LUTSIZE;
  float p;
  int i;

  if(lutfilename !=NULL)
    {
      if ((lutfile = fopen(lutfilename, "r")) == NULL)
     {
       fprintf(stderr, "Unable to open %s.\n", lutfilename);
       fclose(lutfile);
       exit(EXIT_FAILURE);
       }
      else
       {
         fscanf(lutfile, "%f", &p);
         for (i=0; i<lutsize; i++)
           fscanf(lutfile, "%lf", &(powLookupTable[i]));
         
         if (i != lutsize) {
           fprintf(stderr, "Incomplete read of LUT. Numread: %d\n", i);
           fclose(lutfile);
           exit(1);
         }
       }
     fclose(lutfile);
      }
}

