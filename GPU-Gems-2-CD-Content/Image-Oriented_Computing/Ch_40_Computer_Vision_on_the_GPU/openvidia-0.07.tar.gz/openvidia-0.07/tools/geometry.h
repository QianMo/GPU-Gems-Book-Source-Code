#ifndef _GEOMETRY_H
#define _GEOMETRY_H

bool isPointInside(int x,int y,int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4);

#endif
