#include <stdlib.h> //for system
#include <stdio.h> //fopen
#include <unistd.h>//fork
#include <iostream> //cout? 
#include <sys/types.h>//fork
#include <sys/shm.h>
#include <string.h> //memcpy

//lots of useful utils for sending key events
//creating shm images etc...
//look at source for xmg - magnifying glass for X
//http://www.mit.edu/afs/athena/system/pmax_ul4/srvd.74/usr/sipb/src/xmg-0.9.1/xmg.c
#include <X11/extensions/XTest.h>
#include <X11/XWDFile.h>
#include <X11/extensions/XShm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

using namespace std; //cout

int main(int argc, char **argv) {

  int a = atoi(argv[1]);
  cout<<"connecting to shm id "<<a<<endl;
  static unsigned char *c=(unsigned char*)shmat(a, NULL, SHM_RDONLY);

  cout<<"smatted."<<endl;
  cout<<"shm address is "<<(int)c<<endl;
}
