#ifndef _GRAPHICSHELPERS_H
#define _GRAPHICSHELPERS_H

void drawFingerTip(int x, int y);

void drawFingerTip(int x, int y, float r, float g, float b);

//normalized coords
void normDrawCircleHelper(float x, float y);
void normDrawLine(float x, float y, float x2, float y2);
#endif
