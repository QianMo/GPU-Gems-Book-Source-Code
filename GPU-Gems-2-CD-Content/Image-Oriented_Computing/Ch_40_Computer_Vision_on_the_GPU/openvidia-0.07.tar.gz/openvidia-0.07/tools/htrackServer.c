#include <stdio.h>
#include <stdlib.h>

extern void getHandCoords(int *x, int *y);
extern int xnee_motion( int x, int y );
extern int button_event( int b, int state, int msecs ) ;

#define INPUT_SZ_X 320.0
#define INPUT_SZ_Y 240.0

void button_toggle(int x, int y);
void usage() 
{
  printf("Usage:  ./htrackServer [id] {optional scaling x} {optional scaling y}"
        );
  printf("\n");
  printf("   [id] client id \n");
  printf("   {optional x/y scaling} : inputs are 320x240, so you might want\n");
  printf("   to scale the output mouse coordinates to match your screen \n");
  printf("   size.  E.g. 1024 768 scales it to move around 1024x768 size \n");
  printf("   screen\n");
}

void browser_click()
{ 
  xnee_motion(40,80); 
  button_event(1, 1, 0);
  button_event(1, 0, 10);
  usleep(30);
  xnee_motion(640,400); 
}

int main(int argc,char *argv[])
{
  int ipcid;
  int x,y;
  int lastx, lasty;
  float scalex = 1.0, scaley = 1.0;


  if( argc == 1 ) {
    usage();  
    exit(0);
  }
  printf("Starting htrackServer.  Ctrl-c exits. \n");
  printf("Typing 'xset r' at a console restores typematic repeating\n");

  ipcid = atoi(argv[1]);
  shmConnect(ipcid);
  init_xnee();

  if( argc >= 3 ) { 
     scalex = atoi(argv[2])/INPUT_SZ_X;
     printf("Scaling x by %f\n", scalex);
  }
  if( argc == 4 ) { 
     scaley = atoi(argv[3])/INPUT_SZ_Y;
     printf("Scaling y by %f\n", scaley);
  }

 
  while(1){
    getHandCoords(&x, &y);
//    xnee_motion((int)((float)x*scalex),(int)((float)y*scaley));
//    fprintf(stderr, "in: %d %d, out %d %d\n", 
//            x, y, (int)((float)x*scalex), (int)((float)y*scaley));
    usleep(30000);
    button_toggle(x,y);
  }
  close_xnee();
}

#define GS0 0
#define GS00 10
#define GS1 1
#define GS2 2
#define GS3 3

void button_toggle(int x, int y) {
  static int GESTURE_STATE = GS0;
  float on_thresh=0.9;
  float hasleft_thresh=0.8;

  float xn = ((float)x)/INPUT_SZ_X;
  float yn = ((float)y)/INPUT_SZ_Y;


  switch(GESTURE_STATE) { 
    case GS0 : 
      //check for state transition.  entering of rhs region
      if( xn > on_thresh ) { 
        GESTURE_STATE = GS00;
        printf("Entered.  Awaiting gesture.\n");
      }
      break;

    case GS00 : 
      if( xn < on_thresh ) {
        //////button_event(3, 1);
        printf("button pressed\n");
        GESTURE_STATE = GS1;
      }
      break;

    case GS1 : //wait for hand to leave rhs region
      if( xn < hasleft_thresh ) {
        GESTURE_STATE = GS2;
        printf("has left\n");
      }
      break;
   
    case GS2:  
      if( xn > 0.85 ) {
        /////button_event(3,0);
        GESTURE_STATE = GS0;
        printf("rentered.  button released\n");
        printf("GESTURE COMPLETED ****************************\n");
        browser_click();
      } 
      break;

    case GS3:
      if( xn < hasleft_thresh ) {
        GESTURE_STATE = GS0;
        printf("has left\n");
      }
      break;

 
    default :
      printf("?"); 
  }
  fflush(stdout);
}
