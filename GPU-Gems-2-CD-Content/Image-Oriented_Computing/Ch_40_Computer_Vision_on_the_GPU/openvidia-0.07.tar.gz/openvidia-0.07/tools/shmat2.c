/** basic connection to shared memory area. */
/* compile like "gcc -D_AS_OBJECT " to make this into an object */
#include <stdlib.h> //for system
#include <stdio.h> //fopen
#include <unistd.h>//fork
#include <sys/types.h>//fork
#include <sys/shm.h>
#include <string.h> //memcpy

//lots of useful utils for sending key events
//creating shm images etc...
//look at source for xmg - magnifying glass for X
//http://www.mit.edu/afs/athena/system/pmax_ul4/srvd.74/usr/sipb/src/xmg-0.9.1/xmg.c
//#include <X11/extensions/XTest.h>
//#include <X11/XWDFile.h>
//#include <X11/extensions/XShm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

struct framestruct {
  ///width of the frame
  int width;
  ///height of the frame
  int height;
  ///ID number for misc. use.
  int IDnum;
  ///number of channels (greyscale,color,RGBA etc)
  int channels;
  ///Current transformation parameters.
  ///This is used to transfer initial guess parameters,
  ///and then hold the state of the current estimation afterwards,
  ///as better estimates are calculated.
  double params[8];
  ///used for parallel orbits.  Server sets requeested chirps to
  ///some number which it wants to client cards to run on this 
  ///image.  Then, the client sees this, and starts running the
  ///estimations, decrementing this each time - both can see
  ///how the work is progressing.  Results are in the params 
  ///member above
  int requested_chirps;
  ///flags if this frame is being placed into Shm, and should be 
  ///considered as a new request for work
  /////bool isNew; sizeof(bool)=1
  char isNew;


  /*
   * pass skin tome information to other
   * people reading shmframe
   */
  //could use one int, TOP 16 bits are X, bottom 16 bits are Y
  int hand_x;
  int hand_y;
  int foo;
  float thresh_x;//X: skin typically H value < 0.02
  float thresh_y;//Y: skin Sat.typically 0.3->0.6 (camera dependent)
  float thresh_z;//Z: variance allowed around Sat. value
  float thresh_w;//W: maximum allowable brightness (value)
};

static   struct framestruct *Frame;

void getHandCoords(int *x, int *y)
{
  *x = Frame->hand_x;
  *y = Frame->hand_y;
  return;
}

#define IPC_INFO_FILE_NAME "/etc/modules"
//#define IPC_DATA_FILE_NAME "/bin/ls"
#define IPC_DATA_FILE_NAME "/etc/fstab"

static int getKey(int id, key_t *infokey, key_t *datakey )
{
  key_t key;

  printf("Generating Info Key based on %d\n",IPC_INFO_FILE_NAME);
  if( (key = ftok(IPC_INFO_FILE_NAME, id)) == -1 ) {
    perror("ShmFrame ftok (infokey): ");
    return 0;
  }
  printf("INFOKEY IS %d\n",key);
  *infokey = key;

  printf("Generating Data Key based on %d\n",IPC_DATA_FILE_NAME);
  if( (key = ftok(IPC_DATA_FILE_NAME, id)) == -1 ) {
    perror("ShmFrame ftok (infokey): ");
    return 0;
  }
  *datakey = key;

  return 1;
}

#ifndef _AS_OBJECT
int main(int argc, char **argv) {
#else
int shmConnect(int ipcid) {
#endif

#ifndef _AS_OBJECT
  int ipcid = atoi(argv[1]);
  if ( argc!= 2 ) {
    printf("Need to specify shared memory number (integer [0,10])\n");
  }
  ipcid = atoi(argv[1]);
#endif

  unsigned char *data; //image data
  key_t infokey, datakey;
  int infoshmid=-1, datashmid =-1;
  int memsz=-1;

//  cerr<<"getting ipcid "<<ipcid<<endl;
  printf("getting ipcid %d\n", ipcid );
  if( !getKey(ipcid, &infokey, &datakey) ) {
    printf("COUDLD NOT GET KEY\n");
    return 0;
  }
 
  printf("INFOKEY IS %d\n",infokey);
  infoshmid = shmget(infokey,sizeof(struct framestruct),0);
  if( infoshmid == -1 ) {
    printf("Could not shmget info memory, perror follows\n");
    printf("XXXXXXXXX Try running glestpchirp2m to create all the memory areas\n");
    perror("shmget: ");
    return 0;
  }
  if( (Frame = (struct framestruct *)shmat( infoshmid, NULL, 0)) == NULL ) {
    printf("framestruct error, perror follows\n");
    perror("shmat: ");
    return 0;
  }

  //assum char data
  memsz = Frame->width*Frame->height*Frame->channels;
  printf("attaching sz %d",memsz);

  //allocate image buffer
  datashmid = shmget(datakey, memsz, 0644);
  if( datashmid == -1 ) {
    perror("shmget: ");
    printf("Could not shmget data memory\n");
    return 0;
  }
  if( (data = (unsigned char *)shmat( datashmid, NULL, 0)) == NULL ) {
    perror("shmat: ");
    printf("Could not shmat data memory\n");
    return 0;
  }
  return 1;
}
