/*
 * helper functions
 */
#include <GL/glut.h> 
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include "graphicsHelpers.h"
#include <iostream> //cout

using namespace std;

void drawFingerTip(int x, int y) {
  drawFingerTip(x,y,0.0, 0.0, 1.0);
}

void drawFingerTip(int x, int y, float r, float g, float b)
{
  //  glPushMatrix();
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  //  cout<<"Finger at ("<<x<<","<<y<<")"<<endl;
  glColor4f(r,g,b,1.0);
  
  glPointSize(20.0);
  glBegin(GL_POINTS);
  glVertex3f(x/640.0, y/480.0,  -1 );
  glEnd();
  //  glPopMatrix();
}


/* coords are normalized */
void normDrawCircleHelper(float x, float y) {
  glPushMatrix();


  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  glColor4f(0.0,0.0,1.0,1.0);
  glPointSize(10.0);
  //cerr<<"X = "<<x<< "  Y="<<y<<endl;
  glClear(GL_DEPTH_BUFFER_BIT);
  glBegin(GL_POINTS);
    glVertex3f(x, y,   -1.0 );
  glEnd();

  glPopMatrix();
}


void normDrawLine(float x, float y, float x2, float y2) {
  glPushMatrix();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  glColor4f(0.0,0.0,1.0,1.0);
  glPointSize(10.0);
  //cerr<<"X = "<<x<< "  Y="<<y<<endl;
  glClear(GL_DEPTH_BUFFER_BIT);
  glBegin(GL_LINE_STRIP);
    glVertex3f(x, y,   -1.0 );
    glVertex3f(x2, y2, -1.0 );
  glEnd();

  glPopMatrix();
}


void drawBoundingBox()
{
  /*   float l,r,t,b;
   l = HAND_X_COORD/(float)imageWinWidth-BOX_WIDTH;
   r = HAND_X_COORD/(float)imageWinWidth+BOX_WIDTH;
   t = HAND_Y_COORD/(float)imageWinHeight-BOX_WIDTH;
   b = HAND_Y_COORD/(float)imageWinHeight+BOX_WIDTH;
   if( trackFingerTip ) t = HAND_Y_COORD/(float)imageWinHeight-BOX_WIDTH*2;
   float z = -1.0;

  //cerr << l << r<<t<<b<<endl;

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glClear(GL_DEPTH_BUFFER_BIT);
   glColor4f( 0.0, 1.0, 0.0, 1.0);
   glBegin(GL_LINES);
     glVertex3f( l, t, z);
     glVertex3f( r, t, z);
  
     glVertex3f( l, b, z);
     glVertex3f( r, b, z);

     glVertex3f( l, t, z);
     glVertex3f( l, b, z);

     glVertex3f( r, t, z);
     glVertex3f( r, b, z);
   glEnd();
  */
}
