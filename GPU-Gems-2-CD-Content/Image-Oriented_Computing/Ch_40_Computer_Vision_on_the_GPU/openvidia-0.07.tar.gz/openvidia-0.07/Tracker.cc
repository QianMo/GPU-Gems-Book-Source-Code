/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "Tracker.h"
#include "mapping.h"
#include <iostream>
using namespace std;

Tracker::Tracker( CGDisplay *disp, OrbitsInterface *orbiface)
{
  d=disp;
  orbits=orbiface;
  trackx = 0.5; tracky=0.5;
}

void Tracker::estpchirp()
{
  float p[16];
  static bool firsttime = true;
  float R,G,B,A;
  int i;
  //d->activate_fpbuffer();
  //d->render();
  //d->render_to_texture(2);

  for ( i=2;i<=10;i++ ) {
    if( firsttime ) cout<<"Initializing pass "<<i<<endl;
    d->render_pass(i);
   //   cout<<"pass "<<i<<": ";
      d->sumDisplay( &R, &G, &B, &A ); 
      orbits->setDER( OrbitsRGBAmap[i][0], R);
      orbits->setDER( OrbitsRGBAmap[i][1], G);
      orbits->setDER( OrbitsRGBAmap[i][2], B);
      orbits->setDER( OrbitsRGBAmap[i][3], A);
/*
    cout << "FP "<< i << "R : "<<OrbitsRGBAmap[i][0]<< " "<< R << endl;
    cout << "FP "<< i << "G : "<<OrbitsRGBAmap[i][1]<< " "<< G << endl;
    cout << "FP "<< i << "B : "<<OrbitsRGBAmap[i][2]<< " "<< B << endl;
    cout << "FP "<< i << "A : "<<OrbitsRGBAmap[i][3]<< " "<< A << endl;
*/

  }

  d->render_pass(11);
    if( firsttime ) cout<<"Initializing pass 11"<<endl;
    //cout<<"pass "<<11<<": ";
    d->sumDisplay( &R, &G, &B, &A );
    orbits->setder( 0, R);
    orbits->setder( 1, G);
    orbits->setder( 2, B);
    orbits->setder( 3, A);

  d->render_pass(12);
    //cout<<"pass "<<12<<": ";
    if( firsttime ) cout<<"Initializing pass 12"<<endl;
    d->sumDisplay( &R, &G, &B, &A );
    orbits->setder( 4, R);
    orbits->setder( 5, G);
    orbits->setder( 6, B);
    orbits->setder( 7, A);
  orbits->solve_system(d->getDownsampleLevel());

BYPASS:
  d->deactivate_fpbuffer();


  orbits->setDt(d->getDownsampleLevel(),Dt);
  orbits->setDm(d->getDownsampleLevel(),Dm);
  orbits->setDn(d->getDownsampleLevel(),Dn);
  orbits->getParameters(p);
  //d->setChirpMat(p[0], p[1], p[2], p[3], p[4],p[5],p[6],p[7]);
  //d->showstats();
  firsttime = false;
}

void Tracker::update_track( float params[8])
{  
   float x=tracky,y=trackx;
   //float x=0.5,y=0.5;
   float A_11, A_12, A_21, A_22, b_1, b_2, c_1, c_2, denom;

   A_11 = params[0];
   A_12 = params[1];
   b_1  = params[2];
   A_21 = params[3];
   A_22 = params[4];
   b_2  = params[5];
   c_1  = params[6];
   c_2  = params[7];


   denom = (c_1*x + c_2*y + 1);

   x = (A_11*x + A_12*y + b_1) / denom;
   y = (A_21*x + A_22*y + b_2) / denom;

   //cerr<<x<<","<<y<<" "<<x*320<<","<<y*240<<endl;
   tracky = x;
   trackx = y;
}

float Tracker::getTrackx() { return trackx; }
float Tracker::getTracky() { return tracky; }

void Tracker::drawCrosshairs(float x, float y, float z, float size) 
{
  glColor4f(1.0, 0.0, 0.0, 1.0); //color of crosshairs
  glBegin( GL_LINES );
    glVertex3f( x, y-size, z);
    glVertex3f( x, y+size, z);

    glVertex3f( x-size, y, z);
    glVertex3f( x+size, y, z);
  glEnd();
}

