/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "ControlStruct.h"
using namespace std;
#include <iostream>

ControlStruct::ControlStruct()
{
  shm.grabDisplay = true;
  shm.useDiagWin = true;
  shm.runPseudo = false;
  shm.useFPBuffer = true;
  shm.applyParams = false;
  dblbuffer = true;
}

void ControlStruct::set_useDiagWin() { shm.useDiagWin=true; 
  shm.grabDisplay = true; }
void ControlStruct::unset_useDiagWin() { shm.useDiagWin=false; }

void ControlStruct::set_grabDisplay() { shm.grabDisplay = true; }
void ControlStruct::unset_grabDisplay() { 
  if(shm.useDiagWin)unset_useDiagWin();
  shm.grabDisplay=false;
}

void ControlStruct::set_runPseudo() { shm.runPseudo=true; }
void ControlStruct::unset_runPseudo() { shm.runPseudo=false; }

void ControlStruct::set_useFPBuffer() { shm.useFPBuffer=true; }
void ControlStruct::unset_useFPBuffer() {
  unset_runPseudo();
  shm.useFPBuffer = false;
}

void ControlStruct::set_applyParams() { 
  shm.applyParams=true;   shm.grabDisplay=true;
}
void ControlStruct::unset_applyParams() { shm.applyParams=false; }

void ControlStruct::print() 
{
  cerr<<"Grab Display ";
  shm.grabDisplay?cerr<<"ON"<<endl:cerr<<"OFF"<<endl;

  cerr<<"Diagnostic Window ";
  shm.useDiagWin?cerr<<"ON"<<endl:cerr<<"OFF"<<endl;

  cerr<<"Projective Estimation ";
  shm.runPseudo?cerr<<"ON"<<endl:cerr<<"OFF"<<endl;

  cerr<<"Floating Point Buffer ";
  shm.useFPBuffer?cerr<<"ON"<<endl:cerr<<"OFF"<<endl;

  cerr<<"Apply Composite Params ";
  shm.applyParams?cerr<<"ON"<<endl:cerr<<"OFF"<<endl;
}

void ControlStruct::set_dblbuffer() { dblbuffer=true; }
void ControlStruct::unset_dblbuffer() { dblbuffer=false; }
