/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "ImageSender.h"
#include <sched.h>

//public constructor
ImageSender::ImageSender() {
  NUM_PCI_HEADS=1;

  //create shared memory areas, an image pair 0/1 for each head (card)
   for( int i=0; i<NUM_PCI_HEADS; i++ ) {
     heads[i][0] = new ShmFrame(i*2, 320, 240, 3, -1);
     heads[i][1] = new ShmFrame(i*2+1, 320, 240, 3, -1);
   }
}
//public constructor
ImageSender::ImageSender(int w, int h) {
  NUM_PCI_HEADS=1;

  //create shared memory areas, an image pair 0/1 for each head (card)
   for( int i=0; i<NUM_PCI_HEADS; i++ ) {
     heads[i][0] = new ShmFrame(i*2, w,h, 3, -1);
     heads[i][1] = new ShmFrame(i*2+1,w, h, 3, -1);
   }
}



//destructor XXX should free heads
ImageSender::~ImageSender() {

}


bool ImageSender::isProcessing(int GPUnum) {
  return heads[GPUnum][1]->isProcessing();
}

void ImageSender::query_client(int GPUnum, Parameters *convergedEstimate)
{
  /* cerr<<"Querying head "<<GPUnum+1<<" : "<<heads[GPUnum][1]->Frame->requested_chirps<<" chirps remain.";
  cerr<<" between images "<<heads[GPUnum][0]->Frame->IDnum<<" and ";
  cerr<<heads[GPUnum][1]->Frame->IDnum<<endl;
  cerr<<"Current Estimate: "; heads[GPUnum][1]->printParams();
  */
  //record estimate
  if( heads[GPUnum][1]->Frame->IDnum != -1 ) {
    convergedEstimate->set( heads[GPUnum][1]->Frame->params );
  }
}


void ImageSender::client_tasker(int GPUnum, int w, int h, int nch, int frameID, unsigned char *b, 
				int w2, int h2, int nch2, int frameID2, unsigned char *b2, int req_chirp, 
				Parameters current_estimate)
{
  heads[GPUnum][0]->setFrame(w,h,nch,frameID,b);
  Parameters IDP; heads[GPUnum][1]->setParams(IDP); //set identity for first frame
  heads[GPUnum][1]->setFrame(w2,h2,nch2,frameID2,b2);
  heads[GPUnum][1]->setParams(current_estimate);
  heads[GPUnum][1]->setRequestedChirps(req_chirp);

  /*cerr<<"--------------------------------- "<<endl;
  cerr<<"server sending work out to client "<<GPUnum+1<<endl;
  cerr<<"Frames "<<frameID<<" and "<<frameID2<<" , for "<<req_chirp<<" more chirps"<<endl;
  cerr<<"Current estimate ";  current_estimate.print();
  cerr<<"--------------------------------- "<<endl;*/
}


void ImageSender::sendImages(int width, int height, 
			     void* b1, void*b2, 
			     int reqChirp, Parameters initialEstimate,
			     Parameters* convergedEstimate) {
  
  int GPUnum=0;
  client_tasker(GPUnum, width,height,3,1, (unsigned char*) b1,
		width,height,3,2, (unsigned char*) b2,
		reqChirp, initialEstimate);
  
  //  convergedEstimate.set(copy);
  while(isProcessing(GPUnum)) {
    struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 500;
    select(0,0,0,0, &tv);
    //sched_yield();
    //usleep(100000);
  }
  query_client(GPUnum, convergedEstimate);
  //convergedEstimate->print();
}

