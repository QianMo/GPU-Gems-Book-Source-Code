/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "GenericDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"
#include "FragPipeDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include <iostream>
using namespace std;

// Global display object
FragPipeDisplay *d;
Dc1394 *dc1394;
ImlibCapture *im;
GenericFilter *filter1, *filter2, *filter3, *filter4;
GenericFilter *magdir, *cannysearch, *tangent, *gaussianX, *gaussianY;
GenericFilter *derandom;
MomentFilter *momentFilter;
   float cannythresh[4] = {10.0, 4.0, 4.0, 4.0};
   float derandomthresh[4] = {0.25, 0.25, 0.25, 0.25};

int imageWinWidth = 320;
int viewbuf = 0;
int imageWinHeight = 240;
Window  Orbwin;


///global state
bool useImlib = true;
float HAND_X_COORD=0.0;
float HAND_Y_COORD=0.0;




void reshape(int w, int h);
void myIdle();
void keyboard (unsigned char key, int x, int y);
void MouseFunc( int button, int state, int x, int y) ;
void drawFingerTip();
void doMoment();
void drawCircleHelper(float x, float y);
void TellRWMHeCanUseImage(const char *dma_buf_) ;

unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(320*240*3);
int framecounter=0;
int newdata=0;
float *foo[320*240*4];



void render_redirect() {
  ++framecounter;
/*
  if(!newdata)  {  struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 1000;
     select(0,0,0,0, &tv);
 return;}
  newdata = 0; 
*/
  d->activate_fpbuffer();
  d->clear_fpbuffer();
    if( useImlib )  {
      d->reinit_texture(0, 320, 240, im->getRGBData() );
    }
    else {
      d->reinit_texture(0, 320, 240, dma_buf_rgb);
    }
    d->bindTextureARB0(0);
    if (!useImlib) dc1394->tellThreadDoneWithBuffer();

    //cascade the filters
    d->applyFilter(filter1, 0,1); //texture 1 holds undistorted
    d->applyFilter(filter2, 1,2); //texture 2 holds x deriv
    d->applyFilter(filter3, 1,3); //texture 3 holds y deriv
    
    d->bindTextureARB1(3);        //place texture 3 into unit 1
    d->applyFilter(magdir, 2, 4);  //use texture 2, unit0, result to tex4
    d->applyFilter(cannysearch, 4, 5);  //tex4: magdir, tex5 search result
    //optim fodder, (could collapse canny->tangent into a single prog)
    d->applyFilter(tangent, 5, 6);  //tex
    d->applyFilter(gaussianX, 6, 7);  //tex
    d->applyFilter(gaussianY, 7, 8);  //tex

    d->bindTextureARB1(5);        //place canny edgels into texunit 1
    d->applyFilter(derandom, 8, 9);

    //doMoment();//intensive. Not GFX card efficient utilization, but it works.
  d->deactivate_fpbuffer();

  d->bindTextureARB0(viewbuf);
  d->render();
  //////drawFingerTip();

  //optioanlly read back result
  //readback from screen will be different from pbuffer, choo choo choose 
  //glReadPixels(0,0,320,240,GL_RGB,GL_FLOAT,foo); 
  d->showstats();
  glutSwapBuffers();
}  


///// MAIN ///////////////////

int main(int argc, char** argv)
{
   glutInit(&argc, argv);

   //if an argument is given, assume we are using an image file
   if( argc == 2 ) { 
     cout<<"Using image file: "<<argv[1]<<endl;
     cout<<"Note: currently, image file must be 320x240 resolution"<<endl;
     useImlib = true;
   }
   else {
     useImlib = false;
   }
   
   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);


   //typical problem : can't open imlib without display, yet cant
   // size display without loading image from imlib
   d=new FragPipeDisplay(16, imageWinWidth, imageWinHeight, Orbwin );
   d->initDisplay();

   d->setImageSize( 320,240 );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-basic.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?
   if( useImlib ) { 
     im = new ImlibCapture(0,0);
     im->initCapture(d);
     im->loadFile(argv[1]); 
     assert( im->getRGBWidth() == imageWinWidth );
     assert( im->getRGBHeight() == imageWinHeight );
   }
   else {
     dc1394=new Dc1394();
     dc1394->start();
   }


   //d->activate_fpbuffer();
   d->init_texture(0, 320, 240, foo);
   d->init_texture4f(1, 320, 240, foo);
   d->init_texture4f(2, 320, 240, foo);
   d->init_texture4f(3, 320, 240, foo);
   d->init_texture4f(4, 320, 240, foo);
   d->init_texture4f(5, 320, 240, foo);
   d->init_texture4f(6, 320, 240, foo);
   d->init_texture4f(7, 320, 240, foo);
   d->init_texture4f(8, 320, 240, foo);
   d->init_texture4f(9, 320, 240, foo);
   d->init_texture4f(10, 320, 240, foo);
   filter1 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-ibot-undistort.cg");
   filter2 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-gaussianderiv-sigma1-x.cg");
   filter3 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-gaussianderiv-sigma1-y.cg");
   magdir = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-magdir.cg");

   cannysearch = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-canny-search.cg");
   cannysearch->setCGParameter( "thresh", cannythresh);
   tangent = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-tangent.cg");
   gaussianX = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-gaussian-sigma3-x-rgb.cg");
   gaussianY = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-gaussian-sigma3-y-rgb.cg");
   derandom = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-derandom.cg");
   derandom->setCGParameter( "thresh", derandomthresh);

   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}










////////////////////
////// GLUT CALLBACKS ///////////////
////////////////////
void reshape(int w, int h)
{
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  //rosco version
  glFrustum(-1.0,1.0,-1.0,1.0,1.0,100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,-1.0,   0.0, 1.0, 0.0);

  //james version
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);

  //set the fpbuffer to have geometry identical to screen
  d->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  d->deactivate_fpbuffer();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
         viewbuf = atoi((const char * )&key);
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case 's':
         derandomthresh[0] += 0.01;
         cerr<<"derandomthresh = "<<derandomthresh[0]<<endl;
         derandom->setCGParameter( "thresh", derandomthresh);
         break;
      case 'x':
         derandomthresh[0] -= 0.01;
         cerr<<"derandomthresh = "<<derandomthresh[0]<<endl;
         derandom->setCGParameter( "thresh", derandomthresh);
         break;
      case 'a':
         cannythresh[0] += 0.1;
         cerr<<"cannythresh = "<<cannythresh[0]<<endl;
         cannysearch->setCGParameter( "thresh", cannythresh);
         break;
      case 'z':
         cannythresh[0] -= 0.1;
         cerr<<"cannythresh = "<<cannythresh[0]<<endl;
         cannysearch->setCGParameter( "thresh", cannythresh);
         break;
 
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        float pixbuf[4] = {0.0};
        cerr << "("<<x<<","<<y<<"):";
        glReadPixels( (float)x,240.0-(float)y, 1,1, GL_RGBA, GL_FLOAT,  pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
      }
      break;
    case GLUT_RIGHT_BUTTON : 
      break;
  }
}


///helper functions

void drawFingerTip()
{
  drawCircleHelper(HAND_X_COORD/320.0, HAND_Y_COORD/240.0);
}

void  doMoment()
{
    float result[4] = {0.0};
    d->applySumFilter(momentFilter, 3, 4, result );
    //cerr<<"M = ["<<result[0]<<", "<<result[1]<<", ";
    //cerr<<result[2]<<", "<<result[3];
    //cerr<<" M_x = "<<result[1]/result[0]<<", M_y = "<<result[2]/result[0]<<endl;
    HAND_X_COORD=result[1]/result[0];
    HAND_Y_COORD=result[2]/result[0];
    //cerr<<"Avg S : "<<result[3]/result[0]<<endl;
   
    //make sure that enough pixels are actually recognized as skin
    //if( result[0] < 320*240*0.05 || result[0] > 320*240*0.75 ) {
    if( result[0] > 320*240*0.75 || result[0] < 0.001*320*240) {
      //cerr<<"bad stats"<<endl;
      return;
    }
    float thresh[4] = {result[3]/result[0], result[3]/result[0], 0.008, 0.1};
    filter2->setCGParameter("thresh", thresh);
    //cerr<<"window: "<<1.5*sqrt(result[0])<<endl;
}

/* coords are normalized */
void drawCircleHelper(float x, float y) {
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glColor4f(0.0,0.0,1.0,1.0);
  glPointSize(10.0); //XXX move away.
  //cerr<<"X = "<<HAND_X_COORD<< "  Y="<<HAND_Y_COORD<<endl;
  //cerr<<"X = "<<HAND_X_COORD/320.0<< "  Y="<<HAND_Y_COORD/240.0<<endl;
  glClear(GL_DEPTH_BUFFER_BIT);
  glBegin(GL_POINTS);
  //  glVertex3f(x, y,   1.0 );
    glVertex3f(x, y,   -1.0 );
  glEnd();
}

/* Tell function executed in context of Dc1394 thread */
void TellRWMHeCanUseImage(const char *dma_buf_) {
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;

  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;
  uyvy2rgb(dma_buf,dma_buf_rgb,320*240);

  //have only one, need two before we do any orbits
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }

  newdata=1;
}

