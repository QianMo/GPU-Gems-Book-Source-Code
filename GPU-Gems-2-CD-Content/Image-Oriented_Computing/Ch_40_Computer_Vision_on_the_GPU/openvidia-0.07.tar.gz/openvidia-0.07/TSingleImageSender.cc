/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "TSingleImageSender.h"

//public constructor
TSingleImageSender::TSingleImageSender(int client_id) : SingleImageSender(client_id) {
  //nothing new to do
}


TSingleImageSender::~TSingleImageSender() {
  //nothing to do
}

void TSingleImageSender::sendImage(int width, int height, 
				   void* b1) {
  client_tasker(320,240,3,(unsigned char*) b1);
}

void TSingleImageSender::run() {
  while(1) {
    while(isProcessing()) {
      //sched_yield();
      struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 500;
      select(0,0,0,0, &tv);
      
      //  usleep(100);
    }
    query_client();
    while(!isProcessing()) {
      usleep(1000);
    }
  }
}

