/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _PROJPLANE_H
#define _PROJPLANE_H

#include "Parameters.h"
#include "FragmentProgram.h"

#include <glh/glh_extensions.h>
#include <GL/gl.h>
#include <Cg/cgGL.h>

#define NAME_LEN 128

class ProjPlane {
    int width, height; //texture size
    FragmentProgram *FPpassthru;
    int texNum;
    char planeName[NAME_LEN];
    
  public:
    Parameters P, P_pairwise;
    
   
    ProjPlane(int, int, CGcontext, CGprofile);
    ProjPlane(int, int, FragmentProgram *);
    ProjPlane(int, int, float *p, CGcontext, CGprofile);
    ProjPlane(int, int, float *p, FragmentProgram *);
    void draw(bool);    
    void clear();
    void setTexNum(int x) { texNum = x; }
    int  getTexNum() { return texNum; }
    void setPlaneName(char *); //typically source image name (if from file)
    char *getPlaneName();
};

#endif
