/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "SingleImageSender.h"
#include <sched.h>

/*
 * *2 -2 to map client id to shmid
 */

//public constructor
SingleImageSender::SingleImageSender(int client_id) {
  //XXX LOCK TO 3
  //create shared memory areas, an image pair 0/1 for each head (card)
  m_DEBUG=false;

  int ipcid=client_id*2-2;
  int width=320;
  int height=240;
  int nchan=3;
  int ID=-1;
  
  head = new ShmFrame(ipcid, width, height, nchan, ID);
}

//destructor XXX should free heads
SingleImageSender::~SingleImageSender() {
}


bool SingleImageSender::isProcessing() {
  return head->isProcessing();
}

/********************
 * Get the result. XXX Does nothing for now
 ********************/
void SingleImageSender::query_client() 
{
  /* cerr<<"Querying head "<<GPUnum+1<<" : "<<heads[GPUnum][1]->Frame->requested_chirps<<" chirps remain.";
  cerr<<" between images "<<heads[GPUnum][0]->Frame->IDnum<<" and ";
  cerr<<heads[GPUnum][1]->Frame->IDnum<<endl;
  cerr<<"Current Estimate: "; heads[GPUnum][1]->printParams();
  */
  //record estimate
  if( head->Frame->IDnum != -1 ) {
    //XXX DO NOTHING convergedEstimate->set( heads[GPUnum][1]->Frame->params );
  }
}


void SingleImageSender::client_tasker(int w, int h, int nch, unsigned char *b)
{
  int frameID=1;
  //set frame should set the flag to new frame
  head->setFrame(w,h,nch,frameID,b);
  //trigger the workers
  head->setRequestedChirps(1);

  if(m_DEBUG) {
    cerr<<"--------------------------------- "<<endl;
    cerr<<"server sending work out to client errrr.. XXX 3"<<endl;
    cerr<<"Frames "<<frameID<<endl;
    cerr<<"--------------------------------- "<<endl;
  }
}


void SingleImageSender::sendImage(int width, int height, 
				  void* b1)
{
  
  client_tasker(320,240,3,(unsigned char*) b1);
  
  //  convergedEstimate.set(copy);
  while(isProcessing()) {
    //sched_yield();
    struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 500;
    select(0,0,0,0, &tv);
    
    //  usleep(100);
  }
  query_client();

}

