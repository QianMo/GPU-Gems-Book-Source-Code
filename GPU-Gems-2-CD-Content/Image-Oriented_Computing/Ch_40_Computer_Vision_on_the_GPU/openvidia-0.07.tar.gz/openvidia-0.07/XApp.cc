/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "XApp.h"
#include <glh/glh_extensions.h> // for nv extensions, rectangular textures.

#include <stdlib.h> //for system
#include <stdio.h> //fopen
#include <unistd.h>//fork
#include <iostream> //cout? 
#include <sys/types.h>//fork
#include <sys/shm.h>
#include <string.h> //memcpy
#include <math.h>
#include <assert.h>

//lots of useful utils for sending key events
//creating shm images etc...
//look at source for xmg - magnifying glass for X
//http://www.mit.edu/afs/athena/system/pmax_ul4/srvd.74/usr/sipb/src/xmg-0.9.1/xmg.c
#include <X11/extensions/XTest.h>
#include <X11/XWDFile.h>
#include <X11/extensions/XShm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
// The following header
//http://www.dcs.ed.ac.uk/home/mxr/gfx/2d/XWD.txt
//or File /usr/X11R6/include/X11/XWDFile.h
// has strucrts to manipulate XWD.
using namespace std;

/*
 * Default constructor
 */ 
XApp::XApp() 
 {
   exit(-1);
 }

XApp::XApp(char *fname_) {
  fname=fname_;

  /* XXX want to call default constructor here - dunno how */
  UNIQUEID=next_unique_id();
  x=y=0;
  width=640;
  height=480;
  m_usealpha=false;
  alpha=128;
 

  needsInitialization=true;
  int bpp;
  if(m_usealpha) {
    bpp=4;
  } else {
    bpp=3;
  }
  storage = (unsigned char*) malloc( width*height*4 );
}

/*
 * not in constructor coz of all system calls, but maybe c++ doesnt care
 */
void XApp::initShmem() {
  char cmdstr[1024];
  char uniquefilename[1024];
  
  sprintf(uniquefilename,"xvfbshmem%d.tmp",UNIQUEID);
  
  //Xvfb :2 -screen 0 320x240x8 -ac -fbdir /r/curr/fb-dir/
  //use 640x480, decimate horiz by 2, again
  // IF FILE EXISTS USE IT TO ATTACH, OTHERWISE, CREATE IT 
  int result;
  result = access ( uniquefilename, F_OK );
    
  if(result==0) {
  //if(false) {
    //file exists already
    cerr<<"File already exists"<<endl;
  } else {
    /*
     * Want to Launch it in different processe so persists when parent die
     * but it keeps handle to video1394
     */
      sprintf(cmdstr, "Xvfb :%d -screen 0 640x480x24 -ac -shmem 2>%s &",
	      UNIQUEID, uniquefilename);
      cerr <<"executing "<<cmdstr<<"..."<<endl;
      system(cmdstr);
      sleep(1);//wait for xvfb
      //Some need --display some need -display ???
      //mozilla-firefox -display
      char displayString[64];
      if(strcmp(fname, "mozilla-firefox")==0 || strncmp(fname, "mozilla", 7)==0 ) {
	sprintf(displayString, "--display");
      } else {
	sprintf(displayString, "-display");
      }
      char geomString[64];
      if(strcmp(fname, "aterm")==0) {
	//sprintf(geomString, "-geometry 110x40+0+0");
	sprintf(geomString, "110x40+0+0");
      } else {
	// geom has no effect on mozilla
	//sprintf(geomString, "-geometry %dx%d+0+0", width, height);
	sprintf(geomString, "%dx%d+0+0", width, height);
      }
/*
      sprintf(cmdstr, "%s %s :%d.0 %s &", fname, 
              displayString, UNIQUEID, geomString);
      system(cmdstr);
*/


      char idstr[100]; 
     
      if(strcmp(fname, "mozilla-firefox")==0) {
      cerr<<"Special mozilla-firefox case:";
      sprintf(cmdstr, "./delaymoz.sh&");
      cerr<<cmdstr<<endl;
      system(cmdstr);
      } else if( fork() == 0 ) {
        sprintf(idstr, ":%d", UNIQUEID);
        cerr<<"Running "<<fname<<" "<<displayString<<" ";
        cerr<<idstr<<" "<<"-geometry"<<" "<<geomString<<endl;
        execlp(fname, fname,displayString,idstr,"-geometry",geomString, NULL);
        perror("ERROR EXECUTING LAUNCHER PROGRAM: ");
        exit(-1);
      }
       


      //system("xview /r/curr/IMAGES/box.pnm -display :2.0&");
      //system("mozilla-firefox --display :2.0&");
  }


  //output is of the form screen 2 shmid 3899424
  FILE *f=fopen(uniquefilename, "r");
  if(f==NULL) {
    cerr<<"Could not open temp shmemid file. Exiting..."<<endl;
    exit(-1);
  }
  
  char buf1[64];
  char buf2[64];
  int screenidTmp, shmidTmp;
  fscanf(f, "%s %d %s %d", buf1, buf2, &screenidTmp, &shmidTmp);
  cout <<"UNIQUEID="<<UNIQUEID<<", SHMID XVFB=="<<shmidTmp<<endl;

  if(shmidTmp <= 0) {
    cerr<<"Unable to connect to that shmid.  Check the tmp file for error messages from x servers"<<endl;
    exit(-1);
  }
  m_shmatid=shmidTmp;
  fclose(f);
}

XApp::~XApp() {
  //do nothing
}

void XApp::fillInRGB(unsigned char *storage, unsigned char* shim) {
  if(m_shmatid<1){
    cerr<<"Please call initshmem first"<<endl;
    exit(-1);
  }
  if(storage==0 || shim==0) {
    cerr<<"UH OH, storage or shim are null pointers"<<endl;
    exit(-1);
  }


  unsigned char* p=shim;
  
  //The following tries to get a header.
  //I determined none exists in SHMEM
  //XWDFileHeader *header=(XWDFileHeader *)p;
  //p+=sizeof(XWDFileHeader);
  //CARD32 rosco=header->pixmap_depth;
  //cout<<"rosco="<<(int)rosco<<endl;
  p+=167*4; //skip some header.
  int line=0;

  for(int i=0;i<width*height;i++) {
    //tracking a weird segfault

    if(i >= 305920) {
      break;
    }

    //only goes to i=188
    //    continue;
    if(i%640==0) {
      // check if the coming up line is black
      // skip all black lines
      while(true) {
	int sum=0;
	for(int j=0;j<20*4;j++) {
	  sum+=*(p+4*j+0);
	  sum+=*(p+4*j+1);
	  sum+=*(p+4*j+2);
	  //4th bit is padding
	}
	if(sum<3000) {
	  p+=(320*4*2);//a black line
	} else {
	  break;
	}
      }

    }

    *storage++=*p++;
    *storage++=*p++;
    *storage++=*p++;
    if(m_usealpha) {
      *storage++=(unsigned char)alpha;
    }

    *p++;
  }
}



// this will do a bunch of GL calls.
void XApp::render() { 
  preRender();
  if(needsInitialization) { 
    glGenTextures(1,&imgTex);
    shim=(unsigned char*)shmat(m_shmatid, NULL, SHM_RDONLY);
    if(shim<=0) {
      cerr<<"shm failed. address is "<<(int)shim<<endl;
      exit(-1);
    }
    needsInitialization=false;
    cerr<<"attached xvfb shared memory area "<<m_shmatid<<endl; 
  }
  //  memcpy(storage, data, size);
  fillInRGB((unsigned char*)storage, (unsigned char*)shim);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, imgTex);

  GLenum pixelformat;
  if(m_usealpha) {
    pixelformat=GL_RGBA;
  } else {
    pixelformat=GL_RGB;
  }
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGBA,
  	       width,
  	       height,
	       0, pixelformat, GL_UNSIGNED_BYTE, (const GLvoid *)(storage));
  


  //DONT FREE STORAGE  free(storage);
  glEnable(GL_TEXTURE_RECTANGLE_NV);

  //glAlphaFunc(GL_GEQUAL, 0.625);
  //makes it blank
  //glEnable(GL_ALPHA_TEST);
  
  glEnable(GL_BLEND);// blend with what is in target buffer
  glBlendFunc(GL_SRC_ALPHA, GL_SRC_ALPHA);
  glClear(GL_DEPTH_BUFFER_BIT); //essential?

  //  glDisable(GL_BLEND);
  // WEIRD - if i remove line below screen draws red!
  glColor4f(1.0, 1.0, 1.0, 0.5);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, imgTex);
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);  glVertex3f(0.0, 0.0, 1.0);
  glTexCoord2f((float)width,0);  glVertex3f(1.0, 0.0, 1.0);
  glTexCoord2f((float)width,(float)height);  glVertex3f(1.0, 1.0, 1.0);
  glTexCoord2f(0,(float)height);  glVertex3f(0.0, 1.0, 1.0);
  glEnd();

  glDisable(GL_BLEND);
  glDisable(GL_ALPHA_TEST);
  
  glDisable(GL_TEXTURE_RECTANGLE_NV);


  postRender();
}



/*
 * Refer to header for explanation
 * next available x server
 */
int XAPP_NEXTID=2;
