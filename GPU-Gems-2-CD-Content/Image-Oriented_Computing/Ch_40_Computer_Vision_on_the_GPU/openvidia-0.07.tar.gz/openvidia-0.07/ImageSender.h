/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _IMAGESENDER_H
#define _IMAGESENDER_H

// includes
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include <getopt.h>
#include <assert.h>

#include "GenericCapture.h"
#include "Dc1394Capture.h"
#include "Raw1394Capture.h"
#include "ImlibCapture.h"
#include "Parameters.h"
#include "ShmFrame.h"
#include <iostream>
#include <iomanip>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/shape.h>
using namespace std;

// Give komputer 2 pics
// 
class ImageSender {
 protected:
  int NUM_PCI_HEADS;
  ShmFrame *heads[5][2];

  // returns true if this image sender is waiting for shmframe to finish
  bool isProcessing(int GPUnum);
  
  // returns -1 if the client is not ready
  void query_client(int GPUnum, Parameters* convergedParameter);
  
  void client_tasker(int GPUnum,int w, int h, int nch, int frameID, unsigned char *b, 
		     int w2, int h2, int nch2, int frameID2, unsigned char *b2, int req_chirp, 
		     Parameters current_estimate);
  

 public:
  ImageSender();
  ///optionally, specify image w,h to create proper sized shm buffers
  ImageSender(int width, int height); 
  ~ImageSender();
  // for now initial estimate is ignored
  void sendImages(int width, int height, 
		  void* b1, void*b2, 
		  int reqChirp, Parameters initialEstimate,
		  Parameters *convergedEstimate);
  
};

#endif
