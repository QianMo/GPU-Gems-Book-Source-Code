/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

       #include <sys/time.h>
       #include <sys/resource.h>
#include <sched.h>


#include "GenericDisplay.h"
#include "MultitextureDisplay.h"
#include "EigenDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "ImlibCapture.h"
#include "Dc1394Capture.h"
#include "Raw1394Capture.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "Udat.h"
#include <iostream>
using namespace std;

// Global display object
//GenericDisplay *d;
EigenDisplay *d;
Udat *gc;
ImlibCapture *image_loader;
Grab_JPEG *grabber;
int use_cg=1;

#define BUFSZ_W 640
#define BUFSZ_H 480
//int imageWinWidth = 320;
//int imageWinHeight =240;
int imageWinWidth = 640;
int imageWinHeight =480;
//int cols = 30;
int cols = 1;
int rows = 1;

int W = imageWinWidth;
int H = imageWinHeight;

Window  Orbwin;
static unsigned char whitebuf[BUFSZ_W*BUFSZ_H*3] = {255};
static unsigned char gradbuf[BUFSZ_W*BUFSZ_H*3] = {255};
static unsigned char redbuf[BUFSZ_W*BUFSZ_H*3] = {255};
static unsigned char greenbuf[BUFSZ_W*BUFSZ_H*3] = {255};
static unsigned char bluebuf[BUFSZ_W*BUFSZ_H*3] = {255};


////// UTILITY FUNCTION //////////////
void buffer_sample_float4(float sample[4], float *thebuffer,
                          int X, int Y,
                          int xSize, int ySize, int nchans )
{
  int i=0;
  for( i=0 ; i<nchans; i++ ) {
      sample[i] = thebuffer[Y*xSize*nchans+X*nchans+i];
  }
}

void setshape(int w, int h) 
{
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}
////// GLUT CALLBACKS ///////////////
void reshape(int w, int h)
{
  glutSetWindow(Orbwin);
  setshape(w,h);

  //set up FP buffer geometry
  ((MultitextureDisplay *)d)->activate_fpbuffer();
  setshape(imageWinWidth,imageWinHeight);
  ((MultitextureDisplay *)d)->deactivate_fpbuffer();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}


static struct timeval start_time, end_time;

// coz i cant pass member funtion to glutDisplayFunc
/*
 *  Load new images, then call Display object render functions
 */ 
void render_redirect() {
  static int t;
  static bool firstpass = true;
/*
  gc->advanceFrame(); 
  d->init_texture(0, gc->getRGBWidth(), gc->getRGBHeight(),3,
           gc->getRGBData());
  gc->releaseCap();
*/
 gettimeofday(&start_time,NULL);
 d->checkTextureResidency(15);
 ((MultitextureDisplay *)d)->activate_fpbuffer();
 //d->bindTexture(0,1,2,3,4);
 d->render(); 
glFinish();
   //d->bindTexture(0,7,8,9,10);
 //d->render();
 //  d->bindTexture(0,11,12,13,14);
 //d->render();
 ((MultitextureDisplay *)d)->deactivate_fpbuffer();

 gettimeofday(&end_time,NULL);
 t = (end_time.tv_sec*1000000+end_time.tv_usec)-
                (start_time.tv_sec*1000000+start_time.tv_usec);
 cout<< t <<endl;

/*
 if( firstpass ) { firstpass= false; return; }
 else d->showstats(t);
*/
}  


///Eigen Utility function.  Loads in eigen images into textures.
void load_eigen_images(int start_texture, int num) {
   //unsigned char *mem;
   float *memf;
   for( int i=0; i<num ; i++ ) {
     memf  = (float *)gc->getColumnData_1f(2);
     // for render-to-texture from float buffer, make sure
     // the initial textures are FLOAT as well. otherwise SLOOOOW
     d->init_texture4f(start_texture+i, 
                      320/4, 240,  memf);
     free(memf);
     //gc->advanceFrame(1);
   }
}

///pack num images into texture tex
void pack_eigen_images(
    int num,          ///of of texs to pack
    int texw,         ///input texture width
    int texh,         ///input texture height
    float *buffer,    ///target buffer
    int bufw,         ///buffer width
    int bufh)         ///buffer height
{
  float *memf;
  for( int i=0; i<num ; i++ ) {
    memf = (float *)gc->getColumnData_1f(0);
    int xoffset = texw*i; ///offset into buffer (so columsn are correct)
    for( int k=0; k<texh ; k++ ) { //for all rows
      for( int j=0; j<texw ; j++ ) {
        //buffer[bufw*k+xoffset+j] = memf[k*texw+j] ;
        buffer[bufw*k+xoffset+j] = i ; //testing line
      }
    }
    free(memf);  
    //gc->advanceFrame(1);
  }
}

void initVBB( float *VBB, int w, int h, int cols ) 
{
  int pos=0;
  for (int j=0 ; j<h ; j++ ) {
    for( int i=0 ; i<w*cols ; i++ ) {
      VBB[pos] = 1;
      pos++;
    }
  }
}

///// MAIN ///////////////////

int main(int argc, char** argv)
{
/*
   struct sched_param *p;
   sched_getparam(0 , p);
   p->sched_priority = 1;
   sched_setparam(0 , p);
   sched_setscheduler(0, SCHED_RR, p);
*/
   setpriority(PRIO_PROCESS, 0, -11 );
   for( int i=0 ; i<BUFSZ_W*BUFSZ_H; i++ ) gradbuf[i]=1;
   float *VBB1 = (float *)malloc(cols*rows*imageWinWidth*imageWinHeight*
                                 sizeof(float));
   float *VBB2 = (float *)malloc(cols*rows*imageWinWidth*imageWinHeight*
                                 sizeof(float));
   float *VBB3 = (float *)malloc(cols*rows*imageWinWidth*imageWinHeight*
                                 sizeof(float));
   float *gradbuf4f = (float *)malloc(sizeof(float)*W*H*4);
   float *Abuf = (float *)malloc(sizeof(float)*W*H);
   float *Bbuf = (float *)malloc(sizeof(float)*W*H);
   float *Cbuf = (float *)malloc(sizeof(float)*W*H);
   float *Dbuf = (float *)malloc(sizeof(float)*W*H);
   float *Ebuf = (float *)malloc(sizeof(float)*W*H);
   float *Fbuf = (float *)malloc(sizeof(float)*W*H);
   float *Gbuf = (float *)malloc(sizeof(float)*W*H);
   float *Hbuf = (float *)malloc(sizeof(float)*W*H);
   float *gradbuf4f_2 = (float *)malloc(sizeof(float)*W*H*4);
   float *gradbuf4f_3 = (float *)malloc(sizeof(float)*W*H*4);
   float *pckbuf = (float *)malloc(sizeof(float)*4*W/4*H);
   int count = 0;
   for( int j=0 ; j<H ; j++ ) { 
     for( int i=0 ; i<W; i++ ) { 
       gradbuf4f[(i+j*W)*4] = (float)i;
       gradbuf4f[(i+j*W)*4+1]=(float)j;
       gradbuf4f[(i+j*W)*4+2]=(float)i*4+2;
       gradbuf4f[(i+j*W)*4+3]=(float)i*4+3;
       gradbuf4f_2[(i+j*W)*4]=  count++;
       gradbuf4f_2[(i+j*W)*4+1]=count++;
       gradbuf4f_2[(i+j*W)*4+2]=count++;
       gradbuf4f_2[(i+j*W)*4+3]=count++;
       gradbuf4f_3[(i+j*W)*4]  =1;
       gradbuf4f_3[(i+j*W)*4+1]=1;
       gradbuf4f_3[(i+j*W)*4+2]=1;
       gradbuf4f_3[(i+j*W)*4+3]=1;
       Abuf[i+j*W] = 2;
       Bbuf[i+j*W] = 3;
       Cbuf[i+j*W] = 4;
       Dbuf[i+j*W] = 5;

       Ebuf[i+j*W] = 6;
       Fbuf[i+j*W] = 7;
       Gbuf[i+j*W] = 8;
       Hbuf[i+j*W] = 9;
       
     }     
   }
   for( int i=0 ; i<BUFSZ_W*BUFSZ_H*3; i++ )whitebuf[i]=255;
   for( int i=0 ; i<BUFSZ_W*BUFSZ_H*3; i++ )if(i%3==0)redbuf[i]=255;else redbuf[i]=0;
   for( int i=0 ; i<BUFSZ_W*BUFSZ_H*3; i++ )if((i+2)%3==0)greenbuf[i]=255;else greenbuf[i]=0;
   for( int i=0 ; i<BUFSZ_W*BUFSZ_H*3; i++ )if((i+1)%3==0)bluebuf[i]=255;else bluebuf[i]=0;
   glutInit(&argc, argv);
   cout <<"Creating Double Buffered Window" << endl;
   //glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
   //glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowSize(5,5);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);

   grabber = new Grab_JPEG();

   d=new EigenDisplay(64, imageWinWidth, imageWinHeight, Orbwin );
   //gc = new Udat(NULL);
   image_loader = new ImlibCapture();

   d->initDisplay();
   //gc->initCapture(d);
   image_loader->initCapture(d);
   d->setImageSize( W, H );
   //d->setChirpMat( 1.0, 0.00,   0.00, 0.00, 1.0,  0.00, 0.00, 0.0); 
   ((MultitextureDisplay *)d)->initGL("FPeigen/FP-projection.cg");
   d->init_FP_summation("FPeigen/FP-summation.cg", "FPeigen/FP-sum2.cg");
   d->setDownsampleLevel(0);


   d->init_texture4f(0, W/4,H, gradbuf4f_3);
   d->init_texture4f(1, W/4,H, gradbuf4f);
   d->init_texture4f(2, W/4,H, gradbuf4f_2);
   d->init_texture4f(3, W/4,H, gradbuf4f_2);
   d->init_texture4f(4, W/4,H, gradbuf4f_3);

   d->init_texture4f(5, 160,480, gradbuf4f);
   d->init_texture4f(6, 80,3, gradbuf4f_3);

   d->init_texture4f(7, W/4,H, Abuf);
   d->init_texture4f(8, W/4,H, Bbuf);
   d->init_texture4f(9, W/4,H, Cbuf);
   d->init_texture4f(10, W/4,H,Dbuf);

   d->init_texture4f(11, W/4,H, Ebuf);
   d->init_texture4f(12, W/4,H, Fbuf);
   d->init_texture4f(13, W/4,H, Gbuf);
   d->init_texture4f(14, W/4,H,Hbuf);

  ((MultitextureDisplay *)d)->activate_fpbuffer();
   //d->bindTexture(0,1,2,3,4);
   d->bindTexture(0,7,8,9,10);
  ((MultitextureDisplay *)d)->deactivate_fpbuffer();
   //d->bindTexture(0,1,2,3,4);
   d->bindTexture(0,7,8,9,10);
   d->makeDisplayList(W/4,H);
  
  free(VBB1);
  free(VBB2);
  free(VBB3);
  free(gradbuf4f);
  free(gradbuf4f_2);
  free(gradbuf4f_3);
  free(Abuf); free(Bbuf); free(Cbuf); free(Dbuf);
   d->checkTextureResidency(6);
   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMainLoop();
   return 0; 
}
