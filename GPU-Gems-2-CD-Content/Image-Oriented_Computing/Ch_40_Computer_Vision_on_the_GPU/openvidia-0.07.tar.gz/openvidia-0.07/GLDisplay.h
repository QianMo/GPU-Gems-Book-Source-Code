/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _GLDISPLAY_H
#define _GLDISPLAY_H

#include "GenericDisplay.h"
#include <GL/gl.h>

class GLDisplay : public GenericDisplay 
{
 public:
  GLuint *texNames;
  
  GLDisplay(int win);
  ~GLDisplay() {};

  // implement the interface
  void initGL();
  void init_texture(int id, int width, int height, void *data);
  void bindTextures();
  void idleFunc();
  void render();
  void grabDisplay( float *Dm, float *Dn, float *Dt);
  void grabDisplay( unsigned char *Dm, unsigned char *Dn, unsigned char *Dt);
  void showstats(void);
};

#endif

