/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "GenericDisplay.h"
#include "CGDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "ImlibCapture.h"
#include "Dc1394Capture.h"
#include "OrbitsInterface.h"
#include "GlutSubWindow.h"
#include "ControlStruct.h"
#include <iostream>
using namespace std;


//TODO add rendering string
//TODO add capture device string

#define DELAY 55000

// Global display object
GenericDisplay *d;
GenericCapture *gc;
OrbitsInterface *orbits_engine;
int use_cg=1;

int imageWinWidth = 320;
int imageWinHeight = 240;
float Dn[320*240];
float Dm[320*240];
float Dt[320*240];
float Da[320*240];

Window  Orbwin;
GlutSubWindow  *DmWin;
ControlStruct cs;


////// FWD DECLARATIONS ////////////
void DmWinDisplay() ;


////// UTILITY FUNCTION //////////////

void buffer_sample_float4(float sample[4], float *thebuffer,
                          int X, int Y,
                          int xSize, int ySize, int nchans )
{
  int i=0;
  for( i=0 ; i<nchans; i++ ) {
      sample[i] = thebuffer[Y*xSize*nchans+X*nchans+i];
  }
}

////// GLUT CALLBACKS ///////////////

void reshape(int w, int h)
{
  glutSetWindow(Orbwin);
  ((CGDisplay *)d)->activate_fpbuffer();
  glClearColor (0.0, 0.0, 1.0, 1.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
//  d->setChirpMat( 1.0, 0.00, 0.0, 0.00, 1.0, 0.0,0.00,0.0); 
 // glMultMatrixf( d->getChirpMat() );
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
  ((CGDisplay *)d)->deactivate_fpbuffer();
  glClearColor (0.0, 0.0, 1.0, 1.0);
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case '0' : 
      case '1' : 
      case '2' : 
      case '3' : 
      case '4' : 
      case '5' : 
      case '6' : 
      case '7' : 
         if( atoi((const char *)&key)>orbits_engine->getMaxDownsample_levels())
         {
           d->setDownsampleLevel(orbits_engine->getMaxDownsample_levels());
         } 
         else {
           d->setDownsampleLevel(atoi((const char *)&key));
         }
         break;
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

// coz i cant pass member funtion to glutDisplayFunc
/*
 *  Load new images, then call Display object render functions
 */ 
void render_redirect() {
  glutSetWindow(Orbwin);
  if(cs.useFPBuffer) ((CGDisplay *)d)->activate_fpbuffer();
  //TODO: only call 1 init_texture() 
  gc->advanceFrame();
  d->init_texture(1, gc->getRGBWidth(), gc->getRGBHeight(),
           gc->getRGBData());
  d->init_texture(0, gc->getRGBWidth(), gc->getRGBHeight(),
           gc->getRGBDataPreviousFrame());

  float p[16];
  
  //((CGDisplay *)d)->printChirpMat();
  d->render();
  //glutSwapBuffers();
  float sum=1;
  if( cs.grabDisplay ) d->grabDisplay(Dt, Dn, Dm, Da,d->getDownsampleLevel());

  //d->showstats(); return;
  //for( int i=0; i<imageWinWidth*imageWinHeight ; i++ ) { sum+=Dt[i]; }

  //d->render_to_texture(2);

  if(cs.useFPBuffer) ((CGDisplay *)d)->deactivate_fpbuffer();
  d->render_pass(2);
  d->render_pass(3);
/*
  float sample[4];
  buffer_sample_float4(sample,Dt,20,200, imageWinWidth-1, imageWinHeight-1, 1);
  cerr << "sum = " << sum << ", Dt[20][200] = " << sample[0] << endl;
  buffer_sample_float4(sample,Dt,300,20, imageWinWidth-1, imageWinHeight-1, 1);
  cerr << "sum = " << sum << ", Dt[300][20] = " << sample[0] << endl; 

  buffer_sample_float4(sample,Da,20,200, imageWinWidth-1, imageWinHeight-1, 1);
  cerr << "sum = " << sum << ", Da[20][200] = " << sample[0] << endl;
  buffer_sample_float4(sample,Da,300,20, imageWinWidth-1, imageWinHeight-1, 1);
  cerr << "sum = " << sum << ", Da[300][20] = " << sample[0] << endl; 
*/
  if(cs.useDiagWin) DmWinDisplay();
  orbits_engine->setDt(d->getDownsampleLevel(),Dt);
  orbits_engine->setDm(d->getDownsampleLevel(),Dm);
  orbits_engine->setDn(d->getDownsampleLevel(),Dn);
  if( sum == 0 )  return;
  if(cs.runPseudo) orbits_engine->pseudo_estimate(d->getDownsampleLevel());
  orbits_engine->getParameters(p);
  if(cs.applyParams)d->setChirpMat(p[0], p[1], p[2], p[3], p[4],p[5],p[6],p[7]);
  d->showstats();
}  

void DmWinDisplay() 
{
  int readX, readY;
  readX = (int)(imageWinWidth/(pow(2.0,(double)d->getDownsampleLevel()))-1);
  readY = (int)(imageWinHeight/(pow(2.0,(double)d->getDownsampleLevel()))-1) ;
  DmWin->GlutSubWindowSetCurrent();
  if( d->getDownsampleLevel() != 0 ) {
   glClearColor (0.0, 0.0, 1.0, 1.0);
   glClear(GL_COLOR_BUFFER_BIT );
  }
  //glDrawPixels( (imageWinWidth-1), (imageWinHeight-1),
  //              GL_LUMINANCE, GL_FLOAT, Dt );
  glDrawPixels( (readX), (readY),
                GL_LUMINANCE, GL_FLOAT, Dt );
  glutSetWindow(Orbwin);
}



///// MAIN ///////////////////

int main(int argc, char** argv)
{
   cs.print();
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
  // glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);

   if (use_cg) {
     d=new CGDisplay(3, imageWinWidth, imageWinHeight, Orbwin );
   } else {
     d=new GLDisplay(Orbwin);
   }
   //gc=new ImlibCapture();
   gc=new Dc1394Capture();
   d->initDisplay();
   gc->initCapture(d);
   gc->advanceFrame();
   d->setImageSize( gc->getRGBWidth(), gc->getRGBHeight() );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 

   d->initGL();
   d->init_texture(0, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   if(use_cg) {
	   gc->advanceFrame();
	   d->init_texture(1, gc->getRGBWidth(), gc->getRGBHeight(),
			                         gc->getRGBData());
   }
   d->init_texture4f(2, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   //d->init_texture(2, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   d->bindTextures();

   //orbits
   orbits_engine =new OrbitsInterface( 3, imageWinHeight, imageWinWidth );

   DmWin=new GlutSubWindow(Orbwin, 600, 0, imageWinWidth-1, imageWinHeight-1 );
   glutDisplayFunc(DmWinDisplay);
   glutIdleFunc(DmWinDisplay);

   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);

   glutMainLoop();
   return 0; 

}
