/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "GenericDisplay.h"
#include "EigenDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "ImlibCapture.h"
#include "Dc1394Capture.h"
#include "Raw1394Capture.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "Udat.h"
#include <iostream>
using namespace std;

// Global display object
//GenericDisplay *d;
EigenDisplay *d;
Udat *gc;
ImlibCapture *image_loader;
Grab_JPEG *grabber;
int use_cg=1;

int imageWinWidth = 320;
int imageWinHeight = 240;

Window  Orbwin;
static unsigned char whitebuf[320*240*3] = {255};
static unsigned char gradbuf[320*240*3] = {255};
static unsigned char redbuf[320*240*3] = {255};
static unsigned char greenbuf[320*240*3] = {255};
static unsigned char bluebuf[320*240*3] = {255};

////// UTILITY FUNCTION //////////////
void buffer_sample_float4(float sample[4], float *thebuffer,
                          int X, int Y,
                          int xSize, int ySize, int nchans )
{
  int i=0;
  for( i=0 ; i<nchans; i++ ) {
      sample[i] = thebuffer[Y*xSize*nchans+X*nchans+i];
  }
}

////// GLUT CALLBACKS ///////////////

void reshape(int w, int h)
{
  //set up FP buffer geometry
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}


void myIdle(){
}

void keyboard (unsigned char key, int x, int y)
{
   switch (key) {
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}


/*
 *  Load new images, then call Display object render functions
 */ 
void render_redirect() {
/*
  gc->advanceFrame(); 
  d->init_texture(0, gc->getRGBWidth(), gc->getRGBHeight(),3,
           gc->getRGBData());
  gc->releaseCap();
*/
  d->bindTextures(); //necessary otherwise dont get anything th float_buffer
  d->render();
  d->quarter_quad(16, 320,240);
  d->render_quartered();
  d->render_quartered(); //take a peek

 d->showstats();
}  


///Eigen Utility function.  Loads in eigen images into textures.
void load_eigen_images(int num) {
   unsigned char *mem;
   for( int i=0; i<num ; i++ ) {
     cerr<<"i ="<<i<<endl;
     gc->advanceFrame(4);
     mem  = (unsigned char *)gc->getRGBAData();
     // for render-to-texture from float buffer, make sure
     // the initial textures are FLOAT as well. otherwise SLOOOOW
     d->init_texture4f(i, gc->getRGBWidth(), gc->getRGBHeight(),  mem);
     free(mem);
   }
}

///// MAIN ///////////////////

int main(int argc, char** argv)
{
/*
   for( int i=0 ; i<320*240*3; i++ ) gradbuf[i]=i/(320*3);
   for( int i=0 ; i<320*240*3; i++ ) whitebuf[i]=255;
   for( int i=0 ; i<320*240*3; i++ ) if(i%3==0)redbuf[i]=255;else redbuf[i]=0;
   for( int i=0 ; i<320*240*3; i++ ) if((i+2)%3==0)greenbuf[i]=255;else greenbuf[i]=0;
   for( int i=0 ; i<320*240*3; i++ ) if((i+1)%3==0)bluebuf[i]=255;else bluebuf[i]=0;
*/
   glutInit(&argc, argv);

   cout <<"Creating Double Buffered Window" << endl;
   grabber = new Grab_JPEG();

   d=new EigenDisplay(64, imageWinWidth, imageWinHeight, -1 );
   ((MultitextureDisplay *)d)->activate_fpbuffer();
   gc = new Udat(NULL);
   cerr<<"made udat"<<endl;
//   image_loader = new ImlibCapture();

//   d->initDisplay();
   gc->initCapture(d);
   //image_loader->initCapture(d);
   gc->advanceFrame();
   d->setImageSize( gc->getRGBWidth(), gc->getRGBHeight() );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   ((MultitextureDisplay *)d)->initGL("FPeigen/FP-sum.cg");
   d->setDownsampleLevel(0);

   load_eigen_images(32);
//   image_loader->loadFile("r.ppm");
   //d->init_texture(0, image_loader->getRGBWidth(), image_loader->getRGBHeight(),
   //             image_loader->getRGBData() );
   d->init_texture(10, 320,240, redbuf );
   d->bindTextures();
   while(1) { render_redirect(); }

   return 0; 
}
