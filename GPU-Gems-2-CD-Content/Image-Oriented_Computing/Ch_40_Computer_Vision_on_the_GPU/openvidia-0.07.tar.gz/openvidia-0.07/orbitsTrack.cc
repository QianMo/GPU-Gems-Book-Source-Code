/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h> 
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "GenericDisplay.h"
#include "SimpleDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394Capture.h"
#include "Raw1394Capture.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "Correspond.h"
#include "Parameters.h"
#include <iostream>
#include "GLTerm.h"
#include "SoundCapture.h"
#include "ImageSender.h"
#include "TImageSender.h"
#include "Dc1394.h"
#include <math.h> //MAX
#include "conversions.h" // coriander pixel conversions
#include "VirtualX.h"
#include "XApp.h"
#include "ShmFrame.h"
#include "ImageApplication.h"
#include "BoxApp.h"
#include "ListFileLoader.h"
#include "tools/graphicsHelpers.h"

void posixify(int argc, char * argv[]){}; //fill in from orbits version

/*
 * hand tracker
 */
#include "SingleImageSender.h"
#include "TSingleImageSender.h"

using namespace std;
boolean use_undistort=false;

/*
 * some globals
 */
SimpleDisplay *d;
GenericCapture *gc;
Dc1394* dc1394;
ListFileLoader *lfl;
Grab_JPEG *grabber;
Correspond *corr;
BoxApp *boxApp;

/*
 * Globals from the good ol' days
 */
int imageWinWidth = 320;
int imageWinHeight = 240;
Window  rwmWindow;
bool useLFL = false;
char listFile[1024];
int GLWinWidth  = -1;
int GLWinHeight = -1;


/*
 * Image sending and tracking
 */
ImageSender *sender=new ImageSender();
//#define NUMSENDERS 3
#define NUMSENDERS 1
SingleImageSender *senders[NUMSENDERS];


int NUM_ITERATIONS = 15;

/*
 * Forward define functions
 */
void parse_cmdline(int argc, char **argv);
void printHelp();


////// GLUT CALLBACKS ///////////////
void reshape(int w, int h)
{
/*
  float SCALE = 10;
  glutSetWindow(rwmWindow);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(1, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, (float)w/(float)imageWinWidth/SCALE,  
            (float)h/(float)imageWinHeight/SCALE, 0.0,   1.0/SCALE,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glClear(GL_COLOR_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  glutPostRedisplay();
*/
  float SCALE = 3.0f;///enlarges near plane of frustum
  float borderW =( (float)w/(float)imageWinWidth  - 1.0 )/2.0 ;
  float borderH =( (float)h/(float)imageWinHeight - 1.0 )/2.0 ;
  //glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(1, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  cerr<<"w = "<<w<<endl;
  //glFrustum(0.0, (float)w/(float)imageWinWidth/SCALE,  
  //          (float)h/(float)imageWinHeight/SCALE, 0.0,   1.0/SCALE,   100.0);
  glFrustum(-borderW/SCALE, (1.0+borderW)/SCALE,
            (1.0+borderH)/SCALE, -borderH/SCALE,   1.0/SCALE,   1000.0);
  //glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glClear(GL_COLOR_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();


}

void myIdle(){
  usleep(500);
  glutSetWindow(rwmWindow);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(rwmWindow);
}

void MouseFunc( int button, int state, int x, int y) 
{
  double p[8];
  bool clickedApp=false;
  
  switch(button) { 
  case GLUT_LEFT_BUTTON :
    if(state==GLUT_DOWN) {
      cout<<"click at ("<<x<<","<<y<<")"<<endl;
    }

    break;
  case GLUT_RIGHT_BUTTON : 
    break;
  case GLUT_MIDDLE_BUTTON : 
    if( state == GLUT_DOWN ) { 
    }
    break;
  }
}


/*
 * Callback for Dc1394
 */
unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(320*240*3);
int newdata=0;
void TellRWMHeCanUseImage(const char *dma_buf_) {

  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;
  
  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;

  //first one, need two
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }


  newdata=1;
}


/*  
 *  Load new images, then call Display object render functions
 */ 
Parameters global;
int framecounter=0;
unsigned char *reference_buf = NULL;
void render_redirect() {
  ++framecounter;

  if( !lfl ) {
    if(!newdata) {
      struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 500;
      select(0,0,0,0, &tv);
      return;
    }
  //  memcpy(dma_old_buf_rgb, dma_buf_rgb , 320*240*3);
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
  } 
  else {
    lfl->advanceFrame();
    memcpy(dma_old_buf_rgb, dma_buf_rgb , 320*240*3);
    memcpy( dma_buf_rgb, lfl->getRGBData(), 320*240*3  );
  }

  if( reference_buf == NULL ) {
    reference_buf = (unsigned char*)malloc(320*240*4);
    memcpy(reference_buf, dma_buf_rgb, 320*240*3);
  }
 
  d->init_texture(0, 320,240, dma_buf_rgb);
  d->bindTextureARB0(0);
  ///d->render();
  newdata=0;

  // NOW tell him we are done -- try to move up
  if( !lfl ) {
    dc1394->tellThreadDoneWithBuffer();

  }

  if( framecounter < 5 ) return;
  if( false ) { 
    Parameters initialGuess;
    Parameters converged;

    sender->sendImages(320, 240,
    //     dma_old_buf_rgb,
         reference_buf,
         dma_buf_rgb, NUM_ITERATIONS,
         ///initialGuess,
         global,
         &converged);

    global = converged;
  }
  else  {
    Parameters initialGuess;
    Parameters converged;
        sender->sendImages(320, 240,
         ////dma_old_buf_rgb,
         dma_old_buf_rgb,
         //dma_buf_rgb, 
         dma_buf_rgb, 
         NUM_ITERATIONS,
         initialGuess,
         &converged);
   converged.print();
   cout<<"norm: "<<converged.getNorm();
   cout<<" var: "<<converged.getVariance();
   cout<<" stddev: "<<sqrtf(converged.getVariance());
   cout<<endl;
   global = global*converged;
  }


  //This next section draws the input image at the right position.
  //It simply puts the image over the exisiting frame buffer.
  d->FPSimple->activate();
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist= 1.0;
  //apply projection
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glMultMatrixf( global.getAsChirpMat() );
 
  glClear(GL_DEPTH_BUFFER_BIT);
  glBegin(GL_QUADS);
    glTexCoord3f(0.0, imageWinHeight, dist);
    glVertex3f( origin, origin+texheight, texdist);

    glTexCoord3f(0.0, 0.0, dist);
    glVertex3f( origin, origin, texdist);

    glTexCoord3f(imageWinWidth, 0.0, dist);
    glVertex3f( origin+texwidth, origin, texdist);

    glTexCoord3f(imageWinWidth, imageWinHeight, dist);
    glVertex3f( origin+texwidth, origin+texheight, texdist);
  glEnd();
  d->FPSimple->deactivate();

  
  sched_yield(); //NB: Yielding scheduler is essential
  //XXX no more need for yeild if threaded??



  glutSwapBuffers();
  d->showstats();

}  


///// MAIN ///////////////////
int main(int argc, char** argv)
{
  glutInit(&argc, argv);
  parse_cmdline(argc,argv);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH | GLUT_ALPHA);
  GLWinWidth = imageWinWidth*2;
  GLWinHeight = imageWinHeight*2;
  glutInitWindowSize(GLWinWidth, GLWinHeight);

  glutInitWindowPosition(0, 0);
  rwmWindow=glutCreateWindow(argv[0]);

  d=new SimpleDisplay(20, imageWinWidth, imageWinHeight, rwmWindow );

  d->initDisplay();
  d->setImageSize( 320, 240 );
  d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 

  if( !useLFL ) {
    dc1394=new Dc1394();
    dc1394->start();
  }
  else {
    lfl =new  ListFileLoader(listFile);
    lfl->initCapture( d->getDisplay() );
    lfl->advanceFrame();
    memcpy( dma_buf_rgb, lfl->getRGBData(), 320*240*3  );
  }

  if( use_undistort )      
   d->initGL("FPsamples/FP-ibot-undistort.cg");       
  else    
    d->initGL();


  /*
   * START senders
   */
  //Doesnt need double threading?? sender->start();
  for(int i=0;i<NUMSENDERS; i++) {
    //start up 3, then 4, then 5
    //senders[i]=new TSingleImageSender(3+i);
    senders[i]=new SingleImageSender(3+i);
    //senders[i]->start();
  }
  grabber = new Grab_JPEG();

  boxApp = new BoxApp();

  glutSetWindow(rwmWindow);
  glutDisplayFunc(render_redirect);
  glutIdleFunc(myIdle);
  glutReshapeFunc(reshape);
  glutKeyboardFunc(keyboard);
  glutMouseFunc(MouseFunc);
  glutMainLoop();
  return 0; 
}


 // Help on command line options    
 void printHelp()    
 {    
   cout<<"rwm-cv options:"<<endl;   
   cout<<"   -h --help \t: show this help info"<<endl;
   cout<<"   -u --undistort \t: turn on radial undistortion"<<endl;       
   cout<<"   -l --listfile [listfile]"<<endl;
   cout<<"\t\t:  use a listfile instead of live"<<endl;

   cout<<endl;       
 }    
      
 //parse options     
 static struct option long_options[] = {      
   {"undistort", 0,0,'u'},     
   {"listfile", 0,0,'l'},     
   {"help", 0,0,'h'},     
   {0,0,0,0}    
 };   
      
 ////////////////////     
 // Parse cmd line options. Make sure this happens after glinit parse cmd options     
 ////////////////////     
 void parse_cmdline(int argc, char **argv)    
 {    
    char c;     
    opterr = 0; /* prevent weird options from causing errors */   
    posixify(argc,argv);       
      
    while(1) {       
      int this_option_optind = optind ? optind : 1;     
      int option_index = 0;    
      c = getopt_long (argc, argv, "ul:h",     
                       long_options, &option_index);    
      if (c == -1) break;      
      switch(c){     
      case 'u' :     
        cerr<<"Turning on Radial Undistortion"<<endl;
        use_undistort=true;    
        break;       
      case 'l' :     
        strcpy( listFile, optarg );
        cerr<<"List file is:  "<<listFile<<endl;
        useLFL = true;
        break;       
      case 'h' : 
        printHelp();
        exit(0);
        break;
      default :       
        cerr<<"WARNING: unknown switch "<<c<<endl;      
      }    
      
    }      
 }


