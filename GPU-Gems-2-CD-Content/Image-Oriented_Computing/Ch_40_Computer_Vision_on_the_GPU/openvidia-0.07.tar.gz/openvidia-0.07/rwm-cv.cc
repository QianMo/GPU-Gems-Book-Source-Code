/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h> 
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h> //MAX
/*
#include "GenericDisplay.h"
#include "SimpleDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394Capture.h"
#include "Raw1394Capture.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "Correspond.h"
#include "Parameters.h"
#include <iostream>
#include "GLTerm.h"
#include "SoundCapture.h"
#include "ImageSender.h"
#include "TImageSender.h"
#include "Dc1394.h"
#include "conversions.h" // coriander pixel conversions
#include "VirtualX.h"
#include "XApp.h"
#include "ShmFrame.h"
#include "ImageApplication.h"
#include "BoxApp.h"
#include "tools/graphicsHelpers.h"
#include "FragPipeDisplay.h"
*/
#include "libopenvidia.h"

void posixify(int argc, char * argv[]){}; //fill in from orbits version

/*
 * hand tracker
 */
#include "SingleImageSender.h"
#include "TSingleImageSender.h"

using namespace std;
/*
 * for GLTERM
 */
int USE_GLTERM=1;
boolean use_fov=false;
boolean use_undistort=false;
bool useXNEE = true;

/*
 * some globals
 */
GenericDisplay *glterm;
SimpleDisplay *d;
GenericCapture *gc;
Dc1394* dc1394;
Grab_JPEG *grabber;
Correspond *corr;

/*
 * Sound config
 */
bool use_sound=false;
SoundCapture *sc;

/*
 * Globals from the good ol' days
 */
int imageWinWidth = 640;
int imageWinHeight = 480;
Window  rwmWindow;

/*
 * Image sending and tracking
 */
TImageSender *sender=new TImageSender();
#define NUMSENDERS 3
TSingleImageSender *senders[NUMSENDERS];


int EVENT_MOVE=0;
int EVENT_DOWN=4;
int EVENT_UP=5;
void createXneeTmpFile(int i, int x, int y, int eventCode);
// Initial glterm parameters
Parameters gltermInitial, gltermCurrent;
int NUM_ITERATIONS = 6;

#define NUMHANDTRACKERS 1
ShmFrame *handFrames[NUMHANDTRACKERS];
int handtrackerIDs[NUMHANDTRACKERS]={2*3-2};//, 4}; // ID 4
int rectShmemId=2*5-2;//ID 5
ShmFrame *rectFrame;


/*
 * Desktop UI stuff, XXX todo glterm hack
 */
#define NUMAPPS 4
// only use a subset of available apps
#define MAXAPPS 4
ImageApplication *imageApps[NUMAPPS];
XApp *xApps[NUMAPPS];
bool xAppsStarted[NUMAPPS]={false};
char *thumbnails[MAXAPPS]={"images/xterm.png", "images/xclock.png", 
			   "images/mozilla.png", "images/xcalc.png"};
//char *filenames[MAXAPPS]={"aterm", "xclock", "xcalc", "xcalc"};
//char *filenames[MAXAPPS]={"aterm", "xclock", "mozilla-firefox", "xcalc"};
//NB:for some reason firefox doesn't work properly.
// if it starts before its displayed, it crashes, seg faulting the shm area
// you can delay it, then start it when the X is being shown ok,
// but it will crash when the next session is re-attached.
char *filenames[MAXAPPS]={"aterm", "xclock", "mozilla-1.7.3", "xcalc"};
int numClicksIcon=0;
int numClicksCorners=0;
int nextAppToStart=-1;


/*
 * Forward define functions
 */
void parse_cmdline(int argc, char **argv);
void printHelp();


////// GLUT CALLBACKS ///////////////
void reshape(int w, int h)
{
  float SCALE = 10;
  glutSetWindow(rwmWindow);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(1, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, (float)w/(float)imageWinWidth/SCALE,  
            (float)h/(float)imageWinHeight/SCALE, 0.0,   1.0/SCALE,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glClear(GL_COLOR_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  glutPostRedisplay();
}

void myIdle(){
  usleep(500);
  glutSetWindow(rwmWindow);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(rwmWindow);

  if(USE_GLTERM) {
    glterm->handle_key(key);
  }
}

/*
 *Sound processing thread calls this function asyncronously
 *XXX we should use a critical section now?
 */ 
void MouseFunc( int button, int state, int x, int y) 
{
  double p[8];
  bool clickedApp=false;
  
  switch(button) { 
  case GLUT_LEFT_BUTTON :
    if(state==GLUT_DOWN) {
      cout<<"click at ("<<x<<","<<y<<")"<<endl;
      
      // See if we are over Desktop launcher apps
      for(int i=0; i<NUMAPPS; i++) {
	if( imageApps[i]->isMouseOverAlternate(x,y) ){
	  cout<<"launcher click at ("<<x<<","<<y<<")"<<endl;
	  nextAppToStart=i;
	  clickedApp=true;
	}
      }
      // see if we are over real apps
      for(int i=0; i<NUMAPPS; i++) {
	if(xAppsStarted[i]==true) {
	  if( xApps[i]->isMouseOverAlternate(x,y)){
	    cout<<"app click at ("<<x<<","<<y<<")"<<endl;
	    xApps[i]->drawBorder(0.0,1.0,0.0,1.0);
	    
	    createXneeTmpFile( i, x, y, EVENT_DOWN);
	    clickedApp=true;
	  }
	}
      }

      if( !clickedApp && nextAppToStart != -1 ) { 
	cerr << "("<<x<<","<<y<<")"<<endl;
	corr->add_point(x,y);
	numClicksCorners++;

	if(numClicksCorners>=4 && nextAppToStart!=-1) {
	  corr->shell_Corr2p(p);
	  
	  Parameters parm=Parameters(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]);
	  xApps[nextAppToStart]->setInitialParameter(parm);
	  xApps[nextAppToStart]->setCurrentParameter(parm);
	  xAppsStarted[nextAppToStart]=true;
	  numClicksCorners=0;
	  nextAppToStart=-1;
	}
      }
    }
    break;
  case GLUT_RIGHT_BUTTON : 
    /*
      if( state == GLUT_DOWN && nextAppToStart!=-1) { 
      double p[8];

       dc1394->lock();
        corr->shell_Corr2p(p);
       dc1394->unlock();

       Parameters parm=Parameters(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]);
       
       xApps[nextAppToStart]->setInitialParameter(parm);
       xApps[nextAppToStart]->setCurrentParameter(parm);
       }
    */
    break;
  case GLUT_MIDDLE_BUTTON : 
    if( state == GLUT_DOWN ) { 
      corr->clear_points();
    }
    break;
  }
}


/*
 * Callback for Dc1394
 */
unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(320*240*3);
int newdata=0;
void TellRWMHeCanUseImage(const char *dma_buf_) {
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;
  
  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;

  //first one, need two
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }

  newdata=1;
}


/*  
 *  Load new images, then call Display object render functions
 */ 
int framecounter=0;
void render_redirect() {
  ++framecounter;
  if(!newdata) {
    struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 500;
    select(0,0,0,0, &tv);
    return;
  }
  
  uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
  d->init_texture(0, 320,240,
		  dma_buf_rgb);
  d->bindTextureARB0(0);
  newdata=0;
  // NOW tell him we are done -- try to move up
  dc1394->tellThreadDoneWithBuffer();
  d->render();

  if(  corr->hasPoints() ) {
    Parameters initialGuess;
    Parameters converged;
    int isPartial=-1;
    static Parameters lastPartial;
    static bool lastWasPartial=false;
    sender->sendImages(320, 240,
		       dma_old_buf_rgb,
		       dma_buf_rgb, NUM_ITERATIONS,
		       initialGuess,
		       &converged, &isPartial);
    converged.invert();
    if(lastWasPartial) {
      lastPartial.invert();
      converged=converged*lastPartial;;
      lastWasPartial=false;
    }
    if(isPartial==1) {
      lastWasPartial=true;
      lastPartial.set(converged.get());
    }

    Parameters result = gltermCurrent*converged;
    gltermCurrent.set(result.get());
    glterm->setChirpMatParams(gltermCurrent.get()); //tracker use

    for(int i=0; i<NUMAPPS; i++) {
      if(xAppsStarted[i]==1) {
	Parameters xappCurrent=xApps[i]->getCurrentParameter();
	Parameters xappResult=xappCurrent*converged;
	xApps[i]->setCurrentParameter(xappResult);
      }
    }
  }



  for(int i=0;i<NUMSENDERS;i++) {
    senders[i]->sendImage(320,240,dma_buf_rgb);
  }

  sched_yield(); //NB: Yielding scheduler is essential
  //XXX no more need for yeild if threaded??

  /*
   * Render applications properly aligned
   */
  glterm->render();
  for(int i=0; i<NUMAPPS; i++) {
    if(xAppsStarted[i]==true) {
      xApps[i]->render();
    }
  }

  /*
   * Grab finger coord from server, convert to 640 grid
   */
  for(int i=0; i<NUMHANDTRACKERS; i++) {
    int x=handFrames[i]->Frame->hand_x_640;
    int y=handFrames[i]->Frame->hand_y_480;
    drawFingerTip(x,y);
  }

  /*
   * Determine which apps mice are hovering above
   */
  for(int j=0; j<NUMHANDTRACKERS; j++) {
    bool clickOnApp=false;
    /*
     * Use the raster coords method
     */
    int x=handFrames[j]->Frame->hand_x_640;
    int y=handFrames[j]->Frame->hand_y_480;
    int event_code=handFrames[j]->Frame->MOUSE_SIGNAL;
    handFrames[j]->Frame->MOUSE_SIGNAL=0;
  
    // XXXX send mouse click, no matter
    // if didnt click an app, we clicked a corner
    if(event_code==1) { // && clickOnApp==false) {
      float x_avg = handFrames[j]->Frame->MOUSE_SIGNAL_x_320*2;
      float y_avg = handFrames[j]->Frame->MOUSE_SIGNAL_y_240*2;
      MouseFunc(GLUT_LEFT_BUTTON, GLUT_DOWN, (int)x_avg, (int)y_avg);
    } 
    // else move mouse
    for(int i=0; i<NUMAPPS; i++) {
      if(xAppsStarted[i]==true) {
	if( xApps[i]->isMouseOverAlternate(x,y) ){
	  xApps[i]->drawBorder(0.0,1.0,0.0,1.0);
	  // wont create a movement if mousefunc create a tmp file and its not consumed yet
	  cout<<"Move"<<endl;
	  createXneeTmpFile( i, x, y, EVENT_MOVE);
	}
      }
    }

  }
  
  /*
   * Draw "Desktop" Launcher Icons
   */
  // really should draw apps that arent "maximized"
  // For now image app is not attached to things -- it floats, like in looking glass project
  for(int i=0;i<NUMAPPS;i++) {
    imageApps[i]->render();
  }

  /*
   * See if we are over Desktop launcher apps
   */
  for(int i=0; i<NUMAPPS; i++) {
    for(int j=0; j<NUMHANDTRACKERS; j++) {
      /*
       * Use the raster coords method
       */
      int x=handFrames[j]->Frame->hand_x_640;
      int y=handFrames[j]->Frame->hand_y_480;
      
      if( imageApps[i]->isMouseOverAlternate(x,y) || nextAppToStart==i){
	imageApps[i]->drawBorder(0.0,0.0,1.0,1.0);
      }
    }
  }


  /*
   * Render best rectangle so far
   */
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  float r=1.0; float g=0.0; float b=0.0; float alpha=1.0;
  glColor4f(r,g,b,alpha);
  glBegin(GL_LINE_LOOP);
  for(int i=0;i<4;i++) {
    glVertex3f(rectFrame->Frame->rect_x_320[i]/320.0, 
	       rectFrame->Frame->rect_y_240[i]/240.0, -1);
  }
  glEnd();


    

  /*
   * Grab a frame
   */
  int grabGLFrame=1;
  if(grabGLFrame) {
    //grabber->grab_frame((unsigned char*)dma_buf_rgb, 320,240, 0);//0==format
//    grabber->grab_frameGL(320,240, true);
//    grabber->grab_frameGL(640,480, true);
  }

  
  glutSwapBuffers();
  d->showstats();
}  


///// MAIN ///////////////////
int main(int argc, char** argv)
{
  glutInit(&argc, argv);
  parse_cmdline(argc,argv);
  cout <<"Creating Double Buffered Window" << endl;
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH | GLUT_ALPHA);
  //glutInitWindowSize(imageWinWidth+320, imageWinHeight);
  glutInitWindowSize(imageWinWidth, imageWinHeight);
  glutInitWindowPosition(50, 100);
  rwmWindow=glutCreateWindow(argv[0]);

  grabber = new Grab_JPEG();
  grabber->vindex=1000000;
  //d=new SimpleDisplay(3, imageWinWidth, imageWinHeight, rwmWindow );
  d=new FragPipeDisplay(3, imageWinWidth, imageWinHeight, rwmWindow );
  if(USE_GLTERM) {
    glterm=new GLTerm(imageWinWidth, imageWinHeight, rwmWindow);
  }

  corr = new Correspond(imageWinWidth, imageWinHeight );
  //gc=new Dc1394Capture(FORMAT_UYVY);
  //((Dc1394Capture *)gc)->start();
  /*  gc=new ImlibCapture();
  cout << " load file "<<endl;
  ((ImlibCapture *)gc)->initCapture((Display *)d);
  ((ImlibCapture *)gc)->loadFile("/r/dj.jpg");*/
  dc1394=new Dc1394();
  dc1394->start();
  
  //ensure we have 2 frame always
  //    gc->advanceFrame();
  //gc->getRGBData();
  //gc->releaseCap();
  //  gc->advanceFrame();
  
  d->initDisplay();
  d->setImageSize( 320, 240 );
  d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 

  glterm->setChirpMat( 1.000, 0.00,   0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 

  if( use_undistort )      
   d->initGL("FPsamples/FP-ibot-undistort.cg");       
  else    
    d->initGL();

  if(USE_GLTERM) {
    glterm->initGL();
  }

  //  d->init_texture(0, 320,240 ,gc->getRGBData());
  //gc->releaseCap(); // now we are done with frame
  // START SOUND
  if( use_sound ) {
    sc = new SoundCapture();
    sc->start();
  }
  
  /*
   * START senders
   */
  //Doesnt need double threading?? sender->start();
  for(int i=0;i<NUMSENDERS; i++) {
    //start up 3, then 4, then 5
    senders[i]=new TSingleImageSender(3+i);
    senders[i]->start();
  }

  /*
   * Connect to trackers (hand shmems)
   */
  for(int i=0; i<NUMHANDTRACKERS;i++) {
    int client_id=handtrackerIDs[i];
    int handShmemId = client_id*2-2;
    handFrames[i] = new ShmFrame(handShmemId);
  }
  rectFrame=new ShmFrame(rectShmemId);


  /*
   * create "Desktop" Launcher Icons
   */
  //obtained 8 parameters below by clicking where i want orbits to be
  float A=0.1; //larger stretches it verticaly
  float B=0;
  float C=0.85;//larger moves it downwards
  float D=0;
  float E=0.1; //larger stretches it to the right
  float F=0.85;  //larger moves it to the right
  float G=0;
  float H=0;
  for(int i=0; i<MAXAPPS; i++) {
    imageApps[i]=new ImageApplication(thumbnails[i]);
    Parameters pThumbnail=Parameters(A,B,C-0.101*i,D,E,F,G,H);
    imageApps[i]->setCurrentParameter(pThumbnail);
  }

  for(int i=0; i<NUMAPPS; i++) {
    xApps[i]=new XApp(filenames[i]);
    xApps[i]->initShmem();
  }


  glutSetWindow(rwmWindow);
  glutDisplayFunc(render_redirect);
  glutIdleFunc(myIdle);
  glutReshapeFunc(reshape);
  glutKeyboardFunc(keyboard);
  glutMouseFunc(MouseFunc);
  glutMainLoop();
  return 0; 
}



/*
 * Communicate with xnee process via tmp files
 */
void createXneeTmpFile(int i, int x, int y, int eventCode) {
  int xserverId=xApps[i]->UNIQUEID;

  int result=access("tmp.rec", F_OK);
  if(result==0) {
    //it exists
    //return;
    // wait for it to be consumed
    //reset and ignore -- hmm other thread crashed?
    //    system("rm tmp.rec");
    return;
  }

  //find transformed coords for this one
  double x_prime, y_prime=0;
  xApps[i]->getLocalCoords(x, y, &x_prime, &y_prime);
  //XXX should use App screen width instead of hardcoded
  int x_local_coord=(int)(x_prime*320);
  int y_local_coord=(int)(y_prime*240);

  if(false){
    cout<<"("<<x<<","<<y<<") ==> ["<<
      x_prime<<","<<y_prime<<"] ("<<x_local_coord<<","<<y_local_coord<<")"<<endl;
  }   

  FILE *f=fopen("tmp.rec", "w+");
  if( f==NULL ) {
    cerr<<"Could not open tmp.rec for writing"<<endl;
    return;
  }

  fprintf(f, "%d %d %d %d", xserverId, x_local_coord, y_local_coord, eventCode);

  // also need to tell it click+move events
  //0,4,0,0,1,0,0,705513
  //0,6,625,659,0,0,0,705543
  //0,6,627,659,0,0,0,705552
  //0,6,630,659,0,0,0,705559
  //0,6,632,659,0,0,0,705567
  //0,5,0,0,1,0,0,706510

  fclose(f);

  return;
}

 // Help on command line options    
 void printHelp()    
 {    
   cout<<"rwm-cv options:"<<endl;   
   cout<<"   -u --undistort \t: turn on radial undistortion"<<endl;       
   cout<<endl;       
 }    
      
 //parse options     
 static struct option long_options[] = {      
   {"undistort", 0,0,'u'},     
   {0,0,0,0}    
 };   
      
 ////////////////////     
 // Parse cmd line options. Make sure this happens after glinit parse cmd options     
 ////////////////////     
 void parse_cmdline(int argc, char **argv)    
 {    
    char c;     
    opterr = 0; /* prevent weird options from causing errors */   
    posixify(argc,argv);       
      
    while(1) {       
      int this_option_optind = optind ? optind : 1;     
      int option_index = 0;    
      c = getopt_long (argc, argv, "u",     
                       long_options, &option_index);    
      if (c == -1) break;      
      switch(c){     
      case 'u' :     
        cout<<"Turning on Radial Undistortion"<<endl;
        use_undistort=true;    
        break;       
      defalt :       
        cerr<<"WARNING: unknown switch "<<c<<endl;      
      }    
      
    }      
 }


