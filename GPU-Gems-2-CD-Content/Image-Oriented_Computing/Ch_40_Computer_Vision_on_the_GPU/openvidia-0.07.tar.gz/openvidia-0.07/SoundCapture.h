/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _SOUND_CAPTURE_H
#define _SOUND_CAPTURE_H

#include <cc++2/cc++/thread.h>
#include <semaphore.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;
using namespace ost;//threads

#define LENGTH 0.1    /* how many seconds of speech to store */
#define RATE 8000   /* the sampling rate */
#define SIZE 16      /* sample size: 8 or 16 bits */
#define CHANNELS 2  /* 1 = mono 2 = stereo */
#define TRAILING_BUFFER_SIZE 10 /* take into account last 10 sound windows */

class SoundCapture : public Thread, public Mutex
{
 protected:
  int fd;
  //char *buf;
  int bufSize;  
  char buf[(int)(LENGTH*RATE*SIZE*CHANNELS/8)];
  int trailingBuffer[TRAILING_BUFFER_SIZE];
  void *m_callbackFunction;
  void resetTrailingBuffer();
  bool m_DEBUG;

 public:
  int soundEnergy;
  SoundCapture();
  void run();
  bool isLargePulse(int index);
  int findLargestEnergy();
  void SoundCapture::setCallbackFunction(void* f);

};

#endif
