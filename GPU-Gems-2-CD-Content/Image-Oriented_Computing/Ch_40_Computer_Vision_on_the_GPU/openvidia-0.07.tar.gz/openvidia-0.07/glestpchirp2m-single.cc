/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include <getopt.h>


#include "GenericDisplay.h"
#include "SimpleDisplay.h"
#include "CGDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394Capture.h"
#include "Raw1394Capture.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "Correspond.h"
#include "Udat.h"
#include "OrbitsInterface.h"
#include "Parameters.h"
#include "mapping.h"
#include "ProjPlane.h"
#include "ShmFrame.h"
#include <iostream>
#include <iomanip>
#include "GLTerm.h"
using namespace std;
// for GLTERM
#define HI_QUALITY 1
int USE_GLTERM=1;
bool exec_cpu = false;

// Global display object
//GenericDisplay *d;
CGDisplay *orbits;
GenericCapture *gc;
OrbitsInterface *oi, *oicpu;
int use_cg=1;

int imageWinWidth = 320;
int imageWinHeight = 240;
float *sums;

int step=1;

#define MAX_PLANES 100

ProjPlane *planes[MAX_PLANES];

Window  Orbwin;

////// UTILITY FUNCTION //////////////
void buffer_sample_float4(float sample[4], float *thebuffer,
                          int X, int Y,
                          int xSize, int ySize, int nchans )
{
  int i=0;
  for( i=0 ; i<nchans; i++ ) {
      sample[i] = thebuffer[Y*xSize*nchans+X*nchans+i];
  }
}

void printProjectionMatrix()
{
  float pmatrix[16]={0};
  glGetFloatv( GL_PROJECTION_MATRIX, pmatrix);
  printf("%5f %5f %5f %5f\n", pmatrix[0], pmatrix[4], pmatrix[8], pmatrix[12]);
  printf("%5f %5f %5f %5f\n", pmatrix[1], pmatrix[5], pmatrix[9], pmatrix[13]);
  printf("%5f %5f %5f %5f\n", pmatrix[2], pmatrix[6], pmatrix[10], pmatrix[14]);
  printf("%5f %5f %5f %5f\n", pmatrix[3], pmatrix[7], pmatrix[11], pmatrix[15]);
}

////// GLUT CALLBACKS ///////////////

void reshape(int w, int h)
{
  float SCALE = 3.0f;///enlarges near plane of frustum
  float borderW =( (float)w/(float)imageWinWidth  - 1.0 )/2.0 ;
  float borderH =( (float)h/(float)imageWinHeight - 1.0 )/2.0 ;
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(1, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  cerr<<"w = "<<w<<endl;
  //glFrustum(0.0, (float)w/(float)imageWinWidth/SCALE,  
  //          (float)h/(float)imageWinHeight/SCALE, 0.0,   1.0/SCALE,   100.0);
  glFrustum(-borderW/SCALE, (1.0+borderW)/SCALE,  
            (1.0+borderH)/SCALE, -borderH/SCALE,   1.0/SCALE,   100.0);
  //glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glClear(GL_COLOR_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();


  //make a tasty vanilla frustum for fpbuffer orbits
  //dont alter this.
  orbits->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) 320, (GLsizei) 240);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  orbits->deactivate_fpbuffer();

  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);

     switch (key) {
      case 27:
         exit(0);
         break;
      default:
         break;
	 }
}

float Dm[320*240*4]={0.0};
float Dn[320*240*4]={0.0};
float Dt[320*240*4]={0.0};
float Da[320*240*4]={0.0};
Parameters p,P, gltermP, gltermp;
float ptmp[8];
float samp[4];
float R,G,B,A;


///side note:  using a double precision sum gets be closer! to twhat the
//graphics cards does internally.  float seems less! precise.  !
float sumBuffer( float *b, int x, int y) 
{
  double sum=0.0;
  for( int i=0 ; i<y ; i++ ) {
    for( int j=0 ; j<x ; j++ ) { 
      sum+=(double)b[i*x+j];
    }
  } 
  return (float)sum;
}

void print_DER_matrix(float *A)
{
  for( int i=0; i<8; i++ ) {
    for( int j=0; j<8; j++ ) {
      cerr<<setprecision(5)<<A[i*8+j]<<" ";
    }
    cerr<<endl;
  }
}

void compare_DER_matrices(float *A, float *B)
{
  for( int i=0; i<8; i++ ) {
    for( int j=0; j<8; j++ ) {
      cerr<<setprecision(5)<<fabs((A[i*8+j]-B[i*8+j])/B[i*8+j])<<" ";
    }
    cerr<<endl;
  }
}


void setMatrix(float *sums) 
{
/*
  cerr<<"RETRIEVED=[";
  for( int i=0 ; i<11*4 ; i++ ) {
    cerr<<sums[i]<<", ";
  } 
  cerr<<"]"<<endl;
*/

  int k=0;
  for( int i=2;  i<=10; i++ ) {
    for( int j=0; j<4 ; j++ ) {
      oi->setDER( OrbitsRGBAmap[i][j], sums[k++]);
    }
  }
  for( int i=0; i<8 ; i++ ) oi->setder(i, sums[k++]);
}

int num_planes = 9;
int current_plane = 1;
int niter = 18;
int nitercount = 0;
bool exec_est = true;

void render_redirect() {

  if( exec_est ) {
    sums = (float *)malloc(sizeof(float)*4*11);
    orbits->activate_fpbuffer();
      //place desired images into the right texturing units
      orbits->bindTextureARB1( planes[current_plane-1]->getTexNum() ); 
      orbits->bindTextureARB0( planes[current_plane  ]->getTexNum() );
      //orbits->execEstimation(); //exec as immediate mode
      orbits->execEstimationList(); //exec as display list
      orbits->getSums(sums);
      setMatrix(sums) ;
    orbits->deactivate_fpbuffer();
  

    //for( int i=0; i<11*4; i++ ) cerr<<sums[i]<<" ";
    //cerr<<endl;

    free(sums);

    oi->solve_system(step);
    oi->getParameters(ptmp);
    //(exec_cpu)?oicpu->getParameters(ptmp):; //cpu fallback
    P.set(ptmp);
    orbits->setChirpMatParams(P.get() );
    orbits->setCGchirp();
  }

  //render the current cement
  planes[0]->clear(); //clear out 
  planes[current_plane]->P = planes[current_plane-1]->P*P;
  for( int i=0  ; i<=current_plane ; i++ ) {
    orbits->bindTextureARB0(planes[i]->getTexNum());
    planes[i]->draw(false); 
  }


  nitercount++;
  if( nitercount == niter ) {
    nitercount=0;
    if( ++current_plane == num_planes ) {
      current_plane = num_planes-1;
      planes[current_plane]->P.print();
      exec_est = false;
      //reset
      orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
      oicpu->resetParams(); 
    }
    else {
      planes[current_plane]->P = planes[current_plane-1]->P; 
      //reset
      orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
      oicpu->resetParams(); 
      oi->resetParams(); 
    }
  } 


  orbits->showstats();  
  glutSwapBuffers();
  return;
}  

void posixify(int argc, char * argv[]); //fill in from orbits version

//parse options
static struct option long_options[] = {
     {"display", 0, 0, 'd'},
     {0,0,0,0}
};

void parse_cmdline(int argc, char **argv)
{
   char c;
   opterr = 0; /* prevent weird options from causing errors */
   posixify(argc,argv);

   while(1) {
     int this_option_optind = optind ? optind : 1;
     int option_index = 0;
     c = getopt_long (argc, argv, "d:",
                      long_options, &option_index);
     if (c == -1) break;
     switch(c){
     case 'd' :
       break;
     case 'f' :
       break;
     case 'b' :
       break;
     }

   }
}



///// MAIN ///////////////////
//unsigned char whitebuf[320*240*4]= {255};
unsigned char whitebuf[320*240*4]= {255};
int main(int argc, char** argv)
{
   //ShmFrame f(0);
   for( int i=0; i<320*240*4; i++ ) whitebuf[i]=255;
   glutInit(&argc, argv);
   parse_cmdline(argc, argv);
   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_ALPHA);
   glutInitWindowSize(imageWinWidth+300, imageWinHeight+300);
   glutInitWindowPosition(50, 100);
   Orbwin=glutCreateWindow(argv[0]);

   orbits=new CGDisplay(128, 320,240, Orbwin );
   orbits->initDisplay();
   orbits->setDownsampleLevel(step);
   orbits->setImageSize(320,240);  
   orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
   orbits->initGL();

   gc=new ImlibCapture(100,101);
   gc->initCapture(orbits);
   
   oi = new OrbitsInterface(2, 240, 320);
   oicpu = new OrbitsInterface(2, 240, 320);

 ((ImlibCapture *)gc)->loadFile("/home/fungja/videorbits-2.203/images/s04.pgm");
   orbits->init_texture(10, gc->getRGBWidth(),
                        gc->getRGBHeight(),gc->getRGBData() );
   orbits->bindTextureARB0(10);
 
 ((ImlibCapture *)gc)->loadFile("/home/fungja/videorbits-2.203/images/s06.pgm");
   orbits->init_texture(11, gc->getRGBWidth(),
                        gc->getRGBHeight(),gc->getRGBData() );
   orbits->bindTextureARB0(11);
   num_planes = 2;
   


   orbits->init_texture4f(2, gc->getRGBWidth(),
                          gc->getRGBHeight(),gc->getRGBData());
   orbits->init_texture4f(3, gc->getRGBWidth(),
                          gc->getRGBHeight(),gc->getRGBData());

   orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
   oicpu->resetParams(); 
   oi->resetParams(); 

   for( int i=0 ; i<num_planes ; i++ ) {
     planes[i] = new ProjPlane(imageWinWidth, imageWinHeight, 
                               orbits->getContext(), orbits->getProfile() );
     planes[i]->setTexNum(i+10);
   }
   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMainLoop();
   return 0; 
}

void Orbits_Explicit()
{

  float DER_CPU[64];
  float DER_GPU[64];
  float sum[4];
  //reset
  //orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
  //oicpu->resetParams(); 
  //oi->resetParams(); 
/*
 orbits->activate_fpbuffer(); 
  //render deriv 
  orbits->bindTextureARB1(1);
  orbits->bindTextureARB0(0);
  orbits->render();

  //orbits->grabDisplay(Dm, Dn, Dt, Da, 0); //needs n/m reversed
  //    cerr<<"SumR = "<<R<<endl;
  //    cerr<<"SumG = "<<G<<endl;
  //    cerr<<"SumB = "<<B<<endl;
  //    cerr<<"SumA = "<<A<<endl;
  //buffer_sample_float4(samp, Dn, 0, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 1, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 2, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 3, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 317, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 318, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 0, 237, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 1, 237, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dt, 0, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dm, 0, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Dn, 0, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];
  //buffer_sample_float4(samp, Da, 0, 238, 319,239,1 ); cerr<<" Samp:"<<samp[0];




 //full buffere readback
  //buffer_sample_float4(samp, Da, 10, 238, 319,239,1 ); cerr<<"Samp :"<<255*samp[0];

  glFlush();
  orbits->render_to_texture( 2, 0, 0, 320, 240 );
  //glutSwapBuffers();
  orbits->deactivate_fpbuffer(); 


  //estpairwise CPU
  if( exec_cpu ) {
    orbits->bindTextureARB1(1);
    orbits->bindTextureARB0(0);
    orbits->render();

    oicpu->setDt(0, Dt);
    oicpu->setDm(0, Dn); //for unknown reason - orbits seems to treat m/n as h/v
    oicpu->setDn(0, Dm);
    //oicpu->pseudo_estimate(0);
  } 

//  oi->getParameters(ptmp);
//  P.set(ptmp);
//  orbits->setChirpMatParams(P.get() );

  //HW estimation passes
  orbits->activate_fpbuffer();
  orbits->bindTextureARB0(2);
  for( int i =2; i <=10 ; i++ ) {
    orbits->bindTextureARB0(2);
    orbits->render_pass(i);

    if(exec_cpu) {
      //CPU Summation
      orbits->grabDisplay(Dm, Dn, Dt, Da, 0); //needs n/m reversed
      buffer_sample_float4(samp, Dt, 0, 238, 319,239,1 ); 
      //cerr<<" Samp:"<<samp[0];
      R = sumBuffer(Dt, 319, 239);
      G = sumBuffer(Dm, 319, 239);
      B = sumBuffer(Dn, 319, 239);
      A = sumBuffer(Da, 319, 239);
     
      cerr<<"Pass "<<i; 
      cerr<<setprecision(5)<<" SumR = "<<R;
      cerr<<setprecision(5)<<" SumG = "<<G;
      cerr<<setprecision(5)<<" SumB = "<<B;
      cerr<<setprecision(5)<<" SumA = "<<A<<endl;
    }
 
    //GPU summation
    orbits->render_to_texture( 3, 0, 0, 320, 240 );
    //orbits->sumTexture(3, sum); //immediate mode sumation, readback result
    //orbits->sumTextureList(3, sum);  //display list summation, readback result
    orbits->sumTextureList_and_Store(3, i-2);//summation and deferred retrieveal
    //orbits->getSums(i-2,1, sum);   //retrieves sums
    
    //cerr<<"GPU=["<<sum[0]<<", "<<sum[1]<<", "<<sum[2]<<", "<<sum[3]<<"]"<<endl;
    //use GPU results:
    R = sum[0]; G = sum[1]; B = sum[2]; A = sum[3];
    

    // set DER matrix for solution

    //oi->setDER( OrbitsRGBAmap[i][0], R);
    //oi->setDER( OrbitsRGBAmap[i][1], G);
    //oi->setDER( OrbitsRGBAmap[i][2], B);
    //oi->setDER( OrbitsRGBAmap[i][3], A);

  }

  orbits->bindTextureARB0(2);
  orbits->render_pass(11);
  if(exec_cpu) {
    //CPU Summation
    orbits->grabDisplay(Dm, Dn, Dt, Da, 0); //needs n/m reversed
    buffer_sample_float4(samp, Dt, 0, 238, 319,239,1 ); 
    //cerr<<" Samp:"<<samp[0];
    R = sumBuffer(Dt, 319, 239);
    G = sumBuffer(Dm, 319, 239);
    B = sumBuffer(Dn, 319, 239);
    A = sumBuffer(Da, 319, 239);
     
    cerr<<"Pass "<<11; 
    cerr<<setprecision(5)<<" SumR = "<<R;
    cerr<<setprecision(5)<<" SumG = "<<G;
    cerr<<setprecision(5)<<" SumB = "<<B;
    cerr<<setprecision(5)<<" SumA = "<<A<<endl;
  }

  //GPU summation
  orbits->render_to_texture( 3, 0, 0, 320, 240 );
  //orbits->sumTexture(3, sum);
  //orbits->sumTextureList(3, sum);
  orbits->sumTextureList_and_Store(3, 11-2);//summation and deferred retrieveal
  //orbits->getSums(11-2,1, sum);   //retrieves sums
  //cerr<<"GPU=["<<sum[0]<<", "<<sum[1]<<", "<<sum[2]<<", "<<sum[3]<<"]"<<endl;
  //use GPU results:
  R = sum[0]; G = sum[1]; B = sum[2]; A = sum[3];
 
  // set DER matrix for solution

  //oi->setder( 0, R);
  //oi->setder( 1, G);
  //oi->setder( 2, B);
  //oi->setder( 3, A);



   
  orbits->bindTextureARB0(2);
  orbits->render_pass(12);
  if(exec_cpu) { 
    //CPU Summation
    orbits->grabDisplay(Dm, Dn, Dt, Da, 0); //needs n/m reversed
    buffer_sample_float4(samp, Dt, 0, 238, 319,239,1 ); 
    //cerr<<" Samp:"<<samp[0];
    R = sumBuffer(Dt, 319, 239);
    G = sumBuffer(Dm, 319, 239);
    B = sumBuffer(Dn, 319, 239);
    A = sumBuffer(Da, 319, 239);
   
    cerr<<"Pass "<<11; 
    cerr<<setprecision(5)<<" SumR = "<<R;
    cerr<<setprecision(5)<<" SumG = "<<G;
    cerr<<setprecision(5)<<" SumB = "<<B;
    cerr<<setprecision(5)<<" SumA = "<<A<<endl;
  }

  //GPU summation
  orbits->render_to_texture( 3, 0, 0, 320, 240 );
  //orbits->sumTexture(3, sum);
  //orbits->sumTextureList(3, sum);
  orbits->sumTextureList_and_Store(3, 12-2);//summation and deferred retrieveal
//  orbits->getSums(12-2,1, sum);   //retrieves sums
  //cerr<<"GPU=["<<sum[0]<<", "<<sum[1]<<", "<<sum[2]<<", "<<sum[3]<<"]"<<endl;
  //use GPU results:
  R = sum[0]; G = sum[1]; B = sum[2]; A = sum[3];
 
  // set DER matrix for solution

  //oi->setder( 4, R);
  //oi->setder( 5, G);
  //oi->setder( 6, B);
  //oi->setder( 7, A);


  sums = (float *)malloc(sizeof(float)*4*11);
  orbits->getSums(0, 11, sums);
  cerr<<"1st estimation"<<endl;
  for( int i=0; i<11*4; i++ ) cerr<<sums[i]<<" ";
  cerr<<endl;
  setMatrix(sums) ;
  free(sums);
  orbits->deactivate_fpbuffer();
  cerr<<"--------------"<<endl<<endl;

*/
}
