/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "GenericDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"
#include "FragPipeDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include "FindHighestFilter.h"
#include <assert.h>
#include <iostream>
#include <math.h> //fminf
#include "tools/graphicsHelpers.h"
#include <sys/time.h>
#include <time.h>
#include "Grab_JPEG.h"
using namespace std;

//new for the client Komputer stuff
#include "ShmFrame.h"
#include <getopt.h>

//Global tracked finger/hand state
float HAND_X_DERIV=0.0;
float HAND_Y_DERIV=0.0;
float HAND_THETA=0.0;
float HAND_THETA_MAG=0.0;
float HAND_X_COORD=160;
float HAND_Y_COORD=120;
float BOX_WIDTH=0.25;
float BOX_HEIGHT=0.25;
float TIP_X_COORD=160.0;
float TIP_Y_COORD=120.0;


///////////////////////begin global options
bool DEBUG=false;
bool DO_VISUALS=true;
bool DEFAULT_USE_SHM=false;
bool USE_SHM=DEFAULT_USE_SHM;
bool USE_IBOT=true;

/// Uses Full image for statistics.
bool useFullImage=false;
/// Adapts box search size to react to size of blob that is tracked
bool useAdaptiveBoxSize=true;

/// Allows more reliable tracking of the top of the finger tip
/// by relaxing the adaptive box's top coorinate (so the 
/// finger can be higher up w.r.t the blob centroid
bool trackFingerTip=false;

/// Standalone SHM sends tracking results into shared memory, but
/// receives data from the 1394 source directly.
bool standaloneSHM = false;
/////////////////////end global options


int MAX_PCI_HEADS=5;

// Global display object
FragPipeDisplay *d;
Dc1394 *dc1394;
GenericFilter *filter1, *filter2, *filter3, *filter4;
GenericFilter *nopFilter;
FindHighestFilter *fhf;
MomentFilter *momentFilter;
Grab_JPEG *grabber;


int imageWinWidth = 320;
int imageWinHeight = 240;

int imageSrcWidth = 320;
int imageSrcHeight = 240;
int viewbuf = 0;
Window  Orbwin;
bool exec_tracking=false;

// Komputer interface
int client_id =-1;
ShmFrame *shmFrame;

/*
 * The other handtracker
 */
int other_hand_id=-1;
ShmFrame *otherHandShm;


/*
 * Do one iteration of the tracking
 */
void render_visuals() ;


/*
 * Variance stuff
 */
bool LOST_PROCESS=true;
float LOST_PROCESS_THRESHOLD=20;
int MIN_CONSECUTIVE_FINGERTIP=5;
float Y_MOVING_VAR_AVG_THRESH=0.8;
float X_MOVING_VAR_AVG_THRESH=0.9;
int MIN_TIME=500; // min milliseconds between variance events
#define VARIANCE_HIST 15
float varianceMovingAverageX[VARIANCE_HIST];
float varianceMovingAverageY[VARIANCE_HIST];
int positionMovingAverageX[VARIANCE_HIST];//stacks with variance
int positionMovingAverageY[VARIANCE_HIST];
int variance_curr = 0;
int get_next_variance_index() {
  variance_curr++;
  if(variance_curr == VARIANCE_HIST) {
    variance_curr=0;
  }
  return variance_curr;
}
void addVariance(float var_x, float var_y, int x, int y) {
  if( isinf(var_x) != 0 || isnan(var_x) || 
      isinf(var_y) != 0 || isnan(var_y) ) {
    // nan of inf, don't add
    return;
  }
  int index=get_next_variance_index();
  varianceMovingAverageX[index]=var_x;
  varianceMovingAverageY[index]=var_y;
  positionMovingAverageX[index]=x;
  positionMovingAverageY[index]=y;
}
// should throw out outliers for moving average
void getMovingVarPosAvg(float *var_x, float *var_y, int *pos_x, int *pos_y) {
  float sumVarX=0, sumVarY=0;
  int sumPosX=0, sumPosY=0;
  for(int i=0;i<VARIANCE_HIST;i++) {
    sumVarX+=varianceMovingAverageX[i];
    sumVarY+=varianceMovingAverageY[i];
    sumPosX+=positionMovingAverageX[i];
    sumPosY+=positionMovingAverageY[i];
  }
  *var_x=fabsf(sumVarX/VARIANCE_HIST);
  *var_y=fabsf(sumVarY/VARIANCE_HIST);
  *pos_x=sumPosX/VARIANCE_HIST;
  *pos_y=sumPosY/VARIANCE_HIST;

  // safety test for NaN
  if( isinf(*var_x) != 0 || isnan(*var_x) || 
      isinf(*var_y) != 0 || isnan(*var_y) ) {
    // nan of inf, never supposed to happen
    cout<<"FUCKED UP NaN, *var_x="<<*var_x<<" *var_y="<<
      *var_y<<endl;
    exit(-1);
  }
}



////// GLUT CALLBACKS ///////////////
void reshape(int w, int h) {
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  //rosco version
  glFrustum(-1.0,1.0,-1.0,1.0,1.0,100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,-1.0,   0.0, 1.0, 0.0);

  //james version
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);

  //set the fpbuffer to have geometry identical to screen
  d->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  d->deactivate_fpbuffer();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle() {
  usleep(500);
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y) {
  glutSetWindow(Orbwin);
   switch (key) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
         viewbuf = atoi((const char * )&key);
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

void MouseFunc( int button, int state, int x, int y) {
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        float pixbuf[4] = {0.0};
        cerr << "("<<x<<","<<y<<"):";
        glReadPixels( x,imageWinHeight-y, 1,1, GL_RGBA, GL_FLOAT,  pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
      }
      break;
    case GLUT_RIGHT_BUTTON : 
      break;
  }
}

unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(imageSrcWidth*imageSrcHeight*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(imageSrcWidth*imageSrcHeight*3);
void render_client() {

  static bool clientHasFrames = false;
  static bool workToDo=false; 
  
  //task PRE amble :
  //continue or start working case
  if( shmFrame->Frame->requested_chirps > 0 ) {
    //check if we need to update image set
    shmFrame->enterMutex();
    if( shmFrame->Frame->isNew ) {
      if(DEBUG) cerr<<"Received new Frame[0] , id = "<<shmFrame->getID()<<endl;
      //overridde dc1394 areas
      dma_buf_rgb=(unsigned char *)shmFrame->getData();
      //commen out below to not enable visuals
      DO_VISUALS=true;
      if(DEBUG) cerr<<"Bound new frame ok "<<endl;
      shmFrame->Frame->requested_chirps=0;
      shmFrame->Frame->isNew = false; 
    } else {
      cout <<"old frame"<<endl;
    } 
    shmFrame->leaveMutex();
    
    //turn on estimation engine
    exec_tracking = true;
  } 
  else  {
    exec_tracking = false;
    usleep(500);//sleep for 1ms. should be okay at 33ms/frame
    //sched_yield();//sleep for 1ms. should be okay at 33ms/frame
  }

  //do da wurk, one repetition
  //render redirect does the tracking?
  if(DO_VISUALS) {
    render_visuals();
  }
}

int newdata=0;
/* Tell function executed in context of Dc1394 thread */
void TellRWMHeCanUseImage(const char *dma_buf_) {
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;

  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;
  uyvy2rgb(dma_buf,dma_buf_rgb,imageSrcWidth*imageSrcHeight);

  //have only one, need two before we do any orbits
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,imageSrcWidth*imageSrcHeight);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }

  newdata=1;
}


/*
 * Draw line representing average finger derivative
 */
void drawDerivative() {
  normDrawLine(HAND_X_COORD/imageWinWidth, HAND_Y_COORD/imageWinHeight,
	       (HAND_X_COORD-HAND_X_DERIV)/imageWinWidth, (HAND_Y_COORD-HAND_Y_DERIV)/imageWinHeight);
}

/*
 * Draw circle on finger tip.
 */
void drawFingerTip() {
  normDrawCircleHelper(HAND_X_COORD/(float)imageWinWidth, 
		   HAND_Y_COORD/(float)imageWinHeight);
  if( trackFingerTip) 
    normDrawCircleHelper(TIP_X_COORD/(float)imageWinWidth, 
		     TIP_Y_COORD/(float)imageWinHeight);
}

///fung version - set box width based on size of 0th moment (number of skin pixels)
void setBoxWidth(float M_00) {
  static const float min_width = 0.10;
  BOX_WIDTH = 1.4*sqrt(M_00)/(float)imageWinWidth;
  if( BOX_WIDTH < min_width )
    BOX_WIDTH=min_width;
}

/*
 * Set a new hand coord and trigger stats keeping sideeffect
 */ 
// average the last five derivatives
#define DERIV_HIST 5
int deriv_counter=0;
float hand_x_derivs[DERIV_HIST]={0,0,0,0,0}, hand_y_derivs[DERIV_HIST]={0,0,0,0,0}, 
  hand_thetas[DERIV_HIST]={0,0,0,0,0};
void setHandCoord(float x, float y) {
  float OLD_HAND_X_COORD=HAND_X_COORD;
  float OLD_HAND_Y_COORD=HAND_Y_COORD;

  HAND_X_COORD=x;
  HAND_Y_COORD=y;
  
  // average the last five derivatives
  deriv_counter++;
  if(deriv_counter%DERIV_HIST==0) {
    deriv_counter=0;
  }
  hand_x_derivs[deriv_counter]=HAND_X_COORD-OLD_HAND_X_COORD;
  hand_y_derivs[deriv_counter]=HAND_Y_COORD-OLD_HAND_Y_COORD;
  // put a - infront of Y since our +Y is downwards
  float theta_i=atan(-HAND_Y_DERIV/HAND_X_DERIV);
  hand_thetas[deriv_counter]=theta_i;
  
  /*  static bool do_once=false;
      if(!do_once){
      cout<<"fucking weird bug, ctr="<<deriv_counter<<endl;
      do_once=true;
      }
  */
  
  float x_avg=0.0, y_avg=0.0, theta_avg=0.0;
  int found_a_large_deriv=0;
  for(int i=0; i<DERIV_HIST; i++) {
    x_avg+=hand_x_derivs[i];
    y_avg+=hand_y_derivs[i];
    if(hand_x_derivs[i] > LOST_PROCESS_THRESHOLD || 
       hand_y_derivs[i] > LOST_PROCESS_THRESHOLD) {
      found_a_large_deriv++;
    }
    theta_avg+=hand_thetas[i];
  }
  if(found_a_large_deriv>2) {
    if(!LOST_PROCESS) {
      cout<<"LOST -- USING 0th MOMENT"<<endl;
      // clear derivatives
      for(int i=0; i<DERIV_HIST; i++) {
	hand_x_derivs[i]=0;
	hand_y_derivs[i]=0;
	hand_thetas[i]=0;
      }
    }
    LOST_PROCESS=true;
  } else {
    if(LOST_PROCESS) {
      cout<<"FOUND -- USING SECOND MOMENT"<<endl; 
      // clear derivatives
      for(int i=0; i<DERIV_HIST; i++) {
	hand_x_derivs[i]=0;
	hand_y_derivs[i]=0;
	hand_thetas[i]=0;
      }
    }
    LOST_PROCESS=false;
  }
  HAND_X_DERIV=x_avg/DERIV_HIST;
  HAND_Y_DERIV=y_avg/DERIV_HIST;
  HAND_THETA_MAG=sqrtf(HAND_X_DERIV*HAND_X_DERIV+
		       HAND_Y_DERIV*HAND_Y_DERIV);
  HAND_THETA=theta_avg/DERIV_HIST;
  //  cout<<"avg = ("<<x_avg<<","<<y_avg<<")"<<endl;


    /*
     * If we are "close" to other hand tracker, re-initialize to the far corner.
     */
    if( USE_SHM && otherHandShm!=0 ) {
      int other_x = otherHandShm->Frame->hand_x_320;
      int other_y = otherHandShm->Frame->hand_y_240;
      
      if(other_x - HAND_X_COORD < 10 && 
	 other_y - HAND_Y_COORD < 10) {
	HAND_X_COORD = (float)imageWinWidth-other_x;
	HAND_Y_COORD = (float)imageWinHeight-other_y;
      }
    }


    /*
     * Let other clients read my results.
     * Hand Locations, and Hand Color Values
     */
    if(USE_SHM || standaloneSHM ) {
      if( trackFingerTip ) {
        shmFrame->Frame->hand_x_320 = (int)TIP_X_COORD;
        shmFrame->Frame->hand_y_240 = (int)TIP_Y_COORD;
	shmFrame->Frame->hand_x_640 = (int)TIP_X_COORD*2;
        shmFrame->Frame->hand_y_480 = (int)TIP_Y_COORD*2;
      } else {
        shmFrame->Frame->hand_x_320=(int)HAND_X_COORD;
        shmFrame->Frame->hand_y_240=(int)HAND_Y_COORD; 
	shmFrame->Frame->hand_x_640=(int)HAND_X_COORD*2;
        shmFrame->Frame->hand_y_480=(int)HAND_Y_COORD*2; 
	//cout<<"wrote shm ("<<shmFrame->Frame->hand_x_320<<","<<shmFrame->Frame->hand_y_240<<")"<<endl;
      }
      // refer to the cg file FP-ds1.cg to see what these correspond to
      shmFrame->Frame->thresh_x=0.09;//HARD CODE???
      //      shmFrame->Frame->thresh_y=result[3]/result[0];
      shmFrame->Frame->thresh_w=0.15;
      shmFrame->Frame->thresh_z=0.90;
    }

}

int slowdown=0;

void doMoment()
{
    float result[4] = {0.0};
    d->applySumFilter(momentFilter, 4, 5, result );

    //cerr<<"M = ["<<result[0]<<", "<<result[1]<<", ";
    //cerr<<result[2]<<", "<<result[3];
    //cerr<<"M_x ="<<result[1]/result[0]<<",M_y ="<<result[2]/result[0]<<endl;
    //cerr<<"Avg S : "<<result[3]/result[0]<<endl;
   
    // RESULT OF 0 holds 0'th moment, # of skin pixels

    //make sure that enough pixels are actually recognized as skin
    if( result[0] > imageWinWidth*imageWinHeight*0.75 || result[0] < 0.001*imageWinWidth*imageWinHeight) {
      if(++slowdown==100) {
	cerr<<"bad stats"<<endl;
	slowdown=0;
      }
      return;
    }

    setHandCoord(result[1]/result[0],result[2]/result[0]);


    /*
     * If we are "close" to other hand tracker, re-initialize to the far corner.
     */
    if( USE_SHM && otherHandShm!=0 ) {
      int other_x = otherHandShm->Frame->hand_x_320;
      int other_y = otherHandShm->Frame->hand_y_240;
      
      if(other_x - HAND_X_COORD < 10 && 
	 other_y - HAND_Y_COORD < 10) {
	HAND_X_COORD = (float)imageWinWidth-other_x;
	HAND_Y_COORD = (float)imageWinHeight-other_y;
      }
    }


    /*
     * Let other clients read my results.
     * Hand Locations, and Hand Color Values
     */
    if(USE_SHM || standaloneSHM ) {
      if( trackFingerTip ) {
        shmFrame->Frame->hand_x_320 = (int)TIP_X_COORD;
        shmFrame->Frame->hand_y_240 = (int)TIP_Y_COORD;
	shmFrame->Frame->hand_x_640 = (int)TIP_X_COORD*2;
        shmFrame->Frame->hand_y_480 = (int)TIP_Y_COORD*2;
      } else {
        shmFrame->Frame->hand_x_320=(int)HAND_X_COORD;
        shmFrame->Frame->hand_y_240=(int)HAND_Y_COORD; 
	shmFrame->Frame->hand_x_640=(int)HAND_X_COORD*2;
        shmFrame->Frame->hand_y_480=(int)HAND_Y_COORD*2; 
	//cout<<"wrote shm ("<<shmFrame->Frame->hand_x_320<<","<<shmFrame->Frame->hand_y_240<<")"<<endl;
      }
      // refer to the cg file FP-ds1.cg to see what these correspond to
      shmFrame->Frame->thresh_x=0.09;//HARD CODE???
      shmFrame->Frame->thresh_y=result[3]/result[0];
      shmFrame->Frame->thresh_w=0.15;
      shmFrame->Frame->thresh_z=0.90;
    }

    //XXX ADAPTATION DOESNT WORK IF NO MOMENT CALCULATION
    float thresh[4] = {result[3]/result[0], result[3]/result[0], 0.008, 0.1};
    filter2->setCGParameter("thresh", thresh);
    // setboxwidth here, moved

}


/*
 * Get normalized coords of edges of box
 */
void getBoxEdges(float *l, float *r, float *t, float *b) {
  *l = fmaxf(0.0,HAND_X_COORD/(float)imageWinWidth-BOX_WIDTH); 
  *r = fminf(1.0,HAND_X_COORD/(float)imageWinWidth+BOX_WIDTH); 
  *t = fmaxf(0.0,HAND_Y_COORD/(float)imageWinHeight-BOX_HEIGHT); 
  *b = fminf(1.0,HAND_Y_COORD/(float)imageWinHeight+BOX_HEIGHT);
  //l=0.25, r=0.75, t=0.25, b=0.75; cerr << l << r<<t<<b<<endl;

  if( trackFingerTip ) 
    *t = fminf(1.0,HAND_Y_COORD/(float)imageWinHeight-BOX_HEIGHT*2);
}


/*
 * Draw GL bounding box
 */
void drawBoundingBox(float l, float r, float t, float b)
{
  float z = -1.0;

  //cerr << l << r<<t<<b<<endl;

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glClear(GL_DEPTH_BUFFER_BIT);
   glColor4f( 0.0, 1.0, 0.0, 1.0);
   glBegin(GL_LINES);
     glVertex3f( l, t, z);
     glVertex3f( r, t, z);
  
     glVertex3f( l, b, z);
     glVertex3f( r, b, z);

     glVertex3f( l, t, z);
     glVertex3f( l, b, z);

     glVertex3f( r, t, z);
     glVertex3f( r, b, z);
   glEnd();

}

//XXX I BROKE FINGER TIP -- DIFF BUFFER NAME?
float foo[720*480*4];
void findFingerTip(float r, float l, float *x, float *y)
{ 
  float pixbuf[4]; 
  int numpix = (int)( (float)imageWinWidth*(r-l) );
  float highest_position_x=-1.0;
  float highest_position_y=(float)imageWinHeight+10;
  if( DEBUG )cerr<<"Scanning "<<numpix<<" pixels"<<endl;
  glReadPixels( (int)(l*imageWinWidth), 0, numpix,1, GL_RED, GL_FLOAT,  foo);

  //prevent jitter by cropping scan window to be local to last tracked tip?
  int startindex = 2;
  int endindex = numpix;

  for( int i=startindex; i<endindex ; i++ ) { 
    if( foo[i] < highest_position_y ) { 
      highest_position_y = foo[i];
      highest_position_x = i;
    }
  }
  if( DEBUG )cerr<<"Position: "<<highest_position_x+(imageWinWidth*l)<<", "<<highest_position_y<<endl;
  *x = highest_position_x+(imageWinWidth*l);
  *y = highest_position_y;
}

void doFPBuffer(float l, float r, float t, float b) {
  d->activate_fpbuffer();
  d->clear_fpbuffer();
  //d->reinit_texture(0, imageWinWidth, imageWinHeight, dma_buf_rgb);
  d->reinit_texture(0, imageSrcWidth, imageSrcHeight, dma_buf_rgb);
  d->bindTextureARB0(0);
  //XXX keep it for longer to do variane stuff
  //if( !USE_SHM ) dc1394->tellThreadDoneWithBuffer();
  
  //cascade the filters
  if(USE_IBOT) {
    d->applyFilter(filter1, 0,1);//undistort
  } else {
    d-> applyFilter(nopFilter, 0,1);//do nothing
  }

  d->clear_fpbuffer();
  d->applyFilter(filter2, 1,2,l,r,t,b );//hsv conv + thresh
  d->applyFilter(filter3, 2,3,l,r,t,b );//dilate
  d->applyFilter(filter4, 3,4,l,r,t,b );//erode

  // fills in texture unit 5
  // DONT DO MOMENT
  if(LOST_PROCESS) {
    doMoment();//intensive. Not GFX card efficient utilization, but it works.
  }
}


/*
 * Adapt box size using the x and y variances (2nd moment)
 */
void adaptBoxSize(float x_var, float y_var) {
  if( isinf(x_var) != 0 || isnan(x_var) || 
      isinf(y_var) != 0 || isnan(y_var) ) {
    // cout<<"don't use"<<endl;
    return;
  } else {
    // setBoxWidth(result[0]);
    int box_width_i=(int)floorf(BOX_WIDTH*imageWinWidth);
    int box_height_i=(int)floorf(BOX_HEIGHT*imageWinHeight);
    if(DEBUG) {
      cout<<"x_var="<<x_var<<" yvar="<<y_var<<
	" boxw="<<box_width_i<<
	"boxh="<<box_height_i<<endl;
    }
      
    // if it fills a large portion, grow
    //    if(x_var/box_width_i > 0.4) {
    if(14*sqrtf(x_var)>box_width_i) {
      BOX_WIDTH*=1.08;
    } else {
      BOX_WIDTH/=1.10;
    }
    BOX_WIDTH=fmaxf(0.10, fminf(0.80, BOX_WIDTH));

    /*
     * This new way of doing it hugs finger very tightly
     * and follows finger, not whole hand.  
     */
    // if it fills a large portion, grow
    //    if(y_var/box_height_i > 0.35) {
    if(12*sqrtf(y_var) > box_height_i) {
      //      cout<<"grow height"<<4*sqrtf(y_var)<<endl;
      BOX_HEIGHT*=1.08;
    } else {
      BOX_HEIGHT/=1.10;
    }
    BOX_HEIGHT=fmaxf(0.10, fminf(0.80, BOX_HEIGHT));
  }
}

/*
 * fill in glreadbuffer.  Return number of pixels that were skin.
 */
float glreadbuffer[320*240*3];
int fillVarianceBuffer(float l, float r, float t, float b, float *x_var, float *y_var, bool findHigherFingerpoint) {
  int left=(int)(imageWinWidth*l);
  int bottom=(int)(imageWinHeight*b);
  int width=(int)((r-l)*imageWinWidth);
  int height=(int)((b-t)*imageWinHeight);
  int top=(int)(t*imageWinHeight);

  // weird -- man page says "first pixel is bottom left"
  // but i guess in raster coords (2nd quadrant) first
  // pixel is top left, read forwards from there.
  glReadPixels(left, top, width, height, GL_BLUE,
	       GL_FLOAT, glreadbuffer);
  
  float x_variance_sum=0.0, y_variance_sum=0.0;
  int pixel_counter=0;
  for(int j=0; j<height; j++) {
    int consecutive=0;
    for(int i=0; i<width; i++) {
      if(glreadbuffer[j*width+i]!=0) {
	x_variance_sum+=fabsf((i+left)-HAND_X_COORD);
	y_variance_sum+=fabsf((j+top)-HAND_Y_COORD);
	pixel_counter++;

	if(findHigherFingerpoint) {
	  if(++consecutive==MIN_CONSECUTIVE_FINGERTIP) {
	    int y=top+j;
	    int x=left+i;
	    setHandCoord(x,y);
	    //stop searching
	    findHigherFingerpoint=false;
	  }
	}

      }
    }
  }

  if(pixel_counter!=0) {
    *x_var=x_variance_sum/pixel_counter; 
    *y_var=y_variance_sum/pixel_counter; 
  }
  return pixel_counter;
}

/*
 * See if any clicks are to be processed
 */
void doClickProcessing(float x_var,float y_var) {
  float movingVarX, movingVarY;
  int movingX,movingY;
  getMovingVarPosAvg(&movingVarX, &movingVarY, &movingX, &movingY);
  if(DEBUG) {
    cout<<"moving var avg is ("<<movingVarX<<","<<movingVarY
	<<"), y_var="<<y_var<<" x_var="<<x_var<<endl;
  }
  
  static struct timeval prev_click_time;
  static struct timezone mytz;
  static bool first_run=true;
  if(first_run) {
    mytz.tz_minuteswest=5*60;
    gettimeofday(&prev_click_time, &mytz);
    first_run=false;
  }
  struct timeval currtime;
  gettimeofday(&currtime, &mytz);
  int elapsed_milli=(currtime.tv_sec-prev_click_time.tv_sec)
    *1000+(currtime.tv_usec-prev_click_time.tv_usec)/1000;

  // right hand must move down and to the left
  if(elapsed_milli >= MIN_TIME
     && y_var <= Y_MOVING_VAR_AVG_THRESH*movingVarY 
     && x_var >= X_MOVING_VAR_AVG_THRESH*movingVarX
     && ((HAND_THETA >= 0 && HAND_THETA <= 3.14/2)
	 || HAND_THETA_MAG <= 5)) {
    prev_click_time.tv_sec=currtime.tv_sec;
    prev_click_time.tv_usec=currtime.tv_usec;
    cout << "CLICK at ("<<movingX<<","<<movingY<<")"<<endl;
    // 1 for down, set with moving avg to keep it in same
    // location
    if(USE_SHM) {
      shmFrame->Frame->MOUSE_SIGNAL = 1;
      shmFrame->Frame->MOUSE_SIGNAL_x_320 = movingX;
      shmFrame->Frame->MOUSE_SIGNAL_y_240 = movingY;
    }
  }

  // right hand unclick, up and to the right
  if(elapsed_milli >= MIN_TIME
     && y_var >= (1/Y_MOVING_VAR_AVG_THRESH)*movingVarY 
     && x_var <= (1/X_MOVING_VAR_AVG_THRESH)*movingVarX
     && ((HAND_THETA <= 0 && HAND_THETA >= -3.14/2)
	 || HAND_THETA_MAG <= 5)) {
    prev_click_time.tv_sec=currtime.tv_sec;
    prev_click_time.tv_usec=currtime.tv_usec;
    cout << "UNCLICK at ("<<movingX<<","<<movingY<<")"<<endl;

    //2 for up
    if(USE_SHM) {
      shmFrame->Frame->MOUSE_SIGNAL = 2;
      shmFrame->Frame->MOUSE_SIGNAL_x_320 = movingX;
      shmFrame->Frame->MOUSE_SIGNAL_y_240 = movingY;
    }
  }

}

/*
 *ROSCO Compute x variance within the window
 */
void processVariance(float l, float r, float t, float b, bool findHigherFingerpoint) {
  float x_var=0.0, y_var=0.0;
  int pixel_counter=fillVarianceBuffer(l,r,t,b, &x_var, 
				     &y_var, 
				     findHigherFingerpoint);
  if(pixel_counter == 0) {
    // do nothing
    return;
  }

  addVariance(x_var, y_var, (int)HAND_X_COORD, (int)HAND_Y_COORD);
 
  doClickProcessing(x_var, y_var);
  
  if( useAdaptiveBoxSize ) {
    adaptBoxSize(x_var,y_var);
  }

}

int framecounter=0;
void render_visuals() {
  ++framecounter;
/*
  if(!newdata)  {  struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 1000;
  select(0,0,0,0, &tv);
  return;}
  newdata = 0; 
*/

  float l,r,t,b;
  if( useFullImage ) { 
    l=0;     r=1.0;    t=0;    b=1.0;
  } else {
    getBoxEdges(&l,&r,&t,&b);
  }
 
  doFPBuffer(l,r,t,b);

  if( !USE_SHM ) 
    dc1394->tellThreadDoneWithBuffer();
  //note: before we deactivate fpbuffer, don't issue and GL draw cmds
  
  bool findHigherFingerpoint=false;
  if(!LOST_PROCESS) {
    findHigherFingerpoint=true;
  }
  processVariance(l,r,t,b, findHigherFingerpoint);
  
  //now we can use the variance buffer to "hill climb" 
  // and push the box up, and pick lowest x,y

  d->deactivate_fpbuffer();
  d->bindTextureARB0(viewbuf);
  d->render();

  if( trackFingerTip) {
    d->applyFilter(fhf, 3, 4, l,r,0.0,1.0/(float)imageWinHeight);
    findFingerTip(r,l, &TIP_X_COORD, &TIP_Y_COORD);
  }
  
  if( !useFullImage ) {
    drawBoundingBox(l,r,t,b);
  }
  drawFingerTip();
  
  drawDerivative();
                                                                                                                        
    /*
     *    * Grab a frame
     *       */
    int grabGLFrame=1;
      if(grabGLFrame) {
		      grabber->grab_frameGL(320,240, true);
		        }

  d->showstats();
  glutSwapBuffers();
}  

void runTrack(){
  if( USE_SHM ) 
    render_client();
  else {
    render_visuals();
  }
}

/********************
 Create Shm area
********************/
void createSharedMemoryArea(int id) {
  
  //create shared memory areas, an image pair 0/1 for each head (card)
  int frame0ID = id*2-2;
  assert(id>=0);
  shmFrame = new ShmFrame(frame0ID);

  if(other_hand_id != -1) {
    cout<<"Other hand id="<<other_hand_id<<endl;
    int handframeShmId = other_hand_id*2-2;
    otherHandShm = new ShmFrame(handframeShmId);
    cerr<<"Shared Memory: images are "<<otherHandShm->Frame->width<<"x";
    cerr<<otherHandShm->Frame->height<<"x"<<3<<endl;
  } else {
    cerr<<"Other hand id is -1"<<endl;
    cerr<<"Shared Memory: images are "<<shmFrame->Frame->width<<"x";
    cerr<<shmFrame->Frame->height<<"x"<<3<<endl;
  }

} 


/********************
 * Parse cmd line options
 ********************/
void posixify(int argc, char * argv[]){} //fill in from orbits version

static struct option long_options[] = {
  {"client", 0, 0, 'c'},
  {"verbose", 0, 0, 'v'},
  {"help", 0, 0, 'h'},
  {"other-hand", 0, 0, 'o'},
  {"fullimage",0,0,'f'},
  {"tip",0,0,'t'},
  {"noAdaptive",0,0,'A'},
  {"standalone",0,0,'s'},
  {0,0,0,0}
};

void printHelp()
{
  cout<<"skintrack. "<<endl; 
  cout<<"  when no client id given it uses 1394 input."<<endl;
  cout<<"  when a client id is used, it reads video from that client area"<<endl;
  cout<<"skintrack options:"<<endl;
  cout<<"   -n --no-radial    \t: turn off filter that corrects ibot"<<endl;
  cout<<"   -c --client [id]  \t: run this instance as a client, with given id"<<endl;
  cout<<"   -v --verbose      \t: verbose output"<<endl;
  cout<<"   -h --help         \t: print this help message, and quit"<<endl;
  cout<<"   -o --other-hand   \t: client id of other hand tracker to avoid"<<endl;
  cout<<"   -A --noAdaptive   \t: disable adaptive box sizing"<<endl;
  cout<<"   -f --fullimage    \t: use entire image to track. slow."<<endl;
  cout<<"   -t --tip          \t: enable finger tip tracking."<<endl;
  cout<<"   -s --standalone id\t: use as standalone, but send results to Shared Memory"<<endl;
  cout<<" Oh, and use -display :0.1 *before* the above options to run on another screen"<<endl;
  cout<<endl;
}

void parse_cmdline(int argc, char **argv)
{
   char c;
   opterr = 0; /* prevent weird options from causing errors */
   posixify(argc,argv);

   while(1) {
     int this_option_optind = optind ? optind : 1;
     int option_index = 0;
     c = getopt_long (argc, argv, "c:o:nhvfAts:",
                      long_options, &option_index);
     if (c == -1) break;
     switch(c) {

     case 'n':
       USE_IBOT=false;
       break;
     case 'f' : //use full image tracking. does not crop region.
       useFullImage = true;
       break;

     case 't' : //track finger tip
       trackFingerTip = true;
       break;

     case 'A' : //disable adaptive box size  0.5x0.5 region is used instead
       useAdaptiveBoxSize = false;
       break;
 
     case 's' : //standalone, but put results into SHM area
       client_id = atoi(optarg);
       if( client_id < 0 || client_id > MAX_PCI_HEADS ) {
         cerr<<"Invalid Client ID "<<client_id<<" requested. aborting."<<endl;
         cerr<<"Client ID must lie in closed interval [0,5]"<<endl;
         exit(1);
       }
       cerr<<"Initializing as client ID "<<client_id<<endl;
       standaloneSHM = true;
       break;
     
     case 'c' :
       client_id = atoi(optarg);
       if( client_id < 0 || client_id > MAX_PCI_HEADS ) {
         cerr<<"Invalid Client ID "<<client_id<<" requested. aborting."<<endl;
         cerr<<"Client ID must lie in closed interval [0,5]"<<endl;
         exit(1);
       }
       cerr<<"Initializing as client ID "<<client_id<<endl;
       USE_SHM=true;
       break;

     case 'o' : //hand tracker information
       cout<<"Parsing other ahnd id"<<endl;
       other_hand_id = atoi(optarg);
       if( other_hand_id < 0 || other_hand_id > 5 ) {
         cerr<<"Invalid other handtracker ID "<<other_hand_id<<" requested. aborting."<<endl;
         cerr<<"handtracker ID must lie in closed interval [0,5]"<<endl;
         exit(-1);
       }
       break;    

     case 'v' : //print help
       DEBUG=true; 
       break;

     case 'h' : //print help
       printHelp();
       exit(0);
       break;

     default :
       cerr<<"WARNING: unknown switch "<<c<<endl;
     }

   }
}



///// MAIN ///////////////////

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   parse_cmdline(argc,argv);

                                                                                                                           
     grabber = new Grab_JPEG();
       grabber->vindex=9000000;

   if( USE_SHM || standaloneSHM) {
     cout <<"creating shm area"<<endl;
     createSharedMemoryArea(client_id);
     cout <<"done creating shm area"<<endl;
   }


   glutSetWindow(Orbwin);
   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);

   if( !USE_SHM ) {
     dc1394=new Dc1394();
     dc1394->start();
   }

   d=new FragPipeDisplay(8, imageWinWidth, imageWinHeight, Orbwin );

   d->initDisplay();
   d->setImageSize( imageWinWidth,imageWinHeight );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-basic.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?

   //d->activate_fpbuffer();
   //initial texture holds raw data, use Src Image size
   d->init_texture(0, imageSrcWidth, imageSrcHeight, foo);

   //subsequent passes use proceesing size (imageWin)
   d->init_texture4f(1, imageWinWidth, imageWinHeight, foo);
   d->init_texture4f(2, imageWinWidth, imageWinHeight, foo);
   d->init_texture4f(3, imageWinWidth, imageWinHeight, foo);
   d->init_texture4f(4, imageWinWidth, imageWinHeight, foo);
   d->init_texture4f(5, imageWinWidth, imageWinHeight, foo);

   filter1 = new GenericFilter(imageSrcWidth,imageSrcHeight, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-ibot-undistort.cg");
   nopFilter = new GenericFilter(imageSrcWidth,imageSrcHeight, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-nop.cg");

   filter2 = new GenericFilter(imageWinWidth,imageWinHeight, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-rgb2hsv.cg");
   //initial saturation guess. 0.6 good for pyro, 0.4 for ibot
   float thresh[4] = {0.030, 0.40, 0.02, 0.12};
   filter2->setCGParameter("thresh", thresh);
   filter3 = new GenericFilter(imageWinWidth,imageWinHeight, 
			       d->getContext(), d->getProfile(), 
                               "FPsamples/FP-dilate.cg");
   filter4 = new GenericFilter(imageWinWidth,imageWinHeight, 
			       d->getContext(), d->getProfile(), 
                               "FPsamples/FP-erode.cg");


   momentFilter = new MomentFilter(imageWinWidth, imageWinHeight, d->getContext(), d->getProfile() );
   fhf = new FindHighestFilter(imageWinWidth,imageWinHeight,d->getContext(), d->getProfile());

   glutDisplayFunc(runTrack);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}
