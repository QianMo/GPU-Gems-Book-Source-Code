/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _FRAGPIPEDISPLAY_H
#define _FRAGPIPEDISPLAY_H
#include "SimpleDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"

class FragPipeDisplay : public SimpleDisplay
{
  public:
    FragPipeDisplay(int n, int w, int h, int win);
    void bindTextureARB1(int);
    void bindTextureARB2(int);
    CGcontext getContext();
    CGprofile getProfile();
    void applyFilter(GenericFilter *filter, int t_source, int t_sink);
    void applyFilter(GenericFilter *filter, 
                            int t_source, int t_sink,
                            float l, float r, float t, float b) ;
    void applyFilter(GenericFilter *filter, 
                            int t_source, int t_sink,
                            float l, float r, float t, float b, float f) ;
    void applySumFilter(MomentFilter *filter, 
                            int t_source, int t_tmp, float *result );
    void render();
};

#endif
