/*
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "libopenvidia.h"
#include <iostream>
using namespace std;

// Global display object
FragPipeDisplay *d;
Dc1394 *dc1394;
ImlibCapture *im;
GenericFilter *filter1, *filter2, *filter3, *filter4;
MomentFilter *momentFilter;
BoxApp *boxApp;
Correspond *corr;
onv_3dsLoader *myLoader;

float result[12] = {0,0,0,0,0,0,0,0,0,0,0,0};
GLfloat light_ambient[] = { 0.5, 0.5, 0.5, 1.0 };
GLfloat light_diffuse[] = { 60.0, 60.9, 60.9, 1.0 };
GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };
GLfloat light_position[] = { 0.0, 5.0,  0.0, 1.0 };


int imageWinWidth = 320;
int viewbuf = 0;
int imageWinHeight = 240;
Window  Orbwin;


///global state
bool useImlib = false;
bool useModel = false;
char *imageFileName = NULL;
char *modelFileName = NULL;
float HAND_X_COORD=0.0;
float HAND_Y_COORD=0.0;
float rotZ = 0.0;
float sc = 1.0;

int numClickCorners = 0;

float gl_x=0.0;
float gl_y=0.0;

void reshape(int w, int h);
void myIdle();
void keyboard (unsigned char key, int x, int y);
void MouseFunc( int button, int state, int x, int y) ;
void drawFingerTip();
void doMoment();
void drawCircleHelper(float x, float y);
void TellRWMHeCanUseImage(const char *dma_buf_) ;
unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(320*240*3);
int framecounter=0;
int newdata=0;
float *foo[320*240*4];

double f = 368.28488;
double ox = 147.54834;
double oy = 126.01673;

double imageWidth = (double)imageWinWidth;
double imageHeight = (double)imageWinHeight;

float oxIm;
float oyIm;
float ozIm;
float XvecX;
float XvecY;
float XvecZ;
float YvecX;
float YvecY;
float YvecZ;
float ZvecX;
float ZvecY;
float ZvecZ;

float mX=0.0, mY= 0.0, mZ = 0.0;

int elapsedTime(struct timeval *start_time, struct timeval *end_time) {
   return (end_time->tv_sec*1000000+end_time->tv_usec)-
                (start_time->tv_sec*1000000+start_time->tv_usec);

}


void printProjectionMatrix()
{
  float pmatrix[16]={0};
  glGetFloatv( GL_PROJECTION_MATRIX, pmatrix);
  printf("%5f %5f %5f %5f\n", pmatrix[0], pmatrix[4], pmatrix[8], pmatrix[12]);
  printf("%5f %5f %5f %5f\n", pmatrix[1], pmatrix[5], pmatrix[9], pmatrix[13]);
  printf("%5f %5f %5f %5f\n", pmatrix[2], pmatrix[6], pmatrix[10], pmatrix[14]);
  printf("%5f %5f %5f %5f\n", pmatrix[3], pmatrix[7], pmatrix[11], pmatrix[15]);
}



void render_redirect() {
  ++framecounter;
    if( useImlib )  {
      d->reinit_texture(0, 320, 240, im->getRGBData() );
    }
    else {
      d->reinit_texture(0, 320, 240, dma_buf_rgb);
    }
//    d->bindTextureARB0(0);
    if (!useImlib) dc1394->tellThreadDoneWithBuffer();

    //cascade the filters
    glClear(GL_COLOR_BUFFER_BIT);

    d->applyFilter(filter1, 0,1 ,
                   -ox, (((double)imageWidth)-ox), 
                   (((double)imageHeight)-oy), -oy, f )  ;
    filter1->deactivate();

  gl_x = oxIm;
  gl_y = oyIm;
  //centers on right click position in cameragl system
  glMatrixMode(GL_MODELVIEW);
  glClear(GL_DEPTH_BUFFER_BIT);
  glLoadIdentity();
/*
  glBegin(GL_LINES);
    glColor4f(1.0,1.0,1.0,1.0);
    glVertex3f( gl_x, gl_y-100, f);
    glVertex3f( gl_x, gl_y+100, f);

    glVertex3f( gl_x-100, gl_y, f);
    glVertex3f( gl_x+100, gl_y, f);
  glEnd();
*/


  oxIm = result[0];
  oyIm = result[1];
  ozIm = result[2];
  XvecX = result[3];
  XvecY = result[4];
  XvecZ = result[5];
  YvecX = result[6];
  YvecY = result[7];
  YvecZ = result[8];
  ZvecX = result[9];
  ZvecY = result[10];
  ZvecZ = result[11];
  float scalef = 100.0;

  glMatrixMode(GL_MODELVIEW);
  glClear(GL_DEPTH_BUFFER_BIT);
  glLoadIdentity();
  /////glTranslatef(0.0, 0.0, -f);
/*
  glBegin(GL_LINES);
    glColor4f(1.0, 0.0, 0.0, 1.0);
    glVertex3f(oxIm, oyIm, ozIm);
    glVertex3f( oxIm+scalef*XvecX, oyIm+scalef*XvecY,  ozIm+scalef*XvecZ);
 
    glColor4f(0.0, 1.0, 0.0, 1.0);
    glVertex3f(oxIm, oyIm, ozIm);
    glVertex3f( oxIm+scalef*YvecX, oyIm+scalef*YvecY,  ozIm+scalef*YvecZ);

    glColor4f(0.0, 0.0, 1.0, 1.0);
    glVertex3f(oxIm, oyIm, ozIm);
    glVertex3f( oxIm+scalef*ZvecX, oyIm+scalef*ZvecY,  ozIm+scalef*ZvecZ);
  glEnd();
*/
  glMatrixMode(GL_MODELVIEW);
  glClear(GL_DEPTH_BUFFER_BIT);
  glLoadIdentity();
  //float Matrice[]={XvecX,XvecY,XvecZ,0,ZvecX,ZvecY, ZvecZ,0,-YvecX,-YvecY,-YvecZ,0,0,0,0,1};
  glTranslatef(oxIm, oyIm, ozIm);
  glScalef( scalef, scalef, scalef );
  float Matrice[16]={XvecX,XvecY,XvecZ,0,
                   YvecX,YvecY,YvecZ,0,
                   ZvecX,ZvecY, ZvecZ,0,
                    0,0,0,1};
  glMultMatrixf(Matrice);
/*
  cerr<<"Getting GL ModelView "<<endl;
  float modviewmat[16];
  glGetFloatv(GL_MODELVIEW_MATRIX, modviewmat);
  cerr<<modviewmat[0]<<" "<<modviewmat[1]<<" "<<modviewmat[2]<<" "<<modviewmat[3]<<endl;
  cerr<<modviewmat[4]<<" "<<modviewmat[5]<<" "<<modviewmat[6]<<" "<<modviewmat[7]<<endl;
  cerr<<modviewmat[8]<<" "<<modviewmat[9]<<" "<<modviewmat[10]<<" "<<modviewmat[11]<<endl;
  cerr<<modviewmat[12]<<" "<<modviewmat[13]<<" "<<modviewmat[14]<<" "<<modviewmat[15]<<endl;
*/

  glShadeModel(GL_SMOOTH);
  glEnable(GL_LIGHT0);
  glEnable(GL_LIGHT1);
  glEnable(GL_LIGHT2);
  glEnable(GL_LIGHTING);
  glEnable(GL_CULL_FACE);
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_TEXTURE_2D);
  //glEnable(GL_COLOR_MATERIAL);

  glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
  glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);


  glBegin(GL_LINES);
    glColor3f(1.0, 0.0, 0.0);
    glVertex4f( 0.0, 0.0, 0.0, 1.0);
    glVertex4f( 1.0, 0.0, 0.0, 1.0);
    
    glColor3f(0.0, 1.0, 0.0);
    glVertex4f( 0.0, 0.0, 0.0, 1.0);
    glVertex4f( 0.0, 1.0, 0.0, 1.0);

    glColor3f(0.0, 0.0, 1.0);
    glVertex4f( 0.0, 0.0, 0.0, 1.0);
    glVertex4f( 0.0, 0.0, 1.0, 1.0);
  glEnd();

  glScalef(sc,sc,sc);

  glRotatef(90, 1.0, 0.0, 0.0);
  glFlush();

  glBegin(GL_LINES);
    glColor3f(1.0, 1.0, 0.0);
    glVertex4f( 0.0, 0.0, 0.0, 1.0);
    glVertex4f( light_position[0],light_position[1], light_position[2], 1.0);
  glEnd();
  glLightfv(GL_LIGHT0, GL_POSITION, light_position);
  glEnable(GL_LIGHT0);

  glTranslatef(mX, mY, mZ);
  glRotatef(rotZ, 0.0, 1.0, 0.0);

  glShadeModel(GL_SMOOTH);
    GLfloat mat_specular[] = { 0.8, 0.8, 0.8, 1.0 };
    GLfloat mat_shininess[] = { 100.0 };

    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
    glMaterialfv(GL_BACK, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_BACK, GL_SHININESS, mat_shininess);

  //glScalef(sc,sc,sc);

  if( useModel ) myLoader->draw();


  d->showstats();
  glFlush();
  glutSwapBuffers();
  glDisable(GL_CULL_FACE);
  glDisable(GL_DEPTH_TEST);
}  

void posixify(int argc, char * argv[]){} //fill in from orbits version

static struct option long_options[] = {
  {"image",0,0,'i'},
  {"model",0,0,'m'},
  {"help",0,0,'h'},
  {0,0,0,0}
};

void usage() {
  cerr<<"3dcoordCamFrustum takes 4 mouse clicks on the corners of a plane in "<<endl;
  cerr<<"the scene, and places a 3d coordinate system on it."<<endl;
  cerr<<"Click on the corners of the plane in a CLOCKWISE manner,"<<endl;
  cerr<<"starting at the top right corner"<<endl;
  cerr<<"options: "<<endl;
  cerr<<"    -i (--image) filename :  uses a file as background image instead of video"<<endl;
  cerr<<"    -m (--model) filename :  loads a model and places it when the 3d"<<endl;
  cerr<<"                             coordinate system is placed."<<endl;
  cerr<<"    -h (--help)           :  prints this help message."<<endl;
  cerr<<"While running, a,z,s,x,d,c move the model around."<<endl;
  cerr<<"f,v adjust lighting levels, and t,y,g,h,b,n move the light around"<<endl;
}

void parse_cmdline(int argc, char **argv)
{
   char c;
   opterr = 0; /* prevent weird options from causing errors */
   posixify(argc,argv);

   while(1) {
     int this_option_optind = optind ? optind : 1;
     int option_index = 0;
     c = getopt_long (argc, argv, "i:m:h",
                      long_options, &option_index);
     if (c == -1) break;
     switch(c) {
        case 'i' :  //use image file instead of camera
          cerr<<"Requesting Image file "<<optarg<<endl; 
          imageFileName = optarg;
          useImlib = true;
          break;
        case 'm' : // load a 3ds model
          cerr<<"Requesting 3ds model "<<optarg<<endl;
          modelFileName = optarg;
          useModel = true;
          break;
        case 'h' : //cmd line help
        default :
          usage();
          exit(0);
          break;
     }
   }
}


///// MAIN ///////////////////

int main(int argc, char** argv)
{

   parse_cmdline(argc, argv);
   //create the loader, give it the filename (from cmdline)
   glutInit(&argc, argv);

   //if an argument is given, assume we are using an image file

   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);
   if( useModel ) myLoader = new onv_3dsLoader(modelFileName);

   corr = new Correspond(imageWinWidth, imageWinHeight );

   //typical problem : can't open imlib without display, yet cant
   // size display without loading image from imlib
   d=new FragPipeDisplay(8, imageWinWidth, imageWinHeight, Orbwin );
  glShadeModel(GL_SMOOTH);
   d->initDisplay();

   d->setImageSize( 320,240 );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-basic.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?
   if( useImlib ) { 
     im = new ImlibCapture(0,0);
     im->initCapture(d);
     im->loadFile(argv[1]); 
     assert( im->getRGBWidth() == imageWinWidth );
     assert( im->getRGBHeight() == imageWinHeight );
   }
   else {
     dc1394=new Dc1394();
     dc1394->start();
   }


   //d->activate_fpbuffer();
   d->init_texture(0, 320, 240, foo);
   //d->init_texture4f(1, 320, 240, foo);
   d->init_texture(1, 320, 240, foo);
   d->init_texture4f(2, 320, 240, foo);
   d->init_texture4f(3, 320, 240, foo);
   d->init_texture4f(4, 320, 240, foo);
   d->init_texture4f(5, 320, 240, foo);

   filter1 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-ibot-undistort.cg");
                               //"FPsamples/FP-basic.cg");
   filter2 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-rgb2hsv.cg");
   float thresh[4] = {0.020, 0.60, 0.02, 0.10};
   filter2->setCGParameter("thresh", thresh);
   filter3 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-erode-optim.cg");

   momentFilter = new MomentFilter(320,240, d->getContext(), d->getProfile() );

   boxApp = new BoxApp();


  glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
  glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);

    //glEnable(GL_LIGHT0);
     glEnable(GL_LIGHTING);
   //  glEnable(GL_COLOR_MATERIAL);



     glMatrixMode(GL_MODELVIEW);
     glLoadIdentity();

     glShadeModel(GL_SMOOTH);
     //glEnable(GL_CULL_FACE);
     glCullFace(GL_BACK);
     glDepthFunc(GL_LESS );
     //glEnable(GL_DEPTH_TEST);
     glDepthMask(GL_TRUE);




   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}










////////////////////
////// GLUT CALLBACKS ///////////////
////////////////////
void reshape(int w, int h)
{
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
 /* 
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
*/
 /*
 IBOT (gyro hacked one):
  fl(1) = 368.28488;
  fl(2) = 369.04519;
  principal_point(1) = 147.54834;
  principal_point(2) = 126.01673;
  distortion(1) = -0.4142;   ==k1
  distortion(2) = 0.40348;  == k2 etc
  distortion(3) = -0.00085;
  distortion(4) = 0.0009;
  */


  //glFrustum(  -ox/f, (((double)imageWidth)-ox)/f, 
  glFrustum(  (((double)imageWidth)-(320.0-ox))/f, -(320.0-ox)/f ,
              (((double)imageHeight)-oy)/f, -oy/f, 
    //          -oy/f, (((double)imageHeight)-oy)/f, 
                f/f,  (f+1000) )  ;

  printProjectionMatrix();
  gluLookAt( 0.0,0.0,0.0,  0,0, f,   0.0,  1.0, 0.0);
  printProjectionMatrix();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case 'a': mX -=0.1; break;
      case 'z': mX +=0.1; break;
      case 's': mY -=0.1; break;
      case 'x': mY +=0.1; break;
      case 'd': mZ -=0.1; break;
      case 'c': mZ +=0.1; break;
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
         viewbuf = atoi((const char * )&key);
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case 27:
         exit(0);
         break; 
      case 'f': light_ambient[0]+=0.1; light_ambient[1]+=0.1; light_ambient[2]+=0.1; break;
      case 'v': light_ambient[0]-=0.1; light_ambient[1]-=0.1; light_ambient[2]-=0.1; break;
      case 't': light_position[0]+=1; break;
      case 'y': light_position[0]-=1; break;
      case 'g': light_position[1]+=1; break;
      case 'h': light_position[1]-=1; break;
      case 'b': light_position[2]+=1; break;
      case 'n': light_position[2]-=1; break;
      case ',': rotZ += 3.0; break;
      case '.': rotZ -= 3.0; break;
      case 'k': sc *=1.05; break;
      case 'l': sc /=1.05; break;


      default:
         break;
   }
   cerr<<"[mX, My, Mz] = "<<mX<<", "<<mY<<", "<<mZ<<endl;
   cerr<<"LP: "<<light_position[0]<<", "<<light_position[1]<<", "<<light_position[2]<<endl;
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        float pixbuf[4] = {0.0};
        cerr << "("<<x<<","<<y<<"):";
        glReadPixels( x,240-y, 1,1, GL_RGBA, GL_FLOAT,  pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
        corr->add_point(x,y); 
        numClickCorners++;
        if( numClickCorners%4==0 )  {
          int points[8];
          corr->get_points(points);
          cerr<<"points: "<<points[0]<<" "
                          <<points[1]<<" "
                          <<points[2]<<" "
                          <<points[3]<<" "
                          <<points[4]<<" "
                          <<points[5]<<" "
                          <<points[6]<<" "
                          <<points[7]<<endl;
           char cmdstr[1024];
           //sprintf(cmdstr, "./fuckyou.m %d %d %d %d %d %d %d %d > numbers.txt", points[0], points[1], points[2], points[3], points[4], points[5], 
//points[6], points[7]);
if( false ) { //octave
           sprintf(cmdstr, "./planarCoords.m %d %d %d %d %d %d %d %d > numbers.txt", points[0], points[1], points[2], points[3], points[4], points[5], 
points[6], points[7]);
           system(cmdstr);
           FILE *fp = fopen("numbers.txt", "r");
           fscanf(fp, "%f %f %f %f %f %f %f %f %f %f %f %f", &result[0],
                  &result[1], &result[2], &result[3], &result[4],
                  &result[5], &result[6], &result[7], &result[8],
                  &result[9], &result[10], &result[11] );
           cerr<<"result = "<<result[0]<<" "<<
                 result[1]<<" "<<result[2]<<" "<<
                 result[3]<<" "<<result[4]<<" "<<
                 result[5]<<" "<<result[6]<<" "<<
                 result[7]<<" "<<result[8]<<" "<<
                 result[9]<<" "<<result[10]<<" "<<
                 result[11]<<endl;
           fclose(fp);
}
struct timeval tv_start, tv_end;
 gettimeofday( &tv_start,NULL) ;
           planarCoords(points[0], points[1], points[2], points[3], points[4], points[5], points[6], points[7], result);
gettimeofday( &tv_end,NULL) ;
cerr<<"time "<<elapsedTime(&tv_start, &tv_end)<<" microseconds"<<endl;




           cerr<<"result = "<<result[0]<<" "<<
                 result[1]<<" "<<result[2]<<" "<<
                 result[3]<<" "<<result[4]<<" "<<
                 result[5]<<" "<<result[6]<<" "<<
                 result[7]<<" "<<result[8]<<" "<<
                 result[9]<<" "<<result[10]<<" "<<
                 result[11]<<endl;

         }
      }
      break;
    case GLUT_RIGHT_BUTTON : 
     cerr<<"Mouse click, image raster coord: "<<x<<" "<<y<<endl;
     gl_x = ((float)(double)x-ox);
     gl_y = ((float)(double)y-oy); 
      break;

    case GLUT_MIDDLE_BUTTON : 
        glReadPixels( x,240-y, 1,1, GL_RGBA, GL_FLOAT,  light_diffuse);
        glReadPixels( x,240-y, 1,1, GL_RGBA, GL_FLOAT,  light_ambient);
      light_diffuse[0]*=90;
      light_diffuse[1]*=90;
      light_diffuse[2]*=90;
      light_diffuse[3]*=90;
      break;
  }
}


///helper functions

void drawFingerTip()
{
  drawCircleHelper(HAND_X_COORD/320.0, HAND_Y_COORD/240.0);
}

void  doMoment()
{
    float result[4] = {0.0};
    d->applySumFilter(momentFilter, 3, 4, result );
    //cerr<<"M = ["<<result[0]<<", "<<result[1]<<", ";
    //cerr<<result[2]<<", "<<result[3];
    //cerr<<" M_x = "<<result[1]/result[0]<<", M_y = "<<result[2]/result[0]<<endl;
    HAND_X_COORD=result[1]/result[0];
    HAND_Y_COORD=result[2]/result[0];
    //cerr<<"Avg S : "<<result[3]/result[0]<<endl;
   
    //make sure that enough pixels are actually recognized as skin
    //if( result[0] < 320*240*0.05 || result[0] > 320*240*0.75 ) {
    if( result[0] > 320*240*0.75 || result[0] < 0.001*320*240) {
      //cerr<<"bad stats"<<endl;
      return;
    }
    float thresh[4] = {result[3]/result[0], result[3]/result[0], 0.008, 0.1};
    filter2->setCGParameter("thresh", thresh);
    //cerr<<"window: "<<1.5*sqrt(result[0])<<endl;
}

/* coords are normalized */
void drawCircleHelper(float x, float y) {
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glColor4f(0.0,0.0,1.0,1.0);
  glPointSize(10.0); //XXX move away.
  //cerr<<"X = "<<HAND_X_COORD<< "  Y="<<HAND_Y_COORD<<endl;
  //cerr<<"X = "<<HAND_X_COORD/320.0<< "  Y="<<HAND_Y_COORD/240.0<<endl;
  glClear(GL_DEPTH_BUFFER_BIT);
  glBegin(GL_POINTS);
  //  glVertex3f(x, y,   1.0 );
    glVertex3f(x, y,   -1.0 );
  glEnd();
}

/* Tell function executed in context of Dc1394 thread */
void TellRWMHeCanUseImage(const char *dma_buf_) {
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;

  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;
  uyvy2rgb(dma_buf,dma_buf_rgb,320*240);

  //have only one, need two before we do any orbits
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }

  newdata=1;
}

