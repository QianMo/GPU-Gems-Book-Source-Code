/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _TSINGLEIMAGESENDER_H
#define _TSINGLEIMAGESENDER_H

#include "SingleImageSender.h"
using namespace std;

#include <cc++2/cc++/thread.h>
#include <semaphore.h>
#include <unistd.h>

// Give komputer 1 pics, threaded
class TSingleImageSender : public SingleImageSender, public Thread, public Mutex {

  //no arg constructor missing

 public:
  TSingleImageSender(int client_id);
  ~TSingleImageSender();

  void TSingleImageSender::sendImage(int width, int height, 
				     void* b1);

  void run();
  
};

#endif
