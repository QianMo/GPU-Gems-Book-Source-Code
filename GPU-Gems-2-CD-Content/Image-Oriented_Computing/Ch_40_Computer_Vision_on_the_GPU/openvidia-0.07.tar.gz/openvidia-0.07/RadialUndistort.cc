/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "RadialUndistort.h"
#include <iostream>

using namespace std;

RadialUndistort::RadialUndistort( int w, 
                                  int h,
                                  CGcontext fContext,
                                  CGprofile fProfile , 
                                  char *FPname )
 
{

  width = w;
  height= h;
  FPundistort = new FragmentProgram( fContext, fProfile, FPname, 0);
}

void RadialUndistort::undistort( GLuint textureID ) {
  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;


  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture( GL_TEXTURE_RECTANGLE_NV, textureID );

  glClearColor(0.0,0.0,0.0,0.0);
  glMatrixMode(GL_MODELVIEW); //optim fodder
  glLoadIdentity();

  FPundistort->activate();
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, (float)height, dist);
    //glVertex3f( origin, origin+texheight, texdist);
    glVertex3f( origin, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 0.0, dist);
    //glVertex3f( origin, origin, texdist);
    glVertex3f( origin, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,(float)width, 0.0, dist);
    //glVertex3f( origin+texwidth, origin, texdist);
    glVertex3f( origin+texwidth, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,(float)width, (float)height, dist);
    //glVertex3f( origin+texwidth, origin+texheight, texdist);
    glVertex3f( origin+texwidth, origin, texdist);
  glEnd();
  FPundistort->deactivate();
}
