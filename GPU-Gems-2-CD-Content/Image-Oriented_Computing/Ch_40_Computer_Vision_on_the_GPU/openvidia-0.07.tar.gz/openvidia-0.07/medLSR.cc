/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "GenericDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"
#include "FragPipeDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include "BoxApp.h"
#include "Correspond.h"
#include <iostream>
#include "demo.h"
#include "model.h"
#include "ImageSender.h"
#include "FragmentProgram.h"
#include "Parameters.h"
using namespace std;

// Global display object
FragPipeDisplay *d;
Dc1394 *dc1394;
ImlibCapture *im;
GenericFilter *filter1, *filter2, *filter3, *filter4,*filterK;
MomentFilter *momentFilter;
BoxApp *boxApp;
Correspond *corr;
float result[] = {0,0,0,0,0,0,0,0,0,0,0,0};
ImageSender sender=ImageSender();
Parameters initialGuess, convergedResult;
//FragmentProgram *FPSimple;	   
float buff[]={1.0,1.0,1.0,1.0};
int imageWinWidth = 320;
int viewbuf = 0;
int imageWinHeight = 240;
Window  Orbwin;

// extern CGparameter E1Texture, E2Texture, someColor, E2texCoord,E1texCoord, colorO, xincrementParam, yincrementParam;
 extern CGprofile vProfile;
// extern CGprogram fragmentProgram;
 extern CGcontext vContext;

/******************************************************/

/* The number of our GLUT window */
int window; 

/* rotation angle for the triangle. */
float rtri = 90.0f;
float rtrx=15.0f;
float rtry=0,rtrz=0;
float Rx=0.0f;
float Ry=0.0f;
//float Rz=1.2f;
float Rz=0.0f;//change this paramater for the size of the character
float bufRx=0,bufRy=0,bufRz=0,bufrtrx=0,bufrtri=0,bufoxIm=0,bufoyIm=0,bufozIm=0, bufYvec=0,bufXvecZ=0,bufZvecZ=0;

int points[8];

/*****************************************************/

///global state
bool useImlib = false;
bool putCoords = false;


int numClickCorners = 0;

float gl_x=0.0;
float gl_y=0.0;

void reshape(int w, int h);
void myIdle();
void keyboard (unsigned char key, int x, int y);
void MouseFunc( int button, int state, int x, int y) ;
void drawCircleHelper(float x, float y);
void TellRWMHeCanUseImage(const char *dma_buf_) ;
void exitFunc();
void initCoord();
void putAxes();
void drawCharacter();

unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_mouse_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_mouse_buf_rgb=(unsigned char *)malloc(320*240*3);
int framecounter=0;
int newdata=0;
float *foo[320*240*4];

double f = 368.28488;
double ox = 147.54834;
double oy = 126.01673;

double imageWidth = (double)imageWinWidth;
double imageHeight = (double)imageWinHeight;

float scalef;
float oxIm;
float oyIm;
float ozIm;
float buffIm[3]={0.0,0.0,0.0};
float XvecX;
float XvecY;
float XvecZ;
float YvecX;
float YvecY;
float YvecZ;
float ZvecX;
float ZvecY;
float ZvecZ;
int mov=0;
int plane=0;

/*****************************************************/
GLuint texture_name;
float resulta[]={1.0,1.0,1.0,1.0};
float resultb[]={1.0,1.0,1.0,1.0};
void printProjectionMatrix()
{
  float pmatrix[16]={0};
  glGetFloatv( GL_PROJECTION_MATRIX, pmatrix);
  printf("%5f %5f %5f %5f\n", pmatrix[0], pmatrix[4], pmatrix[8], pmatrix[12]);
  printf("%5f %5f %5f %5f\n", pmatrix[1], pmatrix[5], pmatrix[9], pmatrix[13]);
  printf("%5f %5f %5f %5f\n", pmatrix[2], pmatrix[6], pmatrix[10], pmatrix[14]);
  printf("%5f %5f %5f %5f\n", pmatrix[3], pmatrix[7], pmatrix[11], pmatrix[15]);
}

void initCoord(){
char cmdstr[1024];
int pointsF[]={0,0,0,0,0,0,0,0};
int andrewisgay;
if(putCoords){
		 
		 //int a11b=(int)(convergedResult.get()[0]*1000);
		//float a11=convergedResult.get()[0];
		//float a11=((float)a11b)/1000;
		//convergedResult.invert();
		
// 		float a11=( (float)((int)(convergedResult.get()[0]*1000)))/1000;
//   		float a12=( (float)((int)(convergedResult.get()[1]*1000)))/1000;
//   		float b1=( (float)((int)(convergedResult.get()[2]*1000)))/1000;
//   		float a21=( (float)((int)(convergedResult.get()[3]*1000)))/1000;
//   		float a22=( (float)((int)(convergedResult.get()[4]*1000)))/1000;
//   		float b2=( (float)((int)(convergedResult.get()[5]*1000)))/1000;
//   		float c1=( (float)((int)(convergedResult.get()[6]*1000)))/1000;
//   		float c2=( (float)((int)(convergedResult.get()[7]*1000)))/1000;

		float a11=convergedResult.get()[0];
  		float a12=convergedResult.get()[1];
  		float b1=convergedResult.get()[2];
  		float a21=convergedResult.get()[3];
  		float a22=convergedResult.get()[4];
  		float b2=convergedResult.get()[5];
  		float c1=convergedResult.get()[6];
  		float c2=convergedResult.get()[7];
	
	
	//printf("\n a11=%f /a12=%f /b1=%f /a21=%f /a22=%f /b2=%f /c1=%f /c2=%f\n ",a11,a12,b1,a21,a22,b2,c1,c2);
	
        	for(int i=0;i<8;i++){
	if(i%2!=0)
        pointsF[i]=(points[i]*a11+points[i]*a12+b1)/(c1*points[i]+c2*points[i]+1);
	else
	pointsF[i]=(points[i]*a21+points[i]*a22+b2)/(c1*points[i]+c2*points[i]+1);
	}
	}
	
    glBegin(GL_LINES);
    glColor4f(0.0, 1.0, 0.0, 0.0);//Red X axe
    glVertex3f(pointsF[0], pointsF[1], ozIm);
    glVertex3f(pointsF[2], pointsF[3], ozIm);
   
    glColor4f(0.0, 1.0, 0.0, 0.0);//Green Y axe
    glVertex3f(pointsF[2], pointsF[3], ozIm);
    glVertex3f(pointsF[4], pointsF[5], ozIm);
    
    glColor4f(0.0, 1.0, 0.0, 0.0);//Blue Z axe
    glVertex3f(pointsF[4], pointsF[5], ozIm);
    glVertex3f(pointsF[6], pointsF[7], ozIm);
    
    glColor4f(0.0, 1.0, 0.0, 0.0);//Blue Z axe
    glVertex3f(pointsF[6], pointsF[7], ozIm);
    glVertex3f(pointsF[0], pointsF[1], ozIm);
    
    glEnd();

// 	printf("\n");
// 	for (int i=0;i<8;i++)
// 			printf("point[%d]=%d\t",i,points[i]);
// 	printf("\n");
// 	printf("\n");
// 	for (int i=0;i<8;i++)
// 			printf("pointF[%d]=%d\t",i,pointsF[i]);
// 	printf("\n");
	//if(points[0]!=0&&points[1]!=0&&points[2]!=0&&points[3]!=0&&points[4]!=0&&points[5]!=0&&points[6]!=0&&
	//points[7]!=0){
           sprintf(cmdstr, "./planarCoords.m %d %d %d %d %d %d %d %d > numbers.txt", pointsF[0], pointsF[1], pointsF[2], pointsF[3], pointsF[4], pointsF[5], 
pointsF[6], pointsF[7]);
           system(cmdstr);
           FILE *fp = fopen("numbers.txt", "r");
           fscanf(fp, "%f %f %f %f %f %f %f %f %f %f %f %f", &result[0],
                  &result[1], &result[2], &result[3], &result[4],
                  &result[5], &result[6], &result[7], &result[8],
                  &result[9], &result[10], &result[11] );
//            cerr<<"result = "<<result[0]<<" "<<
//                  result[1]<<" "<<result[2]<<" "<<
//                  result[3]<<" "<<result[4]<<" "<<
//                  result[5]<<" "<<result[6]<<" "<<
//                  result[7]<<" "<<result[8]<<" "<<
//                  result[9]<<" "<<result[10]<<" "<<
//                  result[11]<<endl;
           fclose(fp);

  scalef = 100.0;
  oxIm = result[0];
  oyIm = result[1];
  ozIm = result[2];
  XvecX = result[3];
  XvecY = result[4];
  XvecZ = result[5];
  YvecX = result[6];
  YvecY = result[7];
  YvecZ = result[8];
  ZvecX = result[9];
  ZvecY = result[10];
  ZvecZ = result[11];
  putCoords=true;
  }  
  //}

void putAxes(){
if(plane==1){
  glBegin(GL_LINES);
    glColor4f(1.0, 0.0, 0.0, 1.0);//Red X axe
    glVertex3f(oxIm, oyIm, ozIm);
    glVertex3f( oxIm+scalef*XvecX, oyIm+scalef*XvecY,  ozIm+scalef*XvecZ);
 
    
    glColor4f(0.0, 1.0, 0.0, 1.0);//Green Y axe
    glVertex3f(oxIm, oyIm, ozIm);
    glVertex3f( oxIm+scalef*YvecX, oyIm+scalef*YvecY,  ozIm+scalef*YvecZ);

    glColor4f(0.0, 0.0, 1.0, 1.0);//Blue Z axe
    glVertex3f(oxIm, oyIm, ozIm);
    glVertex3f( oxIm+scalef*ZvecX, oyIm+scalef*ZvecY,  ozIm+scalef*ZvecZ);
  glEnd();
  }
  }
  
void drawCharacter()
{
   glMatrixMode(GL_MODELVIEW);
  glClear(GL_DEPTH_BUFFER_BIT);
  glLoadIdentity();
  glMatrixMode(GL_MODELVIEW); 
   initCoord();
  putAxes();
  glLoadIdentity();
      
	float Matrice[]={XvecX,XvecY,XvecZ,0.0,-YvecX,-YvecY,-YvecZ,0.0,ZvecX,ZvecY,ZvecZ,0.0,0.0,0.0,0.0,1.0}; //matrice used for transposition glMultMatrix 
	  glTranslatef(oxIm, oyIm, ozIm);
	glMultMatrixf(Matrice);
	glScalef(0.5,0.5,0.5);
	
  // set the light position and attributes
   const GLfloat lightPosition[] = { 1.0f, -1.0f, -1.0f, -1.0f };
   glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
   const GLfloat lightColorAmbient[] = { 0.6f, 0.6f, 0.6f, 0.6f };
   glLightfv(GL_LIGHT0, GL_AMBIENT, lightColorAmbient);
   const GLfloat lightColorDiffuse[] = { 0.52f, 0.5f, 0.5f, 1.0f };
   glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColorDiffuse);
   const GLfloat lightColorSpecular[] = { 0.1f, 0.1f, 0.1f, 1.0f };
   glLightfv(GL_LIGHT0, GL_SPECULAR, lightColorSpecular);

//   // set camera position
//   glTranslatef(0.0f, 0.0f, Rz);
//    glRotatef(100.0, 1.0f, 0.0f, 0.0f);
//    glRotatef(rtri, 0.0f, 0.0f, 1.0f);
//    glTranslatef(0.0f, 0.0f, -90.0f);
 
//   if(bufRx!=Rx||bufRy!=Ry||bufRz!=Rz||bufrtrx!=rtrx||bufrtri!=rtri||bufoxIm!=oxIm||bufoyIm!=oyIm||bufozIm!=ozIm||bufYvec!=YvecZ||bufXvecZ!=XvecZ||bufZvecZ!=ZvecZ){
//   bufRx=Rx;bufRy=Ry;bufRz=Rz;bufrtrx=rtrx;bufrtri=rtri;bufoxIm=oxIm;bufoyIm=oyIm;bufozIm=ozIm;bufYvec=YvecZ;bufXvecZ=XvecZ;bufZvecZ=ZvecZ;
//   printf("\nRx=%f,Ry=%f,Rz=%f,rtri=%f,rtrx=%f,oxIm=%f,oyIm=%f,ozIm=%f\n",Rx,Ry,Rz,rtri,rtrx,oxIm,oyIm,ozIm);
//   printf("XvecX=%f,YvecX=%f,ZvecX=%f\n",XvecX,YvecX,ZvecX);
//   printf("XvecY=%f,YvecY=%f,ZvecY=%f\n",XvecY,YvecY,ZvecY);
//   printf("XvecZ=%f,YvecZ=%f,ZvecZ=%f\n",YvecZ,XvecZ,ZvecZ);
//   }
//   d->applyFilter(filter4, 0,1 ,
//                     -ox, (((double)imageWidth)-ox), 
//                     (((double)imageHeight)-oy), -oy ) ;
// d->applyFilter(filter4, 1,2 ,
//                     -ox, (((double)imageWidth)-ox), 
//                     (((double)imageHeight)-oy), -oy )  ;
//   cgGLEnableProfile(vProfile);

//  cgGLEnableProfile(vProfile); 
//  printf("salut\n");
 //FPSimple->bind(); 
 
 //FPSimple->activate();
 //FPSimple->putgain(resulta);
 //FPSimple->activate();

 theDemo.onRender(mov);
 //FPSimple->deactivate();	
  //FPSimple->deactivate();
}

void render_redirect() {
int i,j;
	
	// put here from demo:onrender
	// thought that these initializes were needed, but they went over cam, so placed before cam
	// now we see video for a frame and then blue screen, possible clearning of screen elsewhere..
	// seem to have no effect here.....
  ++framecounter;
               char cmdstr[1024];
	   	  float resultorbits[8];
    if( useImlib )  {
      d->reinit_texture(0, 320, 240, im->getRGBData() );
    }
    else {
      d->reinit_texture(0, 320, 240, dma_buf_rgb);
    }
    d->bindTextureARB0(0);
    if (!useImlib) dc1394->tellThreadDoneWithBuffer();

    //cascade the filters
     d->applyFilter(filter1, 0,1 ,
                    -ox, (((double)imageWidth)-ox), 
                    (((double)imageHeight)-oy), -oy, f )  ;
     
// 		d->applyFilter(filter4, 1,2 ,
//                     -ox, (((double)imageWidth)-ox), 
//                     (((double)imageHeight)-oy), -oy )  ;
	//d->applyFilter(filter4, 1,2 ) ; 

	 d->activate_fpbuffer();
  d->clear_fpbuffer();
      d->bindTextureARB0(2);
      d->bindTextureARB1(1);
//       d->applyFilter(filter1, 1,3,
//                     -ox, (((double)imageWidth)-ox), 
//                     (((double)imageHeight)-oy), -oy, f )  ;
	// d->bindTextureARB1(3);
      d->applyFilter(filterK, 0, 2);
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) 320, (GLsizei) 240);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();	    
	 //NEW
		 d->applySumFilter(momentFilter, 2, 4, resultb );
  
     resultb[0]=resultb[0]/resultb[3];
     resultb[1]=resultb[1]/resultb[3];
     resultb[2]=resultb[2]/resultb[3];
     resultb[3]=resultb[3]/resultb[3];
  
  if(abs(1.0-resultb[0])>0.1||abs(1.0-resultb[1])>0.1||
      abs(1.0-resultb[2])>0.1)
      {
      	resulta[0]=abs(1.0-resultb[0]);
        resulta[1]=abs(1.0-resultb[1]);
	resulta[2]=abs(1.0-resultb[2]);
	resulta[3]=abs(1.0-resultb[3]);
	}    
	
	   cerr<<"resulta = ["<<resulta[0]<<", "<<resulta[1]<<", ";
     cerr<<resulta[2]<<", "<<resulta[3]<<"]"<<endl;
     
     cerr<<"resultb = ["<<resultb[0]/resultb[3]<<", "<<resultb[1]/resultb[3]<<", ";
     cerr<<resultb[2]/resultb[3]<<", "<<resultb[3]/resultb[3]<<"]"<<endl<<endl;


  d->deactivate_fpbuffer();
	//d->clear_fpbuffer();
	//d->applyFilter(filter2, 0,2 ) ;
	//d->applyFilter(filter3, 0,3 ) ;
	/*d->applyFilter(filter4, 1,2 ) ; */  

//end

  
  // if we comment this out, we see the video, so something hear is clearing the screen, don't know what...
  // theDemo.onRender();
 // printf("test %d\t\n",theDemo.getWidth());
    

         //d->deactivate_fpbuffer();
	 
      /**************************************/
      		
	   //number 4 it's a good compromise
	   //sender.sendImages(320, 240,dma_old_buf_rgb,dma_buf_rgb,8,initialGuess,&convergedResult);   
	   
	     //d->setChirpMatParams(convergedResult.get());
	 // convergedResult.print();
	/**************************************/
   // d->activate_fpbuffer();
    d->render();
  // d->activate_fpbuffer();
    drawCharacter();
    d->deactivate_fpbuffer();
    //theDemo.onRender();	  
   //glutSwapBuffers();

}  

///// MAIN ///////////////////

int main(int argc, char** argv)
{

   glutInit(&argc, argv);
   /***************************Creation and Initialisation of a character****************/
      if(!theDemo.onCreate(argc, argv))
    {
      std::cerr << "Creation of the demo failed." << std::endl;
      return -1;
    }
     if(!theDemo.onInit())
   {
     std::cerr << "Initialization of the demo failed." << std::endl;
     return -1;
   }
 // LoadValue("alienman.blend.raw");

   //if an argument is given, assume we are using an image file
   if( argc == 2 ) { 
     cout<<"Using image file: "<<argv[1]<<endl;
     cout<<"Note: currently, image file must be 320x240 resolution"<<endl;
     useImlib = true;
   }
   else {
     useImlib = false;
   }
   
   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);

   corr = new Correspond(imageWinWidth, imageWinHeight );

   //typical problem : can't open imlib without display, yet cant
   // size display without loading image from imlib
   d=new FragPipeDisplay(8, imageWinWidth, imageWinHeight, Orbwin );


//    FPSimple = new FragmentProgram( vContext, vProfile, "FPsamples/FP-basic.cg", 0 );
     
   
   
   d->initDisplay();

   d->setImageSize( 320,240 );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0);
    
   d->initGL("FPsamples/FP-basic.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?
   if( useImlib ) { 
     im = new ImlibCapture(0,0);
     im->initCapture(d);
     im->loadFile(argv[1]); 
     assert( im->getRGBWidth() == imageWinWidth );
     assert( im->getRGBHeight() == imageWinHeight );
   }
   else {
     dc1394=new Dc1394();
     dc1394->start();
   }


   //d->activate_fpbuffer();
   d->init_texture(0, 320, 240, foo);
   d->init_texture4f(1, 320, 240, foo);
   d->init_texture4f(2, 320, 240, foo);
   d->init_texture4f(3, 320, 240, foo);
   d->init_texture4f(4, 320, 240, foo);
   d->init_texture4f(5, 320, 240, foo);

   filter1 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-ibot-undistort.cg");
   filter2 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-rgb2hsv.cg");
   float thresh[4] = {0.020, 0.60, 0.02, 0.10};
   filter2->setCGParameter("thresh", thresh);
   filter3 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-erode-optim.cg");
   filter4 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-mohit.cg");
   filterK = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-GiveK-new.cg");
    
			       

   momentFilter = new MomentFilter(320,240, d->getContext(), d->getProfile() );

   boxApp = new BoxApp();

   //glClearColor(1.0,0.0,0.0,0.0);
  //glColor3f(1.0,0.0,0.0);
  //glPointSize(2.0);
  
  atexit(exitFunc);
   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
    // initialize our demo instance
  
   glutMainLoop();
   return 0; 
}

void exitFunc()
{
  // shut the demo instance down
  theDemo.onShutdown();
}

////////////////////
////// GLUT CALLBACKS ///////////////
////////////////////
void reshape(int w, int h)
{
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  glFrustum(  (((double)imageWidth)-(320.0-ox))/f, -(320.0-ox)/f ,
              (((double)imageHeight)-oy)/f, -oy/f, 
    //          -oy/f, (((double)imageHeight)-oy)/f, 
                f/f,  (f+1000) )  ;

  printProjectionMatrix();
  gluLookAt( 0.0,0.0,0.0,  0,0, f,   0.0,  1.0, 0.0);
  printProjectionMatrix();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle(){
  theDemo.onIdle();
  glutSetWindow(Orbwin);

  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
         viewbuf = atoi((const char * )&key);
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case 27:
         theDemo.onShutdown();
	 exit(0);
	 
         break;
	 
	 /****TRANSLATION**************/
	case 'Q':
		Rx-=10.0f;
		break;
	case 'q':
		Rx-=10.0f;
		break;
	case 'W':
		Rx+=10.0f;
		break;
	case 'w':
		Rx+=10.0f;
		break;
	case 'E':
		Ry+=10.0f;
		break;
	case 'e':
		Ry+=10.0f;
		break;
	case 'D':
		Ry-=10.0f;
		break;
	case 'd':
		Ry-=10.0f;
		break;
	/****ZOOM**************/
	case 'Z':
		Rz+=10.0f;
		break;
	case 'z':
		Rz+=10.0f;
		break;
	case 'X':
		Rz-=10.0f;
		break;
	case 'x':
		Rz-=10.0f;
		break;
	/****ROTATION**************/	
	case '+':
      rtri+=5.0f;	
      glutPostRedisplay();
	break;
    case '-':
      rtri-=5.0f;	
      glutPostRedisplay();
	break;
    case 'o':
      rtrx+=5.0f;	
      glutPostRedisplay();
	break;
    case 'p':
      rtrx-=5.0f;	
      glutPostRedisplay();
	break;
	case 'r':
      rtry+=5.0f;	
      glutPostRedisplay();
	break;
    case 't':
      rtry-=5.0f;	
      glutPostRedisplay();
	break;
	case 'y':
      rtrz+=5.0f;	
      glutPostRedisplay();
	break;
    case 'u':
      rtrz-=5.0f;	
      glutPostRedisplay();
	break;
   case 'm':
   if(mov!=2)mov++;
   else mov=0;
   break;
	
/****************ON/OFF Axes**********************/
    case 'G':
    case 'g':
    	if(plane ==0)plane=1;
	else plane=0;
	break;
     
	default:
		break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        
	float pixbuf[4] = {0.0};
        cerr << "("<<x<<","<<y<<"):";
        glReadPixels( (float)x,240.0-(float)y, 1,1, GL_RGBA, GL_FLOAT,  pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
// 	      printf("X=%f/Y=%f/[pixbuf[0]=%f/pixbuf[1]=%f/pixbuf[2]=%f/pixbuf[3]=%f]",x,y,pixbuf[0],pixbuf[1],pixbuf[2],pixbuf[3]);
        corr->add_point(x,y); 
        numClickCorners++;
        if( numClickCorners%4==0 )  {
	  dma_mouse_buf_rgb=dma_buf_rgb;
          corr->get_points(points);
	  
          cout<<"points: "<<points[0]<<" "
                          <<points[1]<<" "
                          <<points[2]<<" "
                          <<points[3]<<" "
                          <<points[4]<<" "
                          <<points[5]<<" "
                          <<points[6]<<" "
                          <<points[7]<<endl;
			  	printf("\n");
	/*for (int i=0;i<8;i++)
			printf("point[%d]=%d\t",i,points[i]);
	printf("\n");
	printf("\n");
	*/putCoords=false; 
      }
      }
      break;
    case GLUT_RIGHT_BUTTON : 
     cerr<<"Mouse click, image raster coord: "<<x<<" "<<y<<endl;
     gl_x = ((float)(double)x-ox);
     gl_y = ((float)(double)y-oy); 


      break;
  }
}



/* coords are normalized */
void drawCircleHelper(float x, float y) {
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glColor4f(0.0,0.0,1.0,1.0);
  glPointSize(10.0); //XXX move away.
  //cerr<<"X = "<<HAND_X_COORD<< "  Y="<<HAND_Y_COORD<<endl;
  //cerr<<"X = "<<HAND_X_COORD/320.0<< "  Y="<<HAND_Y_COORD/240.0<<endl;
  glClear(GL_DEPTH_BUFFER_BIT);
  glBegin(GL_POINTS);
  //  glVertex3f(x, y,   1.0 );
    glVertex3f(x, y,   -1.0 );
  glEnd();
}

/* Tell function executed in context of Dc1394 thread */
void TellRWMHeCanUseImage(const char *dma_buf_) {
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;

  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;
  uyvy2rgb(dma_buf,dma_buf_rgb,320*240);

  //have only one, need two before we do any orbits
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }

  newdata=1;
}

