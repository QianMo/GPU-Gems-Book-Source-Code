/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _GENERICFILTER_H
#define _GENERICFILTER_H
  
#include "FragmentProgram.h"
#include <glh/glh_extensions.h>


///Generic Filter class is a class to wrap a Fragment Program which 
///acts as a filter on an image.   The Fragment Program name must
///be specified on creation.
class GenericFilter {
  private:
    int width, height;
    FragmentProgram *FP;
    ///draws quad at only the specified area
    void drawFilterQuad( GLuint textureID,
                         float left, float right,
                         float top, float bottom ) ;
    void drawFilterQuad( GLuint textureID,
                         float left, float right,
                         float top, float bottom, float f ) ;
    float clip(float );
  public:
    GenericFilter( int w, int h, CGcontext fContext,
                     CGprofile fProfile , char *FPname );
    void applyFilter(GLuint ID );
    void applyFilter(GLuint ID, 
                     float left, float right,
                     float top, float bottom ) ;

    void applyFilter(GLuint ID, 
                     float left, float right,
                     float top, float bottom , float f) ;

    void setCGParameter4x4(char *name, float *value );
    void setCGParameter(char *name, float *value );
    void setCGParameter(char *name, double *value );
    float getWidth(void) { return (float)width; }
    float getHeight(void) { return (float)height; }
    void deactivate() { FP->deactivate(); }
};

#endif
