/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _IMLIB_CAPTURE_H
#define _IMLIB_CAPTURE_H

#include "GenericCapture.h"
#include "GenericDisplay.h"
#include <Imlib.h>
//#include <Imlib2.h>

class ImlibCapture : public GenericCapture 
{  
 protected:
  ImlibData *imlib_id;
  ImlibImage *im;
  char filename[256];
  int filenumber;
  int startnum, endnum;
 public:
  ImlibCapture();
  ImlibCapture(int start, int end);
  ~ImlibCapture();
  void ImlibCapture :: initCapture(Display *d);
  void initCapture(GenericDisplay *d);
  void advanceFrame();
  void* getRGBData();
  int getRGBWidth();
  int getRGBHeight();
  void loadFile(char *);
};

#endif

