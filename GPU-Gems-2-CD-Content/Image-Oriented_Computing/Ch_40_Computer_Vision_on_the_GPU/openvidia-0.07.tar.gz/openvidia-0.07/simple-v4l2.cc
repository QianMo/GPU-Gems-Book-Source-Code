/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "GenericDisplay.h"
#include "SimpleDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394.h"
#include "V4L2.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include <iostream>
using namespace std;

// Global display object
SimpleDisplay *d;
Dc1394 *dc1394;
V4L2 *v4l2;

//int imageWinWidth = 320;
//int imageWinHeight = 240;
int imageWinWidth = 640;
int imageWinHeight = 480;
Window  Orbwin;

////// GLUT CALLBACKS ///////////////

void reshape(int w, int h)
{
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  //rosco version
  glFrustum(-1.0,1.0,-1.0,1.0,1.0,100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,-1.0,   0.0, 1.0, 0.0);

  //james version
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      break;
    case GLUT_RIGHT_BUTTON : 
      break;
  }
}
unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(320*240*3);
int newdata=0;
/* Tell function executed in context of Dc1394 thread */
void TellRWMHeCanUseImage(const char *dma_buf_) {
//void TellRWMHeCanUseImage( char *dma_buf_) {
/*
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;

  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;
  uyvy2rgb(dma_buf,dma_buf_rgb,320*240);

  //have only one, need two before we do any orbits
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
    //dc1394->tellThreadDoneWithBuffer();
    v4l2->tellThreadDoneWithBuffer();
    return;
  }
*/
  dma_buf = (unsigned char *)dma_buf_;

  newdata=1;
}


int framecounter=0;

void render_redirect() {
  ++framecounter;

  if(!newdata)  {  struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 1000;
     select(0,0,0,0, &tv);
 return;}


  d->init_texture4c(0, 640, 480, dma_buf);
  newdata = 0;
  //dc1394->tellThreadDoneWithBuffer();
  v4l2->tellThreadDoneWithBuffer();
  d->render();
  d->showstats();
  glutSwapBuffers();
}  


///// MAIN ///////////////////

int main(int argc, char** argv)
{
   glutInit(&argc, argv);

   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);
/*
   dc1394=new Dc1394();
   dc1394->start();
*/
   //create V4L2 object.  Interface calls are identical to dc1394
   v4l2 = new V4L2();
   v4l2->start();
   d=new SimpleDisplay(3, imageWinWidth, imageWinHeight, Orbwin );

   d->initDisplay();
   //V4L2 uses 640x480 images as input instead of 320x240 
   //d->setImageSize( 320,240 );
   d->setImageSize( 640,480 );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   //d->initGL("FPsamples/FP-ibot-undistort.cg");
   //V4L2 needs to be byte shuffled to show up
   d->initGL("FPsamples/FP-v4l2-endianconvert.cg");

   glutSetWindow(Orbwin);
   glutFullScreen();
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}
