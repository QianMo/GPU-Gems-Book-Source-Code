 ipcs | grep $USER | grep 777  | sed -e "s/0x00000000//"  | sed -e "s/ [ *].*//" > /tmp/shmKeys.txt
 ipcrm -m  `head -1 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -2 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -3 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -4 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -5 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -6 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -7 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -8 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -9 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -10 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -11 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -12 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -13 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -14 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -15 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -16 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -17 /tmp/shmKeys.txt | tail -1`
 ipcrm -m  `head -18 /tmp/shmKeys.txt | tail -1`


