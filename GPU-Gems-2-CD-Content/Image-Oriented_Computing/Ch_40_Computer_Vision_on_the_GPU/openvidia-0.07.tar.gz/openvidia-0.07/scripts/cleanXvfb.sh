killall Xvfb rwm-cv xnee
rm *.tmp
