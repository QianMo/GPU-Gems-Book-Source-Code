/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _DC1394_H
#define _DC1394_H

#include "GenericCapture.h"
#include "GenericDisplay.h"
#include <cc++2/cc++/thread.h>
//#include <thread.h>
#include <cc++2/cc++/config.h>
#include <cc++2/cc++/exception.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <libraw1394/raw1394.h>
#include <libdc1394/dc1394_control.h>

using namespace std;
using namespace ost;

/*
 * The interaction model is as follows:
 *   As soon as a picture is ready, notify all picture consumers
 *   by a function pointer.
 *   The notification should not be a time consuming method
 *   A seperate method for the consumers to indicate that 
 *   they are done should be provided.
 *
 *  We want RGB capture since UYVY->RGB is very expensive
 */


class Dc1394 : public Thread, public Mutex
{  
 protected:
  const static int DefaultCaptureWidth=320;
  const static int DefaultCaptureHeight=240;
  int CaptureWidth,CaptureHeight;

  dc1394_cameracapture camera;
  raw1394handle_t handle; // selected camera
  nodeid_t *camera_nodes; // all nodes on bus

  int bufferUsed;
  bool noDMA;
  
  void doOHCI();


 public:
  Dc1394();
  ~Dc1394();
  // Start Thread
  void run(); 
  void tellThreadDoneWithBuffer();


  void lock() { ENTER_CRITICAL; }
  void unlock() { LEAVE_CRITICAL; }



};

#endif

