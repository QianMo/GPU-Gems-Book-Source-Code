/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/


#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>

using namespace std;
int EVENT_MOVE=0;
int EVENT_DOWN=4;
int EVENT_UP=5;

/*
 * Launch the xnee proces
 */
int main(int argc, char** argv) {
  
  /*
   *  consume a tmp.rec file if it exists
   *    create a tmp-consumed, then a tmp-consumed2 that holds all info
   */
  while(true) {
    int width=320;
    int height=240;
   
    int result=access("tmp.rec", F_OK);
    if(result==0) {
      // exists
    } else {
      usleep(1000);
      continue;
    }
    
    if( system("mv tmp.rec tmp-consumed.rec") != 0) {
      continue;
    } //otherwise we succeeded in consuming it.

    FILE *f=fopen("tmp-consumed.rec","r");
    if( f==NULL ) {
      cerr<<"Could not open tmp-consumed.rec"<<endl;
      continue;
    }
    char buf[64];
    int screenId, x_coord, y_coord, eventCode;
    fscanf(f, "%d %d %d %d", &screenId, &x_coord, &y_coord, &eventCode);
    fclose(f);

    char tail[50]={'\0'};
    // some nice magic constantss
    // mult by two to get into 640 from 320 coord
    // sprintf(tail, "0,6,%d,%d,0,0,0,782180", HAND_X_COORD, HAND_Y_COORD);
    // VIRT X SERVER MOUSE COORDS ALLWAYS 1280x1024
     system("cat header.rec > tmp-consumed2.rec");
   static int timeCounter=5987600;
    int i=(int)(x_coord*1280.0/width);
    int j=(int)(y_coord*1024.0/height);
    if(eventCode==EVENT_MOVE) {
      sprintf(tail, "0,6,%d,%d,0,0,0,%d", i, j, timeCounter++);
    
      char cmd2[256]={'\0'};
      sprintf(cmd2,"echo \"%s\" >> tmp-consumed2.rec", tail);
      system(cmd2);
      system(cmd2); // do it twice so xnee relays event.
    } else if (eventCode==EVENT_DOWN) {
      cout<<"CLICK"<<endl;
      sprintf(tail, "0,6,%d,%d,0,0,0,%d", i, j, timeCounter++);
      char cmd3[256]={'\0'};
      sprintf(cmd3,"echo \"%s\" >> tmp-consumed2.rec", tail);
      system(cmd3);
      system(cmd3); // do it twice so xnee relays event.
      
      sprintf(tail, "0,4,0,0,1,0,0,%d", timeCounter++);
      sprintf(cmd3,"echo \"%s\" >> tmp-consumed2.rec", tail);
      system(cmd3);

      sprintf(tail, "0,5,0,0,1,0,0,%d", i, j, timeCounter++);
      sprintf(cmd3,"echo \"%s\" >> tmp-consumed2.rec", tail);
      system(cmd3);
  }

    char cmd4[256]={'\0'};
    sprintf(cmd4, "xnee --display :%d.0 -rep -f tmp-consumed2.rec --no-sync", screenId);
    system(cmd4);
    
    usleep(70000);
  }
}
