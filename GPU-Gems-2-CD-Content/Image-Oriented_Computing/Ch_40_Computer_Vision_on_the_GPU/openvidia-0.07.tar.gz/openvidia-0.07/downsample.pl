#!/usr/bin/perl -w

while (defined($nextname = </home/rosco/test-jpg\ ???.jpg>)) {
 # create filenames
 $filed = $nextname;
 $files = $filed;
 $files =~ s/test-jpeg\ /t/;
 $files =~ s/jpg/ppm/;
 printf("files is: $files\n");

 printf("Generating $files from $filed\n");

 `djpeg $filed > deleteme_big.ppm`;
 `pnmcut -width 640 deleteme_big.ppm > deleteme_crop.ppm`;
 `pnmscale 0.5 deleteme_crop.ppm > $files`;
}

