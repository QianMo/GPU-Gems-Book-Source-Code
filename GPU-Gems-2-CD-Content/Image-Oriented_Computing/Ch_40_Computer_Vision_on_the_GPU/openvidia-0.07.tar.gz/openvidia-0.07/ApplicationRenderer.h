/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _APPLICATION_RENDERER_H
#define _APPLICATION_RENDERER_H

#include <GL/glut.h>
#include <iostream>
#include <Parameters.h>

using namespace std;


// XXX should these all be pointers, or should we return
// objects as we are doing now
/*
 * This class is designed to encapsulate the drawing
 * of an application into rwm. It rotates coords to 
 * approprate orientation and scale so that the application
 * simply draws itself as it does on a regular 2D desktop
 */
class ApplicationRenderer
{
  
 protected:
  Parameters initialAppParameter;
  Parameters currentAppParameter;

  // ALL SUBCLASSES MUST CALL PARENT.preRender!
  // move over to right spot. translate back to 0 is infront of the camera
  // COOL IDEA - make a  virtual render_override, called by this parent.
  void preRender();
  
  //move back to original position
  void postRender();

 public:
  ApplicationRenderer() {};
  ~ApplicationRenderer() {};
  void setInitialParameter(Parameters p);
  Parameters getInitialParameter();
  void setCurrentParameter(Parameters p);
  Parameters getCurrentParameter();
  
  // CALL PRERENDER FIRST, POST RENDER AT END
  // this will do a bunch of GL calls.
  // XXX should be virtual but "undefined ref to vtable" errror in the child classes??
 //orbits is raster display coords
  /* -0,0-----1,0
   * |
   * |
   *  0,1     1,1
   */
  void render() {};


  /*
   * Get the 4 corners of the rendered texture, for mouse-collision detection
   */
  void getRenderedScreenLocation(int *x1, int *y1, int *x2, int *y2,
				 int *x3, int *y3, int *x4, int *y4);
  /*
   * for mapping mouse to a locally-appropriate screen coord in the xvfb
   */
  void getLocalCoords(int x, int y, double *x_prime, double *y_prime);
  bool isMouseOver(int x, int y);
  bool isMouseOverAlternate(int x, int y);
  void drawBorder(float r=1.0, float g=0.0, float b=0.0, float alpha=1.0);

};

#endif
