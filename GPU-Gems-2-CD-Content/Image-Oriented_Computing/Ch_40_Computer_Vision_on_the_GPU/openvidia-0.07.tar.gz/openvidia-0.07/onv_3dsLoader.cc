/*
// Ben Humphrey (DigiBen)
// Game Programmer
// DigiBen@GameTutorials.com
// Co-Web Host of www.GameTutorials.com
*/
//Thank you to gametutorials.com for permission to include this work
//based on their 3ds loader tutorial.
/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/


#include "onv_3dsLoader.h"

onv_3dsLoader::onv_3dsLoader(char *modelname) 
{
     g_Load3ds.Import3DS(&g_3DModel, modelname);


    for(int i = 0; i < g_3DModel.numOfMaterials; i++)
    {
        // Check to see if there is a file name to load in this material
        if(strlen(g_3DModel.pMaterials[i].strFile) > 0)
        {
            // Use the name of the texture file to load the bitmap, with a texture ID (i).
            // We pass in our global texture array, the name of the texture, and an ID to reference it. 
///call this to actually make a texture
//NB: 
/////            CreateTexture(g_Texture, g_3DModel.pMaterials[i].strFile, i);
        }

        // Set the texture ID for this material
        g_3DModel.pMaterials[i].texureId = i;
    }
    g_ViewMode      = GL_TRIANGLES;
    g_bLighting     = true;
    g_RotateX       = 0.0f;
    g_RotateY       = 0.0f+180.0f;
    g_RotationSpeed = 3.0f;
    g_zoom = 1.0f;
}

void onv_3dsLoader::draw()
{
	for(int i = 0; i < g_3DModel.numOfObjects; i++)
	{
		if(g_3DModel.pObject.size() <= 0)
		{
			printf("SHIT happens\n");
			break;
		}
      t3DObject *pObject = &g_3DModel.pObject[i];

        if(pObject->bHasTexture) {

            // Turn on texture mapping and turn off color
            glEnable(GL_TEXTURE_2D);

            // Reset the color to normal again
            glColor3ub(255, 255, 255);

            // Bind the texture map to the object by it's materialID
            glBindTexture(GL_TEXTURE_2D, g_Texture[pObject->materialID]);
        } else {

            // Turn off texture mapping and turn on color
            glDisable(GL_TEXTURE_2D);

            // Reset the color to normal again
            glColor3ub(255, 255, 255);
        }

	glBegin(g_ViewMode);

		//t3DObject *pObject = &g_3DModel.pObject[i];
		pObject = &g_3DModel.pObject[i];
		for(int j = 0; j < pObject->numOfFaces; j++)
		{
			for(int whichVertex = 0; whichVertex < 3; whichVertex++)
			{

				int index = pObject->pFaces[j].vertIndex[whichVertex];
				glNormal3f(pObject->pNormals[ index ].x, pObject->pNormals[ index ].y, pObject->pNormals[ index ].z);

                    if(pObject->bHasTexture) {

                        // Make sure there was a UVW map applied to the object or else it won't have tex coords.
                        if(pObject->pTexVerts) {
                            glTexCoord2f(pObject->pTexVerts[ index ].x, pObject->pTexVerts[ index ].y);
                        }
                    } else {
                        if(g_3DModel.pMaterials.size() && pObject->materialID >= 0)
                        {
                            // Get and set the color that the object is, since it must not have a texture
                            BYTE *pColor = g_3DModel.pMaterials[pObject->materialID].color;

                            // Assign the current color to this model
                            glColor3ub(pColor[0], pColor[1], pColor[2]);
                        }
}


				glVertex3f(pObject->pVerts[ index ].x, pObject->pVerts[ index ].y, pObject->pVerts[ index ].z);
			}
		}

	glEnd();
}

}

