%**
%* This file is part of the OpenVIDIA project at http://openvidia.sf.net
%* Copyright (C) 2004, James Fung
%*
%* OpenVIDIA is free software; you can redistribute it and/or modify
%* it under the terms of the GNU General Public License as published by
%* the Free Software Foundation; either version 2 of the License, or
%* (at your option) any later version.
%*
%* OpenVIDIA is distributed in the hope that it will be useful,
%* but WITHOUT ANY WARRANTY; without even the implied warranty of
%* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%* GNU General Public License for more details.
%*
%* You should have received a copy of the GNU General Public License
%* along with OpenVIDIA; if not, write to the Free Software
%* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%**/

p1 = [2/480 3/640];
p2 = [251/480 189/640 ];
off= [229/480 188/640];
A=[2.556588 0.435609
    -0.333761 3.385378];
b= [-1.461656 -0.820864]';
c=[ -0.087951 -0.087059];

(A*p2'+b)./(c*p2'+[1 1]');
%ok this transformation is correct.
err=(A*p2'+b)./(c*p2'+[1 1]')-p1'


Cvo = [2.556588 0.435609 -1.461656 0
      -0.333761 3.385378  -0.820864 0
     -0.087951 -0.087059 1 0
 0 0 0 1]

Cvo*[ p2 1 1]' %gives p1 to be normalized by z
inv(Cvo)*[p1 1 1]' % gives p2 to normalized by z


p1gl = [3/640 2/480];
p2gl = [189/640 251/480];

%GLize the matrix. x/y
% This should be the modelview matrix.
%
% [ a22 a21 b2 0
%   a12 a11 b1 0
%  -c2  -c1 -1 0
%   0    0   0 1 ]
%

%Cgl= [3.385378 -0.333761  -0.820864 0
%    0.435609 2.556588 -1.461656 0
%    -0.087059  -0.087951  1 0
%    0 0 0 1]

%try b1/b2 in t1,t2 spots
% [ a22 a21  0 b2 
%   a12 a11  0 b1 
%  -c2  -c1 -1 0
%   0    0   0 1 ]
% seems to give same answer, z=1, w=1
Cgl= [3.385378 -0.333761 0  -0.820864 
    0.435609 2.556588 0 -1.461656 
    -0.087059  -0.087951  1 0
    0 0 0 1]

%flip Z AXIS
Cgl(3,:)*=-1
Cgl*[p2gl 1 1]'  %draw your quad at +1 (it'll get flipped)
%ans./ans(3)
%ans(3)=-ans(3) %flip it about the z axis.

F = [2.000000 0.000000 1.000000 0.000000
0.000000 -2.000000 -1.000000 0.000000
0.000000 0.000000 -1.002002 -0.200200
0.000000 0.000000 -1.000000 0.000000
]
F*ans

%glpoint is in NDCS (Normalized Device Coordinate System)
% which is defined as a cube, [-1,1] on each axis
glpoint =ans./ans(4) %normalize by homogeneous coords

% so our raster is 640x480, and glpoint will be rasterized onto
% that.  Note: 320x240 screen coordinate is 0,0 NDCS
glpoint.*[320, 240, 1, 1,]' + [320,240,0,0]'





% so this is ok, except for the -z axis thang. shucky durn.     




