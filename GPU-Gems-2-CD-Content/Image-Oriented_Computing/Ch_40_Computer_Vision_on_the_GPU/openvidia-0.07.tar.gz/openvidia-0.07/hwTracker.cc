/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "GenericDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"
#include "FragPipeDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include <iostream>

// new for the client Komputer stuff
#include "ShmFrame.h"
#include <getopt.h>


using namespace std;

// Global display object
FragPipeDisplay *d;
Dc1394 *dc1394;
GenericFilter *filter1, *filter2, *filter3, *filter4;
MomentFilter *momentFilter;

int imageWinWidth = 320;
int viewbuf = 0;//each buf has different filter
int imageWinHeight = 240;

// Komputer interface
int client_id = -1;
ShmFrame *shmFrame;
Window  mainWindow;
float HAND_X_COORD=0.0;
float HAND_Y_COORD=0.0;
float *readback[320*240*4];
float *shmdata;
boolean DEBUG=true;
boolean exec_tracking;
int MAX_PCI_HEADS=5;

void doTracking();
void render_visuals();
void createSharedMemoryArea();

/********************
 * functions related to image client, or Komputer
 ********************/
/*
 * by client we mean "tracking calculator part"
 * This is the main estimation/rendering function run the by clients
 */
void render_client() {

  static bool clientHasFrames = false;
  static bool workToDo=false;

  //task PRE amble :
  //continue or start working case
  if( shmFrame->Frame->requested_chirps > 0 ) {
    //check if we need to update image set
    shmFrame->enterMutex();
    if( shmFrame->Frame->isNew ) {
      if(DEBUG) cerr<<"Received new Frame[0] , id = "<<shmFrame->getID()<<endl;
      // XXX BIND FRAME HERE
      shmdata=(float *)shmFrame->getData();
      //turn on estimation engine
      exec_tracking = true;

      if(DEBUG) cerr<<"Bound new frame ok "<<endl;
      shmFrame->Frame->requested_chirps=0;
      shmFrame->Frame->isNew = false; 
    } else {
      cout <<"old frame"<<endl;
    }
    shmFrame->leaveMutex();
  }
  else  { 
    exec_tracking = false;
    usleep(1000);//sleep for 1ms. should be okay at 33ms/frame
    //sched_yield();//sleep for 1ms. should be okay at 33ms/frame
  }
  
  //do da wurk, one repetition
  if( exec_tracking ){
    doTracking();
    render_visuals();
  }
}

/*
 * Do one iteration of the tracking
 */
void doTracking() {
  //done in visuals now
  return;
}


////// GLUT CALLBACKS ///////////////
void reshape(int w, int h)
{
  glutSetWindow(mainWindow);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  //rosco version
  //glFrustum(-1.0,1.0,-1.0,1.0,1.0,100.0);
  //gluLookAt(0.0,0.0,0.0,  0.0, 0.0,-1.0,   0.0, 1.0, 0.0);

  //james version
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);

  //set the fpbuffer to have geometry identical to screen
  d->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  d->deactivate_fpbuffer();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}


void myIdle(){
  glutSetWindow(mainWindow);
  render_client();
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(mainWindow);
   switch (key) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
         viewbuf = atoi((const char * )&key);
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        float pixbuf[4] = {0.0};
       cerr << "("<<x<<","<<y<<"):";
        glReadPixels( (float)x,240.0-(float)y, 1,1, GL_RGBA, GL_FLOAT,  pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
      }
      break;
    case GLUT_RIGHT_BUTTON : 
      break;
  }
}




/* coords are normalized */
void drawCircleHelper(float x, float y) {
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glColor4f(0.0,0.0,1.0,1.0);
  glPointSize(10.0); //XXX move away.
  glClear(GL_DEPTH_BUFFER_BIT);
  glBegin(GL_POINTS);
    glVertex3f(x, y,   -1.0 );
  glEnd();
}

void drawFingerTip() {
  drawCircleHelper(HAND_X_COORD/320.0, HAND_Y_COORD/240.0);
}

void  doMoment() {
    float result[4] = {0.0};
    d->applySumFilter(momentFilter, 3, 4, result );
    HAND_X_COORD=result[1]/result[0];
    HAND_Y_COORD=result[2]/result[0];
    //cerr<<"Avg S : "<<result[3]/result[0]<<endl;
    
    //make sure that enough pixels are actually recognized as skin
    if( result[0] > 320*240*0.75 || result[0] < 0.001*320*240) {
      //      cerr<<"bad stats"<<endl;
      return;
    }
    float thresh[4] = {result[3]/result[0], result[3]/result[0], 0.008, 0.1};
    filter2->setCGParameter("thresh", thresh);
}

/********************
 * Draw to the frame buffer
 ********************/
void render_visuals() {
  d->activate_fpbuffer();
  d->clear_fpbuffer();
  d->reinit_texture(0, 320, 240, shmdata);
  d->bindTextureARB0(0);
  
  //cascade the filters
  d->applyFilter(filter1, 0,1);
  d->applyFilter(filter2, 1,2);
  d->applyFilter(filter3, 2,3);
  doMoment();//intensive. Not GFX card efficient utilization, but it works.
  d->deactivate_fpbuffer();
  
  d->bindTextureARB0(viewbuf);
  d->render();
  drawFingerTip();
  
  //optioanlly read back result
  //readback from screen will be different from pbuffer, choo choo choose 
  glReadPixels(0,0,320,240,GL_RGB,GL_FLOAT,readback); 
  d->showstats();
  glutSwapBuffers();
}  

/********************
 * Parse cmd line options
 ********************/
void posixify(int argc, char * argv[]); //fill in from orbits version
void posixify(int argc, char * argv[]){} //fill in from orbits version

static struct option long_options[] = {
  {"client", 0, 0, 'c'},
  {"help", 0, 0, 'h'},
  {0,0,0,0}
};

void printHelp()
{
  cout<<"hwTracker options:"<<endl;
  cout<<"   -c --client [id]  \t: run this instance as a client, with given id"<<endl;
  cout<<"   -h --help         \t: print this help message, and quit"<<endl;
  cout<<" Oh, and use -display :0.1 to before the above options to run on another screen"<<endl;
  cout<<endl;
}

void parse_cmdline(int argc, char **argv)
{
   char c;
   opterr = 0; /* prevent weird options from causing errors */
   posixify(argc,argv);

   while(1) {
     int this_option_optind = optind ? optind : 1;
     int option_index = 0;
     c = getopt_long (argc, argv, "c:h:",
                      long_options, &option_index);
     if (c == -1) break;
     switch(c){
     case 'c' :
       client_id = atoi(optarg);
       if( client_id < 0 || client_id > MAX_PCI_HEADS ) {
         cerr<<"Invalid Client ID "<<client_id<<" requested. aborting."<<endl;
         cerr<<"Client ID must lie in closed interval [0,5]"<<endl;
         exit(1);
       }
       cerr<<"Initializing as client ID "<<client_id<<endl;
       break;
     case 'h' : //print help
       printHelp();  
       exit(0);
       break;
     defalt :
       cerr<<"WARNING: unknown switch "<<c<<endl;
     }

   }
}


///// MAIN ///////////////////
int main(int argc, char** argv)
{
  cout <<"DEPRECATED -- USE SKINTRACK INSTEAD"<<endl;
  cout <<"DEPRECATED -- USE SKINTRACK INSTEAD"<<endl;
  cout <<"DEPRECATED -- USE SKINTRACK INSTEAD"<<endl;
  cout <<"DEPRECATED -- USE SKINTRACK INSTEAD"<<endl;


  cout<<"PLEASE FORCE TO CLIENT ID 3!!!"<<endl;
  glutInit(&argc, argv);
  parse_cmdline(argc, argv); //make sure this occurs after glut parses
  
  if(client_id<0) {
    cerr<<"You must supply a client id"<<endl;
    exit(-1);
  }
  
  cout <<"Creating Double Buffered Window" << endl;
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowSize(imageWinWidth, imageWinHeight);
  glutInitWindowPosition(100, 100);
  mainWindow=glutCreateWindow(argv[0]);
  
   d=new FragPipeDisplay(8, imageWinWidth, imageWinHeight, mainWindow );
   
   d->initDisplay();
   d->setImageSize( 320,240 );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
   d->initGL("FPsamples/FP-basic.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?

   //d->activate_fpbuffer();
   d->init_texture(0, 320, 240, shmdata);
   d->init_texture4f(1, 320, 240, shmdata);
   d->init_texture4f(2, 320, 240, shmdata);
   d->init_texture4f(3, 320, 240, shmdata);
   d->init_texture4f(4, 320, 240, shmdata);
   d->init_texture4f(5, 320, 240, shmdata);

   filter1 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-ibot-undistort.cg");
   filter2 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-rgb2hsv.cg");
   float thresh[4] = {0.020, 0.60, 0.02, 0.10};
   filter2->setCGParameter("thresh", thresh);
   filter3 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-erode.cg");

   momentFilter = new MomentFilter(320,240, d->getContext(), d->getProfile() );

   cout <<"creating shm area"<<endl;
   createSharedMemoryArea();
   cout <<"done creating shm area"<<endl;

   glutSetWindow(mainWindow);
   glutDisplayFunc(render_client);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}


/********************
 * Create Shm area
 ********************/
void createSharedMemoryArea() {
  //create shared memory areas, an image pair 0/1 for each head (card)
  int frame0ID = client_id*2-2;
  shmFrame = new ShmFrame(frame0ID);
}
