/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include<Cg/cg.h>
#include<Cg/cgGL.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "GenericDisplay.h"
#include "GenericFilter.h"
#include "MomentFilter.h"
#include "FragPipeDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "conversions.h"
#include "BoxApp.h"
#include "Correspond.h"
#include <iostream>
//#include "demo.h"
#include "ImageSender.h"
#include "Parameters.h"
//#include <SDL/SDL.h>
#include<SDL/SDL_image.h>
//#include<stdlib.h>
#include "FragmentProgram.h"
#include "FragmentProgramDouble.h"
GLuint texNames,texNamesold;

using namespace std;

// Global display object
FragPipeDisplay *d,*dold;
Dc1394 *dc1394;
ImlibCapture *im;
GenericFilter *filter1, *filter2, *filter3, *filter4, *filterK;
MomentFilter *momentFilter;
BoxApp *boxApp;
Correspond *corr;
float result[] = {0,0,0,0,0,0,0,0,0,0,0,0};
ImageSender sender=ImageSender();
Parameters initialGuess, convergedResult;
FragmentProgram *FPSimple;	   
FragmentProgramDouble *FPDouble;
int imageWinWidth = 320;
int viewbuf = 0;
int imageWinHeight = 240;
Window  Orbwin;
float valuecolor=1.0;
// extern CGparameter E1Texture, E2Texture, someColor, E2texCoord,E1texCoord, colorO, xincrementParam, yincrementParam;
extern CGprofile vProfile;
// extern CGprogram fragmentProgram;
extern CGcontext vContext;

/******************************************************/

/* The number of our GLUT window */
int window; 

/* rotation angle for the triangle. */
float rtri = 90.0f;
float rtrx=15.0f;
float rtry=0,rtrz=0;
float Rx=0.0f;
float Ry=0.0f;
//float Rz=1.2f;
float Rz=0.0f;//change this paramater for the size of the character
float bufRx=0,bufRy=0,bufRz=0,bufrtrx=0,bufrtri=0,bufoxIm=0,bufoyIm=0,bufozIm=0, bufYvec=0,bufXvecZ=0,bufZvecZ=0;

int points[8];
unsigned int screengain=510;

/*****************************************************/

///global state
bool useImlib = false;
bool putCoords = false;
bool fourclicks =false;

GLuint texture_name;
GLuint objet;
SDL_Surface * texture;



int numClickCorners = 0;

float gl_x=0.0;
float gl_y=0.0;

void reshape(int w, int h);
void myIdle();
void keyboard (unsigned char key, int x, int y);
void MouseFunc( int button, int state, int x, int y) ;
void drawCircleHelper(float x, float y);
void TellRWMHeCanUseImage(const char *dma_buf_) ;
// void exitFunc();
void initCoord();
void putAxes();
void drawCube();

void plmtoppm(char *filename);
void ppmtoplm(char *filename);
void loadLUT(char * filename,double LUT[256]);
int binary_search(double val,double LUT[256]);

unsigned char* dma_buf=0;
unsigned char* dma_old_buf=0; // could be invalid though!
unsigned char* dma_mouse_buf=0; // could be invalid though!
unsigned char* dma_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_old_buf_rgb=(unsigned char *)malloc(320*240*3);
unsigned char* dma_mouse_buf_rgb=(unsigned char *)malloc(320*240*3);
int framecounter=0;
int newdata=0;
float *foo[320*240*4];

double f = 368.28488;
double ox = 147.54834;
double oy = 126.01673;

double imageWidth = (double)imageWinWidth;
double imageHeight = (double)imageWinHeight;

float scalef;
float oxIm;
float oyIm;
float ozIm;
float buffIm[3]={0.0,0.0,0.0};
float XvecX;
float XvecY;
float XvecZ;
float YvecX;
float YvecY;
float YvecZ;
float ZvecX;
float ZvecY;
float ZvecZ;
int mov=0;
int plane=0;
//float valuegain=1.0;
float resulta[]={1.0,1.0,1.0,1.0};
float resultb[]={1.0,1.0,1.0,1.0};


 
 static GLubyte im2[3*128*128]; 
 static int texture2 = 1;
 static float grisFonce[] = { 0.25F,0.25F,0.25F,1.0F };
 static float blanc[] = { 1.0F,1.0F,1.0F,1.0F };
int cpt=0;


void printProjectionMatrix()
{
  float pmatrix[16]={0};
  glGetFloatv( GL_PROJECTION_MATRIX, pmatrix);
  printf("%5f %5f %5f %5f\n", pmatrix[0], pmatrix[4], pmatrix[8], pmatrix[12]);
  printf("%5f %5f %5f %5f\n", pmatrix[1], pmatrix[5], pmatrix[9], pmatrix[13]);
  printf("%5f %5f %5f %5f\n", pmatrix[2], pmatrix[6], pmatrix[10], pmatrix[14]);
  printf("%5f %5f %5f %5f\n", pmatrix[3], pmatrix[7], pmatrix[11], pmatrix[15]);
}

void lectureTexture(char *fichier,int dx,int dy) {
   FILE *f = fopen(fichier,"rb") ;
   if ( f ) {
     for ( int i = 0 ; i < dx ; i++ )
       for ( int j = 0 ; j < dy ; j++ )
         fread(&im2[(j*dy+i)*3],1,3,f) ;
     fclose(f) ; }
   } 


void initCoord(){
  scalef = 100.0;
  oxIm = result[0];
  oyIm = result[1];
  ozIm = result[2];
  XvecX = result[3];
  XvecY = result[4];
  XvecZ = result[5];
  YvecX = result[6];
  YvecY = result[7];
  YvecZ = result[8];
  ZvecX = result[9];
  ZvecY = result[10];
  ZvecZ = result[11];
  }

void putAxes(){
if(plane==1){
  glBegin(GL_LINES);
    glColor4f(1.0, 0.0, 0.0, 1.0);//Red X axe
    glVertex3f(oxIm, oyIm, ozIm);
    glVertex3f( oxIm+scalef*XvecX, oyIm+scalef*XvecY,  ozIm+scalef*XvecZ);
 
    
    glColor4f(0.0, 1.0, 0.0, 1.0);//Green Y axe
    glVertex3f(oxIm, oyIm, ozIm);
    glVertex3f( oxIm+scalef*YvecX, oyIm+scalef*YvecY,  ozIm+scalef*YvecZ);

    glColor4f(0.0, 0.0, 1.0, 1.0);//Blue Z axe
    glVertex3f(oxIm, oyIm, ozIm);
    glVertex3f( oxIm+scalef*ZvecX, oyIm+scalef*ZvecY,  ozIm+scalef*ZvecZ);
  glEnd();
  }
  }
  
void drawCube()
{

	GLfloat pos[]={0.0F,0.0F,-1.0F,0.0F};
	GLfloat shininess[]={50.0F};


   glMatrixMode(GL_MODELVIEW);
  glClear(GL_DEPTH_BUFFER_BIT);
  glLoadIdentity();
  glMatrixMode(GL_MODELVIEW); 
   initCoord();
   putAxes();  
  
  glLoadIdentity();
  
      
	float Matrice[]={XvecX,XvecY,XvecZ,0.0,-YvecX,-YvecY,-YvecZ,0.0,ZvecX,ZvecY,ZvecZ,0.0,0.0,0.0,0.0,1.0}; //matrice used for transposition glMultMatrix 
  glTranslatef(oxIm, oyIm, ozIm);
  glMultMatrixf(Matrice);
   //glScalef(10,10,10);
	
  glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
  
  
  glEnable(GL_LIGHT0);
  glEnable(GL_LIGHTING);
  glLightfv(GL_LIGHT0,GL_AMBIENT,grisFonce);
  glLightfv(GL_LIGHT0,GL_DIFFUSE,blanc);
  glMaterialfv(GL_FRONT,GL_SPECULAR,blanc);
  glMaterialfv(GL_FRONT,GL_SHININESS,shininess);
  
  // set the light position and attributes
//    const GLfloat lightPosition[] = { 1.0f, -1.0f, -1.0f, -1.0f };
//    glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
//    const GLfloat lightColorAmbient[] = { 0.6f, 0.6f, 0.6f, 0.6f };
//    glLightfv(GL_LIGHT0, GL_AMBIENT, lightColorAmbient);
//    const GLfloat lightColorDiffuse[] = { 0.52f, 0.5f, 0.5f, 1.0f };
//    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColorDiffuse);
//    const GLfloat lightColorSpecular[] = { 0.1f, 0.1f, 0.1f, 1.0f };
//    glLightfv(GL_LIGHT0, GL_SPECULAR, lightColorSpecular);
 
   

 glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);

// ---- Cr�ation d'un objet de texture. ------------------------------------------------
glGenTextures (1, &texture_name);
glBindTexture (GL_TEXTURE_2D, texture_name);
	
// Param�trage de la texture.
glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

// Chargement du fichier.
//ppmtoplm("1.ppm");
//plmtoppm("1.plm");

// texture = IMG_Load ("1.ppm");
// 
// if(!texture)
//         {
// 	   /* image failed to load */
//            printf("\n\n\nIMG_Load: %s\n\n\n", IMG_GetError());
//            SDL_Quit();
//           }

	
// Jonction entre OpenGL et SDL.
 glTexImage2D (GL_TEXTURE_2D, 0, GL_RGB, texture->w, texture->h, 0, 
               GL_RGB, GL_UNSIGNED_BYTE, texture->pixels);
	       
    
    
//     glTexImage2D(GL_TEXTURE_2D,
//                 0,3,128,128,0,
//                 GL_RGB,
//                 GL_UNSIGNED_BYTE,
//                 im2);
//  
// ---- Fin de cr�ation de l'objet de texture. -----------------------------------------

glEnable (GL_TEXTURE_2D);
glShadeModel(GL_SMOOTH);
glBindTexture (GL_TEXTURE_2D,  texture_name);

/*
resulta[0]=10.0;
resulta[1]=10.0;
resulta[2]=10.0;
resulta[3]=10.0;*/

 
 FPSimple->activate();

glRotatef(90.0,1.0,0.0,0.0);

glRotatef(90.0,0.0,1.0,0.0);
glScalef(20.0,20.0,20.0);

glTranslatef(0.0,1.35,0.0);

/*** Added ***/
   glutSolidTeapot(2.0);
/*
// On peut enfin cr�er un objet (ici un simple carr�).	
glBegin (GL_QUADS);
                // Front Face
                glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);      // Bottom Left Of The Texture and Quad
                glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);      // Bottom Right Of The Texture and Quad
                glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);      // Top Right Of The Texture and Quad
                glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);      // Top Left Of The Texture and Quad
                // Back Face
                glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);      // Bottom Right Of The Texture and Quad
                glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);      // Top Right Of The Texture and Quad
                glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);      // Top Left Of The Texture and Quad
                glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);      // Bottom Left Of The Texture and Quad
                // Top Face
                glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);      // Top Left Of The Texture and Quad
                glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);      // Bottom Left Of The Texture and Quad
                glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f,  1.0f);      // Bottom Right Of The Texture and Quad
                glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);      // Top Right Of The Texture and Quad
                // Bottom Face
                glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f);      // Top Right Of The Texture and Quad
                glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f);      // Top Left Of The Texture and Quad
                glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);      // Bottom Left Of The Texture and Quad
                glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);      // Bottom Right Of The Texture and Quad
                // Right face
                glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);      // Bottom Right Of The Texture and Quad
                glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);      // Top Right Of The Texture and Quad
                glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);      // Top Left Of The Texture and Quad
                glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);      // Bottom Left Of The Texture and Quad
                // Left Face
                glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);      // Bottom Left Of The Texture and Quad
                glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);      // Bottom Right Of The Texture and Quad
                glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);      // Top Right Of The Texture and Quad
                glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);      // Top Left Of The Texture and Quad

glEnd ();
*/
FPSimple->deactivate();	
// Fin de l'application de la texture.
glDisable (GL_TEXTURE_2D);

}
float buff[]={1.0,1.0,1.0,1.0};
void render_redirect() {
int i,j;

	// put here from demo:onrender
	// thought that these initializes were needed, but they went over cam, so placed before cam
	// now we see video for a frame and then blue screen, possible clearning of screen elsewhere..
	// seem to have no effect here.....
  ++framecounter;
               char cmdstr[1024];
	   	  float resultorbits[8];
     if (!useImlib) dc1394->tellThreadDoneWithBuffer();

    if( useImlib )  {
      d->reinit_texture(0, 320, 240, im->getRGBData());
    }
    else {
     d->reinit_texture(0, 320, 240, dma_buf_rgb);
       d->reinit_texture(1, 320, 240, dma_old_buf_rgb);
    }
    /*Apply the gain to the screen*/
   // cerr<<"screengain="<<screengain<<endl;
    //dc1394->set_gain(screengain);
    /*
    d->activate_fpbuffer();
  d->clear_fpbuffer();
    //d->reinit_texture(0, imageWinWidth, imageWinHeight, dma_buf_rgb);
    d->reinit_texture(0, imageSrcWidth, imageSrcHeight, dma_buf_rgb);
    d->bindTextureARB0(0);
    if( !USE_SHM ) dc1394->tellThreadDoneWithBuffer();

    //cascade the filters
    d->applyFilter(filter1, 0,1);//undistort
  d->clear_fpbuffer();
    d->applyFilter(filter2, 1,2,l,r,t,b,f );//hsv conv + thresh
    d->applyFilter(filter3, 2,3,l,r,t,b,f );//morpho
    doMoment();//intensive. Not GFX card efficient utilization, but it works.
 */
    
    
   //d->bindTextureARB1(1);
    //d->bindTextureARB1(1);
    d->bindTextureARB0(0);
//    if (!useImlib) dc1394->tellThreadDoneWithBuffer();
  dc1394->set_gain(screengain);
          
    //cascade the filters
    d->applyFilter(filter1, 0,2 ,
                    -ox, (((double)imageWidth)-ox), 
                    (((double)imageHeight)-oy), -oy, f )  ;
  /*******************************************/
      ///d->activate_fpbuffer();
      //d->clear_fpbuffer();
      //FPDouble = new FragmentProgramDouble( vContext, vProfile, "FPsamples/FP-GiveK-new.cg",0, 1);

   //   d->bindTextureARB0(0);
   //   d->bindTextureARB1(1);
      
      
      
      
     //FPDouble->activate();
     //d->activate_fpbuffer();
 //     FPDouble->drawFilterQuad(2, 0.0, 1.0, 0.0, 1.0);
       if(fourclicks){
       
  d->activate_fpbuffer();
  d->clear_fpbuffer();
      d->bindTextureARB0(2);
      d->bindTextureARB1(1);
//       d->applyFilter(filter1, 1,3,
//                     -ox, (((double)imageWidth)-ox), 
//                     (((double)imageHeight)-oy), -oy, f )  ;
	// d->bindTextureARB1(3);
      d->applyFilter(filterK, 0, 2);
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) 320, (GLsizei) 240);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

//   	buff[0]=resultb[0];
//         buff[1]=resultb[1];
// 	buff[2]=resultb[2];
// 	buff[3]=resultb[3];
     
     d->applySumFilter(momentFilter, 2, 4, resultb );
  
     for(i=0;i<4;i++)
     resultb[i]=resultb[i]/resultb[3];
     
     resultb[0]=(resultb[0]+resultb[1]+resultb[2])/3;
     
//      resulta[0]=resultb[0]/resultb[3];
//      resulta[1]=resultb[1]/resultb[3];
//      resulta[2]=resultb[2]/resultb[3];
//      resulta[3]=1;

     
     
//      resulta[0]=resulta[0]*(resultb[0]/resultb[3]);
//      resulta[1]=resulta[0]*(resultb[1]/resultb[3]);
//      resulta[2]=resulta[0]*(resultb[2]/resultb[3]);
//      resulta[3]=resulta[0]*(resultb[3]/resultb[3]);


  
  if(abs(1.0-resultb[0])>0.1)
      {
     
//        	resulta[0]=abs(1.0-resultb[0]);
//          resulta[1]=abs(1.0-resultb[1]);
//  	resulta[2]=abs(1.0-resultb[2]);
//  	resulta[3]=abs(1.0-resultb[3]);
      //  if(cpt%2==0){
	for(int i=0;i<4;i++)
		resulta[i]=resulta[i]*resultb[i];
	//}
	//cpt++;
	
	/*cpt+=2;
	if(cpt==2)cpt=0;
	*/     
	}
   FPSimple->putgain(resulta);
 
    
//    cerr<<"resulta = ["<<resulta[0]<<", "<<resulta[1]<<", ";
//      cerr<<resulta[2]<<", "<<resulta[3]<<"]"<<endl;
//      
  //    cerr<<"K= "<<resultb[0]<<endl;
    //  cerr<<"K apply= "<<resulta[0]<<endl;
      
// 
//      cerr<<"total good points= ["<<resultb[3] <<"]"<<endl;

  d->deactivate_fpbuffer();
}
//     //printf("%f",result[0]);
	//valuegain=result[0]/result[3];
//    //valuegain=1;
    
     //FPDouble->deactivate();
    //d->deactivate_fpbuffer();
    
    /******************************************/ 
    
     
  d->render();
  
    // unconcered here, give gain the proper value and it will run...

 drawCube();   
   glutSwapBuffers();

}  

///// MAIN ///////////////////

int main(int argc, char** argv)
{

   glutInit(&argc, argv);
   /*******************Load cube texture*******************/
   
     //lectureTexture("Marbre.raw",128,128) ;
 texture = IMG_Load ("mohit.jpg");

if(!texture)
        {
	   /* image failed to load */
           printf("\n\n\nIMG_Load: %s\n\n\n", IMG_GetError());
           SDL_Quit();
          }
	  /************************************/
   //if an argument is given, assume we are using an image file
   if( argc == 2 ) { 
     cout<<"Using image file: "<<argv[1]<<endl;
     cout<<"Note: currently, image file must be 320x240 resolution"<<endl;
     useImlib = true;
   }
   else {
     useImlib = false;
   }
   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);

   corr = new Correspond(imageWinWidth, imageWinHeight );

   //typical problem : can't open imlib without display, yet cant
   // size display without loading image from imlib
   d=new FragPipeDisplay(8, imageWinWidth, imageWinHeight, Orbwin );
  
  
   d->initDisplay();

   d->setImageSize( 320,240 );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0);
    
   d->initGL("FPsamples/FP-basic.cg"); //output must have FP program active 
                                       //for NV_TEXTURE_RECTANGLE type?
   if( useImlib ) { 
     im = new ImlibCapture(0,0);
     im->initCapture(d);
     im->loadFile(argv[1]); 
     assert( im->getRGBWidth() == imageWinWidth );
     assert( im->getRGBHeight() == imageWinHeight );
   }
   else {
     dc1394=new Dc1394();
     dc1394->start();
   }

   //d->activate_fpbuffer();
   d->init_texture(0, 320, 240, foo);
   d->init_texture4f(1, 320, 240, foo);
   d->init_texture4f(2, 320, 240, foo);
   d->init_texture4f(3, 320, 240, foo);
   d->init_texture4f(4, 320, 240, foo);
   d->init_texture4f(5, 320, 240, foo);
  
   
   
   
   filter1 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-ibot-undistort.cg");
   filter2 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-rgb2hsv.cg");
   float thresh[4] = {0.020, 0.60, 0.02, 0.10};
   filter2->setCGParameter("thresh", thresh);
   filter3 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-erode-optim.cg");
   filter4 = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-mohit.cg");
   
   filterK = new GenericFilter(320,240, d->getContext(), d->getProfile(), 
                               "FPsamples/FP-GiveK-new.cg");
			       

   momentFilter = new MomentFilter(320,240, d->getContext(), d->getProfile() );

   boxApp = new BoxApp();

  
   FPSimple = new FragmentProgram( vContext, vProfile, "FPsamples/FP-lightspacegain.cg",  texture_name);
   
   
   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
  
   glutMainLoop();
   return 0; 
}

////////////////////
////// GLUT CALLBACKS ///////////////
////////////////////
void reshape(int w, int h)
{
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  glFrustum(  (((double)imageWidth)-(320.0-ox))/f, -(320.0-ox)/f ,
              (((double)imageHeight)-oy)/f, -oy/f, 
                f/f,  (f+1000) )  ;

  printProjectionMatrix();
  gluLookAt( 0.0,0.0,0.0,  0,0, f,   0.0,  1.0, 0.0);
  printProjectionMatrix();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();

  //set the fpbuffer to have geometry identical to screen
  d->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  d->deactivate_fpbuffer();



}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
         viewbuf = atoi((const char * )&key);
         cout<<"new viewbuf is "<<viewbuf<<endl;
         break;
      case 27:
        dc1394->set_gain(510);
        exit(0);
	break;
	 
	/****Gain**************/	
	case '+':
      //valuegain+=0.1f;	
      screengain+=200;
      //valuecolor+=0.1;
      printf("+");
      if(screengain>510){screengain=510;}
    
      //cerr<<screengain;
	break;
    case '-':
    screengain-=200;
    //valuecolor-=0.1;
    printf("-");
     if(screengain<10||screengain>1000){screengain=11;}
  
      //valuegain-=0.1f;	
    //  cerr<<screengain;
    	break;
    /****************ON/OFF Axes**********************/
    case 'G':
    case 'g':
    	if(plane ==0)plane=1;
	else plane=0;
	break;
// case 'z':
// valuecolor+=0.1f;break;
// case 'Z':
// valuecolor-=0.1f;break;

	default:
		break;
   }
}

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) {
        float pixbuf[4] = {0.0};
        cerr << "("<<x<<","<<y<<"):";
        glReadPixels( (float)x,240.0-(float)y, 1,1, GL_RGBA, GL_FLOAT,  pixbuf);
        cerr <<"[ "<< pixbuf[0] <<", "<<pixbuf[1]<<", ";
              cerr << pixbuf[2] <<", "<<pixbuf[3]<<"] "<<endl;
        corr->add_point(x,y); 
        numClickCorners++;
        if( numClickCorners%4==0 )  {
          int points[8];
          corr->get_points(points);
          cerr<<"points: "<<points[0]<<" "
                          <<points[1]<<" "
                          <<points[2]<<" "
                          <<points[3]<<" "
                          <<points[4]<<" "
                          <<points[5]<<" "
                          <<points[6]<<" "
                          <<points[7]<<endl;
           char cmdstr[1024];
           //sprintf(cmdstr, "./fuckyou.m %d %d %d %d %d %d %d %d > numbers.txt", points[0], points[1], points[2], points[3], points[4], points[5], 
//points[6], points[7]);
           sprintf(cmdstr, "./planarCoords.m %d %d %d %d %d %d %d %d > numbers.txt", points[0], points[1], points[2], points[3], points[4], points[5], 
points[6], points[7]);
           system(cmdstr);
           FILE *fp = fopen("numbers.txt", "r");
           fscanf(fp, "%f %f %f %f %f %f %f %f %f %f %f %f", &result[0],
                  &result[1], &result[2], &result[3], &result[4],
                  &result[5], &result[6], &result[7], &result[8],
                  &result[9], &result[10], &result[11] );
           cerr<<"result = "<<result[0]<<" "<<
                 result[1]<<" "<<result[2]<<" "<<
                 result[3]<<" "<<result[4]<<" "<<
                 result[5]<<" "<<result[6]<<" "<<
                 result[7]<<" "<<result[8]<<" "<<
                 result[9]<<" "<<result[10]<<" "<<
                 result[11]<<endl;
           fclose(fp);
	   fourclicks=true;
         }
	 
      }
      break;
    case GLUT_RIGHT_BUTTON : 
     cerr<<"Mouse click, image raster coord: "<<x<<" "<<y<<endl;
     gl_x = ((float)(double)x-ox);
     gl_y = ((float)(double)y-oy); 


      break;
  }
}


/* coords are normalized */
void drawCircleHelper(float x, float y) {
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glColor4f(0.0,0.0,1.0,1.0);
  glPointSize(10.0); //XXX move away.
  glClear(GL_DEPTH_BUFFER_BIT);
  glBegin(GL_POINTS);
    glVertex3f(x, y,   -1.0 );
  glEnd();
}

/* Tell function executed in context of Dc1394 thread */
void TellRWMHeCanUseImage(const char *dma_buf_) {
  //save old frame
  dma_old_buf=dma_buf;
  unsigned char *tmp=dma_old_buf_rgb;
  dma_old_buf_rgb=dma_buf_rgb;

  //write to new frame
  dma_buf=(unsigned char *)dma_buf_;
  dma_buf_rgb=tmp;
  uyvy2rgb(dma_buf,dma_buf_rgb,320*240);

  //have only one, need two before we do any orbits
  if(dma_old_buf==0) {
    uyvy2rgb(dma_buf,dma_buf_rgb,320*240);
    dc1394->tellThreadDoneWithBuffer();
    return;
  }
  newdata=1;
}

