/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "TextureSummator.h"
#include <iostream>
#include <assert.h>
using namespace std;

static bool debug=true;

///Creates a texture summator object.  The texture summator 
///basically executes a list of openGL commands to sum whatever
///the contents a given texture happen to be.
///The texture to be summed should already be binded to ARB0
///(the summator does not bind to avoid redundant calls)
///160x120 and 320x240 textures are supported.

TextureSummator::TextureSummator (
                                  ///image/texture width
                                  int w, 
                                  ///image/texture height
                                  int h, 
                                  /// floating point buffer width
                                  int fpw, 
                                  /// floating point buffer height
                                  int fph, 
                                  /// current CG context for Fragment Progs.
                                  CGcontext fContext, 
                                  /// current CG profile for Fragment Progs.
                                  CGprofile fProfile,
                                  /// texture name to be summed. deprecated.
                                  GLuint tex)
{
  sumsWidth = 11;
  width = w;
  height = h;
 
  fpbwidth = fpw;
  fpbheight = fph;

  texName = tex;
 
  if ( (width != 320 && width != 160)  ||
       (height!= 240 && height!= 120) ) 
  {
    cerr<<"ERROR: ONLY 160x120 or 320x240 images allowed."<<cerr;
  }

  context = fContext;
  profile = fProfile;

  sumListName = glGenLists(1);
  listIsCompiled = false;

  char name[100] = {'\0'};
  char dirname[100] = {'\0'};

  //sprintf(dirname, "FPestpchirp2m");
  sprintf(dirname, "FPsamples");

  sprintf(name, "%s/FP-sum%dx%d-pass-1.cg", dirname,width,height);
  FPpass1 = new FragmentProgram( context, profile, name, texName);

  sprintf(name, "%s/FP-sum%dx%d-pass-2.cg", dirname, width,height);
  FPpass2 = new FragmentProgram( context, profile, name, texName);

  sprintf(name, "%s/FP-nop.cg", dirname, width,height);
  FPpassthru = new FragmentProgram( context, profile, name, texName);

  glGenTextures(1, &passtexture);
  glGenTextures(1, &paramtexture);

  glBindTexture(GL_TEXTURE_RECTANGLE_NV, passtexture);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER,
                  GL_LINEAR);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER,
                  GL_LINEAR);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGBA_NV,
            w, h,
            0, GL_RGBA, GL_FLOAT, NULL);

  glBindTexture(GL_TEXTURE_RECTANGLE_NV, paramtexture);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER,
                  GL_LINEAR);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER,
                  GL_LINEAR);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGBA_NV,
  //          sumsWidth, 1,
w,h,
            0, GL_RGBA, GL_FLOAT, NULL);


}


///compile a display list to encapsulate openGL commands required to
///execute the sum.
void TextureSummator::compileList(//target texture. deprecated.
                                  GLuint texIn)
{
  glNewList( sumListName, GL_COMPILE);
    GLsum(texIn);
  glEndList();
  listIsCompiled = true;
}

void TextureSummator::GLsum(GLuint texIn )
{
  int dist=0;
  float texwidth = 1.0/((float)fpbwidth); //display one pixel wide
  float texheight = ((float)height)/((float)fpbheight); 
    //1.0 for full size, 0.5 1x down etc.
  float origin = 0.0;
  float texdist=-1.0;
/* OPTIM
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texIn);
*/

  glClearColor(0.0,0.0,0.0,0.0);
  //OPTIMglClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  //render a single column.  each fragment output is the sum of its row
  FPpass1->activate();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  //texheight=texheight/3.0;  //a decimation can be applied to speed up
                              //computation, sacrificing accuracy
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, (float)height, dist);
    glVertex3f( origin, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 0.0, dist);
    glVertex3f( origin, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,1.0, 0.0, dist);
    glVertex3f( origin+texwidth, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,1.0, (float)height, dist);
    glVertex3f( origin+texwidth, origin+texheight, texdist);
  glEnd();

  //if using display lists, this doesnt show anything during compilation.
/*
  float result[4];
  glReadPixels(0,fpbheight-height,1,1,GL_RGBA,GL_FLOAT,result);
  cerr<<"Sum1 "<<result[0]<<" "<<result[1]<<" ";
  cerr<<result[2]<<" "<<result[3]<<endl;
*/


  //FPpass1->deactivate();
  //FPpass2->activate();
  FPpass2->bind();

  //now read this colum back into a local texture
/* OPTIM 
  glActiveTextureARB(GL_TEXTURE0_ARB);
  //glBindTexture(GL_TEXTURE_RECTANGLE_NV, passtexture);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texIn);
*/
  //glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0,0,0, 1,height);
  glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 
                       0, 0,
                       0, fpbheight-height,  //start pos
                       1, height);


  //do pass2, which sums the column up
  //display a single pixel - sufficient to sum whole image
  //origin then has summation
  //OPTIMglClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glBegin(GL_QUADS);
    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 0.0, dist);
    //glVertex3f( origin, origin, texdist);
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 1.0, dist);
    glVertex3f( origin, origin+1.0/(float)height, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 0.0, dist);
    glVertex3f( origin, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,1.0, 0.0, dist);
    glVertex3f( origin+texwidth, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,1.0, 1.0, dist);
    glVertex3f( origin+texwidth, origin+1.0/(float)height, texdist);
  glEnd();

  FPpass2->deactivate();

  //glBindTexture(GL_TEXTURE_RECTANGLE_NV, paramtexture );
  //glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0,0, 0,height-1, 1,1 );


}

///GLsum_and_store executes a summation and stores the result in a 
///texture.  This defers the readback of the value to some later
///point, allowing for CPU/GPU interaction to be collapsed
///to only when necessary.
void TextureSummator::GLsum_and_store(GLuint texIn /**texture to be summed. 
                                                      deprecated. */, 
                                      int xoffset /** offset in storage texture 
                                                      where sum is to be
                                                      stored */ )
{
  GLsum(texIn);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, paramtexture );
  //origin pixel has summation
  //glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, xoffset,0, 0,fpbheight-1, 
  //                     1,1 );
  glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, xoffset,0, 
                       0,  fpbheight-1, 
                       1,  1 );
  //if using display lists, this doesnt show anything during compilation.
/*
  float result[4];
  glReadPixels(0,fpbheight-1,1,1,GL_RGBA,GL_FLOAT,result);
  cerr<<"Sum1 "<<result[0]<<" "<<result[1]<<" ";
  cerr<<result[2]<<" "<<result[3]<<endl;
*/

  //debug
/*
  {
    float result[4];
    glReadPixels(0,fpbheight-1,1,1,GL_RGBA,GL_FLOAT,result);
    cerr<<"Store:"<<result[0]<<" "<<result[1]<<" ";
    cerr<<result[2]<<" "<<result[3]<<endl;
  }
*/


}

///retrieveSums() is used to get the results of the summations.
///It reads the stored summations from offset xstart, returning xnum
///values in the results array
void TextureSummator::retrieveSums(int xstart /** starting offset of where to
                                                  begin reading back from the
                                                  stored sums */, 
                                   int xnum /**number of values to read back */,
                                   float *results /**array to place results into */)
{ 
  int dist=0;
  float texwidth = ((float)sumsWidth)/((float)fpbwidth);
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;

  assert( xnum <= sumsWidth );

  glClearColor(0.0,0.0,0.0,0.0);
//OPTIM  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, paramtexture );
  //display the texture where the results are stored.

//OPTIM  glMatrixMode(GL_MODELVIEW);
//OPTIM  glLoadIdentity();

  glColor4f(0.0,1.0,1.0,0.0);

  FPpassthru->activate();
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 1.0, dist);
    glVertex3f( origin, origin+1.0/(float)fpbheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 0.0, dist);
    glVertex3f( origin, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,(float)sumsWidth, 0.0, dist);
    glVertex3f( origin+texwidth, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,(float)sumsWidth, 1.0, dist);
    glVertex3f( origin+texwidth, origin+1.0/(float)fpbheight, texdist);
  glEnd();
  FPpassthru->deactivate();


  glReadPixels(xstart,fpbheight-1,xnum,1,GL_RGBA,GL_FLOAT,results);
/* //debug
  cerr<<"ReStore:"<<results[0]<<" "<<results[1]<<" ";
  cerr<<results[2]<<" "<<results[3]<<endl;
*/


  //debug, read the whole buffer
/*
  {
    float *sums = (float *)malloc(sizeof(float)*4*sumsWidth);
    glReadPixels(0,fpbheight-1,sumsWidth,1,GL_RGBA,GL_FLOAT,sums);
    cerr<<"Restore=[";
    for( int i=0 ; i<sumsWidth*4 ; i++ ) {
      cerr<<sums[i]<<", ";
    } 
    cerr<<"]"<<endl;
    free(sums);
  }
*/

  
}

///execute the summation of the current texture in ARB0
void TextureSummator::sum(float *result /**pointer to where to place result*/, 
                           GLuint texIn /**target texture, deprecated*/)
{
  GLsum(texIn);
  //snarf out the value
  glReadPixels(0,fpbheight-1,1,1,GL_RGBA,GL_FLOAT,result);
  //cerr<<"Sum2 "<<result[0]<<" "<<result[1]<<" ";
  //cerr<<result[2]<<" "<<result[3]<<endl;

  return;
}

///execute the summation of the current texture in ARB0 as a display list.
///this function compiles the display list first if it has not yet
///been complied.
void TextureSummator::sumList( float *result /** pointer to where result is 
                                                 to be put */, 
                               GLuint texIn ///target texture, deprecated. 
                               )
{

  if( !isListCompiled() ) {
    cerr<<"Compiling List"<<endl;
    compileList(texIn);
    listIsCompiled = true;
  }
  glCallList(sumListName); 
  //CPU intensive. +30% load on P4 2.4 GHz !! aye carumba
  //glReadPixels(0,fpbheight-1,1,1,GL_RGBA,GL_FLOAT,result);
  //adding the select here seems to reduce load (less spin locking?)
  //E.g. 40% load is reduced to under 10% on FX5200 with 33000 msec delay
  //before the readpixels call
  sched_yield();
  {  struct timeval tv; tv.tv_sec = 0; tv.tv_usec = 4000;
      select(0,0,0,0, &tv);
}
  glReadPixels(0,fpbheight-1,1,1,GL_RGBA,GL_FLOAT,result);

//  cerr<<"SumL "<<result[0]<<" "<<result[1]<<" ";
//  cerr<<result[2]<<" "<<result[3]<<endl;
 

}

