/*
 *  V4L2 video capture example
 */
/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 * based on Video4linux2 capture.c example code from 
 * http://v4l2spec.bytesex.org/spec/capture-example.html
 **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <getopt.h>             /* getopt_long() */

#include <fcntl.h>              /* low-level i/o */
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <iostream>
#include <fstream>

#include "V4L2.h"
using namespace std;
extern void TellRWMHeCanUseImage(const char *);

void V4L2 :: tellThreadDoneWithBuffer() {
  if( bufferUsed != 0 ) {}
  bufferUsed=0;
}

V4L2::~V4L2() {}

void V4L2::set_controls()  {

  struct v4l2_queryctrl queryctrl;
  struct v4l2_control control;
 
  memset (&queryctrl, 0, sizeof (queryctrl));
  queryctrl.id = V4L2_CID_BRIGHTNESS;
 
  if (-1 == ioctl (fd, VIDIOC_QUERYCTRL, &queryctrl)) {
          if (errno != EINVAL) {
                  perror ("VIDIOC_QUERYCTRL");
                 exit ();
          } else {
                  printf ("V4L2_CID_BRIGHTNESS is not supported\n");
          }
  } else if (queryctrl.flags & V4L2_CTRL_FLAG_DISABLED) {
          printf ("V4L2_CID_BRIGHTNESS is not supported\n");
  } else {
          memset (&control, 0, sizeof (control));
          control.id = V4L2_CID_BRIGHTNESS;
          control.value = queryctrl.default_value;
          control.value -=3000;
          cerr<<"[V4L2] Brightness : "<<control.value<<endl;
  
          if (-1 == ioctl (fd, VIDIOC_S_CTRL, &control)) {
                  perror ("VIDIOC_S_CTRL");
                  exit ();
          }
  }
  memset (&queryctrl, 0, sizeof (queryctrl));
  queryctrl.id = V4L2_CID_SATURATION;
 
  if (-1 == ioctl (fd, VIDIOC_QUERYCTRL, &queryctrl)) {
          if (errno != EINVAL) {
                  perror ("VIDIOC_QUERYCTRL");
                 exit ();
          } else {
                  printf ("V4L2_CID_SATURATION is not supported\n");
          }
  } else if (queryctrl.flags & V4L2_CTRL_FLAG_DISABLED) {
          printf ("V4L2_CID_SATURATION is not supported\n");
  } else {
          memset (&control, 0, sizeof (control));
          control.id = V4L2_CID_SATURATION;
          control.value = queryctrl.default_value;
          control.value += 24000;
          cerr<<"[V4L2] Saturation : "<<control.value<<endl;
  
          if (-1 == ioctl (fd, VIDIOC_S_CTRL, &control)) {
                  perror ("VIDIOC_S_CTRL");
                  exit ();
          }
  }
  memset (&queryctrl, 0, sizeof (queryctrl));
  queryctrl.id = V4L2_CID_CONTRAST;
 
  if (-1 == ioctl (fd, VIDIOC_QUERYCTRL, &queryctrl)) {
          if (errno != EINVAL) {
                  perror ("VIDIOC_QUERYCTRL");
                 exit ();
          } else {
                  printf ("V4L2_CID_CONTRAST is not supported\n");
          }
  } else if (queryctrl.flags & V4L2_CTRL_FLAG_DISABLED) {
          printf ("V4L2_CID_CONTRAST is not supported\n");
  } else {
          memset (&control, 0, sizeof (control));
          control.id = V4L2_CID_CONTRAST;
          control.value = queryctrl.default_value;
          control.value += 20000;
          cerr<<"[V4L2] Contrast : "<<control.value<<endl;
  
          if (-1 == ioctl (fd, VIDIOC_S_CTRL, &control)) {
                  perror ("VIDIOC_S_CTRL");
                  exit ();
          }
  }

  memset (&queryctrl, 0, sizeof (queryctrl));
  queryctrl.id = V4L2_CID_HUE;
 
  if (-1 == ioctl (fd, VIDIOC_QUERYCTRL, &queryctrl)) {
          if (errno != EINVAL) {
                  perror ("VIDIOC_QUERYCTRL");
                 exit ();
          } else {
                  printf ("V4L2_CID_HUE is not supported\n");
          }
  } else if (queryctrl.flags & V4L2_CTRL_FLAG_DISABLED) {
          printf ("V4L2_CID_CONTRAST is not supported\n");
  } else {
          memset (&control, 0, sizeof (control));
          control.id = V4L2_CID_HUE;
          control.value = queryctrl.default_value;
          control.value -= 4000;
          cerr<<"[V4L2] Hue : "<<control.value<<endl;
  
          if (-1 == ioctl (fd, VIDIOC_S_CTRL, &control)) {
                  perror ("VIDIOC_S_CTRL");
                  exit ();
          }
  }


}


#define CLEAR(x) memset (&(x), 0, sizeof (x))
static void
errno_exit                     (const char *           s)
{
        fprintf (stderr, "%s error %d, %s\n",
                 s, errno, strerror (errno));

        // (EXIT_FAILURE);
}

static int
xioctl                          (int                    fd,
                                 int                    request,
                                 void *                 arg)
{
        int r;

        do r = ioctl (fd, request, arg);
        while (-1 == r && EINTR == errno);

        return r;
}


static void write_image(const void *p)
{
  FILE *FD = fopen("output.ppm", "w");
  fprintf(FD, "P6\n320 240\n255\n");
  fwrite(p, 320*240, 3, FD );
  fclose(FD);
  //(0);
}

static void
process_image                   (const void *           p)
{
        fputc ('.', stdout);
        write_image(p);
        fflush (stdout);
}
char *V4L2::read_frame(void)
{
        struct v4l2_buffer buf;
	unsigned int i;

	switch (io) {
	case IO_METHOD_READ:
    		if (-1 == read (fd, buffers[0].start, buffers[0].length)) {
            		switch (errno) {
            		case EAGAIN:
                    		return 0;

			case EIO:
				/* Could ignore EIO, see spec. */

				/* fall through */

			default:
				errno_exit("read");
			}
		}

    		//process_image (buffers[0].start);
          return (char *)buffers[0].start;

		break;

	case IO_METHOD_MMAP:
		CLEAR (buf);

            	buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            	buf.memory = V4L2_MEMORY_MMAP;

    		if (-1 == xioctl (fd, VIDIOC_DQBUF, &buf)) {
            		switch (errno) {
            		case EAGAIN:
                    		return 0;

			case EIO:
				/* Could ignore EIO, see spec. */

				/* fall through */

			default:
				errno_exit("VIDIOC_DQBUF");
			}
		}

                assert (buf.index < n_buffers);

	        //process_image (buffers[buf.index].start);

		if (-1 == xioctl (fd, VIDIOC_QBUF, &buf))
			errno_exit("VIDIOC_QBUF");
          return (char *)buffers[buf.index].start;
		break;

	case IO_METHOD_USERPTR:
		CLEAR (buf);

    		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    		buf.memory = V4L2_MEMORY_USERPTR;

		if (-1 == xioctl (fd, VIDIOC_DQBUF, &buf)) {
			switch (errno) {
			case EAGAIN:
				return 0;

			case EIO:
				/* Could ignore EIO, see spec. */

				/* fall through */

			default:
				errno_exit("VIDIOC_DQBUF");
			}
		}

		for (i = 0; i < n_buffers; ++i)
			if (buf.m.userptr == (unsigned long) buffers[i].start
			    && buf.length == buffers[i].length)
				break;

		assert (i < n_buffers);

    		//process_image ((void *) buf.m.userptr);

		if (-1 == xioctl (fd, VIDIOC_QBUF, &buf))
			errno_exit("VIDIOC_QBUF");
          return (char *) buf.m.userptr;

		break;
	}

}
/*
void V4L2::
mainloop                        (void)
*/
void V4L2::run()
{
        char *newimgbuf;
        while (1) {
                for (;;) {
                        fd_set fds;
                        struct timeval tv;
                        int r;

                        FD_ZERO (&fds);
                        FD_SET (fd, &fds);

                        /* Timeout. */
                        tv.tv_sec = 2;
                        tv.tv_usec = 0;

                        r = select (fd + 1, &fds, NULL, NULL, &tv);

                        if (-1 == r) {
                                if (EINTR == errno)
                                        continue;

                                errno_exit("select");
                        }

                        if (0 == r) {
                                fprintf (stderr, "select timeout\n");
                                // (EXIT_FAILURE);
                        }
               lock();
			if (newimgbuf = read_frame ())
                    		break;
               unlock();
	
			/* EAGAIN - continue select loop. */
                }
                bufferUsed = 1;
                TellRWMHeCanUseImage((const char *)newimgbuf);
                
               
        }
}

void V4L2::stop_capturing(void)
{
        enum v4l2_buf_type type;

	switch (io) {
	case IO_METHOD_READ:
		/* Nothing to do. */
		break;

	case IO_METHOD_MMAP:
	case IO_METHOD_USERPTR:
		type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

		if (-1 == xioctl (fd, VIDIOC_STREAMOFF, &type))
			errno_exit ("VIDIOC_STREAMOFF");

		break;
	}
}

void V4L2::start_capturing(void)
{
        unsigned int i;
        enum v4l2_buf_type type;

	switch (io) {
	case IO_METHOD_READ:
		/* Nothing to do. */
		break;

	case IO_METHOD_MMAP:
		for (i = 0; i < n_buffers; ++i) {
            		struct v4l2_buffer buf;

        		CLEAR (buf);

        		buf.type        = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        		buf.memory      = V4L2_MEMORY_MMAP;
        		buf.index       = i;

        		if (-1 == xioctl (fd, VIDIOC_QBUF, &buf))
                    		errno_exit ("VIDIOC_QBUF");
		}
		
		type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

		if (-1 == xioctl (fd, VIDIOC_STREAMON, &type))
			errno_exit ("VIDIOC_STREAMON");

		break;

	case IO_METHOD_USERPTR:
		for (i = 0; i < n_buffers; ++i) {
            		struct v4l2_buffer buf;

        		CLEAR (buf);

        		buf.type        = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        		buf.memory      = V4L2_MEMORY_USERPTR;
        		buf.m.userptr	= (unsigned long) buffers[i].start;
			buf.length      = buffers[i].length;

        		if (-1 == xioctl (fd, VIDIOC_QBUF, &buf))
                    		errno_exit ("VIDIOC_QBUF");
		}


		type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

		if (-1 == xioctl (fd, VIDIOC_STREAMON, &type))
			errno_exit ("VIDIOC_STREAMON");

		break;
	}
}

void V4L2::uninit_device(void)
{
        unsigned int i;

	switch (io) {
	case IO_METHOD_READ:
		free (buffers[0].start);
		break;

	case IO_METHOD_MMAP:
		for (i = 0; i < n_buffers; ++i)
			if (-1 == munmap (buffers[i].start, buffers[i].length))
				errno_exit ("munmap");
		break;

	case IO_METHOD_USERPTR:
		for (i = 0; i < n_buffers; ++i)
			free (buffers[i].start);
		break;
	}

	free (buffers);
}

void
V4L2::init_read			(unsigned int		buffer_size)
{
        buffers = (struct buffer *)calloc (1, sizeof (*buffers));

        if (!buffers) {
                fprintf (stderr, "Out of memory\n");
                // (EXIT_FAILURE);
        }

	buffers[0].length = buffer_size;
	buffers[0].start = malloc (buffer_size);

	if (!buffers[0].start) {
    		fprintf (stderr, "Out of memory\n");
            	// (EXIT_FAILURE);
	}
}

void V4L2::init_mmap			(void)
{
	struct v4l2_requestbuffers req;

        CLEAR (req);

        req.count               = 4;
        req.type                = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        req.memory              = V4L2_MEMORY_MMAP;

	if (-1 == xioctl (fd, VIDIOC_REQBUFS, &req)) {
                if (EINVAL == errno) {
                        fprintf (stderr, "%s does not support "
                                 "memory mapping\n", dev_name);
                        // (EXIT_FAILURE);
                } else {
                        errno_exit ("VIDIOC_REQBUFS");
                }
        }

        if (req.count < 2) {
                fprintf (stderr, "Insufficient buffer memory on %s\n",
                         dev_name);
                // (EXIT_FAILURE);
        }

        buffers = (struct buffer *)calloc (req.count, sizeof (*buffers));

        if (!buffers) {
                fprintf (stderr, "Out of memory\n");
                // (EXIT_FAILURE);
        }

        for (n_buffers = 0; n_buffers < req.count; ++n_buffers) {
                struct v4l2_buffer buf;

                CLEAR (buf);

                buf.type        = V4L2_BUF_TYPE_VIDEO_CAPTURE;
                buf.memory      = V4L2_MEMORY_MMAP;
                buf.index       = n_buffers;

                if (-1 == xioctl (fd, VIDIOC_QUERYBUF, &buf))
                        errno_exit ("VIDIOC_QUERYBUF");

                buffers[n_buffers].length = buf.length;
                buffers[n_buffers].start =
                        mmap (NULL /* start anywhere */,
                              buf.length,
                              PROT_READ | PROT_WRITE /* required */,
                              MAP_SHARED /* recommended */,
                              fd, buf.m.offset);

                if (MAP_FAILED == buffers[n_buffers].start)
                        errno_exit ("mmap");
        }
}

void
V4L2::init_userp			(unsigned int		buffer_size)
{
	struct v4l2_requestbuffers req;

        CLEAR (req);

        req.count               = 4;
        req.type                = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        req.memory              = V4L2_MEMORY_USERPTR;

        if (-1 == xioctl (fd, VIDIOC_REQBUFS, &req)) {
                if (EINVAL == errno) {
                        fprintf (stderr, "%s does not support "
                                 "user pointer i/o\n", dev_name);
                        // (EXIT_FAILURE);
                } else {
                        errno_exit ("VIDIOC_REQBUFS");
                }
        }

        buffers = (struct buffer *)calloc (4, sizeof (*buffers));

        if (!buffers) {
                fprintf (stderr, "Out of memory\n");
                // (EXIT_FAILURE);
        }

        for (n_buffers = 0; n_buffers < 4; ++n_buffers) {
                buffers[n_buffers].length = buffer_size;
                buffers[n_buffers].start = malloc (buffer_size);

                if (!buffers[n_buffers].start) {
    			fprintf (stderr, "Out of memory\n");
            		// (EXIT_FAILURE);
		}
        }
}

void
V4L2::init_device                     (void)
{
        struct v4l2_capability cap;
        struct v4l2_cropcap cropcap;
        struct v4l2_crop crop;
        struct v4l2_format fmt;
        unsigned int min;

        if (-1 == xioctl (fd, VIDIOC_QUERYCAP, &cap)) {
                if (EINVAL == errno) {
                        fprintf (stderr, "%s is no V4L2 device\n",
                                 dev_name);
                        // (EXIT_FAILURE);
                } else {
                        errno_exit ("VIDIOC_QUERYCAP");
                }
        }

        if (!(cap.capabilities & V4L2_CAP_VIDEO_CAPTURE)) {
                fprintf (stderr, "%s is no video capture device\n",
                         dev_name);
                // (EXIT_FAILURE);
        }

	switch (io) {
	case IO_METHOD_READ:
		if (!(cap.capabilities & V4L2_CAP_READWRITE)) {
			fprintf (stderr, "%s does not support read i/o\n",
				 dev_name);
			// (EXIT_FAILURE);
		}

		break;

	case IO_METHOD_MMAP:
	case IO_METHOD_USERPTR:
		if (!(cap.capabilities & V4L2_CAP_STREAMING)) {
			fprintf (stderr, "%s does not support streaming i/o\n",
				 dev_name);
			// (EXIT_FAILURE);
		}

		break;
	}

        /* Select video input, video standard and tune here. */

        cropcap.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

        if (-1 == xioctl (fd, VIDIOC_CROPCAP, &cropcap)) {
                /* Errors ignored. */
        }

        crop.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        crop.c = cropcap.defrect; /* reset to default */

        if (-1 == xioctl (fd, VIDIOC_S_CROP, &crop)) {
                switch (errno) {
                case EINVAL:
                        /* Cropping not supported. */
                        break;
                default:
                        /* Errors ignored. */
                        break;
                }
        }

        CLEAR (fmt);

        fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE; 
        if (-1 == xioctl (fd, VIDIOC_G_FMT, &fmt)) {
                perror("[V4L2] err. trying to query formats");
        }
        

        CLEAR (fmt);

        fmt.type                = V4L2_BUF_TYPE_VIDEO_CAPTURE;

        fmt.fmt.pix.width       = 640; 
        fmt.fmt.pix.height      = 480;
        //fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
        //fmt.fmt.pix.width       = 320; 
        //fmt.fmt.pix.height      = 240;
        fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_RGB32;
        fmt.fmt.pix.field       = V4L2_FIELD_INTERLACED;
 
        cerr<<"[V4L2] Requesting 640x480 RGB32 Interlaced"<<endl;
        if (-1 == xioctl (fd, VIDIOC_S_FMT, &fmt)) errno_exit ("VIDIOC_S_FMT");
        /* Note VIDIOC_S_FMT may change width and height. */

	/* Buggy driver paranoia. */
	min = fmt.fmt.pix.width * 2;
	if (fmt.fmt.pix.bytesperline < min)
		fmt.fmt.pix.bytesperline = min;
	min = fmt.fmt.pix.bytesperline * fmt.fmt.pix.height;
	if (fmt.fmt.pix.sizeimage < min)
		fmt.fmt.pix.sizeimage = min;

	switch (io) {
	case IO_METHOD_READ:
		init_read (fmt.fmt.pix.sizeimage);
		break;

	case IO_METHOD_MMAP:
		init_mmap ();
		break;

	case IO_METHOD_USERPTR:
		init_userp (fmt.fmt.pix.sizeimage);
		break;
	}

    struct v4l2_input input;
    memset (&input, 0, sizeof (input));
    if (-1 == ioctl (fd, VIDIOC_G_INPUT, &input.index)) {
        perror ("VIDIOC_G_INPUT");
        //exit (EXIT_FAILURE);
    }

    if (-1 == ioctl (fd, VIDIOC_ENUMINPUT, &input)) {
        perror ("VIDIOC_ENUM_INPUT");
        //exit (EXIT_FAILURE);
    }
    v4l2_std_id  std_id;
    std_id = V4L2_STD_NTSC;
    if (-1 == ioctl (fd, VIDIOC_S_STD, &std_id)) {
        perror ("VIDIOC_ENUM_INPUT");
        //exit (EXIT_FAILURE);
    }
    cerr<<"[V4L2] setting NTSC norm."<<endl;
    if (0 == (input.std & V4L2_STD_NTSC)) {
        fprintf (stderr, "Oops. NTSC is not supported.\n");
        //exit (EXIT_FAILURE);
    }

}

void V4L2::close_device                    (void)
{
/*
        if (-1 == close (fd))
	        errno_exit ("close");

        fd = -1;
*/
//can't figure out how to use close in c++ with the threading
}

void
V4L2::open_device                     (void)
{
        struct stat st; 

        if (-1 == stat (dev_name, &st)) {
                fprintf (stderr, "Cannot identify '%s': %d, %s\n",
                         dev_name, errno, strerror (errno));
                // (EXIT_FAILURE);
        }

        if (!S_ISCHR (st.st_mode)) {
                fprintf (stderr, "%s is no device\n", dev_name);
                // (EXIT_FAILURE);
        }

        fd = open (dev_name, O_RDWR /* required */ | O_NONBLOCK, 0);

        if (-1 == fd) {
                fprintf (stderr, "Cannot open '%s': %d, %s\n",
                         dev_name, errno, strerror (errno));
                // (EXIT_FAILURE);
        }
}

static void
usage                           (FILE *                 fp,
                                 int                    argc,
                                 char **                argv)
{
        fprintf (fp,
                 "Usage: %s [options]\n\n"
                 "Options:\n"
                 "-d | --device name   Video device name [/dev/video]\n"
                 "-h | --help          Print this message\n"
                 "-m | --mmap          Use memory mapped buffers\n"
                 "-r | --read          Use read() calls\n"
                 "-u | --userp         Use application allocated buffers\n"
                 "",
		 argv[0]);
}

static const char short_options [] = "d:hmru";

static const struct option
long_options [] = {
        { "device",     required_argument,      NULL,           'd' },
        { "help",       no_argument,            NULL,           'h' },
        { "mmap",       no_argument,            NULL,           'm' },
        { "read",       no_argument,            NULL,           'r' },
        { "userp",      no_argument,            NULL,           'u' },
        { 0, 0, 0, 0 }
};
/*
int
main                            (int                    argc,
                                 char **                argv)
*/
V4L2::V4L2()
{
        dev_name = NULL;
        io = IO_METHOD_MMAP;
        fd = -1;
        buffers = NULL;
        n_buffers = 0;

        dev_name = "/dev/video";
/*
        for (;;) {
                int index;
                int c;
                c = getopt_long (argc, argv,
                                 short_options, long_options,
                                 &index);
                if (-1 == c)
                        break;
                switch (c) {
                case 0:
                        break;
                case 'd':
                        dev_name = optarg;
                        break;
                case 'h':
                        usage (stdout, argc, argv);
                        // (EXIT_SUCCESS);
                case 'm':
                        io = IO_METHOD_MMAP;
			break;
                case 'r':
                        io = IO_METHOD_READ;
			break;
                case 'u':
                        io = IO_METHOD_USERPTR;
			break;
                default:
                        usage (stderr, argc, argv);
                        // (EXIT_FAILURE);
                }
        }
*/
        open_device ();
        init_device ();
        set_controls();
        start_capturing ();
/*
        mainloop ();
        stop_capturing ();
        uninit_device ();
        close_device ();
*/
        // (EXIT_SUCCESS);
}
