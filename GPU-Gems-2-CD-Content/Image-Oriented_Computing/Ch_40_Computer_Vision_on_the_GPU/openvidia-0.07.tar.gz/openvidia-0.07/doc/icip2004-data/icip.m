%params20s = aload('Parameters-20iterations-serial.txt');
%params16s = aload('Parameters-16iterations-serial.txt');
%params12s = aload('Parameters-12iterations-serial.txt');
%params14s = aload('Parameters-14iterations-serial.txt');
%paramsparallel = aload('Parameters-16-8-8-5.txt');
%paramsparallel = aload('Parameters-16-16-4-5.txt');

paramsbase = aload('Parameters-20iterations-serial.txt');
paramsserial =aload('Parameters-16iterations-serial.txt');
%paramsparallel = paramsparallel = aload('Parameters-14-14-6-5.txt');
paramsparallel = aload('Params-12-4-fast.txt');


r=[0:1:239];
r=r./240;
rows = ones(320,1)*r;
rows=rows';

c=[0:1:319];
c=c./320;
cols = ones(240,1)*c;

for img=1:78
  P = [ paramsbase(img,:) 1];
  P = reshape(P,3,3)';
 
  det=P(3,1).*rows + P(3,2).*cols + 1;
  newrows = (P(1,1).*rows + P(1,2).*cols + P(1,3))./det;
  newcols =(P(2,1).*rows + P(2,2).*cols + P(2,3))./det;
 


  P = [ paramsserial(img,:) 1];
  P = reshape(P,3,3)';

  det=P(3,1).*rows + P(3,2).*cols + 1;
  newrows_16 = (P(1,1).*rows + P(1,2).*cols + P(1,3))./det;
  newcols_16 =(P(2,1).*rows + P(2,2).*cols + P(2,3))./det;

  %euclidean pixel distances 
  diff = (abs(newrows-newrows_16).*240).* (abs(newrows-newrows_16).*240) + (abs(newcols-newcols_16).*320).* (abs(newcols-newcols_16).*320) ;
  diff = sqrt(diff);
  imgdiffserial(img)=max(max(diff));



  P = [ paramsparallel(img,:) 1];
  P = reshape(P,3,3)';

  det=P(3,1).*rows + P(3,2).*cols + 1;
  newrows_16 = (P(1,1).*rows + P(1,2).*cols + P(1,3))./det;
  newcols_16 =(P(2,1).*rows + P(2,2).*cols + P(2,3))./det;

  %euclidean pixel distances 
  diff = (abs(newrows-newrows_16).*240).* (abs(newrows-newrows_16).*240) + (abs(newcols-newcols_16).*320).* (abs(newcols-newcols_16).*320) ;
  diff = sqrt(diff);
  imgdiffparallel(img)=max(max(diff));

end

title('Maximum Pixel Error');
ylabel('Pixel Registration Error');
xlabel('Image Frame');
plot(    [1:78], imgdiffserial, "-1;single, 16 repetitions;",
    [1:78], imgdiffparallel, "-2;12 single, 4 parallel repetitions;")
gset key 50, 35.5
gset terminal postscript 22; system("rm voperror.eps");
gset output "pork.eps";
replot; system("eps2eps pork.eps voperror.eps");
system("gv voperror.eps&");


