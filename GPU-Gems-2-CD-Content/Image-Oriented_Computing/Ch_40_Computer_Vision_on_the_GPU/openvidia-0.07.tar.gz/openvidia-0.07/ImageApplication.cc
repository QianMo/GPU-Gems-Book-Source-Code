/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "ImageApplication.h"
#include "ImlibCapture.h"
#include <glh/glh_extensions.h>
// for nv extensions, rectangular textures.


// Need a display object, make it class wide, by making it global.
// please send flame mail to imlib developers for this one
Display *imageApplicationDisp=XOpenDisplay(":0.0");

ImageApplication::ImageApplication(char *fname_) {
  x=y=100;
  width=height=100;

  imlibcapture=new ImlibCapture(100,101);
  imlibcapture->initCapture(imageApplicationDisp);
  fname=fname_; 
  imlibcapture->loadFile(fname);


  isInitialized=false;
  useAlpha=true;
}

ImageApplication::~ImageApplication() {
  //do nothing
}

// this will do a bunch of GL calls.
void ImageApplication::render() { 
  preRender();


  int w=imlibcapture->getRGBWidth();
  int h=imlibcapture->getRGBHeight();
  void* data = imlibcapture->getRGBData();
  int size = imlibcapture->getRGBWidth()*
  imlibcapture->getRGBHeight()*4;
  unsigned char *storage;

  if( isInitialized==false ) { 
    glGenTextures(1,&imgTex);
    storage = (unsigned char*) malloc( size );
    memcpy(storage, data, size);
  }

  glBindTexture(GL_TEXTURE_RECTANGLE_NV, imgTex);
  if( isInitialized==false ) {
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGBA,
  	       imlibcapture->getRGBWidth(),
  	       imlibcapture->getRGBHeight(),
	       0, GL_RGB, GL_UNSIGNED_BYTE, (const GLvoid *)(storage));
    isInitialized=true;
    free(storage);
  }

  glEnable(GL_TEXTURE_RECTANGLE_NV);

  if(useAlpha) {
    glEnable(GL_BLEND);// blend with what is in target buffer
    //    glBlendFunc(GL_SRC_ALPHA, GL_SRC_ALPHA);
    glBlendFunc(GL_DST_COLOR, GL_ONE_MINUS_DST_COLOR);
    glClear(GL_DEPTH_BUFFER_BIT); //essential?
  } else {
    glDisable(GL_BLEND);
  }

  glColor4f(5.0, 5.0, 1.0, 0.0);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, imgTex);
  glBegin(GL_POLYGON);
  glTexCoord2f(0,0);  glVertex3f(0.0, 0.0, 1.0);
  glTexCoord2f((float)w,0);  glVertex3f(1.0, 0.0, 1.0);
  glTexCoord2f((float)w,(float)h);  glVertex3f(1.0, 1.0, 1.0);
  glTexCoord2f(0,(float)h);  glVertex3f(0.0, 1.0, 1.0);
  glEnd();
  
  if(useAlpha) {
    glDisable(GL_BLEND);
    glDisable(GL_ALPHA_TEST);
  } 
  glDisable(GL_TEXTURE_RECTANGLE_NV);

  postRender();
}



