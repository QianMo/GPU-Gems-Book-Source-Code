/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "Parameters.h"
#include <iostream>
#include <iomanip>
using namespace std;

Parameters::Parameters(Data a11in,
                       Data a12in,
                       Data b1in,
                       Data a21in,
                       Data a22in,
                       Data b2in,
                       Data c1in,
                       Data c2in )
{
  a11 = a11in;
  a12 = a12in;
  b1  = b1in;
  a21 = a21in;
  a22 = a22in;
  b2  = b2in;
  c1  = c1in;
  c2  = c2in;
  support = 0.0;
}

void Parameters::setSupport(float in)
{
  support = in;
}

float Parameters::getSupport()
{
  return support;
}

void Parameters::setIdentity()
{
  set(); //will use default arguments of set which is identity
}

void Parameters::set(Data *p)
{
  set(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]);
}

void Parameters::set(Data a11in,
                Data a12in,
                Data b1in,
                Data a21in,
                Data a22in,
                Data b2in,
                Data c1in,
                Data c2in )

{
  a11 = a11in;
  a12 = a12in;
  b1  = b1in;
  a21 = a21in;
  a22 = a22in;
  b2  = b2in;
  c1  = c1in;
  c2  = c2in;
}

void Parameters::print()
{
  cout<<a11<<" "<<a12<<" "<<b1<<" "<<a21<<" "<<a22<<" "<<b2<<" ";
  cout<<c1<<" "<<c2<<endl;
}


///applies parameters to coordinates to generate new coordinates
///this takes in GL x/y convention pair, and uses orbits on it, taking into
///acount orbits updown/leftright ordering for x,y
void Parameters::apply(Data x, Data y, Data *newx, Data *newy)
{
  Data denom=(c1*y + c2*x + 1);
  *newy = (a11*y + a12*x + b1) / denom;
  *newx = (a21*y + a22*x + b2) / denom;
}

void Parameters::apply(Data *newx, Data *newy)
{
  apply(*newx, *newy, newx, newy);
}


///returns a pointer to an array of Datas holding current values.
///this array is used for return purposes only, changing it's values
///will not change the state of the Parameters object
Data *Parameters::get()
{
  parray[0] = a11; 
  parray[1] = a12; 
  parray[2] = b1; 
  parray[3] = a21; 
  parray[4] = a22; 
  parray[5] = b2; 
  parray[6] = c1; 
  parray[7] = c2; 
 
  return parray;
}

void Parameters::invert() 
{
  Var pInitial, pInverted;
  makeVar(&pInitial, get() );
  init_var(&pInverted, "inverted parameters", 8, 1,
        INTERNAL_VARIABLE, GREY_SCALE,NULL);

  pinverse( &pInitial, &pInverted);
 
  //column major ordering from orbits - orbits based on matlab/octave
  a11 = pInverted.data[0];
  a12 = pInverted.data[1];
  b1  = pInverted.data[2];
  a21 = pInverted.data[3];
  a22 = pInverted.data[4];
  b2  = pInverted.data[5];
  c1  = pInverted.data[6];
  c2  = pInverted.data[7];

  Var_Destructor(&pInitial);
  Var_Destructor(&pInverted);
  
}

void Parameters::compose(Parameters P)
{
  Var A, B, C;
  makeVar( &A, get() );
  makeVar( &B, P.get() );
  init_var(&C, "composed parameters", 8, 1,
        INTERNAL_VARIABLE, GREY_SCALE,NULL);
  pcompose( &B, &A, &C );
 
  a11 = C.data[0];
  a12 = C.data[1];
  b1  = C.data[2];
  a21 = C.data[3];
  a22 = C.data[4];
  b2  = C.data[5];
  c1  = C.data[6];
  c2  = C.data[7];

  Var_Destructor(&A);
  Var_Destructor(&B);
  Var_Destructor(&C);
}

Parameters Parameters::operator*(Parameters P)
{
  Parameters Preturn;
  Var A, B, C;
  makeVar( &A, get() );
  makeVar( &B, P.get() );
  init_var(&C, "composed parameters", 8, 1,
        INTERNAL_VARIABLE, GREY_SCALE,NULL);
  pcompose( &B, &A, &C );

  Preturn.a11 = C.data[0];
  Preturn.a12 = C.data[1];
  Preturn.b1  = C.data[2];
  Preturn.a21 = C.data[3];
  Preturn.a22 = C.data[4];
  Preturn.b2  = C.data[5];
  Preturn.c1  = C.data[6];
  Preturn.c2  = C.data[7];

  Var_Destructor(&A);
  Var_Destructor(&B);
  Var_Destructor(&C);

  return Preturn;
}

void Parameters::makeVar(Var *v, Data *params)
{
  init_var(v, "parameters", 8, 1,
           INTERNAL_VARIABLE, GREY_SCALE,NULL);
  v->data[0] = params[0];
  v->data[1] = params[1];
  v->data[2] = params[2];
  v->data[3] = params[3];
  v->data[4] = params[4];
  v->data[5] = params[5];
  v->data[6] = params[6];
  v->data[7] = params[7];
}

float *Parameters::getAsChirpMat()
{
    chirpmat[0] = a22;
    chirpmat[4] = a21;
    chirpmat[8] = b2;
    chirpmat[12] =  0;
    chirpmat[1] = a12;
    chirpmat[5] = a11;
    chirpmat[9] = b1;
    chirpmat[13] = 0;
    chirpmat[2] = -c2;
    chirpmat[6] = -c1;
    chirpmat[10]= -1;
    chirpmat[14]= 0;
    chirpmat[3] = 0;
    chirpmat[7] = 0;
    chirpmat[11]= 0;
    chirpmat[15]= 1;
    return chirpmat;
}

float Parameters::getVariance()
{
  return 
  (a11-1.0)*(a11-1.0) +
  (a12-0.0)*(a12-0.0) +
  (b1 -0.0)*(b1 -0.0) +
  (a21-0.0)*(a21-0.0) +
  (a22-1.0)*(a22-1.0) +
  (b2 -0.0)*(b2 -0.0) +
  (c1 -0.0)*(c1 -0.0) +
  (c2 -0.0)*(c2 -0.0) ;
}

float Parameters::getNorm()
{
  return 
  sqrtf(
  (a11)*(a11) +
  (a12)*(a12) +
  (b1 )*(b1 ) +
  (a21)*(a21) +
  (a22)*(a22) +
  (b2 )*(b2 ) +
  (c1 )*(c1 ) +
  (c2 )*(c2 ) ) ;

}

