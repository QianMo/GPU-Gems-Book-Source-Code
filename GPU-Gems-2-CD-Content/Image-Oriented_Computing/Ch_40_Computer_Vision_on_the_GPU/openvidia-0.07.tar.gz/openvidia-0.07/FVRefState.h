/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef FVREFSTATE_H
#define FVREFSTATE_H_

#include "Parameters.h"

///A set of features can be saved to be used as a reference. This object
///encapsulates this.  The features should be placed into this structures' 
///public variables, see flcornersTrack/cornersTrack.cc for how this is
///done.  This object has a findCorrespondences function to determine the
///feature correspodences  with other such objects.
class FVRefState {
   private : 
     inline float distBetweenFeatures( float *v1, float *v2 );
     int findBestFeatureMatchLocal(float corners[1000][2],
                          float cornersPrev[1000][2],

                          //feature vectors
                          float fvec[240][128],
                          float fvecPrev[240][128],

                          //where to write the matches
                          float match[240][5],
                          int age[240],

                          //how many elements of the above arrays are 
                          // actually filled
                          int numFeaturesNew,
                          int numFeaturesOld,

                          //Parameters: if we have a guess as to where
                          // the points are (i.e. when we are
                          // comparing to an old reference frame),
                          // then we can use it before we 
                          // restrict the search radius.
                          Parameters Pguess,


                          //search radius to restrict matches to.
                          float searchRadius,
                          float thresh  );

   

   public : 
     /**corners[] is an array of feature point coordinates.,
        stored as x,y pairs, one per line */ 
     ///feature coordinates, x,y positions, one per line
     float corners[1000][2];

     ///Fvec is the array of feature vectors.  The rows here
     /// correspond row by row to the corners[] array which holds
     /// the locations.  Thus, fvec[4] is located at corners[4] etc..
     ///can only record 240 features (since that is the Y size of the 
     ///GPU floating point buffer used to calc. the features currently.
     float fvec[240][128];
 
     ///feature canonical orientation, dX, dY sum gradients actually.
     float orientation[240][3];

     ///This is how many features are currently stored in the corners[]
     /// and fvec arrays
     int numFeatures;

     ///This can be used to record the projective coordinates of this
     /// reference frame
     Parameters P;

     ///Unique ID number for each of the features. - unused currently
     int ID[240];

     ///A metric of how old the feature is, how persistent. - unused currently
     int Age[240];
  
     ///If a point is being tracked in this frame this is the position of the 
     ///point w.r.t. the reference frame (with the frame at the identity).
     ///To draw this point at the right location w.r.t your current
     ///video frame, apply a calculated Proj. Coord. Trans. to this point. 
     ///stored as normalized raster coords.
     float pos[2];

     ///Reinitializes the reference frame.  Currently this just means
     ///setting the ID numbers of the vectors to new unique IDs.  Existing
     ///data in the object will persist, but should be considered garbage.
     int reinit(int IDcount) ;

     FVRefState();

     ///Finds the feature correspondences between this object and the given
     ///reference.  "Guess" can be input as an estimate of position
     /// (currently guess isn't used), searchRadius confines the search
     /// to only look at features within that 2d distance (normalized to 
     /// image size).  Returns the number of correspondences found, and 
     /// fills in the matchArray with the appropriate 
     /// (this: x1,y1),(reference: x2,y2)_ set of 
     /// feature correspondences (normalized coordinate system).
     int findCorrespondences( FVRefState &reference,
                              Parameters guess, float searchRadius, 
                              float matchArray[240][5], float thresh);
};
#endif
