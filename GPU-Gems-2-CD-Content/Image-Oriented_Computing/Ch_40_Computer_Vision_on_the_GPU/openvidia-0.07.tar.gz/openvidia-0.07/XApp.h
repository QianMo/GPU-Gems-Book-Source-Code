/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _XAPP_H
#define _XAPP_H

#include "ApplicationRenderer.h"

/*
 * Global coz c++ can eat my shit, defined in the XAPP object file
 * so only linked once.
 */
extern int XAPP_NEXTID;

class XApp : public ApplicationRenderer
{
 private:
  // default constructor -- for derived classes
  XApp();
  bool needsInitialization;
  unsigned char *storage;
  unsigned char *shim;

 protected:
  int x,y,width,height;
  GLuint imgTex;

  int m_shmatid;
  char* fname;
  bool m_usealpha;
  unsigned char alpha;
  
  void fillInRGB(unsigned char *storage, unsigned char* shim);
  static int next_unique_id() {
    return XAPP_NEXTID++;
  }

 public:
  //name of app to execute
  XApp(char* fname);
  ~XApp();

  // so rwm can read and send to correct xserver
  int UNIQUEID; 

  // cant fork in the constructor. fuxors things.
  void initShmem();
  
  // this will do a bunch of GL calls.
  void render();
};

#endif
