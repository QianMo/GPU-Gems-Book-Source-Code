/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "GenericDisplay.h"
#include "MultitextureDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394Capture.h"
#include "Raw1394Capture.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include <iostream>
using namespace std;

// Global display object
GenericDisplay *d;
GenericCapture *gc;
Grab_JPEG *grabber;
int use_cg=1;

int imageWinWidth = 320;
int imageWinHeight = 240;

Window  Orbwin;
static unsigned char whitebuf[320*240*3] = {255};
static unsigned char gradbuf[320*240*3] = {255};

////// UTILITY FUNCTION //////////////
void buffer_sample_float4(float sample[4], float *thebuffer,
                          int X, int Y,
                          int xSize, int ySize, int nchans )
{
  int i=0;
  for( i=0 ; i<nchans; i++ ) {
      sample[i] = thebuffer[Y*xSize*nchans+X*nchans+i];
  }
}

////// GLUT CALLBACKS ///////////////

void reshape(int w, int h)
{
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);
   switch (key) {
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}


// coz i cant pass member funtion to glutDisplayFunc
/*
 *  Load new images, then call Display object render functions
 */ 
void render_redirect() {
  gc->advanceFrame(); 
  d->init_texture(0, gc->getRGBWidth(), gc->getRGBHeight(),
           gc->getRGBData());
  d->init_texture(1, gc->getRGBWidth(), gc->getRGBHeight(),
           whitebuf);
  d->init_texture(2, gc->getRGBWidth(), gc->getRGBHeight(),
           gradbuf);
/* uncomment to start grabbing.
  grabber->grab_frame((unsigned char *)gc->getRGBData(),
                      gc->getRGBWidth(),gc->getRGBHeight(),
                      FORMAT_RGB24);
*/
  gc->releaseCap();
  //((MultitextureDisplay *)d)->activate_fpbuffer();
  d->render();
  //d->render_to_texture(2);
  //((MultitextureDisplay *)d)->deactivate_fpbuffer();
  glutSwapBuffers();
  cout <<".";
  fflush(stdout);
  d->showstats();
}  


///// MAIN ///////////////////

int main(int argc, char** argv)
{
   for( int i=0 ; i<320*240*3; i++ ) gradbuf[i]=i/(320*3);
   for( int i=0 ; i<320*240*3; i++ ) whitebuf[i]=128;
   glutInit(&argc, argv);
   cout <<"Creating Double Buffered Window" << endl;
   //glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth, imageWinHeight);
   glutInitWindowPosition(100, 100);
   Orbwin=glutCreateWindow(argv[0]);

   grabber = new Grab_JPEG();

   d=new MultitextureDisplay(3, imageWinWidth, imageWinHeight, Orbwin );
   //gc=new ImlibCapture();
   //gc=new Dc1394Capture(FORMAT_RGB24);
   //gc=new Dc1394Capture();
   //((Dc1394Capture *)gc)->start();
   gc=new Raw1394Capture();
   ((Raw1394Capture *)gc)->start();

   d->initDisplay();
   gc->initCapture(d);
   gc->advanceFrame();
   d->setImageSize( gc->getRGBWidth(), gc->getRGBHeight() );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 

   d->initGL();
   d->init_texture(0, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   gc->releaseCap();
   if(use_cg) {
	   gc->advanceFrame();
	   d->init_texture(1, gc->getRGBWidth(), gc->getRGBHeight(),
			                         gc->getRGBData());
        gc->releaseCap();
   }
   d->init_texture4f(2, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   d->bindTextures();
   d->setDownsampleLevel(0);

   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMainLoop();
   return 0; 
}
