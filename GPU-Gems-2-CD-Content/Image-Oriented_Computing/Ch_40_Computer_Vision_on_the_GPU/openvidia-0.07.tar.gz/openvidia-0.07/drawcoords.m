%
% * This file is part of the OpenVIDIA project at http://openvidia.sf.net
% * Copyright (C) 2004, James Fung
% *
% * OpenVIDIA is free software; you can redistribute it and/or modify
% * it under the terms of the GNU General Public License as published by
% * the Free Software Foundation; either version 2 of the License, or
% * (at your option) any later version.
% *
% * OpenVIDIA is distributed in the hope that it will be useful,
% * but WITHOUT ANY WARRANTY; without even the implied warranty of
% * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% * GNU General Public License for more details.
% *
% * You should have received a copy of the GNU General Public License
% * along with OpenVIDIA; if not, write to the Free Software
% * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
% **/

function pointMat=drawcoords(oxIm,oyIm, X,Y,Z,Mint,scale);

Or = inv(Mint)*[oxIm;oyIm;1]*scale;
Zp = Or+Z;
Xp =Or+X;
Yp = Or+Y;

zp = Mint*Zp;
zp = zp./zp(3);

xp = Mint*Xp;
xp = xp./xp(3);
yp = Mint*Yp;
yp = yp./yp(3);

%plot([oxIm zp(1)],[oyIm zp(2)],'g-', 'LineWidth', 1);
%plot([oxIm xp(1)],[oyIm xp(2)],'b-', 'LineWidth', 1);
%plot([oxIm yp(1)],[oyIm yp(2)],'r-', 'LineWidth', 1);
pointMat = [oxIm oyIm zp(1) zp(2);oxIm oyIm xp(1) xp(2);oxIm oyIm yp(1) yp(2)];
