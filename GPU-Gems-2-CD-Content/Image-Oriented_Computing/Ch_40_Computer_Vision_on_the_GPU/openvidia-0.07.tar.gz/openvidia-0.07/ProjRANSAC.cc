/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "ProjRANSAC.h"
#include <stdlib.h>
#include <iostream>
using namespace std;

ProjRANSAC::ProjRANSAC(int inM, int inN)
{
  M = inM;
  N = inN;
  //corrArray = NULL;
  //numCorr = 0;

  init_var(&pDechirp, "dechirp parameters", 8, 1,
        INTERNAL_VARIABLE, GREY_SCALE,NULL);
  init_var(&pRechirp, "rechirp parameters", 8, 1,
        INTERNAL_VARIABLE, GREY_SCALE,NULL);
  init_var(&pFinal, "final parameters", 8, 1,
        INTERNAL_VARIABLE, GREY_SCALE,NULL);

  for(int i =0; i<8; i++ ) {
    srcCorners[i] = -1.0;
    destCorners[i] = -1.0;
  }
}

Parameters ProjRANSAC::get_P_from_Corr(float m1, float n1, float i1, float j1,
               float m2, float n2, float i2, float j2,
               float m3, float n3, float i3, float j3,
               float m4, float n4, float i4, float j4 )
{

  srcCorners[0] = (double)m1/(double)M;
  srcCorners[1] = (double)n1/(double)N;

  srcCorners[2] = (double)m2/(double)M;
  srcCorners[3] = (double)n2/(double)N;

  srcCorners[4] = (double)m3/(double)M;
  srcCorners[5] = (double)n3/(double)N;

  srcCorners[6] = (double)m4/(double)M;
  srcCorners[7] = (double)n4/(double)N;

  destCorners[0] = (double) i1 / (double) M;
  destCorners[1] = (double) j1 / (double) N;

  destCorners[2] = (double) i2 / (double) M;
  destCorners[3] = (double) j2 / (double) N;

  destCorners[4] = (double) i3 / (double) M;
  destCorners[5] = (double) j3 / (double) N;

  destCorners[6] = (double) i4 / (double) M;
  destCorners[7] = (double) j4 / (double) N;

  corners2d(pDechirp.data, destCorners);
  corners2r(pRechirp.data, srcCorners);

  pcompose(&pDechirp, &pRechirp, &pFinal);
  Parameters Pcorr(pFinal.data[0], pFinal.data[1], pFinal.data[2],
                   pFinal.data[3], pFinal.data[4], pFinal.data[5],
                   pFinal.data[6], pFinal.data[7] );
  
  for(int i =0; i<8; i++ ) {
    if( i ==0 || i == 4 ) {
      pDechirp.data[i] = 0;
      pRechirp.data[i] = 0;
      pFinal.data[i] = 0;
    } else {
      pDechirp.data[i] = 0;
      pRechirp.data[i] = 0;
      pFinal.data[i] = 0;
   }
  }
  return Pcorr;
}    

Parameters ProjRANSAC::find_P( float in_corrArray[240][5], int in_numCorr,
                               int *supportReturn )
{
  //corrArray = in_corrArray;
  //numCorr = in_numCorr;
  Parameters currentGuessP;

  if( in_numCorr <= 0 ) {
    cerr<<"No matched input. Cannot RANSAC"<<endl;
    RANSAC_P[0].setIdentity();
    *supportReturn  = 0;
    return RANSAC_P[0];
  }

  ///reinitialize the RANSACSupportArray to blank (not yet computed)
  for( int i=0 ; i<RANSAC_MAX_CORR ; i++ ) {
     RANSACSupportArray[i] = -1;
  }

  ///pick some points randomly
  //srand( 1000000 ) ;
  //srand(time(NULL)) ;
  int maxSupport = 0;
for( int j = 0 ; j<30 ; j ++ ) { 
  int corr1 = (int)(floorf((float)rand()/((float)RAND_MAX)*(float)in_numCorr));
  int corr2 = (int)(floorf((float)rand()/((float)RAND_MAX)*(float)in_numCorr)); 
  int corr3 = (int)(floorf((float)rand()/((float)RAND_MAX)*(float)in_numCorr));
  int corr4 = (int)(floorf((float)rand()/((float)RAND_MAX)*(float)in_numCorr)); 
/*
  cerr<<"Using "<<corr1<<" "<<corr2<<" "<<corr3<<" "<<corr4<<endl;
  cerr<<"Correspondences are "<<endl;
  cerr<<" "<<in_corrArray[corr1][0]<<" ";
  cerr<<in_corrArray[corr1][1]<<"  ";
  cerr<<in_corrArray[corr1][2]<<" ";
  cerr<<in_corrArray[corr1][3]<<" ";

  cerr<<" "<<in_corrArray[corr2][0]<<" ";
  cerr<<in_corrArray[corr2][1]<<"  ";
  cerr<<in_corrArray[corr2][2]<<" ";
  cerr<<in_corrArray[corr2][3]<<" ";

  cerr<<" "<<in_corrArray[corr3][0]<<" ";
  cerr<<in_corrArray[corr3][1]<<"  ";
  cerr<<in_corrArray[corr3][2]<<" ";
  cerr<<in_corrArray[corr3][3]<<" ";

  cerr<<" "<<in_corrArray[corr4][0]<<" ";
  cerr<<in_corrArray[corr4][1]<<"  ";
  cerr<<in_corrArray[corr4][2]<<" ";
  cerr<<in_corrArray[corr4][3]<<" ";
  cerr<<endl;
*/

  ///reverse coords. x=n, y=m
  currentGuessP = get_P_from_Corr(in_corrArray[corr1][1], in_corrArray[corr1][0],
                               in_corrArray[corr1][3], in_corrArray[corr1][2],
                               in_corrArray[corr2][1], in_corrArray[corr2][0],
                               in_corrArray[corr2][3], in_corrArray[corr2][2],
                               in_corrArray[corr3][1], in_corrArray[corr3][0],
                               in_corrArray[corr3][3], in_corrArray[corr3][2],  
                               in_corrArray[corr4][1], in_corrArray[corr4][0],
                               in_corrArray[corr4][3], in_corrArray[corr4][2]);

  ////RANSAC_P[0].print();
  ///0.000520 is 1 pixel diameter around a point
  int support = getSupport(currentGuessP, in_corrArray, in_numCorr, 0.00520);

  ///cerr<<"-->It had support "<<support<<"out of "<<in_numCorr<<"samples"<<endl;
  if( support > maxSupport ) {
    maxSupport = support;
    RANSAC_P[0] = currentGuessP;
    RANSAC_P[0].setSupport( (float)support/(float)in_numCorr );
  }
  
}
  //full correspondence array
  getSupport(RANSAC_P[0], in_corrArray, in_numCorr,0.00520);
  //cerr<<"Best estimate had "<<maxSupport<<"/"<<in_numCorr<<" support"<<endl;
  *supportReturn = maxSupport;
  return RANSAC_P[0];
 
}

double ProjRANSAC::dist( double x1, double y1, double x2, double y2) {
  //cerr<<"d "<<sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
  //return sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
  return ((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
}

int ProjRANSAC::getSupport( Parameters P, 
                            float in_corrArray[240][5], 
                            int numCorr,
                            double thresh ) 
{
  double newx, newy;
  int Psupport = 0;
  if( numCorr <= 0 ) {  
    cerr<<"no correspondences. can't ransac."<<endl;
  }

  for( int i=0; i<numCorr ;i++ ) {
    double oldx = (double)in_corrArray[i][0]/(double)N;
    double oldy = (double)in_corrArray[i][1]/(double)M;

    double newx = (double)in_corrArray[i][2]/(double)N;
    double newy = (double)in_corrArray[i][3]/(double)M;
    
    double calcx, calcy; //as predicted by P under consideration

    P.apply( oldx, oldy, &calcx, &calcy ); //right direction XXX ?
    //cerr<<"Compare "<<newx<<" "<<newy<<" "<<calcx<<" "<<calcy<<endl;
    if( dist( newx, newy, calcx, calcy ) < thresh*thresh ) {
      Psupport++;
      //set support array
      RANSACSupportArray[i] = 1;
    }
    else {
      RANSACSupportArray[i] = 0;
    }
   
  }
  return Psupport;
}
