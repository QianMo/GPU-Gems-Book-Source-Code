/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "GlutSubWindow.h"
#include <unistd.h>
#include <time.h>
#include <stdio.h>
#include <iostream>
using namespace std;


GlutSubWindow::GlutSubWindow( int parent_win_in, 
                              int x_in,  
                              int y_in,  
                              int width_in, 
                              int height_in )
{
  //win = glutCreateSubWindow( parent_win_in, x_in, y_in, width_in, height_in );
  glutInitWindowSize(width_in, height_in);
  glutInitWindowPosition(x_in, y_in);
  win=glutCreateWindow("diagnostic");
  parent_win = parent_win_in;
  x = x_in;  
  y = y_in;  
  width = width_in; 
  height =height_in;

} 

void GlutSubWindow::GlutSubWindowSetCurrent() 
{
  glutSetWindow( win );
}

void GlutSubWindow::GlutSubWindowPostRedisplay()
{
  glutSetWindow( win );
  glutPostRedisplay();
}

