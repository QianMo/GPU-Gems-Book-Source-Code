/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/


#include <GL/glut.h>
//#include "3ds.h"
//#include "3dsLoader.h"
#include "libopenvidia.h"

////#define MAX_TEXTURES 100

//onv_3dsLoader myLoader("models/figure.3DS");
onv_3dsLoader *myLoader;
/*
unsigned int g_Texture[MAX_TEXTURES] = {0};
CLoad3DS g_Load3ds;
t3DModel g_3DModel;
int   g_ViewMode      = GL_TRIANGLES;
bool  g_bLighting     = true;
*/
float g_RotateX       = 0.0f;
float g_RotateY       = 0.0f+180.0f;
float g_RotationSpeed = 3.0f;
float g_zoom = 1.0f;



void displayCB(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
     glClear(GL_DEPTH_BUFFER_BIT);

     glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
     glRotatef(g_RotateX, 1.0, 0.0f, 0);
     glRotatef(g_RotateY, 0.0, 1.0f, 0);
     glScalef(g_zoom, g_zoom, g_zoom);
     glColor4f(1.0, 1.0, 1.0, 1.0);
     //glutWireCube(1.0);
     
  glBegin(GL_LINES);
    glColor3f(1.0, 0.0, 0.0);
    glVertex4f( 0.0, 0.0, 0.0, 1.0);
    glVertex4f( 1.0, 0.0, 0.0, 1.0);

    glColor3f(0.0, 1.0, 0.0);
    glVertex4f( 0.0, 0.0, 0.0, 1.0);
    glVertex4f( 0.0, 1.0, 0.0, 1.0);

    glColor3f(0.0, 0.0, 1.0);
    glVertex4f( 0.0, 0.0, 0.0, 1.0);
    glVertex4f( 0.0, 0.0, 1.0, 1.0);
  glEnd();

     glTranslatef(0.0, 2.05, 0.0);
	glEnable(GL_TEXTURE_2D);
	glColor3ub(255, 255, 255);
     glColor4f(0.8, 0.8, 0.8, 1.0);

GLfloat light_position[] = {  0.0, -2.0, 5.0, 1.0 };
glLightfv(GL_LIGHT0, GL_POSITION, light_position);
glEnable(GL_LIGHT0);

     //draw the model    
     myLoader->draw();

	glLoadIdentity();


	glFlush();
     glutSwapBuffers();
}

void keyCB(unsigned char key, int x, int y)
{
	if( key == 'q' )
	{
/*
	    for (int i = 0; i < g_3DModel.numOfObjects; i++)
		{
			delete [] g_3DModel.pObject[i].pFaces;
			delete [] g_3DModel.pObject[i].pNormals;
			delete [] g_3DModel.pObject[i].pVerts;
			delete [] g_3DModel.pObject[i].pTexVerts;
		}
*/
		exit(0);
	}
	else if (key == '+')
	{
		//glScalef(1.1,1.1,1.1);
          g_zoom *= 1.1;
	}
	else if (key == '-')
	{
		//glScalef(0.9,0.9,0.9);
          g_zoom *= 0.9;
	} else if( key == 'a') {
		g_RotateY -= g_RotationSpeed;
	} else if( key == 'd') {
		g_RotateY += g_RotationSpeed;
	} else if (key == 'w' ) {
		g_RotateX += g_RotationSpeed;
	} else if (key == 's' ) {
		g_RotateX -= g_RotationSpeed;
	}
	displayCB();
}

int main(int argc, char *argv[])
{
	int win;

	if (argc != 2)
	{
		printf("Usage: %s [3DS File]\n",argv[0]);
		exit(1);
	}
	
	glutInit(&argc, argv);
	//glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(1024,768);
	win = glutCreateWindow("3DS Converter");
     //create the loader, give it the filename (from cmdline)
     myLoader = new onv_3dsLoader(argv[1]);

	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHTING);
	glEnable(GL_COLOR_MATERIAL);
	
  	glutDisplayFunc(displayCB);
	glutKeyboardFunc(keyCB);


     glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glEnable(GL_TEXTURE_2D);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE); 
     glCullFace(GL_BACK); 
  glDepthFunc(GL_LESS );
	glEnable(GL_DEPTH_TEST);
	glDepthMask(GL_TRUE);

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
 glViewport(0,0,1024,768); 

  //james version
  glFrustum(-0.5*4.0/3.0, 0.5*4.0/3.0,  -0.5, 0.5,   1.0,   100.0);
  gluLookAt(0.0,0.0,-5.0,  0.0, 0.0,  0.0,   0.0, 1.0, 0.0);


     glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
    GLfloat mat_specular[] = { 0.8, 0.8, 0.8, 1.0 };
    GLfloat mat_shininess[] = { 100.0 };

    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);


//GLfloat light_ambient[] = { 1.0, 0.5, 0.5, 1.0 };
GLfloat light_diffuse[] = { 0.9, 0.9, 0.9, 1.0 };
GLfloat light_ambient[] = { 0.0, 0.0, 0.0, 1.0 };
GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };

glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
GLfloat ld[4] = {0.0, 0.0, 1.0, 1.0};
glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, ld);


GLfloat light_position[] = {  3.0, 4.0, -1.0, 1.0 };
glLightfv(GL_LIGHT0, GL_POSITION, light_position);


	glutMainLoop();
	
	return 0;
}
