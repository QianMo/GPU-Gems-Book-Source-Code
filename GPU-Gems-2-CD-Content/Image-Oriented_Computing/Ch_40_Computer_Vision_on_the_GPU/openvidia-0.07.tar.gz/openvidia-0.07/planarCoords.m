#! /usr/bin/octave2.1 -qf
# a sample Octave program


%**
%* This file is part of the OpenVIDIA project at http://openvidia.sf.net
%* Copyright (C) 2004, James Fung
%*
%* OpenVIDIA is free software; you can redistribute it and/or modify
%* it under the terms of the GNU General Public License as published by
%* the Free Software Foundation; either version 2 of the License, or
%* (at your option) any later version.
%*
%* OpenVIDIA is distributed in the hope that it will be useful,
%* but WITHOUT ANY WARRANTY; without even the implied warranty of
%* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%* GNU General Public License for more details.
%*
%* You should have received a copy of the GNU General Public License
%* along with OpenVIDIA; if not, write to the Free Software
%* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%**/

%printf ("progrname %s\n", program_name);
inx1 = argv(1);
iny1 = argv(2);
inx2 = argv(3);
iny2 = argv(4);
inx3 = argv(5);
iny3 = argv(6);
inx4 = argv(7);
iny4 = argv(8);

x1 = sscanf(inx1{1}, "%d");
y1 = sscanf(iny1{1}, "%d");
x2 = sscanf(inx2{1}, "%d");
y2 = sscanf(iny2{1}, "%d");
x3 = sscanf(inx3{1}, "%d");
y3 = sscanf(iny3{1}, "%d");
x4 = sscanf(inx4{1}, "%d");
y4 = sscanf(iny4{1}, "%d");

%x1, y1, x2, y2, x3,y3, x4,y4
%1 1 319 2 319 238 2 239
%x1 = 1;
%x2 = 319;
%x3 = 320;
%x4 = 4;
%y1 = 3;
%y2 = 4;
%y3 =240;
%y4 = 240;

bbox = [x1,x2,x3,x4,x1; y1,y2,y3,y4,y1];


fl(1) = 368.28488;
fl(2) = 369.04519;
principal_point(1) = 147.54834;
principal_point(2) = 126.01673;
distortion(1) = -0.4142;
distortion(2) = 0.40348;
distortion(3) = -0.00085;
distortion(4) = 0.0009;
camera_matrix(1) = fl(1);
camera_matrix(2) = 0;
camera_matrix(3) = principal_point(1);
camera_matrix(4) = 0;
camera_matrix(5) = fl(2);
camera_matrix(6) = principal_point(2);
camera_matrix(7) = 0;
camera_matrix(8) = 0;
camera_matrix(9) = 1;
f = mean(fl);

Mint = [fl(1) 0 principal_point(1);
    0   fl(2) principal_point(2);
    0 0 1];


for L = 1:4
    %line 1, dirvect
    t=(bbox(:,L)-bbox(:,L+1))./norm(bbox(:,L)-bbox(:,L+1));
    par(1:2,L) =[-t(2);t(1)];
    par(3,L)= -bbox(:,L)'*par(1:2,L);
end
par = par';

%compute intersections in image coords
int1 = cross(par(1,:),par(3,:));
int1 = int1./int1(3);
int2 = cross(par(2,:),par(4,:));
int2 = int2./int2(3);

%compute normal to rect plane (assuming a plane!)
planevec1 = [int1(1:2)-principal_point f];
planevec1 =     planevec1./norm(planevec1);
planevec2 = [int2(1:2)-principal_point(1) f];
planevec2 =     planevec2./norm(planevec2);    
n = cross(planevec1,planevec2)/norm(cross(planevec1,planevec2));
n = n*sign(dot(n,[0,0,1]));
%dot(planevec1,planevec2)

%compute camera rotation matrix

R3 = n;
R1 = planevec1;
R1 = R1*sign(dot(R1,[1 0 0]));

% pick biggest dimension method (although i haven't here)
R2 = cross(R1,R3);
R2 = R2*sign(dot(R2,[0 1 0]));
iR = [R1' R2' R3'];
R = inv(iR);

if 1
    %svd method. best fit rotation
    R2 = planevec2;
    R2 = R2*sign(dot(R2,[1 0 0]));
    iR = [R1' R2' R3'];
    [u s v] = svd(iR);
    iR = u*v';
    iR(:,1) = iR(:,1)*sign(R(1,1));
    iR(:,2) = iR(:,2)*sign(R(2,2));
    iR(:,3) = iR(:,3)*sign(R(3,3));
end


R = inv(iR);

coordOr(1) = mean(bbox(1,1:4));
coordOr(2) = mean(bbox(2,1:4));

pointMat =drawcoords(coordOr(1),coordOr(2), iR(:,1),-iR(:,2),-iR(:,3),Mint,10); %minuses so that normal
%points towards the camera and because of 0,0 in top left


oxIm = pointMat(1,1)-principal_point(1);
oyIm = pointMat(1,2)-principal_point(2);
ozIm = f;
Xvec = iR(:,1);
Yvec = -iR(:,2);
Zvec = -iR(:,3); 

%zp(1) = pointMat(1,3);
%zp(2) = pointMat(1,4);
%xp(1) = pointMat(2,3);
%xp(2) = pointMat(2,4);
%yp(1) = pointMat(3,3);
%yp(2) = pointMat(3,4);


printf("%f %f %f %f %f %f %f %f %f %f %f %f",oxIm, oyIm,ozIm, Xvec(1), Xvec(2),Xvec(3),Yvec(1),Yvec(2),Yvec(3),Zvec(1),Zvec(2),Zvec(3));

