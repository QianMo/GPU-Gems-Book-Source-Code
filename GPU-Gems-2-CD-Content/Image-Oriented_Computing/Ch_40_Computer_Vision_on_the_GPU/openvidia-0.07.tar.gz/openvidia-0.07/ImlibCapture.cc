/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "ImlibCapture.h"
#include <iostream>
using namespace std;

ImlibCapture :: ImlibCapture() {
  imlib_id=0;
  filenumber=0;
  startnum = 0 ;
  endnum = 0;
  im=NULL;
  cerr << "Constructed imlib capture" << endl;
}

ImlibCapture :: ImlibCapture(int s, int e) {
  imlib_id=0;
  filenumber=s;
  startnum = s ;
  endnum = e;
  im = NULL;
  cerr << "Constructed imlib capture" << endl;
}


ImlibCapture :: ~ImlibCapture() {
  cerr << "Destroyed imlib capture" << endl;
}

void ImlibCapture :: initCapture(Display *d) {
  Display *disp=XOpenDisplay(":0.0");
  imlib_id=Imlib_init(disp);
}

void ImlibCapture :: initCapture(GenericDisplay *d) {
  imlib_id=Imlib_init(d->getDisplay());
}

void ImlibCapture :: loadFile(char *fname) {
  if( fname == NULL ) {
    cerr<<"ImlibCapture: tried to load bad image pointer"<<endl;
  }
  if(imlib_id==0) {
    cerr<<"not initCaptured"<<endl;
  }
  cerr <<"ImlibCapture: opening ..." << fname;
  im=Imlib_load_image(imlib_id,fname);
  CaptureWidth = getRGBWidth();
  CaptureHeight = getRGBHeight();
  cerr <<"Opened"<<endl;
}

void ImlibCapture :: advanceFrame() {
 if(endnum==0) {
	 return;
 }
  sprintf(filename,"v%07d.jpg",++filenumber); 
  
  loadFile(filename);

  if (filenumber == endnum+1) {
    filenumber=startnum;
  }
}

void* ImlibCapture :: getRGBData() {
  if( im == NULL ) {
    cerr<<"NO IMAGE LOADED. ERROR"<<endl;
    return NULL;
  }
  else
    return im->rgb_data;
}

int ImlibCapture :: getRGBWidth() {
 
  if( im == NULL ) {
    cerr<<"NO IMAGE LOADED. ERROR"<<endl;
    return 0;
  }
  else
    return im->rgb_width;
}

int ImlibCapture :: getRGBHeight() {
  if( im == NULL ) {
    cerr<<"NO IMAGE LOADED. ERROR"<<endl;
    return 0;
  }
  else
    return im->rgb_height;
}
