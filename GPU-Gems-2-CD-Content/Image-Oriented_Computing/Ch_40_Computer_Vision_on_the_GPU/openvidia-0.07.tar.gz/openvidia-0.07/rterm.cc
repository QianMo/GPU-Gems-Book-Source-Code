/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <GL/glut.h> 
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "GenericDisplay.h"
#include "SimpleDisplay.h"
#include "CGDisplay.h"
#include "GLDisplay.h"
#include "GenericCapture.h"
#include "Dc1394Capture.h"
#include "Raw1394Capture.h"
#include "ImlibCapture.h"
#include "Grab_JPEG.h"
#include "Correspond.h"
#include "Udat.h"
#include "Tracker.h"
#include "OrbitsInterface.h"
#include "Parameters.h"
#include <iostream>
#include "GLTerm.h"
using namespace std;
// for GLTERM
#define HI_QUALITY 1
int USE_GLTERM=1;

// Global display object
//GenericDisplay *d;
GenericDisplay *glterm;
SimpleDisplay *d;
CGDisplay *orbits;
Tracker *estpchirp;
OrbitsInterface *orbitsinterface;
GenericCapture *gc;
Grab_JPEG *grabber;
Correspond *corr;
int use_cg=1;

int imageWinWidth = 640;
int imageWinHeight = 480;

Window  Orbwin;

////// UTILITY FUNCTION //////////////
void buffer_sample_float4(float sample[4], float *thebuffer,
                          int X, int Y,
                          int xSize, int ySize, int nchans )
{
  int i=0;
  for( i=0 ; i<nchans; i++ ) {
      sample[i] = thebuffer[Y*xSize*nchans+X*nchans+i];
  }
}

void printProjectionMatrix()
{
  float pmatrix[16]={0};
  glGetFloatv( GL_PROJECTION_MATRIX, pmatrix);
  printf("%5f %5f %5f %5f\n", pmatrix[0], pmatrix[4], pmatrix[8], pmatrix[12]);
  printf("%5f %5f %5f %5f\n", pmatrix[1], pmatrix[5], pmatrix[9], pmatrix[13]);
  printf("%5f %5f %5f %5f\n", pmatrix[2], pmatrix[6], pmatrix[10], pmatrix[14]);
  printf("%5f %5f %5f %5f\n", pmatrix[3], pmatrix[7], pmatrix[11], pmatrix[15]);
}

////// GLUT CALLBACKS ///////////////

void reshape(int w, int h)
{
  float SCALE = 10;
  glutSetWindow(Orbwin);

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(1, 0, (GLsizei) w, (GLsizei) h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, (float)w/(float)imageWinWidth/SCALE,  
            (float)h/(float)imageWinHeight/SCALE, 0.0,   1.0/SCALE,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glClear(GL_COLOR_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();


  //make a tasty vanilla frustum for fpbuffer orbits
  orbits->activate_fpbuffer();
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glViewport(0, 0, (GLsizei) 320, (GLsizei) 240);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(0.0, 1.0,  1.0, 0.0,   1.0,   100.0);
  gluLookAt(0.0,0.0,0.0,  0.0, 0.0,  -1.0,   0.0, 1.0, 0.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  orbits->deactivate_fpbuffer();

  glutPostRedisplay();
}


void myIdle(){
  glutSetWindow(Orbwin);
  glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
  glutSetWindow(Orbwin);

  if(USE_GLTERM) {
    glterm->handle_key(key);
  }
  /*   switch (key) {
      case 27:
         exit(0);
         break;
      default:
         break;
	 }*/
}

Parameters gltermInitial;

void MouseFunc( int button, int state, int x, int y) 
{
  switch(button) { 
    case GLUT_LEFT_BUTTON :
      if( state == GLUT_DOWN ) { 
        cerr << "("<<x<<","<<y<<")"<<endl;
        corr->add_point(x,y);
      }
      break;
    case GLUT_RIGHT_BUTTON : 
      if( state == GLUT_DOWN ) { 
        double p[8];
        corr->shell_Corr2p(p);
        glterm->setChirpMat( p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]); 
        gltermInitial.set( p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]); 
      }
      break;
    case GLUT_MIDDLE_BUTTON : 
      if( state == GLUT_DOWN ) { 
        corr->clear_points();
      }
      break;
  }
}
bool sense=true;
void doCrop ()
{ 
  int x,y,w,h;
  corr->getCropParams(320,240, &x, &y, &w, &h);
  //cerr<<"to crop at "<<x<<","<<y<<" size "<<w<<","<<h<<endl;
  if( sense) {  //0,1,0
    orbits->render_to_texture(0, x, y, w, h); 
    // note the binding order is important - any use of TexCoord3f (not multi) will use
    // latest bound texture-  not unit0 necesaarily
    //orbits->bindTextureARB1(1);
    //orbits->bindTextureARB0(0);
    
  }
  else { //1,0,1
    orbits->render_to_texture(1, x, y ,w, h);
    //orbits->bindTextureARB1(0);
    //orbits->bindTextureARB0(1);
  }
  sense = !sense; //make sense into nonsense
}

// coz i cant pass member funtion to glutDisplayFunc
/*
 *  Load new images, then call Display object render functions
 */ 

float Dm[320*240*4];
float Dn[320*240*4];
float Dt[320*240*4];
float Da[320*240*4];
Parameters p,P, gltermP, gltermp;
void render_redirect() {
  float ptmp[8];
  static bool haspair = false;
  

  gc->advanceFrame(); 

  d->init_texture(0, gc->getRGBWidth(), gc->getRGBHeight(),
           gc->getRGBData());
  gc->releaseCap();

  d->render();

  if( corr->hasPoints() ) {
    corr->drawQuad(320,240);
    doCrop();


  orbits->activate_fpbuffer();
      
    if( sense) {  //0,1,0
      orbits->bindTextureARB1(1);
      orbits->bindTextureARB0(0);
    }
    else { //1,0,1
      orbits->bindTextureARB1(0);
      orbits->bindTextureARB0(1);
    }

    if( !haspair ) { haspair = true; goto skip; }//dont orbit until 2 images
    orbitsinterface->resetParams();
    orbitsinterface->getParameters(ptmp);
    orbits->setChirpMatParams(ptmp);
    orbits->printChirpMat(); 
    orbits->render(); 
    orbits->render_to_texture(2);
    orbits->grabDisplay(Dm, Dn, Dt, Da, 0);

    orbitsinterface->setDt(0, Dt);
    orbitsinterface->setDm(0, Dm);
    orbitsinterface->setDn(0, Dn);
    orbitsinterface->pseudo_estimate(0);


skip: 
  orbits->deactivate_fpbuffer();

    //reassert display
    d->bindTextureARB0(0); 
    d->render();
  }

  if(USE_GLTERM) {
    glterm->render();
  }
  glFlush();
  glutSwapBuffers();
  //cout <<".";
  fflush(stdout);
  d->showstats();
 
  orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
  
}  



///// MAIN ///////////////////

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   cout <<"Creating Double Buffered Window" << endl;
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   //glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(imageWinWidth+320, imageWinHeight);
   glutInitWindowPosition(50, 100);
   Orbwin=glutCreateWindow(argv[0]);

   grabber = new Grab_JPEG();
   //orbits=new CGDisplay(3, imageWinWidth, imageWinHeight, Orbwin );
   orbits=new CGDisplay(3, 320,240, Orbwin );
   orbits->setDownsampleLevel(0);
   orbits->setImageSize(320,240);  
   orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
   orbits->initGL();

   d=new SimpleDisplay(3, imageWinWidth, imageWinHeight, Orbwin );
   if(USE_GLTERM) {
     glterm=new GLTerm(imageWinWidth, imageWinHeight, Orbwin);
   }

   //gc=new ImlibCapture(100,101);
   orbitsinterface = new OrbitsInterface(1, 240, 320);
   estpchirp = new Tracker(orbits, orbitsinterface); 
   corr = new Correspond(imageWinWidth, imageWinHeight );
   //gc=new Udat("U.dat");
   gc=new Dc1394Capture(FORMAT_RGB24);
   //gc=new Dc1394Capture();
   ((Dc1394Capture *)gc)->start();
   //gc=new Raw1394Capture();
   //((Raw1394Capture *)gc)->start();
   gc->initCapture(d);
   gc->advanceFrame();

   d->initDisplay();

   d->setImageSize( gc->getRGBWidth(), gc->getRGBHeight() );
   d->setChirpMat( 1, 0.00,  -0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
  orbits->setChirpMat(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0);
   glterm->setChirpMat( 1.000, 0.00,   0.00, 0.00, 1.0, -0.00,-0.00, 0.0); 
//   glterm->setChirpMat(0.387495, -0.029836, 0.522917, 0.047613, 0.274448, 0.298438, 0.034693, 0.029180  );
   //glterm->setChirpMat( 0.132241, -0.070937, 0.430430, 0.318872, 0.224949, 0.182278, -0.071016, 0.286632 );
   d->initGL();
   orbits->initGL();
   if(USE_GLTERM) {
     glterm->initGL();
   }

   d->init_texture(0, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   orbits->init_texture_4u(0, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   orbits->init_texture_4u(1, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   orbits->init_texture4f(3, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   orbits->init_texture4f(4, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());

   gc->releaseCap();

   if(use_cg) {
	   gc->advanceFrame();
	   d->init_texture(1, gc->getRGBWidth(), gc->getRGBHeight(),
			                         gc->getRGBData());
        gc->releaseCap();
   }

   d->init_texture4f(2, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());
   orbits->init_texture4f(2, gc->getRGBWidth(),gc->getRGBHeight(),gc->getRGBData());

   //d->bindTextures(); //why does this line mess up drawing colors?!
   d->setDownsampleLevel(0);

   glutSetWindow(Orbwin);
   glutDisplayFunc(render_redirect);
   glutIdleFunc(myIdle);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(MouseFunc);
   glutMainLoop();
   return 0; 
}
