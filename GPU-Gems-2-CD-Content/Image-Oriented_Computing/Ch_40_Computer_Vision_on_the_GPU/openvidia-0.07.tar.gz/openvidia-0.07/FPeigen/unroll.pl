#!/usr/bin/perl -w
#for( $j = 0 ; $j<2 ; $j++ ) {
for( $i = 0 ; $i<240 ; $i++ ) {
#printf("sum += texRECT(FPE1, float2(%d,fptexCoord.x));\n", $i);
printf("sum += texRECT(FPE1, float2(%d, xcoord));\n", $i);
#printf("sum += texRECT(FPE1, float2(%d,x));\n", $i, $j);
}
#}
