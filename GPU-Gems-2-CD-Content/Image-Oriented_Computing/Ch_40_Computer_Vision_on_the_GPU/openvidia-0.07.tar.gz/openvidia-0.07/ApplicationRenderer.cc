/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "ApplicationRenderer.h"
#include "tools/graphicsHelpers.h"
#include "tools/geometry.h"
#include <GL/glut.h> 


// for data variable
#ifdef __cplusplus
extern "C" {
#endif

#include "mat_util.h"

#ifdef __cplusplus
}
#endif


void ApplicationRenderer::setInitialParameter(Parameters p) {
  initialAppParameter = p;
}

Parameters ApplicationRenderer::getInitialParameter() {
  return initialAppParameter;
}

void ApplicationRenderer::setCurrentParameter(Parameters p) {
  currentAppParameter=p;
}

Parameters ApplicationRenderer::getCurrentParameter() {
  return currentAppParameter;
}
  
void ApplicationRenderer::preRender() {
  glPushMatrix();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glMultMatrixf( currentAppParameter.getAsChirpMat() );

}

void ApplicationRenderer::postRender() {


  glPopMatrix();
}


void ApplicationRenderer::drawBorder(float r, float g, float b, float alpha) {
  // new way (should be 3D)
  preRender();
  glColor4f(r,g,b,alpha);
  glBegin(GL_LINE_LOOP);
  // draw slightly around it.
  float delta=0.005;
  glVertex3f(0-delta,0-delta,1.0);
  glVertex3f(0-delta,1+delta,1.0);
  glVertex3f(1+delta,1+delta,1.0);
  glVertex3f(1+delta,0-delta,1.0);
  glEnd();
  postRender();


  // 2D Flat way:
  /*  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  int x[4], y[4];
  getRenderedScreenLocation(x,y,x+1,y+1,x+2,y+2,x+3,y+3);
  glColor4f(r,g,b,alpha);
  glBegin(GL_LINE_LOOP);
  for(int i=0;i<4;i++) {
  glVertex3f(x[i]/640.0, y[i]/480.0, -1);
  }
  glEnd();*/
}

/*
 * Report if the mouse is over the current application
 */
bool ApplicationRenderer::isMouseOver(int x, int y) {
  int x1,y1,x2,y2,x3,y3,x4,y4;
  getRenderedScreenLocation(&x1,&y1,&x2,&y2,&x3,&y3,&x4,&y4);
  
  bool drawCorners=false;
  if(drawCorners) {
    drawFingerTip(x1,y1,1.0,0.0,0.0);
    drawFingerTip(x2,y2,0.0,1.0,0.0);
    drawFingerTip(x3,y3,0.0,0.0,1.0);
    drawFingerTip(x4,y4,1.0,1.0,1.0);
  }
  
  //return isPointInside(x,y,x1,y1,x2,y2,x3,y3,x4,y4);
///where did this function go?
  return false;

}

/*
 *  The other way of checking if the mouse is over the app
 */
bool ApplicationRenderer::isMouseOverAlternate(int x, int y) {
  /* handtracker x,y is on a 640 grid */
  double x_prime, y_prime;
  getLocalCoords(x,y,&x_prime, &y_prime);
  
  if( x_prime >= 0 && x_prime <= 1 &&
      y_prime >= 0 && y_prime <= 1) {
    return true;
  } 
  return false;
}

/*
 * Refer to ICASSP 2004 paper
 * relative position on root-video-texture is a 320x240 grid, in form of
 *
 *  (x1,y1)  (x2,y2)
 *  (x4,y4)  (x3,y3)
 *
 * relative position on root-video-texture is a 320x240 grid
 * BUG: moving to left, is the ximage that is above it
 * Possible something to do with c's and +1 being 
 * negative for GL systems.  Otherwise, x,y reversed 
 * OR COULD BE MATH PROBLEMS  
 * note -- rendered screen location and GL clicks on 640x480 grid
 * many other operations are on a 320 grid
 */
void ApplicationRenderer::getRenderedScreenLocation(int *x1, int *y1, int *x2, int *y2,
						    int *x3, int *y3, int *x4, int *y4) {
  // rendered screen location and GL muose clicks on 640x480 grid
  // but most other operations are on a 320 grid
  int width=640;
  int height=480;
  Parameters current=getCurrentParameter();

  /*
   * Our Raster-Scan GL coords <--> Orbits uses y across, x down
   * 
   * ORIGINALLY:
   * denom = (current.c1*x+current.c2*y + 1);
   *x2= (int) (width * ( (current.a11*x + current.a12*y + current.b1)/denom) );
   *y2= (int) (height * ( (current.a21*x + current.a22*y + current.b2)/denom) );
   */
  double x=0.0;
  double y=0.0; 
  double denom = (current.c1*x+current.c2*y + 1);
  *y1= (int)round(height*(current.a11*x + current.a12*y + current.b1)/denom);
  *x1= (int)round(width *(current.a21*x + current.a22*y + current.b2)/denom);
  
  // Since Orbits y is x, for "top right corner" use y=1, x=0
  x=0.0;
  y=1.0; 
  denom = (current.c1*x+current.c2*y + 1);
  *y2= (int)round(height*(current.a11*x + current.a12*y + current.b1)/denom);
  *x2= (int)round(width *(current.a21*x + current.a22*y + current.b2)/denom);
 
  x=1.0;
  y=1.0; 
  denom = (current.c1*x+current.c2*y + 1);
  *y3= (int)round(height*(current.a11*x + current.a12*y + current.b1)/denom);
  *x3= (int)round(width*(current.a21*x + current.a22*y + current.b2)/denom);

  x=1.0;
  y=0.0; 
  denom = (current.c1*x+current.c2*y + 1);
  *y4= (int)round(height*(current.a11*x + current.a12*y + current.b1)/denom);
  *x4= (int)round(width*(current.a21*x + current.a22*y + current.b2)/denom);
}


/*
 * Rewrite: Given raster scan coords on 640 grid, convert to normalized
 * orbits parms.  Then return them as normalized raster scan order
 * coords.
 *
 */

/*
 * Given an current coordinate system point in [0,0] -> [1,1], find the coordinates of it 
 * in the transformed coordinate system.
 *
 * Usage: Take a mouse click, coordinate transform it,
 * if it lies in 0,0 -> 1,1 then the click was within the 
 * original texture square mapped to that coord on the screen
 */ 
void ApplicationRenderer::getLocalCoords(int x, int y, double *x_prime, double *y_prime) {
  Parameters current=getCurrentParameter();
  current.invert();

  /*
   * CAREFUL
   * Turn raster order x,y into orbits style x and y, normalize
   */
  double orbits_y=x/640.0;
  double orbits_x=y/480.0;

  /*
   * In orbits world, we're in raster order, not 2nd quadrant
   * so set y to negative y, and fix on the way out.
   */
  double denom = current.c1*orbits_x+current.c2*orbits_y + 1;

  // reverse Y and X coz of orbits reasons described above
  *y_prime = (current.a11*orbits_x + current.a12*orbits_y + current.b1)/denom;
  *x_prime = (current.a21*orbits_x + current.a22*orbits_y + current.b2)/denom;
}
