/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "Dc1394Capture.h"
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
using namespace std;


#define FORMAT_UYVY 6
// support multiple buffers for videorbits


Dc1394Capture :: ~Dc1394Capture() { 
  if(handle!=0) {
    dc1394_release_camera(handle,&camera);
    raw1394_destroy_handle(handle);
  }
  cout << "Destroyed dc1394 capture" << endl;
}

Dc1394Capture :: Dc1394Capture(int RequestedFormat) {
  gainval = 128;
  switch(RequestedFormat) {
    case FORMAT_RGB24:
    case FORMAT_GREYSCALE:
//      CaptureWidth = 320; //no such thing
//      CaptureHeight = 240;
      CaptureWidth = 640;
      CaptureHeight = 480;
      break;
    default:
      CaptureWidth = DefaultCaptureWidth;
      CaptureHeight = DefaultCaptureHeight;
  }
  v1394_uyvy_buf = (unsigned char *)malloc( CaptureWidth*CaptureHeight*2);
  // rgb is actually rgb24? - so *3 not *4
  v1394_rgb_buf = (unsigned char *)malloc( CaptureWidth*CaptureHeight*4);
  v1394_rgb_buf_previous_frame = (unsigned char *)malloc( CaptureWidth*CaptureHeight*4);
  cout << "constructed Dc1394Capture" <<endl;

  int numNodes;
  int numCameras;
  //nodeid_t * camera_nodes;
  dc1394_feature_set features;

  /*-----------------------------------------------------------------------
   *  Open ohci and asign handle to it
   *-----------------------------------------------------------------------*/
  handle = dc1394_create_handle(0);
  if (handle==NULL)
  {
    fprintf( stderr, "Unable to aquire a raw1394 or video1394 handle\n\n"
             "Please check \n"
	     "  - if the kernel modules `ieee1394',`raw1394' and `ohci1394' are loaded \n"
	     "  - if you have read/write access to /dev/raw1394\n\n");
    cerr<<"killing thread."<<endl;
    int *killer=0;
    int a=*killer;
  }

  
  /*-----------------------------------------------------------------------
   *  get the camera nodes and describe them as we find them
   *-----------------------------------------------------------------------*/
  numNodes = raw1394_get_nodecount(handle);
  camera_nodes = dc1394_get_camera_nodes(handle,&numCameras,1);
  fflush(stdout);
  if (numCameras<1)
  {
    fprintf( stderr, "no cameras found :(\n");
    raw1394_destroy_handle(handle);
    //exit(1);
  }
  printf("working with the first camera on the bus\n");
  
  /*-----------------------------------------------------------------------
   *  to prevent the iso-transfer bug from raw1394 system, check if
   *  camera is highest node. For details see 
   *  http://linux1394.sourceforge.net/faq.html#DCbusmgmt
   *  and
   *  http://sourceforge.net/tracker/index.php?func=detail&aid=435107&group_id=8157&atid=108157
   *-----------------------------------------------------------------------*/
  if( camera_nodes[0] == numNodes-1)
  {
    fprintf( stderr, "\n"
             "Sorry, your camera is the highest numbered node\n"
             "of the bus, and has therefore become the root node.\n"
             "The root node is responsible for maintaining \n"
             "the timing of isochronous transactions on the IEEE \n"
             "1394 bus.  However, if the root node is not cycle master \n"
             "capable (it doesn't have to be), then isochronous \n"
             "transactions will not work.  The host controller card is \n"
             "cycle master capable, however, most cameras are not.\n"
             "\n"
             "The quick solution is to add the parameter \n"
             "attempt_root=1 when loading the OHCI driver as a \n"
             "module.  So please do (as root):\n"
             "\n"
             "   rmmod ohci1394\n"
             "   insmod ohci1394 attempt_root=1\n"
             "\n"
             "for more information see the FAQ at \n"
             "http://linux1394.sourceforge.net/faq.html#DCbusmgmt\n"
             "\n");
    //exit( 1);
  }
  
  /*-----------------------------------------------------------------------
   *  setup capture
   *-----------------------------------------------------------------------*/

  printf("Setting up dma camera capture.\n");
  switch(RequestedFormat) {
    case FORMAT_UYVY:
      if (dc1394_dma_setup_capture(handle,
			         camera_nodes[0], // camera id
			         0, // iso channel
			         FORMAT_VGA_NONCOMPRESSED, //format
			         MODE_320x240_YUV422, //mode
			         //MODE_640x480_MONO,
			         //MODE_640x480_RGB,
			         SPEED_400, //max speed
			         FRAMERATE_30, //framerate
			         //FRAMERATE_15, //framerate
			         4, //num dma buffers
                        1, //extra dma buff
			         1, //dropframes
			         "/dev/video1394/0", //videodevice
			         &camera)!=DC1394_SUCCESS) 
       {
          fprintf( stderr,"unable to setup camera-\n"
    	        "check line %d of %s to make sure\n"
             "that the video mode,framerate and format are\n"
   	        "supported by your camera\n",
   	         __LINE__,__FILE__);
          dc1394_release_camera(handle,&camera);
          raw1394_destroy_handle(handle);
          //exit(1);
          CaptureFormat = -1;
       }
       CaptureFormat = RequestedFormat;
       break;

     case FORMAT_RGB24:
      if (dc1394_dma_setup_capture(handle,
			         camera_nodes[0], // camera id
			         0, // iso channel
			         FORMAT_VGA_NONCOMPRESSED, //format
			         MODE_640x480_RGB,
			         SPEED_400, //max speed
			         FRAMERATE_15, //framerate
			         4, //num dma buffers
                        1, //extra
			         1, //dropframes
			         "/dev/video1394/0", //videodevice
			         &camera)!=DC1394_SUCCESS) 
       {
          fprintf( stderr,"unable to setup camera-\n"
    	        "check line %d of %s to make sure\n"
             "that the video mode,framerate and format are\n"
   	        "supported by your camera\n",
   	         __LINE__,__FILE__);
          dc1394_release_camera(handle,&camera);
          raw1394_destroy_handle(handle);
          CaptureFormat= -1;
       }
       cerr <<"Dc1394 using rgb24"<<endl;
       CaptureFormat = RequestedFormat;
       break;
     case FORMAT_GREYSCALE:
      if (dc1394_dma_setup_capture(handle,
			         camera_nodes[0], // camera id
			         0, // iso channel
			         FORMAT_VGA_NONCOMPRESSED, //format
			         MODE_640x480_MONO,
			         SPEED_400, //max speed
			         FRAMERATE_15, //framerate
			         4, //num dma buffers
                        1, //extra dma
			         1, //dropframes
			         "/dev/video1394/0", //videodevice
			         &camera)!=DC1394_SUCCESS) 
       {
          fprintf( stderr,"unable to setup camera-\n"
    	        "check line %d of %s to make sure\n"
             "that the video mode,framerate and format are\n"
   	        "supported by your camera\n",
   	         __LINE__,__FILE__);
          dc1394_release_camera(handle,&camera);
          raw1394_destroy_handle(handle);
          CaptureFormat = -1;
       }
       CaptureFormat = RequestedFormat;
       break;
     default:
       cerr<<"Dc1394: WARNING: Requested format could not be accomodated.";
       cerr<<endl;
  }
  
  /*-----------------------------------------------------------------------
   *  have the camera start sending us data
   *-----------------------------------------------------------------------*/
  if (dc1394_start_iso_transmission(handle,camera.node)
      !=DC1394_SUCCESS) 
    {
      fprintf( stderr, "unable to start camera iso transmission\n");
      dc1394_release_camera(handle,&camera);
      raw1394_destroy_handle(handle);
      //exit(1);
    }
}



void Dc1394Capture :: initCapture(GenericDisplay *d) {}

//default constructor  - deprecated  (ooh i said deprecated)
Dc1394Capture :: Dc1394Capture() {
  fprintf(stderr,"deprecated 1394 constructor\n");
  return;
}


void Dc1394Capture :: advanceFrame() { ENTER_CRITICAL }
void Dc1394Capture :: releaseCap() { LEAVE_CRITICAL }

//void Dc1394Capture :: advanceFrame() {
void Dc1394Capture :: run() {
  cerr<<"Started Dc1394 Capture thread!"<<endl;
  while(1) {
    if (dc1394_dma_single_capture(&camera)!=DC1394_SUCCESS) {
      cerr<< "single frame capture failed"<<endl;
      cerr<<"killing thread."<<endl;
      int *killer=0;
      int a=*killer;
      //      exit(-1);
    }
  
    //320x230x2, 2 is for yuv422
    // I could do away with this memcpy and put it straight into RGB
    ENTER_CRITICAL
    switch(CaptureFormat) {
      case FORMAT_UYVY : 
        memcpy(v1394_uyvy_buf,(const char *)camera.capture_buffer,
               CaptureWidth*CaptureHeight*2);
        break;
      case FORMAT_RGB24 :
        memcpy(v1394_rgb_buf,(const char *)camera.capture_buffer,
               CaptureWidth*CaptureHeight*3);
	cout <<"captured a frame!"<<endl;
	for(int i=0;i<20;i++) {
	  cout << *(((unsigned char*)v1394_rgb_buf)+i);
	}
	cout <<endl;
        break;
      default :
        cerr<<"Dc1394 Warning:  getting unknown video format\n"<<endl;
    }  
    LEAVE_CRITICAL
 
    dc1394_dma_done_with_buffer(&camera);
  }
}


// Must call this after getRGBData since the other function has a sideeffect
// of swiveling the buffer pointers
void* Dc1394Capture :: getRGBDataPreviousFrame() {
  return v1394_rgb_buf_previous_frame;
}

void* Dc1394Capture :: getUVUYData() {
  return v1394_uyvy_buf;
}

void* Dc1394Capture :: getRGBData() {
  void *tmp;

  switch(CaptureFormat) {
    case FORMAT_UYVY: 
      // swivel the buffer pointers
      tmp = v1394_rgb_buf_previous_frame;
      v1394_rgb_buf_previous_frame = v1394_rgb_buf;
      v1394_rgb_buf = tmp;
      UYVYtoRGB24((unsigned char *)v1394_uyvy_buf,
                  (unsigned char *)v1394_rgb_buf,
                  CaptureWidth,CaptureHeight);
      return v1394_rgb_buf;
      break;
    case FORMAT_RGB24:
      // XXX i think buffer swiveling is broke here
      return v1394_rgb_buf;
      break;
    default :
      cerr<<"Dc1394 Warning:  getting unknown video format"<<endl;
      break;
  }
}

int Dc1394Capture :: getRGBWidth() {
  return CaptureWidth;
}

int Dc1394Capture :: getRGBHeight() {
  return CaptureHeight;
}

int Dc1394Capture :: get_gain() {
  int retval=0;
  retval = dc1394_get_exposure(handle, camera_nodes[0], &(this->gainval));
  cerr<<"retval "<<retval<<endl; fflush(stderr);
  //gainval = retval;
}

unsigned char Dc1394Capture::clip(float pixel_val) {
  if (pixel_val >= 255) {
    return 255;
  } else if (pixel_val <= 0){ 
    return 0;
  } else {
    return (unsigned char)(pixel_val);
  }
}

void Dc1394Capture :: UYVYtoRGB24(unsigned char *s, unsigned char *d, int width, int height) {
    int i,j;
    unsigned char y0,u,y1,v,r1,r2,b1,b2,g1,g2;
    
    for(i=0; i<height; i++)
      {
	for(j=0; j<width*2; j+=4)
	  {
	    u = *s++;
	    y0  = *s++;
          v   = *s++;
          y1  = *s++;
                                                                                
          b1 = clip(1.164*(y0-16)+2.018*(u-128));
          g1 = clip(1.164*(y0-16)-0.813*(v-128)-0.391*(u-128));
          r1 = clip(1.164*(y0-16)+1.596*(v-128));
                                                                                
          b2 = clip(1.164*(y1-16)+2.018*(u-128));
          g2 = clip(1.164*(y1-16)-0.813*(v-128)-0.391*(u-128));
          r2 = clip(1.164*(y1-16)+1.596*(v-128));
                                                                                
          *d++ = r1;
          *d++ = g1;
          *d++ = b1;
          *d++ = r2;
          *d++ = g2;
          *d++ = b2;
        }
    }
}
