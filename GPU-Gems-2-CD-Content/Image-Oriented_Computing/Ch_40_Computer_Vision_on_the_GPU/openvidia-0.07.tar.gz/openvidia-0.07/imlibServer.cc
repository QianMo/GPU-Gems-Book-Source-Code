/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include <getopt.h>
#include <assert.h>

#include "GenericCapture.h"
#include "ImlibCapture.h"
#include "Parameters.h"
#include "ImageSender.h"

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/shape.h>

using namespace std;
int niterreq=-1;

void posixify(int argc, char * argv[]); //fill in from orbits version
void posixify(int argc, char * argv[]) {}//fill in from orbits version
char filename1[1024]="images/s06.pgm";
char filename2[1024]="images/s04.pgm";

void printHelp()
{
  cout<<"imlibServer options:"<<endl;
  cout<<"Usage: imlibServer {optional filenam 1} {optional filename 2}"<<endl; 
  cout<<"   -p --parallell [n]\t: do this [n] number of parallel iterations."<<endl;
  cout<<"Options can be put before or after the filenames."<<endl;
  cout<<endl;
}

//parse options
static struct option long_options[] = {
     {"parallel", 0, 0, 'p'},
     {"help", 0, 0, 'h'},
     {0,0,0,0}
};

void parse_cmdline(int argc, char **argv)
{
   char c;
   opterr = 0; /* prevent weird options from causing errors */
   posixify(argc,argv);

   while(1) {
     int this_option_optind = optind ? optind : 1;
     int option_index = 0;
     c = getopt_long (argc, argv, "p:h",
                      long_options, &option_index);
     if (c == -1) break;
     switch(c){
     case 'p' : //parallel requests
       niterreq = atoi(optarg);
       assert(niterreq > 0);
       break;
     case 'h' : //print help
       printHelp();  exit(0);
       break;
     defalt :
       cerr<<"WARNING: unknown switch "<<c<<endl;
     }
   }

   //after options what happens to non options
   //getopt places all unrecognized options at the end
   if( optind < argc ) {
     if( optind + 1 >= argc ) { 
       cerr<<"Two filenames must be supplied if you specify any"<<endl;
       exit(1);                  
     } 
     else {
       cerr<<"Filename 1: "<<argv[optind]<<endl;
       cerr<<"Filename 2: "<<argv[optind+1]<<endl;
       strcpy(filename1,argv[optind]);
       strcpy(filename2,argv[optind+1]);
     }
  }
  else {
       cerr<<"Filename 1 (Default): "<<filename1<<endl;
       cerr<<"Filename 2 (Default): "<<filename2<<endl;
  }

}

///// MAIN ///////////////////
int main(int argc, char** argv)
{
   int imageW=-1; 
   int imageH=-1;
   parse_cmdline(argc, argv); //make sure this occurs after glut parses
   if(niterreq < 1) {
     cerr << "please supply an parallel iteration parameter"<<endl;
     exit(-1);
   } else {
     cerr<<"Requesting "<<niterreq<<" parallel iterations."<<endl;
   }
   
   // please send flame mail to imlib developers for this one
   Display *disp=XOpenDisplay(":0.0");
   
   ImlibCapture *imlibcapture=new ImlibCapture(100,101);
   imlibcapture->initCapture(disp);
   //imlibcapture->loadFile("images/s04.pgm");
   imlibcapture->loadFile(filename1);
   void* data1 = imlibcapture->getRGBData();
   imageW = imlibcapture->getRGBWidth();
   imageH = imlibcapture->getRGBHeight();
   int size = imageW*imageH*3;
   unsigned char *storage1 = (unsigned char*) malloc( size );
   memcpy(storage1, data1, size);

   //imlibcapture->loadFile("images/s06.pgm");
   imlibcapture->loadFile(filename2);
   void* data2 = imlibcapture->getRGBData();
   unsigned char *storage2 = (unsigned char*)malloc( size );
   memcpy(storage2, data2, size);
   
   ImageSender sender=ImageSender();
   Parameters initialGuess, convergedResult;
   cout <<"sending..."<<endl;
   sender.sendImages(imageW,imageH,storage1, storage2,
		     niterreq, initialGuess, &convergedResult);
   cout <<"got result."<<endl;
   convergedResult.print();

   return 0; 
}

