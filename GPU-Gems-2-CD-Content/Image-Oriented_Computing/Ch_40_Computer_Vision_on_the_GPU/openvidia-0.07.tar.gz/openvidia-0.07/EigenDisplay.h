/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _EIGENDISPLAY_H
#define _EIGENDISPLAY_H

#include "MultitextureDisplay.h"
//#include "fpc.h"
//#include "FragmentProgram.h"
//#include "FragmentProgram2Tex.h"

class EigenDisplay : public MultitextureDisplay
{
 private:
   void EigenDisplay::draw_quad_folded_16tex( int dist,
                                              float texwidth,
                                              float texheight,
                                              float origin, 
                                              float texdist ) ;
  FragmentProgram *FP_summation, *FP_sum2;
  GLuint listName, sumListName, sum2ListName, texIterList;
  GLuint projList[32];

 public:
  EigenDisplay(int num_textures, int imageWinWidth, int imageWinHeight, int win);
  void quarter_quad(int start_tex, int w, int h);
  void init_FP_summation(char *FPname, char *FPname2);
  void render();
  void render_quartered();
  void bindTexture0to3(int);
  void bindTexture(int,int,int,int,int);
  void bindTexture4to7(int);
  void bindTexture8to11(int);
  void bindTexture12to15(int);
  //void makeDisplayList(int,int,int,int);
  void makeDisplayList(int,int);
  bool checkTextureResidency(int);
};

#endif

