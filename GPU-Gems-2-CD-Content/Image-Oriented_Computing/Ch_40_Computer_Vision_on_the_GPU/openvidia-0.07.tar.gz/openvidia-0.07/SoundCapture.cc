/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

// AUDIO
#include "SoundCapture.h"
#include <linux/soundcard.h>
extern int HAND_X_COORD;
extern int HAND_Y_COORD;
// XXXX REMOVED THIS INTERFACE< HACK BELOW
int HAND_X_COORD=0;
int HAND_Y_COORD=0;

#include <GL/glut.h> //for callback


extern void MouseFunc(int,int,int,int);
   // SOUND STUFF - check <linux/sound.h>x
   // to test: sox -c 0 -t ossdsp /dev/dsp test.wav
   // then mplayer test.wav 

SoundCapture :: SoundCapture() {
  m_DEBUG=false;
  soundEnergy=0;
  resetTrailingBuffer();

  /* open sound device */
  fd = open("/dev/dsp", O_RDWR);
  if (fd < 0) {
    perror("open of /dev/dsp failed");
  }
  
  /* set sampling parameters */
  int arg = SIZE;      /* sample size */
  int status = ioctl(fd, SOUND_PCM_WRITE_BITS, &arg);
  if (status == -1)
    perror("SOUND_PCM_WRITE_BITS ioctl failed");
  if (arg != SIZE)
    perror("unable to set sample size");
  
  arg = CHANNELS;  /* mono or stereo */
  status = ioctl(fd, SOUND_PCM_WRITE_CHANNELS, &arg);
  if (status == -1)
    perror("SOUND_PCM_WRITE_CHANNELS ioctl failed");
  if (arg != CHANNELS)
    perror("unable to set number of channels");
  
  arg = RATE;      /* sampling rate */
  status = ioctl(fd, SOUND_PCM_WRITE_RATE, &arg);
  if (status == -1)
    perror("SOUND_PCM_WRITE_WRITE ioctl failed");
  //fprintf(stderr, "OPENED MICROPHONE FOR READING at %d kHz\n", status);
  
  bufSize=sizeof(buf);
}

void SoundCapture :: run() {
  int circularCounter=0;
  while (1) { /* loop until Control-C */
    if(circularCounter == TRAILING_BUFFER_SIZE-1) {
      circularCounter=0;
    } else {
      ++circularCounter;
    }
    int status = read(fd, buf, bufSize); /* record some sound */
    if (status != bufSize) {
      perror("read wrong number of bytes");
    }
    int sum=0;
    for(int i=0;i<bufSize; i++) {
      unsigned char c=*(buf+i);
      sum+=(int)c;
    }
    //fprintf(stderr,"AVG VALUE IS %d, sum is %d, bufSize is %d\n", sum/bufSize, sum, bufSize);

    soundEnergy=sum/bufSize;

    //    ENTER_CRITICAL
      trailingBuffer[circularCounter]=soundEnergy;
      //LEAVE_CRITICAL
      if(m_DEBUG) fprintf(stderr,"Largest mic val=%d\n",trailingBuffer[findLargestEnergy()]);
      if(isLargePulse(circularCounter)) {
	MouseFunc(GLUT_LEFT_BUTTON, GLUT_DOWN, HAND_X_COORD, HAND_Y_COORD );
	resetTrailingBuffer();
      }
  }
}

int SoundCapture::findLargestEnergy() {
  int largestIndex=0;
  int largestVal=0;
  for(int i=0; i<TRAILING_BUFFER_SIZE; i++) {
    if(trailingBuffer[i]>largestVal) {
      largestIndex=i;
      largestVal=trailingBuffer[i];
    }
  }
  return largestIndex;
}

void SoundCapture::setCallbackFunction(void* f) {
  m_callbackFunction=f;
}

bool SoundCapture::isLargePulse(int index) {
  int largest=findLargestEnergy();
  double sum=0;
  for(int i=0; i<TRAILING_BUFFER_SIZE;i++) {
    if(i!=index) {
      sum+=trailingBuffer[i];
    }
  }
  double avg=sum/(TRAILING_BUFFER_SIZE-1);
  if(trailingBuffer[index]>1.5*avg) 
    return true;
  return false;
}

void SoundCapture::resetTrailingBuffer() {
  // init to large values so no clicks at start
  for(int i=0;i<TRAILING_BUFFER_SIZE; i++) {
    trailingBuffer[i]=999999;
  }
}
