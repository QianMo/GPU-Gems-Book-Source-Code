/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "OrbitsInterface.h"
//#include <videorbits.h>
#include <assert.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>
using namespace std;


void setIdentityParams( Var *p) ;
void printVar( Var *p ) ;
void setZeroParams( Var *p ) ;
void mirror_DER_matrix(Var *DER) ;

#include <iostream>
OrbitsInterface::OrbitsInterface( int downsamp_lvls, int inM, int inN) {
  m_DEBUG=0;
  //initialize DER (8x8 matrix)
  DERIVATIVES = (Var *)calloc(1, sizeof(Var));
  Derivatives = (Var *)calloc(1, sizeof(Var));
  DERIVATIVES->channels = 1;
  Derivatives->channels = 1;
  DERIVATIVES->name = "DERIVATIVES";
  Derivatives->name = "Derivatives";

  Derivatives->data = (Data *)calloc(8 * 1, sizeof(Data));
  Derivatives->M = 8;  Derivatives->N = 1;  Derivatives->channels = 1;
  Derivatives->var_type = INTERNAL_VARIABLE;
  for (int j=0; j<8 ; j++ ) {
    Derivatives->data[j] = 0.0;
  }

  DERIVATIVES->data = (Data *)calloc(8 * 8 * 1, sizeof(Data));
  DERIVATIVES->M = 8;  DERIVATIVES->N = 8;  DERIVATIVES->channels = 1; 
  /* # channels */
  DERIVATIVES->var_type = INTERNAL_VARIABLE;
  for (int i=0;i<8;i++ ) {
    for (int j=0; j<8 ; j++ ) {
      DERIVATIVES->data[i*8+j] = 0.0;
    }
  }



  parameters = (Var *)malloc(sizeof(Var));
  init_var(parameters, "pairwise parameters", 8, 1,
         INTERNAL_VARIABLE, GREY_SCALE,NULL);
  parameters->data = (Data *)calloc(8, sizeof(Data));
  parameters->M = 8;   parameters->N = 1;
  parameters->channels = 1;
  setIdentityParams( parameters ) ;

  pcomposed = (Var *)malloc(sizeof(Var));
  init_var(pcomposed, "composed parameters", 8, 1,
         INTERNAL_VARIABLE, GREY_SCALE,NULL);
  pcomposed->data = (Data *)calloc(8, sizeof(Data));
  pcomposed->M = 8;   pcomposed->N = 1;
  pcomposed->channels = 1;
  setIdentityParams( pcomposed ) ;

  prev_pcomposed = (Var *)malloc(sizeof(Var));
  init_var(prev_pcomposed, "previous composed parameters", 8, 1,
         INTERNAL_VARIABLE, GREY_SCALE,NULL);
  prev_pcomposed->data = (Data *)calloc(8, sizeof(Data));
  prev_pcomposed->M = 8;   prev_pcomposed->N = 1;
  prev_pcomposed->channels = 1;
  setIdentityParams( prev_pcomposed ) ;

  //fullsize
  M = inM;
  N = inN;
 
  downsample_levels = downsamp_lvls; 
  channels = 1;  //only grayscale images are supported for now

  //make an array of Vars to hold derivative images of different sizes
  Dts = (Var **) malloc(sizeof(Var *)*(downsample_levels+1));
  Dms = (Var **)malloc(sizeof(Var *)*(downsample_levels+1));
  Dns = (Var **) malloc(sizeof(Var *)*(downsample_levels+1));

  //create the Var structs, but don't fillin the memory pointers
  for( int i=0 ; i<=downsample_levels ; i++ ) {
    Dts[i] = (Var *)calloc(1, sizeof(Var));
    Dms[i] = (Var *)calloc(1, sizeof(Var));
    Dns[i] = (Var *)calloc(1, sizeof(Var));
    //derivatives are one smaller because of edges
    init_var((Var *)Dts[i],"Dt",(int)(M/(pow(2.0,(double)i))-1),(int)(N/(pow(2.0,(double)i))-1),INTERNAL_VARIABLE,channels,NULL);
    init_var((Var *)Dms[i],"Dm",(int)(M/(pow(2.0,(double)i))-1),(int)(N/(pow(2.0,(double)i))-1),INTERNAL_VARIABLE,channels,NULL);
    init_var((Var *)Dns[i],"Dn",(int)(M/(pow(2.0,(double)i))-1),(int)(N/(pow(2.0,(double)i))-1),INTERNAL_VARIABLE,channels,NULL);
    cerr << "Dts[" << i << "] is (" << Dts[i]->M << "x"<< Dts[i]->N << ")"<<endl;
    //run_estpchirp2m("Hello");
    Dts[i]->data = NULL;
    Dms[i]->data = NULL;
    Dns[i]->data = NULL;
  }
}

void OrbitsInterface::setDER( int index, float value )
{
  DERIVATIVES->data[index] = value;
}

void OrbitsInterface::setder( int index, float value )
{
  Derivatives->data[index] = value;
}

void OrbitsInterface::setDt(int level, Data *dtbuffer) {
  //Dts[level]->data = dtbuffer;
  cerr<<"DEPRECTAED.  NEEDS TO BE WRITTEN TO CAST INPUT FLOAT BUFFER TO DBL"<<
  endl;
}

void OrbitsInterface::setDm(int level, Data *dmbuffer) {
  //Dms[level]->data = dmbuffer;
  cerr<<"DEPRECTAED.  NEEDS TO BE WRITTEN TO CAST INPUT FLOAT BUFFER TO DBL"<<
  endl;
}

void OrbitsInterface::setDn(int level, Data *dnbuffer) {
  //Dns[level]->data = dnbuffer;
  cerr<<"DEPRECTAED.  NEEDS TO BE WRITTEN TO CAST INPUT FLOAT BUFFER TO DBL"<<
  endl;
}

void OrbitsInterface::resetParams() {
  setIdentityParams(prev_pcomposed);
  setIdentityParams(pcomposed);
  setIdentityParams(parameters);
}

// XXX what is diff b/w pseudo est and solve system
//    pseudo_estimate is the recreation of the orbits
//    function, using the CPU to build the hessian and
//    residuals, given downsampled/derivated images.
//    solve_system() uses the GPU instead to do this.
void OrbitsInterface::pseudo_estimate( int level )
{
//    Var * DERIVATIVES;
//    Var * Derivatives;
//    Var * parameters;

    Var *Dt, *Dm, *Dn;
    Data p1, p2, p3, p4, p5, p6, p7, p8;


    Dt = Dts[level];
    Dm = Dms[level];
    Dn = Dns[level];

  for( int i=0; i<8; i++ ) {
    for( int j=0; j<8; j++ ) {
      DERIVATIVES->data[i*8+j]=0.0;
    }
    cerr<<endl;
  }
  for( int i=0; i<8; i++ ) {
      Derivatives->data[i]=0.0;
  }
 

    //TODO this func has many many callocs in it - static alloc them?? 
    build_pseudo_sum_matrix(Dts[level], Dms[level], Dns[level], 
                            DERIVATIVES, Derivatives);

    /*cerr<<"CPU MATRIX GAUSSIAN IN"<<endl;
  for( int i=0; i<8; i++ ) {
    for( int j=0; j<8; j++ ) {
      cerr<<setprecision(5)<<DERIVATIVES->data[i*8+j]<<" ";
    }
    cerr<<endl;
  }
  cerr<<endl;
  for( int i=0; i<8; i++ ) {
      cerr<<setprecision(5)<<Derivatives->data[i]<<" ";
  }
  cerr<<endl;
    */

    div_mat_by_constant(DERIVATIVES, 4.0, DERIVATIVES);
    div_mat_by_constant(Derivatives, 2.0, Derivatives);

    gaussian_elimination(DERIVATIVES, parameters, Derivatives);
    /*
  cerr<<"CPU MATRIX GAUSSIAN OUT"<<endl;
  for( int i=0; i<8; i++ ) {
    for( int j=0; j<8; j++ ) {
      cerr<<setprecision(5)<<DERIVATIVES->data[i*8+j]<<" ";
    }
    cerr<<endl;
    }*/


    /* - - reorder, nornalize, and add the I matrix to the parameters - - */

    parameters->data[0] = parameters->data[0] * (Data)Dt->M;
    parameters->data[1] = parameters->data[1] + (Data)1.0;
    parameters->data[2] = parameters->data[2] * ((Data)Dt->N / (Data)Dt->M);
    parameters->data[3] = parameters->data[3] / (Data)Dt->M;
  
    parameters->data[4] = parameters->data[4] * (Data)Dt->N;
    parameters->data[5] = parameters->data[5] * (Data)Dt->M / (Data)Dt->N;
    parameters->data[6] = parameters->data[6] + (Data)1.0;
    parameters->data[7] = parameters->data[7] / (Data)Dt->N;

  
    p1 = parameters->data[3];
    p2 = parameters->data[1];
    p3 = parameters->data[2];
    p4 = parameters->data[7];
    p5 = parameters->data[5];
    p6 = parameters->data[6];
    p7 = parameters->data[0];
    p8 = parameters->data[4];
  
    parameters->data[0] = p1;
    parameters->data[1] = p2;
    parameters->data[2] = p3;
    parameters->data[3] = p4;
    parameters->data[4] = p5;
    parameters->data[5] = p6;
    parameters->data[6] = p7;
    parameters->data[7] = p8;

    parameters = pseudo2p(parameters);
    setZeroParams(pcomposed);
   if(m_DEBUG) {
	   printVar( parameters ); 
	   printVar( prev_pcomposed );
   }
    pcompose( parameters, prev_pcomposed, pcomposed );
    if(m_DEBUG) printVar( pcomposed );
    copy_data( pcomposed, prev_pcomposed );
    if(m_DEBUG) cout << "++++++++ ITERATION COMPLETED +++++++++++++" << endl <<endl;

    //free(DERIVATIVES->data);  
    //free(Derivatives->data);
}

void OrbitsInterface::solve_system(int level)
{
    Var *Dt, *Dm, *Dn;
    Data p1, p2, p3, p4, p5, p6, p7, p8;
    Var *Der = Derivatives;
   //these vars only used for dimensions (M,N)
    Dt = Dts[level];
    Dm = Dms[level];
    Dn = Dns[level];
    /* - - need to negate Derivatives - - */
    Der->data[0] = -(Der->data[0]);
    Der->data[1] = -(Der->data[1]);
    Der->data[2] = -Der->data[2];
    Der->data[3] = -Der->data[3];
    Der->data[4] = -Der->data[4];
    Der->data[5] = -Der->data[5];
    Der->data[6] = -Der->data[6];
    Der->data[7] = -Der->data[7];

    mirror_DER_matrix(DERIVATIVES);
/*
  cerr<<"GPU MATRIX Gaussian IN"<<endl;
  for( int i=0; i<8; i++ ) {
    for( int j=0; j<8; j++ ) {
      cerr<<setprecision(5)<<DERIVATIVES->data[i*8+j]<<" ";
    }
    cerr<<endl;
  }
    cerr<<endl;
  for( int i=0; i<8; i++ ) {
      cerr<<setprecision(5)<<Derivatives->data[i]<<" ";
  }
  cerr<<endl;
*/




    div_mat_by_constant(DERIVATIVES, 4.0, DERIVATIVES);
    div_mat_by_constant(Derivatives, 2.0, Derivatives);

    gaussian_elimination(DERIVATIVES, parameters, Derivatives);
/*
  cerr<<"GPU MATRIX Gaussian OUT"<<endl;
  for( int i=0; i<8; i++ ) {
    for( int j=0; j<8; j++ ) {
      cerr<<setprecision(5)<<DERIVATIVES->data[i*8+j]<<" ";
    }
    cerr<<endl;
  }
*/

    /* - - reorder, nornalize, and add the I matrix to the parameters - - */

    parameters->data[0] = parameters->data[0] * (Data)Dt->M;
    parameters->data[1] = parameters->data[1] + (Data)1.0;
    parameters->data[2] = parameters->data[2] * ((Data)Dt->N / (Data)Dt->M);
    parameters->data[3] = parameters->data[3] / (Data)Dt->M;
  
    parameters->data[4] = parameters->data[4] * (Data)Dt->N;
    parameters->data[5] = parameters->data[5] * (Data)Dt->M / (Data)Dt->N;
    parameters->data[6] = parameters->data[6] + (Data)1.0;
    parameters->data[7] = parameters->data[7] / (Data)Dt->N;
  
    p1 = parameters->data[3];
    p2 = parameters->data[1];
    p3 = parameters->data[2];
    p4 = parameters->data[7];
    p5 = parameters->data[5];
    p6 = parameters->data[6];
    p7 = parameters->data[0];
    p8 = parameters->data[4];
  
    parameters->data[0] = p1;
    parameters->data[1] = p2;
    parameters->data[2] = p3;
    parameters->data[3] = p4;
    parameters->data[4] = p5;
    parameters->data[5] = p6;
    parameters->data[6] = p7;
    parameters->data[7] = p8;

    parameters = pseudo2p(parameters);
    setZeroParams(pcomposed);
    if(m_DEBUG) {
	    printVar( parameters ); 
	    printVar( prev_pcomposed );
    }
    pcompose( parameters, prev_pcomposed, pcomposed );
   if(m_DEBUG)  printVar( pcomposed );
    copy_data( pcomposed, prev_pcomposed );
   if(m_DEBUG)  cout << "++++++++ ITERATION COMPLETED +++++++++++++" << endl <<endl;

    //free(DERIVATIVES->data);  
    //free(Derivatives->data);
}


float *OrbitsInterface::getParameters(float returnParams[8] )
{
  returnParams[0] = pcomposed->data[0];
  returnParams[1] = pcomposed->data[1];
  returnParams[2] = pcomposed->data[2];
  returnParams[3] = pcomposed->data[3];
  returnParams[4] = pcomposed->data[4];
  returnParams[5] = pcomposed->data[5];
  returnParams[6] = pcomposed->data[6];
  returnParams[7] = pcomposed->data[7];
  return returnParams;
}
double *OrbitsInterface::getParameters(double returnParams[8] )
{
  returnParams[0] = pcomposed->data[0];
  returnParams[1] = pcomposed->data[1];
  returnParams[2] = pcomposed->data[2];
  returnParams[3] = pcomposed->data[3];
  returnParams[4] = pcomposed->data[4];
  returnParams[5] = pcomposed->data[5];
  returnParams[6] = pcomposed->data[6];
  returnParams[7] = pcomposed->data[7];
  return returnParams;
}



void printVar( Var *p ) 
{
  cout << p->name << ": ";
  for( int i=0 ; i<8 ; i++ ) cout << p->data[i] << " ";
  cout << endl;
}

void setIdentityParams( Var *p) 
{
  p->data[0] = 1.0;
  p->data[1] = 0.0;
  p->data[2] = 0.0;
  p->data[3] = 0.0;
  p->data[4] = 1.0;
  p->data[5] = 0.0;
  p->data[6] = 0.0;
  p->data[7] = 0.0;
}

void OrbitsInterface::setParams( Var *p, Data *params )
{
  p->data[0] = params[0];
  p->data[1] = params[1];
  p->data[2] = params[2];
  p->data[3] = params[3];
  p->data[4] = params[4];
  p->data[5] = params[5];
  p->data[6] = params[6];
  p->data[7] = params[7];
}

void OrbitsInterface::setStartParams( double *params )
{
  setParams(prev_pcomposed, params);
}


void setZeroParams( Var *p ) {
  for ( int i=0; i<8 ; i++ ) p->data[i] = 0.0;
}

void mirror_DER_matrix(Var *DER) 
{

   /*  duplicate sums
  FP5-R [14] -> FP6-R [21] (means FP6-R := FP5-R)
  FP6-B [23] -> FP7-G [30]
  FP5-G [15] -> FP7-R [29]
  FP2-B [2] -> FP9-R  [12]
  FP3-B [6] -> FP10-R [37]
  */

// This removes some duplicates - FP7R and FP6R later found to be wrong though
// so dont use these at all
//  assert(DER->data[21] == DER->data[14]);
//  DER->data[21] = DER->data[14];
//  assert(DER->data[30] == DER->data[23]);
//  DER->data[30] = DER->data[23];
//  assert(DER->data[29] == DER->data[15]);
//  DER->data[29] = DER->data[15];
//  assert(DER->data[12] == DER->data[2]);
//  DER->data[12] = DER->data[2];
//  assert(DER->data[37] == DER->data[6]);
//  DER->data[37] = DER->data[6];


  int x,y;
  for (x=0; x<DER->M; x++){
        for(y=x+1;y<DER->N;y++){
              DER->data[x+y*DER->M]=DER->data[x*DER->M+y];
        }
  }

}

void OrbitsInterface::getDER(float *b)
{
  for(int i=0; i<64; i++ ) 
  {
      b[i] = DERIVATIVES->data[i];
  }
}
