/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "Correspond.h"
#include <iostream>
#include <GL/gl.h>
#include <glh/glh_extensions.h>


using namespace std;
 
Correspond::Correspond(int w, int h)
{
  width = w;
  height = h;
  points_array_ptr = selected_points;
  last_pos = &(selected_points[7]);
  has_points = false;

  for( int i= 0 ; i<8 ; i++ ) selected_points[i] = 0;
}

void Correspond::add_point( int w, int h )
{
  *points_array_ptr = w;
  points_array_ptr++;
  *points_array_ptr = h;
  if( points_array_ptr == last_pos ) { 
    points_array_ptr = selected_points;
    has_points = true;
  }
  else points_array_ptr++;

  return ;
}


void Correspond::get_points(int *in)
{
  memcpy(in, selected_points, 8*sizeof(int));
}

bool Correspond::hasPoints() { return has_points; }

void Correspond::clear_points()
{
  for( int i=0 ; i<8 ; i++ ) selected_points[i] = 0;
  points_array_ptr = selected_points;
  has_points = false;
}

int Correspond::get_left_side()
{
  int left_side = width+1;
  for( int i=0 ; i<8 ; i+=2 )
  {
//    cerr << " comparing " << selected_points[i] << " to "<<left_side<<endl;
    if( selected_points[i] < left_side ) left_side = selected_points[i];
  } 
  return left_side;
}

float Correspond::get_left_side_normalized()
{ return (float)((float)get_left_side()/((float)width)); }

int Correspond::get_right_side()
{
  int right_side = -1;
  for( int i=0; i<8 ; i+= 2 ) 
  {
  //  cerr << " comparing " << selected_points[i] << " to "<<right_side<<endl;
    if( selected_points[i] > right_side ) right_side = selected_points[i];
  }
  return right_side;
}

float Correspond::get_right_side_normalized()
{ return (float)((float)get_right_side()/((float)width)); }

int Correspond::get_top_side()
{
  int top_side = -1;
  for( int i=1 ; i<8 ; i+=2 )
  {
//    cerr << " comparing " << selected_points[i] << " to "<<left_side<<endl;
    if( selected_points[i] > top_side ) top_side = selected_points[i];
  } 
  return top_side;
}

float Correspond::get_top_side_normalized()
{ return (float)((float)get_top_side()/((float)height)); }

int Correspond::get_bottom_side()
{
  int bottom_side = height+1;
  for( int i=1 ; i<8 ; i+=2 )
  {
//    cerr << " comparing " << selected_points[i] << " to "<<left_side<<endl;
    if( selected_points[i] < bottom_side ) bottom_side = selected_points[i];
  } 
  return bottom_side;
}

float Correspond::get_bottom_side_normalized()
{ return (float)((float)get_bottom_side()/((float)height)); }

void Correspond::getCropParams(
     int cropW, 
     int cropH, 
     int *x, 
     int *y, 
     int *w,  
     int *h ) 
{
  int left = get_left_side();
  int right = get_right_side();
  int top = get_top_side();
  int bottom = get_bottom_side();
  
  int centerX = (right-left)/2+left;
  int centerY = (top-bottom)/2+bottom;

  int leftCrop = centerX - cropW/2;
  int rightCrop = centerX + cropW/2;
  int topCrop = centerY + cropH/2;
  int bottomCrop = centerY - cropH/2;
 
   //make srue cropping box is specified area
  if( leftCrop < 0 ) {
    leftCrop = 0; 
    rightCrop = cropW;
  }
  else if( rightCrop > width ) {
    rightCrop = width;
    leftCrop = width-cropW;
  }

  //top is larger Y coordinate (lower on raster)
  if( topCrop > height ) {
    topCrop = height;
    bottomCrop = height - cropH;
  }
  else if (bottomCrop < 0 ) {
    topCrop = cropH;
    bottomCrop = 0;
  }
  
  *x = leftCrop;
  *y = height-topCrop;
  
  *w = cropW;
  *h = cropH;
}


void Correspond::drawCropLines(int cropW, int cropH)
{
  float left = get_left_side_normalized();
  float right = get_right_side_normalized();
  float top = get_top_side_normalized();
  float bottom = get_bottom_side_normalized();
  
  float centerX = (right-left)/2.0+left;
  float centerY = (top-bottom)/2.0+bottom;

  float leftCrop = centerX - (float)cropW/(float)width/2.0;
  float rightCrop = centerX + (float)cropW/(float)width/2.0;
  float topCrop = centerY + (float)cropH/(float)height/2.0;
  float bottomCrop = centerY - (float)cropH/(float)height/2.0;

  //make srue cropping box is specified area
  if( leftCrop < 0 ) {
    leftCrop = 0; 
    rightCrop = (float)cropW/(float)width;
  }
  else if( rightCrop > 1.0 ) {
    rightCrop = 1.0;
    leftCrop = 1.0-(float)cropW/(float)width;
  }

  //top is larger Y coordinate (lower on raster)
  if( topCrop > 1.0 ) {
    topCrop = 1.0;
    bottomCrop = 1.0 - (float)cropH/(float)height;
  }
  else if (bottomCrop < 0 ) { 
    topCrop = (float)cropH/(float)height;
    bottomCrop = 0;
  }

  //apply small offset to the cropping lines so taht copypixels doesn't grab
  // the crop lines by mistake 
  float twopixW = 2.0/(float)width;
  float twopixH = 2.0/(float)height;
  leftCrop -= twopixW;
  rightCrop += twopixW;
  bottomCrop -= twopixH;
  topCrop += twopixH;

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glClearColor(0.0,0.0,0.0,1.0);
  glClear(GL_DEPTH_BUFFER_BIT); //essential?
  glColor4f(0.0, 0.8, 0.0,1.0);
  glLineWidth(1.0);
  glBegin(GL_LINES);   
    //approximate center
/*
    glVertex3f( centerX, 0.0, -1.0);
    glVertex3f( centerX, 1.0, -1.0);
    glVertex3f( 0.0, centerY, -1.0);
    glVertex3f( 1.0, centerY, -1.0);
*/

    //cropping lines
    glColor4f(0.8, 0.0, 0.0,1.0);
    glVertex3f( leftCrop, topCrop, -1.0);
    glVertex3f( leftCrop, bottomCrop, -1.0);

    glVertex3f( rightCrop, topCrop, -1.0);
    glVertex3f( rightCrop, bottomCrop, -1.0);


    glVertex3f( leftCrop, topCrop, -1.0);
    glVertex3f( rightCrop, topCrop, -1.0);
    glVertex3f( leftCrop, bottomCrop, -1.0);
    glVertex3f( rightCrop, bottomCrop, -1.0);

  glEnd();
}


void Correspond::drawCropLines()
{
  float left = get_left_side_normalized();
  float right = get_right_side_normalized();
  float top = get_top_side_normalized();
  float bottom = get_bottom_side_normalized();
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glClearColor(0.0,0.0,0.0,1.0);
  glClear(GL_DEPTH_BUFFER_BIT); //essential?
  glColor4f(0.0, 0.8, 0.0,1.0);
  glLineWidth(2.0);
  glBegin(GL_LINES);

    glColor4f(0.0, 0.8, 0.0,1.0);
    glVertex3f( left, 0.0, -1.0);
    glColor4f(0.0, 0.8, 0.0,1.0);
    glVertex3f( left, 1.0, -1.0);

    glColor4f(0.0, 0.8, 0.0,1.0);
    glVertex3f( right, 0.0, -1.0);
    glColor4f(0.0, 0.8, 0.0,1.0);
    glVertex3f( right, 1.0, -1.0);

    glColor4f(0.0, 0.8, 0.0,1.0);
    glVertex3f( 0.0, top, -1.0);
    glColor4f(0.0, 0.8, 0.0,1.0);
    glVertex3f( 1.0, top, -1.0);
    glColor4f(0.0, 0.8, 0.0,1.0);
    glVertex3f( 0.0, bottom, -1.0);
    glColor4f(0.0, 0.8, 0.0,1.0);
    glVertex3f( 1.0, bottom, -1.0);
  glEnd();
}

///draw a masking quad around the area selected, automatically
///determine a rectangular quad bounding area which fits the
///selection exactly
void Correspond::drawQuad()
{
  float left = get_left_side_normalized();
  float right = get_right_side_normalized();
  float top = get_top_side_normalized();
  float bottom = get_bottom_side_normalized();

  drawMaskingQuad(left,right,top,bottom);
}


void Correspond::getQuadCorners(int cropW, int cropH, float* leftCrop, float* rightCrop, float* topCrop, float* bottomCrop) {
  
  float left = get_left_side_normalized();
  float right = get_right_side_normalized();
  float top = get_top_side_normalized();
  float bottom = get_bottom_side_normalized();

  float centerX = (right-left)/2.0+left;
  float centerY = (top-bottom)/2.0+bottom;

  *leftCrop = centerX - (float)cropW/(float)width/2.0;
  *rightCrop = centerX + (float)cropW/(float)width/2.0;
  *topCrop = centerY + (float)cropH/(float)height/2.0;
  *bottomCrop = centerY - (float)cropH/(float)height/2.0;

  //make srue cropping box is specified area
  if( *leftCrop < 0 ) {
    *leftCrop = 0; 
    *rightCrop = (float)cropW/(float)width;
  }
  else if( *rightCrop > 1.0 ) {
    *rightCrop = 1.0;
    *leftCrop = 1.0-(float)cropW/(float)width;
  }

  //top is larger Y coordinate (lower on raster)
  if( *topCrop > 1.0 ) {
    *topCrop = 1.0;
    *bottomCrop = 1.0 - (float)cropH/(float)height;
  }
  else if (*bottomCrop < 0 ) { 
    *topCrop = (float)cropH/(float)height;
    *bottomCrop = 0;
  }
}

///draws a maskingquad but the crop area is given as cropW x cropH roughly
///centered around desired/selected area
void Correspond::drawQuad(int cropW, int cropH)
{
  float leftCrop, rightCrop, topCrop, bottomCrop=0;
  getQuadCorners(cropW,cropH,&leftCrop,&rightCrop,&topCrop,&bottomCrop);
  leftCrop -= 0.01;
  rightCrop += 0.01;
  topCrop += 0.01;
  bottomCrop -= 0.01;
  drawMaskingQuad(leftCrop,rightCrop,topCrop,bottomCrop);
}


void Correspond::drawMaskingQuad(float left, 
                                 float right,  
                                 float top, 
                                 float bottom)
{
  int i;
  float d=-1.0;
  float w=(float)width;
  float h=(float)height;
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glClearColor(0.0,0.0,0.0,1.0);
  glClear(GL_DEPTH_BUFFER_BIT); //essential?

  //clear out ALPHA
/*
  glEnable(GL_BLEND);
   ///uses input color as a elementwise multiplier on destination
  glBlendFunc(GL_ZERO, GL_SRC_COLOR);//0 src + dst, excpt dstalpha=0
  glColor4f(1.0,1.0,1.0,0.0);
  glBegin(GL_QUADS);
    glVertex3f( left, top, d);
    glVertex3f( right, top, d);
    glVertex3f( right, bottom, d);
    glVertex3f( left, bottom, d);
  glEnd();
  //glDisable(GL_BLEND);
  glFinish();

*/

  //glBlendFunc(GL_ONE, GL_ONE); //add alpha on quad //WORKS
  glEnable(GL_BLEND);
  glBlendFunc(GL_ZERO, GL_SRC_COLOR); //filter. elemental muiltply
  glColor4f(0.0,1.0,0.0,0.0);
  glBegin(GL_QUADS);
    for(i=0;i<8; i+=2) {
     glVertex3f(selected_points[i]/w,selected_points[i+1]/h,-1.0);
    }
  glEnd();
  glDisable(GL_BLEND);


  //mask out areas of 0 alpha
  //also works: 
  glBlendFunc(GL_ONE, GL_ZERO);
  //glBlendFunc(GL_DST_ALPHA, GL_ZERO);
  //glBlendFunc(GL_ONE_MINUS_DST_ALPHA, GL_ONE);
  glEnable(GL_BLEND);

  glColor4f(0.0,0.0,1.0,0.0);
  glBegin(GL_QUADS);
    glVertex3f( left, top, d);
    glVertex3f( right, top, d);
    glVertex3f( right, bottom, d);
    glVertex3f( left, bottom, d);
  glEnd();
  glDisable(GL_BLEND);


}

void Correspond::render_cropped_texture(int cropW, int cropH)
{

  int dist=0;
  float texwidth = (float)cropW/(float)width;
  float texheight = (float)cropH/(float)height;
  float xorigin = 1.0;
  float yorigin = 0.0;
  float texdist=-1.0;
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glColor4f(0.0, 1.0, 0.0, 1.0);
  glBegin(GL_QUADS);
    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, cropH, dist);
    glTexCoord3f(0.0, cropH, dist);
    glVertex3f( xorigin, yorigin+texheight, texdist);

    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 0.0, dist);
    glTexCoord3f(0.0, 0.0, dist);
    glVertex3f( xorigin, yorigin, texdist);

    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB,cropW, 0.0, dist);
    glTexCoord3f(cropW, 0.0, dist);
    glVertex3f( xorigin+texwidth, yorigin, texdist);

    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB,cropW,cropH, dist);
    glTexCoord3f(cropW,cropH, dist);
    glVertex3f( xorigin+texwidth, yorigin+texheight, texdist);
  glEnd();


}

static void get_params_from_file(FILE *param_file,int framenum, double *params_out)
{
  static int currentframe=1;
  float tmpparams[8];

  int i,j;

  for(i=currentframe; i<=framenum; i++) {
    for(j=0; j<8; j++ ) {
      fscanf(param_file, "%f", &(tmpparams[j]));
    }
  }
    for(j=0; j<8; j++ ) {
      params_out[j] = (double)tmpparams[j];
      printf("%8g ", (params_out[j]));
    }
    printf("\n");
  currentframe = framenum;
}

static int read_param_file(char *fname, int linenum, double *params){
  FILE *param_file = NULL; 
  //fprintf(stderr,"Opening paramters file %s!\n", fname);
  param_file = fopen(fname, "r");
  if( param_file == NULL )  {
    perror("Error opening parameters file");
    return -1;
  }
  get_params_from_file(param_file,linenum, params);
  if( param_file != NULL) fclose(param_file);
  return 1;
}

void Correspond::shell_Corr2p(double params[8]) 
{
  FILE *corners_file = NULL ;
  char *corners_file_name = "TMP_corners.txt";
  char *output_file_name = "TMP_corners_out.txt";
  char cmdstr[1024] = {'\0'};
  
  corners_file = fopen(corners_file_name, "w");
  if( corners_file == NULL ) { 
    perror("Error opening parameters file");
    return;
  }
  fprintf(corners_file, "%d  %d\n", height,width);
  fprintf(corners_file, "%d  %d   %d  %d  ",  0, 0, selected_points[1], selected_points[0]);
  fprintf(corners_file, "%d  %d   %d  %d  ",  0, width, selected_points[3], selected_points[2]);
  fprintf(corners_file, "%d  %d   %d  %d  ",  height, width, selected_points[5], selected_points[4]);
  fprintf(corners_file, "%d  %d   %d  %d  ",  height, 0, selected_points[7], selected_points[6]);
  fclose(corners_file);

  sprintf(cmdstr, "corr2p %s %s\n", corners_file_name, output_file_name); 
  system(cmdstr);

  read_param_file(output_file_name, 1, params);

  return;
}




