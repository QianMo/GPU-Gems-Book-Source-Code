/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "Downsampler.h"
#include <iostream>
#include <assert.h>
using namespace std;


///Creates a downsampler object.   Requires a 
///CG context/profile.
Downsampler::Downsampler( int w /** texture width */,        
                          int h /** texture height */,
                          int fpw /** floating poitn buffer width */,
                          int fph /** floating point buffer height */,
                          CGcontext fContext /**CG Context*/,
                          CGprofile fProfile /**CG Profile*/)
{
  width = w;
  height = h;
  fpbwidth = fpw;
  fpbheight = fph;

  listIsCompiled = false;

  char name[100] = {'\0'};
  char dirname[100] = {'\0'};

  sprintf(dirname, "FPestpchirp2m");

  sprintf(name, "%s/FP-downsample%dx%d.cg", dirname,width,height);
  FPdownsampler = new FragmentProgram(fContext, fProfile, name, 0);
  
  sprintf(name, "%s/FP-downsample%dx%d-ARB0.cg", dirname,width,height);
  FPdownsamplerARB0 = new FragmentProgram(fContext, fProfile, name, 10);
  sprintf(name, "%s/FP-downsample%dx%d-ARB1.cg", dirname,width,height);
  FPdownsamplerARB1 = new FragmentProgram(fContext, fProfile, name, 10);
}

///Downsample a texture, and copy the result into texture memory.
void Downsampler::downSample(
        /**texture ID of texture to be downsampled */
                             GLuint origTexture,
        /**texture ID of where to place resulting texture */
                             GLuint targTexture )
{
  int dist=0;
  float texwidth = 0.5; //downsampled size is 1/4 image
  float texheight = 0.5;
  float origin = 0.0;
  float texdist=-1.0;

  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, origTexture);

  downSampleARB0(targTexture);
}

///downsamples the 320x240 contents of TEXUNIT0 (ARB0), and places the
///resulting image into a target texture.
void Downsampler::downSampleARB0(GLuint targTexture 
                                 /**texture to store result in*/
                                 )
{
  int dist=0;
  float texwidth = 0.5; //downsampled size is 1/4 image
  float texheight = 0.5;
  float origin = 0.0;
  float texdist=-1.0;

  glClearColor(0.0,0.0,0.0,0.0);
  //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW); //optim fodder
  glLoadIdentity();

  FPdownsamplerARB0->activate();
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, (float)height, dist);
    //glVertex3f( origin, origin+texheight, texdist);
    glVertex3f( origin, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 0.0, dist);
    //glVertex3f( origin, origin, texdist);
    glVertex3f( origin, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,(float)width, 0.0, dist);
    //glVertex3f( origin+texwidth, origin, texdist);
    glVertex3f( origin+texwidth, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,(float)width, (float)height, dist);
    //glVertex3f( origin+texwidth, origin+texheight, texdist);
    glVertex3f( origin+texwidth, origin, texdist);
  glEnd();
  FPdownsamplerARB0->deactivate();   

  copyResult( targTexture );
}
///downsamples the 320x240 contents of TEXUNIT1 (ARB1), and places the
///resulting image into a target texture.
void Downsampler::downSampleARB1(GLuint targTexture
                                 /**texture to store result in*/
                                 )
{
  int dist=0;
  float texwidth = 0.5; //downsampled size is 1/4 image
  float texheight = 0.5;
  float origin = 0.0;
  float texdist=-1.0;

  glClearColor(0.0,0.0,0.0,0.0);
  //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW); //optim fodder
  glLoadIdentity();


  FPdownsamplerARB1->activate();
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,0.0, (float)height, dist);
//    glVertex3f( origin, origin+texheight, texdist);
    glVertex3f( origin, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,0.0, 0.0, dist);
//    glVertex3f( origin, origin, texdist);
    glVertex3f( origin, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,(float)width, 0.0, dist);
//    glVertex3f( origin+texwidth, origin, texdist);
    glVertex3f( origin+texwidth, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,(float)width, (float)height, dist);
//    glVertex3f( origin+texwidth, origin+texheight, texdist);
    glVertex3f( origin+texwidth, origin, texdist);
  glEnd();
  FPdownsamplerARB1->deactivate();   

  copyResult( targTexture );
}


void Downsampler::copyResult(GLuint targTexture)
{
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, targTexture );
  glCopyTexSubImage2D(  GL_TEXTURE_RECTANGLE_NV, 0, 0,0,
                       0,  fpbheight/2,
                       width/2,  height/2);
                       //0, 119,
                       //160, 120);
}
