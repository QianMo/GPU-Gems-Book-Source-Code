/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#ifndef _TEXTURE_SUMMATOR_H
#define _TEXTURE_SUMMATOR_H

#include "FragmentProgram.h"
#include <glh/glh_extensions.h>


/** sums up a 320x240 or 160x120 texture placed in texture unit 0.
    It allows for deferring readback of the result by having a 
    storage texture which collects results.  These results can all then
    be read back to the CPU with a single call. */
class TextureSummator {
    GLuint texName, passtexture, paramtexture;
    GLuint sumListName;
    int width; 
    int height;   
    int fpbwidth, fpbheight;
    int sumsWidth;
    CGcontext context ;
    CGprofile profile ;
    bool listIsCompiled ;

    FragmentProgram *FPpass1, *FPpass2, *FPpassthru;
    void GLsum( GLuint );
    
  public:
    TextureSummator(int w, 
                    int h, 
                    int fpw,
                    int fph,
                    CGcontext fContext, 
                    CGprofile fProfile,
                    GLuint tex);
    void sum(float *, GLuint);
    void compileList(GLuint);
    void sumList( float *, GLuint );
    ///query if the display list for the summation has been compiled.
    bool isListCompiled() { return listIsCompiled; }
    void GLsum_and_store(GLuint texIn, int xoffset );
    void retrieveSums(int xstart, int xnum, float *results);
};
#endif
