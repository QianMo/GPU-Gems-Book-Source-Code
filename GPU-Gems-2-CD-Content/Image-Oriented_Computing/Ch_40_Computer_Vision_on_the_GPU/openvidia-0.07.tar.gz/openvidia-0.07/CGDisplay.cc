/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "CGDisplay.h"
#include "nvidia.h"

#include <Cg/cgGL.h>
#include <glh/glh_extensions.h>
#include <assert.h>

#include <iostream>
using namespace std;

extern CGparameter E1Texture, E2Texture, someColor, E2texCoord,E1texCoord, colorO, xincrementParam, yincrementParam;
extern CGprofile vProfile;
extern CGprogram fragmentProgram, FPds1;
extern CGcontext vContext;

extern CGprogram FPpt;
extern CGparameter FPpttexCoord0, FPpttexture0, FPpttexCoord1, FPpttexture1;

extern CGprogram fragmentProgram2;
extern CGparameter FP2texCoord, FP2texture;

static float readback[320*240*4];
static void printPixel(int x, int y, int W, int H)
{

  glReadPixels(x,y,W,H,GL_RGBA,GL_FLOAT, readback);
//  glReadPixels(x,y,W,H,GL_RGB,GL_UNSIGNED_BYTE, readback);

  cerr<<"readback["<<x<<"]["<<y<<"]= "<<readback[0]<<", "<<readback[1]<<", ";
  cerr<<readback[2]<<", "<<readback[3]<<endl;
}


///readback and show whats in the fpbuffer so we can see what the card
///is thinking. //hardcoded to drawpixels at rterm friendly location
void CGDisplay::peek_fpbuffer(int x, int y, int W, int H)
{
  float rpos[4];
  fpbuffer.activate();
  glReadPixels(x,y,W,H,GL_RGBA,GL_FLOAT, readback);
  fpbuffer.deactivate();
  //glGetFloatv(GL_CURRENT_RASTER_POSITION,rpos);
  //cerr<< "rpos "<< rpos[0] <<" "<<rpos[1]<<" "<<rpos[2]<<" "<<rpos[3]<<endl;
  glRasterPos4f(1.0, 0.5, -1.0, 1);
  glDrawPixels( W, H, GL_RGBA, GL_FLOAT, readback);
  fpbuffer.activate();
}

void CGDisplay::show_buffer( int W, int H, float *b)
{
  //fpbuffer.deactivate();
  glRasterPos4f(1.0, 0.5, -1.0, 1);
  glDrawPixels( W-1, H-1, GL_LUMINANCE, GL_FLOAT, b);
  //fpbuffer.activate();
}



CGDisplay::CGDisplay(int num_textures, int w, int h, int win) 
  : GenericDisplay(win)
{
  imageWinWidth = w;
  imageWinHeight = h;
  //downsample_levels : how many times downsampled (0 is orig, 1 is downsmpl 1x)
  downsample_level = 0; 
  this->num_textures=num_textures;
  // create vector to hold textures
  texNames = new GLuint[num_textures+1];
  //cout << "Constructed CGdisplay" << endl;
  
  //initialize chirpmat, have fun figuring out the mod 5 ;) FOOL
  int i;
  for (i=0; i<16; i++ ) { (i%5==0)?chirpmat[i]=1.0:chirpmat[i]=0.0; } //dense!

  execListIsCompiled = false;
  fullHessian = true;
  makeHessian = true; //flag determining if the pass needs to make the hessian
                       // since its the first pass, or if the hessian was 
                       // already made in previous pass and is to be reused
}

// XXX many headaches were caused by the lack of setCGchirp at the end of this
void CGDisplay::setChirpMatParams( double p[8]) 
  {
    setChirpMat(p[0],p[1],p[2],p[3],
                p[4],p[5],p[6],p[7]);
    setCGchirp();
  }


void CGDisplay::initGL() {
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glShadeModel(GL_FLAT);
  //glEnable(GL_DEPTH_TEST);
  if( ImageHeight == -1 || ImageWidth == -1 ) {
    cerr<<"error, called initGL without having set image size!"<<endl;
    exit(1);
  }
/*
  for( int i=0; i<16; i++ ) {
   if( i%4==0 ) cerr << endl;
   cerr << chirpmat[i] << " " ;
  }
*/
   
  char fpDirName[1024]={'\0'};
  char fpFPName[1024]={'\0'};
  sprintf(fpDirName, "FPestpchirp2m");

  init_cg(texNames, ImageWidth, ImageHeight, chirpmat);

  if( fullHessian ) {
    sprintf(fpFPName, "%s/FP-ds0.cg", fpDirName ); 
  }
  else {
    sprintf(fpFPName, "%s/FP-ds0-nohess.cg", fpDirName ); 
  }
  init_FP(fpFPName, texNames, ImageWidth, ImageHeight, chirpmat);

  //bad overwrites the fullsize variables. only downsampling estimation will 
  //work after the below bit is called
  if( downsample_level == 1 ) {
    if( fullHessian ) {
      sprintf(fpFPName, "%s/FP-ds1.cg", fpDirName );  
    }
    else {
      sprintf(fpFPName, "%s/FP-ds1-nohess.cg", fpDirName );  
    }
    init_FPds1(fpFPName, texNames, ImageWidth/2, ImageHeight/2, chirpmat);
  }
setCGchirp();

  sprintf(fpFPName, "%s/FP-pass-thru.cg", fpDirName ); 
  makeFPpassthru( vContext, vProfile,
                  fpFPName, texNames[0], texNames[1]);

  
  for( int i=0 ; i<11; i++ ) {
    sprintf(fpFPName, "%s/FP-pass-%d.cg", fpDirName, i+2 ); 
    FParray[i] = new FragmentProgram( vContext, vProfile, 
                                    fpFPName, texNames[0]);
  }
/*
  FParray[0] = new FragmentProgram( vContext, vProfile, 
                                    "FP-pass-2.cg", texNames[0]);

  FParray[1] = new FragmentProgram( vContext, vProfile, 
                                    "FP-pass-3.cg", texNames[0]);

  FParray[2] = new FragmentProgram( vContext, vProfile, 
                                    "FP-pass-4.cg", texNames[0]);

  FParray[3] = new FragmentProgram( vContext, vProfile, 
                                    "FP-pass-5.cg", texNames[0]);

  FParray[4] = new FragmentProgram( vContext, vProfile, 
                                    "FP-pass-6.cg", texNames[0]);

  FParray[5] = new FragmentProgram( vContext, vProfile, 
                                    "FP-pass-7.cg", texNames[0]);
  FParray[6] = new FragmentProgram( vContext, vProfile, 
                                    "FP-pass-8.cg", texNames[0]);

  FParray[7] = new FragmentProgram( vContext, vProfile, 
                                    "FP-pass-9.cg", texNames[0]);

  FParray[8] = new FragmentProgram( vContext, vProfile, 
                                    "FP-pass-10.cg", texNames[0]);

  FParray[9] = new FragmentProgram( vContext, vProfile, 
                                    "FP-pass-11.cg", texNames[0]);

  FParray[10] = new FragmentProgram( vContext, vProfile, 
                                    "FP-pass-12.cg", texNames[0]);
*/
  ts = new TextureSummator(320,240, 320,240,vContext, vProfile, texNames[2]);
  
  ts_down1 = new TextureSummator(160,120, 320,240,vContext, vProfile, 
                                 texNames[2]);
  ds = new Downsampler( 320,240, 320,240,vContext,vProfile);
  radialUndistort = new RadialUndistort( 320, 240, vContext, vProfile,
                          "FPsamples/FP-ibot-undistort.cg");


  glh_init_extensions("GL_ARB_multitexture");
  glGenTextures(num_textures, texNames);
  
  //initialize listname integeres
  renderPassLists[0] = glGenLists( 11 );
  for(int i=0; i<11; i++ ) renderPassLists[i] = renderPassLists[0]+i;
  estimationList = glGenLists(1);
  DSList = glGenLists(1);

  cerr<<"Creating Image buffer"<<imageWinWidth<<"x" << imageWinHeight<<"...";
  if (!fpbuffer.create(imageWinWidth, imageWinHeight)) exit(-1);
  cerr << "[ok]" << endl; 

  

}

// should bounds check on id?
void CGDisplay::init_texture(int id, int width, int height, void *data) {
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER,
                  //GL_NEAREST); 
                  GL_LINEAR); 
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER,
                  //GL_NEAREST);
                  GL_LINEAR);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGBA,
	       width, height,
	       0, GL_RGB, GL_UNSIGNED_BYTE, data);
  //bindTextures();
  errcheck();
}


void CGDisplay::init_texture_4u(int id, int width, int height, void *data) {
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER,
                  //GL_NEAREST); 
                  GL_LINEAR); 
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER,
                  //GL_NEAREST);
                  GL_LINEAR);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGBA,
	       width, height,
	       0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
  //bindTextures();
  errcheck();
}

void CGDisplay::init_texture_grey(int id, int width, int height, void *data) {
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER,
                  //GL_NEAREST); 
                  GL_LINEAR); 
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER,
                  //GL_NEAREST);
                  GL_LINEAR);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGBA,
	       width, height,
	       0, GL_RGB, GL_UNSIGNED_BYTE, data);
  //bindTextures();
  errcheck();
}


void CGDisplay::init_texture4f(int id, int width, int height, void *data) {
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[id]);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MAG_FILTER,
                  GL_LINEAR);
  glTexParameteri(GL_TEXTURE_RECTANGLE_NV, GL_TEXTURE_MIN_FILTER,
                  GL_LINEAR);
  glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGBA_NV,
            width, height,
            0, GL_RGBA, GL_FLOAT, NULL);
  errcheck();

}
 
void CGDisplay::bindTextureARB0(int texobj ) 
{
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[texobj]);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
}

void CGDisplay::bindTextureARB1(int texobj ) 
{
  glActiveTextureARB(GL_TEXTURE1_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[texobj]);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
}


void CGDisplay::bindTextureARB2(int texobj ) 
{
  glActiveTextureARB(GL_TEXTURE2_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[texobj]);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
}

//bind textures to texturing units
void CGDisplay::bindTextures() {
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glActiveTextureARB(GL_TEXTURE0_ARB);
 // glEnable(GL_TEXTURE_2D);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[0]);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
  
  glActiveTextureARB(GL_TEXTURE1_ARB);
 // glEnable(GL_TEXTURE_2D);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[1]);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

  glActiveTextureARB(GL_TEXTURE2_ARB);
 // glEnable(GL_TEXTURE_2D);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[2]);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

  errcheck();
}

void CGDisplay::idleFunc() {
  bindTextures();
  render();
}

void CGDisplay::setCGchirp()
{
  ///our stored chirpmat is for -z orbits, but 
  ///the FP uses z=1 so we mult the third row by -1
  ///to set the FP chirpmat, then return to original storage mode
  chirpmat[2] = -chirpmat[2];
  chirpmat[6] = -chirpmat[6];
  chirpmat[10] = -chirpmat[10];
  nv_reset_pchirp(chirpmat);
  chirpmat[2] = -chirpmat[2];
  chirpmat[6] = -chirpmat[6];
  chirpmat[10] = -chirpmat[10];
}

void CGDisplay::render() {

  //  cout << "render loop" << endl;
  //bindTextures(); /// AAAAXXXXX
  glClearColor(0.0,0.0,0.0,0.0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  //glClear(GL_COLOR_BUFFER_BIT);
 

  //cgGLEnableClientState(E1texCoord);
  //cgGLEnableClientState(E2texCoord);
  cgGLEnableProfile(vProfile);

  if( downsample_level == 0 ) cgGLBindProgram(fragmentProgram);
  else if( downsample_level == 1 )  cgGLBindProgram(FPds1);
  else { cerr<<"bad downsampling level.  no derivative taken"<<endl; }



  


  glMatrixMode(GL_MODELVIEW);  
  glLoadIdentity();
  //glTranslatef( 1.0, 0.5,0.0); ///AAA //needed to display at position
 // for screen


  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;
  texwidth = texwidth/powf(2.0, downsample_level);
  texheight = texheight/powf(2.0, downsample_level);

  int renderImgHeight = ImageHeight/(int)powf(2.0, downsample_level);
  int renderImgWidth = ImageWidth/(int)powf(2.0, downsample_level);
  //int renderImgHeight = ImageHeight;
  //int renderImgWidth = ImageWidth;
  //cerr<<"render image height/width "<< renderImgHeight<<" "<<renderImgWidth ;
  //cerr<<endl;



  //apply projection
//  glMatrixMode(GL_PROJECTION);
//  glPushMatrix(); //save projection matrix before manipulation
//  glMultMatrixf( getChirpMat() );
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, renderImgHeight, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,0.0, renderImgHeight, dist); 
    glVertex3f( origin, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 0.0, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,0.0, 0.0, dist); 
    glVertex3f( origin, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,renderImgWidth, 0.0, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,renderImgWidth, 0.0, dist); 
    glVertex3f( origin+texwidth, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,renderImgWidth,renderImgHeight,dist); 
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,renderImgWidth,renderImgHeight,dist); 
    glVertex3f( origin+texwidth, origin+texheight, texdist);
  glEnd();

//OPTIM  cgGLDisableProfile( vProfile );
  //common
  //XXXglFlush();
  //glDisable(GL_TEXTURE_2D);
  errcheck();
  //printPixel(319, 120, 320, 1); 
}

void CGDisplay::render_pass(int render_pass) 
{
//OPTIM  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  FParray[render_pass-2]->activate();
  if( render_pass == 2 ) { glMatrixMode(GL_MODELVIEW);  
    glLoadIdentity();
  }
/*
if( render_pass == 2 ) {
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glEnable(GL_TEXTURE_RECTANGLE_NV);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[2]);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
}
*/
  drawTexture(GL_TEXTURE0_ARB);
  //XXXglFlush();
  errcheck();
  FParray[render_pass-2]->deactivate(); 
}

void CGDisplay::grabDisplay(float *Dm, float *Dn, float *Dt,  float *Da,
                            int downsample_level  )
{
  static float *rgba_buffer = NULL;
  int readX, readY;    //amount to read
  int startX, startY;  //starting corner
  int i=0,j=0;

  //read the framebuffer into memory
  if( rgba_buffer == NULL) {
    rgba_buffer = (float *)malloc(sizeof(float)*imageWinWidth*imageWinHeight*4);
  }



  //readback 0:319 X, 0:239 Y gives 319x239 array of pixels, [0,318]
  startX = 0;
  //startY = (imageWinHeight-(int)(imageWinHeight/(pow(2.0,(double)downsample_level))));
  startY = imageWinHeight-(int)(imageWinHeight);
  //startY = 0;

/*
  readX = (int)(imageWinWidth/(pow(2.0,(double)downsample_level))-1);
  readY = (int)(imageWinHeight/(pow(2.0,(double)downsample_level))-1) + startY;
*/
  readX = (int)(imageWinWidth);
  readY = (int)(imageWinHeight + startY);

  startY=1;
  readY = 239;  
  //readY+=1;

  if( downsample_level == 1 ) {
    startY = 120;
    readY = 120;
    startX = 0;
    readX = 160;
  }


  cout << "reading (" << startX << "," << readX; 
  cout << ") to (" << startY << "," <<readY  <<")" << endl;


 
 //TODO could try partial read pixels, and thread the channel splitting? 
/*
  glReadPixels( startX, startY, readX, readY, 
                GL_RGB, GL_FLOAT, rgba_buffer);
 
  //split out derivatives into 1 channel derivative images 
  //for( i=0 ; i< (imageWinWidth-1) * (imageWinHeight-1) * 4 ;  ) {
  for( i=0 ; i< (imageWinWidth-1) * (imageWinHeight-1) * 3 ;  ) {
    Dm[j]  = rgba_buffer[i++];
    Dn[j]  = rgba_buffer[i++];
    Dt[j]  = rgba_buffer[i++];
    //Dt[j]  = rgba_buffer[i++];
    j++;
  }
*/
//  22 -> 25 fps on 700Mhz+FX5200

//BLUE and GREEN get swapped on readback
  glReadPixels( startX, startY, readX, readY, 
                GL_RED, GL_FLOAT, Dt);
  glReadPixels( startX, startY, readX, readY, 
                GL_GREEN, GL_FLOAT, Dm);
  glReadPixels( startX, startY, readX, readY, 
                GL_BLUE, GL_FLOAT, Dn);
  glReadPixels( startX, startY, readX, readY, 
                GL_ALPHA, GL_FLOAT, Da);

}

//// SUM DISPLAY
//sums the independent channels displayed
void CGDisplay::sumDisplay(float *R, float *G, float *B, float *A)
{
  static float *rgba_buffer = NULL;
  register double sumR=0.0, sumG=0.0, sumB=0.0, sumA=0.0;
  int readX, readY;    //amount to read
  int startX, startY;  //starting corner
  int i=0,j=0;

  //read the framebuffer into memory
  if( rgba_buffer == NULL) {
    rgba_buffer = (float *)malloc(sizeof(float)*imageWinWidth*imageWinHeight*4);
  }
  startX = 0;
  startY = imageWinHeight-imageWinHeight/(int)(powf(2.0,downsample_level))/fraction;
  readX = (int)(imageWinWidth/(pow(2.0,(double)downsample_level))-1+1);
  readY = imageWinHeight-1+1;
  //cout << "summing (" << startX << "," << readX; 
  //cout << ") to (" << startY << "," <<readY  <<")" << endl; 
  glReadPixels( startX, startY, readX, readY, GL_RGBA, GL_FLOAT, rgba_buffer);

  //gets [B,G,R,A]
  //MMX Fodder
  for( i=0 ; i< (readX-startX) * (readY-startY) * 4 ;  ) {
    sumR += rgba_buffer[i++];
    sumG += rgba_buffer[i++];
    sumB += rgba_buffer[i++];
    sumA += rgba_buffer[i++];
  }

  *R = sumR; *G = sumG; *B = sumB; *A = sumA;
  //cout << "R="<<sumR<<" G="<<sumG<<" B="<<sumB<<" A="<<sumA<<endl;
  return;
}

void CGDisplay::sumTexture(int texnum, float *sum)
{
  if( downsample_level == 0 ) ts->sum(sum, texNames[texnum]);
  else if( downsample_level == 1 ) ts_down1->sum(sum, texNames[texnum]);
  else {   
    cerr<<"Invalid downsampling level "<<downsample_level<<" requested."<<endl;
  }
}

void CGDisplay::sumTextureList(int texnum, float *sum)
{
  if( downsample_level == 0 ) ts->sumList(sum, texNames[texnum]);
  else if( downsample_level == 1 ) ts_down1->sumList(sum, texNames[texnum]);
  else {   
    cerr<<"Invalid downsampling level "<<downsample_level<<" requested."<<endl;
  }
}

void CGDisplay::sumTextureList_and_Store(int texnum, int xoffset)
{
  if( downsample_level == 0 ) ts->GLsum_and_store( texNames[texnum], xoffset );
  else if( downsample_level == 1 ) ts_down1->GLsum_and_store( texNames[texnum], 
                                                             xoffset );
  else {   
    cerr<<"Invalid downsampling level "<<downsample_level<<" requested."<<endl;
  }
}

//assums orbits style sums by default
void CGDisplay::getSums(float * results) 
{ 
  getSums(0, 11, results); 
}

void CGDisplay::getSums(int xoffset, int xnum, float * results)
{
  if( downsample_level == 0 ) ts->retrieveSums( xoffset, xnum, results );
  else if( downsample_level == 1 )  ts_down1->retrieveSums( xoffset, 
                                                            xnum, results );
  else {
    cerr<<"Invalid downsampling level "<<downsample_level<<" requested."<<endl;
  }
  errcheck();
}



void CGDisplay::grabDisplay(unsigned char *Dm, unsigned char *Dn, unsigned char *Dt)
{
  static unsigned char *rgba_buffer = NULL;
  int i=0,j=0;

  //read the framebuffer into memory
  if( rgba_buffer == NULL) {
    rgba_buffer = (unsigned char *)malloc( ImageWidth*ImageHeight*4);
  }
  glReadPixels(0,0,ImageWidth,ImageHeight, GL_RGBA,GL_UNSIGNED_BYTE,rgba_buffer);
 
  //split out derivatives into 1 channel derivative images 
  for( i=0 ; i<ImageHeight*ImageHeight*4 ;  ) {
    Dm[j]  = rgba_buffer[i++];
    Dn[j]  = rgba_buffer[i++];
    Dt[j]  = rgba_buffer[i++];
    i++; 
    j++;
  }
}

void CGDisplay::activate_fpbuffer() { fpbuffer.activate(); }
void CGDisplay::deactivate_fpbuffer() { fpbuffer.deactivate(); }

void CGDisplay::showstats(void) {
  int curtime;
  curtime = time(NULL);
  if( lasttime != curtime) {
    fps=fpscounter;
    fpscounter=1;
    lasttime = curtime;
    cerr << "fps = " << fps << "  " << 1.0/((float)fps)*1000 << "msecs\r" ;
  } else fpscounter++;
}

void CGDisplay::render_to_texture(int num) {
  int startX, startY, readX, readY;
  startX = 0;
  startY = (imageWinHeight-(int)(imageWinHeight/(pow(2.0,(double)downsample_level))));

  readX = (int)(imageWinWidth/(pow(2.0,(double)downsample_level)));
  readY = (int)(imageWinHeight/(pow(2.0,(double)downsample_level))) + startY;

  glActiveTextureARB(GL_TEXTURE2_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[num]);
  glCopyTexImage2D( GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGBA_NV, 
                    0,0,320,240,0 );
  //glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0,0,0, 320,240);
  //glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0,startX, startY,
  //                     readX, readY);
  errcheck();
}

void CGDisplay::render_to_texture(
     int num,
     int x,
     int y,
     int width,
     int height)
{
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glBindTexture(GL_TEXTURE_RECTANGLE_NV, texNames[num]);
  glCopyTexSubImage2D( GL_TEXTURE_RECTANGLE_NV, 0, 0, 0,x,y, width,height);
  errcheck();
  //FPSimple->activate();
}


void CGDisplay::drawTexture( GLenum TEXTURE_UNIT ) 
{
  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;

  //read back texture is already resized.
  texwidth = texwidth/powf(2.0, downsample_level);
  texheight = texheight/powf(2.0, downsample_level);

 assert(fraction==1.0);
  glBegin(GL_QUADS);
    glMultiTexCoord3fARB(TEXTURE_UNIT,
                         0.0, 
                         ImageHeight/powf(2.0, downsample_level)/fraction, 
                         dist); 
    glVertex3f( origin, (origin+texheight)/fraction, texdist);

    glMultiTexCoord3fARB(TEXTURE_UNIT,
                         0.0, 
                         0.0/fraction, 
                         dist); 
    glVertex3f( origin, origin/fraction, texdist);

    glMultiTexCoord3fARB(TEXTURE_UNIT,
                         ImageWidth/powf(2.0, downsample_level), 
                         0.0/fraction, 
                         dist); 
    glVertex3f( origin+texwidth, origin/fraction, texdist);

    glMultiTexCoord3fARB(TEXTURE_UNIT,
                         ImageWidth/powf(2.0, downsample_level), 
                         ImageHeight/powf(2.0, downsample_level)/fraction, 
                         dist); 
    glVertex3f( origin+texwidth, (origin+texheight)/fraction, texdist);
  glEnd();
}

void DiagnoseBuffer(float *rgba_buffer) {
  cerr<<"rgbabuffer[0][0]="<<rgba_buffer[0]<<endl;
  cerr<<"rgbabuffer[0][1]="<<rgba_buffer[1]<<endl;
  cerr<<"rgbabuffer[0][2]="<<rgba_buffer[2]<<endl;
  cerr<<"rgbabuffer[0][3]="<<rgba_buffer[3]<<endl;

  cerr<<"rgbabuffer[0][319]="<<rgba_buffer[319*4+0]<<endl;
  cerr<<"rgbabuffer[0][319]="<<rgba_buffer[319*4+1]<<endl;
  cerr<<"rgbabuffer[0][319]="<<rgba_buffer[319*4+2]<<endl;
  cerr<<"rgbabuffer[0][319]="<<rgba_buffer[310*4+3]<<endl;

  cerr<<"rgbabuffer[0][320]="<<rgba_buffer[320*4+0]<<endl;
  cerr<<"rgbabuffer[0][320]="<<rgba_buffer[320*4+1]<<endl;
  cerr<<"rgbabuffer[0][320]="<<rgba_buffer[320*4+2]<<endl;
  cerr<<"rgbabuffer[0][320]="<<rgba_buffer[320*4+3]<<endl;

  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+0]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+1]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+2]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+3]<<endl;

  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+4*319+0]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+4*319+1]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+4*319+2]<<endl;
  cerr<<"rgbabuffer[239][0]="<<rgba_buffer[320*4*239+4*319+3]<<endl;
}

void CGDisplay::render_vid( float trackx, float tracky) {


  float crosssize = 0.15;
  //  cout << "render loop" << endl;
  bindTextures();
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glColor4f( 1.0,1.0,1.0,1.0);
  glLineWidth( 3.0);
  glBegin(GL_LINES);
    glColor4f( 1.0,1.0,1.0,1.0);
    glVertex3f( trackx-crosssize,tracky,-1.0);
    glColor4f( 1.0,1.0,1.0,1.0);
    glVertex3f( trackx+crosssize,tracky,-1.0 );
    glColor4f( 1.0,1.0,1.0,1.0);
    glVertex3f( trackx,tracky-crosssize,-1.0);
    glColor4f( 1.0,1.0,1.0,1.0);
    glVertex3f( trackx,tracky+crosssize,-1.0 );
  glEnd();
  //XXXglFlush();
 
  cgGLEnableClientState(FPpttexCoord0);
  cgGLEnableClientState(FPpttexCoord1);
  cgGLEnableProfile(vProfile);
  cgGLBindProgram(FPpt);
   

  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist=-1.0;
  //texwidth = texwidth/powf(2.0, downsample_level);
  //texheight = texheight/powf(2.0, downsample_level);

  //apply projection
//  glMatrixMode(GL_PROJECTION);
//  glPushMatrix(); //save projection matrix before manipulation
//  glMultMatrixf( getChirpMat() );

  glBegin(GL_QUADS);
    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, ImageHeight, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,0.0, ImageHeight, dist);
    glVertex3f( origin, origin+texheight, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,0.0, 0.0, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,0.0, 0.0, dist);
    glTexCoord3f(0.0, 0.0, dist);
    glVertex3f( origin, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,ImageWidth, 0.0, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,ImageWidth, 0.0, dist);
    glTexCoord3f(ImageWidth, 0.0, dist);
    glVertex3f( origin+texwidth, origin, texdist);

    glMultiTexCoord3fARB(GL_TEXTURE0_ARB,ImageWidth, ImageHeight, dist); 
    glMultiTexCoord3fARB(GL_TEXTURE1_ARB,ImageWidth, ImageHeight, dist);
    glTexCoord3f(ImageWidth, ImageHeight, dist);
    glVertex3f( origin+texwidth, origin+texheight, texdist);
  glEnd();



  //glPopMatrix();

  //common
  //glFlush();
  //glDisable(GL_TEXTURE_2D);
  //FPpassthru->deactivate();
  cgGLDisableProfile(vProfile);
/*
  glColor3f( 1.0,1.0,1.0);
  glLineWidth( 3.0);
  glBegin(GL_LINES);
    glColor4f( 1.0,1.0,1.0,1.0);
    glVertex3f( 0.25,0.5,-1.0);
    glColor4f( 1.0,1.0,1.0,1.0);
    glVertex3f( 0.75,0.5,-1.0 );
  glEnd();
*/
  //OPTIMglFlush();
  errcheck();
}

CGcontext CGDisplay::getContext() { return vContext; }
CGprofile CGDisplay::getProfile() { return vProfile; }

void CGDisplay::execEstimation()
{
  static bool makeHessian = true;
  //activate_fpbuffer(); 
  //render derivative
  //bindTextureARB1(1);
  //bindTextureARB0(0);

  if( downsample_level == 1 ) {
    //cgGLEnableProfile(vProfile);
    //render_DS_ARB0(5);
    //render_DS_ARB1(6);
    bindTextureARB0(5);
    bindTextureARB1(6);
  }

  render(); //ok -need to choose the correct FP.cg though
  //glFlush();

  //save derivative
  //not sure btween 119 and 120 render_to_texture Y coordinates.
  if( downsample_level == 0 ) 
    render_to_texture( 2, 0, 0, 320, 240 ); //only render portion if DS
  else if( downsample_level == 1 )
   //render_to_texture( 2, 0, 119, 160, 120 ); //only render portion if DS
   render_to_texture( 2, 0, 120, 160, 120 ); //only render portion if DS
  else 
    cerr<<"BAD DOWNSAMPLING LEVEL"<<endl;

  bindTextureARB0(2);
  //run each pass to build 8x8 matrix

  int startpass = 2;
  //if not using full hessian, then see if we already have a stored
  //hessian and bypass those passes , just start with residual
  if( !fullHessian ) {
    if( makeHessian == false ) startpass = 11;  
  }

  for( int i =startpass; i <=12 ; i++ ) {
    bindTextureARB0(2);

    render_pass(i); //ok

    if( downsample_level == 0 ) {
      render_to_texture( 3, 0, 0, 320, 240 ); //only render portion if DS
    }
    else if( downsample_level == 1 ) {
      render_to_texture( 3, 0, 120, 160, 120 ); //only render portion if DS
    }
    else {
      cerr<<"BAD DOWNSAMPLING LEVEL"<<endl;
    }
    sumTextureList_and_Store(3, i-2);


  }
  //if not using full hessian, this records fact that hessian is in VRAM
  if( !fullHessian) {
    makeHessian = false;
  }
  //deactivate_fpbuffer(); 
  //now orbits->getSums() will retrieve all calculated sums
}

void CGDisplay::compileEstimationList()
{
 glNewList(estimationList, GL_COMPILE);
   execEstimation();
 glEndList();
 cerr<<"Orbits estimation display list compile complete"<<endl;
}

void CGDisplay::execEstimationList()
{
  if( !execListIsCompiled ) {
    cerr<<"Compiling estimation List"<<endl;
    compileEstimationList();
    execListIsCompiled = true;
  }
  glCallList(estimationList);
}

void CGDisplay::render_DS(int t1, int t2)
{
  ds->downSample(texNames[t1], texNames[t2]);
}
void CGDisplay::render_DS_ARB0(int t)
{ ds->downSampleARB0(texNames[t]); }
void CGDisplay::render_DS_ARB1(int t)
{ ds->downSampleARB1(texNames[t]); }

void CGDisplay::Undistort(int t1, int t2) {
  radialUndistort->undistort(texNames[t1]);
  render_to_texture(t2, 0,0, 320,240); //render_to_tex translates t2 internally
}
