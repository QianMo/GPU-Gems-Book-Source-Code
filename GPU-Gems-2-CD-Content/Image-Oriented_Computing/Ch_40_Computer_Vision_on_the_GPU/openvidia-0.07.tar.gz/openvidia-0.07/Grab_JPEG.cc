/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "Grab_JPEG.h"
#include <iostream>
#include <assert.h>

using namespace std;

void Grab_JPEG::init_JPEG_TO_DISK( int method, int quality )
{
  jcinfo.err = jpeg_std_error( &jerr );
  jpeg_create_compress( &jcinfo );

  /* these are just default vals which are changed in grab_frame/field */
  jcinfo.input_components         = 3;
  jcinfo.in_color_space           = JCS_RGB;
  jpeg_set_defaults( &jcinfo );

//  jcinfo.dct_method = JDCT_ISLOW;
  jcinfo.dct_method = JDCT_IFAST;  // fast but poor quality for file size

  // this is to set the jpeg quality (comment out for default):
  jpeg_set_quality(&jcinfo, quality, 1 );

  /* allocate memory */
  jpegbuf.start_addr              = (JOCTET *)malloc(1024*1024*4);
  /* END JPEG                     */
}

Grab_JPEG::Grab_JPEG()
{
  init_JPEG_TO_DISK( JDCT_ISLOW, 95);
  init_vindex();
 // vindex = 0;
}


void Grab_JPEG::grab_frameGL(int width, int height) {
  //assume RGB
  static unsigned char* buf=(unsigned char*)malloc(width*height*3);
  glReadPixels(0,0,width, height, GL_RGB, GL_UNSIGNED_BYTE,(GLvoid *)buf);
  grab_frame(buf,width,height,0);
  //free(buf);
}
void Grab_JPEG::grab_frameGL(int width, int height,bool invert) {
  //assume RGB
  static unsigned char* buf=(unsigned char*)malloc(width*height*3);
  glReadPixels(0,0,width, height, GL_RGB, GL_UNSIGNED_BYTE,(GLvoid *)buf);
  grab_frame(buf,width,height,invert);
  //free(buf);
}

int Grab_JPEG::grab_frame(unsigned char *vid_buf, 
                      int width, 
                      int height, 
                      int format,
                      char *fname,
                      bool invert)
{

  FILE *outfile = NULL;
  char cmdstr[80];
  char pork[25];
  struct timeval curtime;
  int i,bpp;
  JSAMPROW row_ptr[1024];
  unsigned char *compress_buf;

  /* Mark time current jpeg was taken - used for aud+vid sync */
  gettimeofday(&curtime, NULL);

  outfile = fopen(fname, "w");
  assert(outfile != NULL );
  //sprintf(msgstr,"v%07d.jpg\n",vindex-1);
  //totchars = strlen(msgstr);
  //redisplaytext = 1 ;
  //printf("Writing %s ", msgstr);
  fflush(stdout);
  bpp=3;
/*
    switch( format ) {
    case FORMAT_RGB24 :
      if( FLIPRGB )flip_rgb(vid_buf, width, height);
      jcinfo.in_color_space = JCS_RGB;
      compress_buf = vid_buf;
      bpp = 3;
      break;
    case FORMAT_YUV :
      jcinfo.in_color_space = JCS_YCbCr;
      compress_buf = vid_buf;
      bpp = 3;
      break;
    case FORMAT_YUYV :
      if( YUVbuf == NULL ) YUVbuf=(unsigned char *)malloc(width*height*3);
      YUYVtoYUV(vid_buf, YUVbuf, width, height);
      jcinfo.in_color_space = JCS_YCbCr;
      compress_buf = YUVbuf;
      bpp = 3;
      break;
    case FORMAT_RGB32 :
      if( RGBbuf == NULL ) RGBbuf=(unsigned char *)malloc(width*height*3);
      RGB32toRGB24_fliprgb(vid_buf, RGBbuf, width, height);
      compress_buf = RGBbuf;
      bpp = 3;
      break;
    default :
      fprintf(stderr, "grab_frame passed incorrect buffer type\n");
      return -1;
  }
*/
  compress_buf = vid_buf;
  
  jpeg_stdio_dest((j_compress_ptr)(&jcinfo), (FILE *)outfile);
  
  /* set image info */ 
  jcinfo.image_width = width;
  jcinfo.image_height = height;
  
  /* Rukkus time */
  sprintf(cmdstr,"time: %lu %lu           ", curtime.tv_sec, curtime.tv_usec);
  
  jpeg_start_compress( &jcinfo,  (bool)true);
  
  /* WRITE THE TIMESTAMP IN THE COMMENT FIELD */
  jpeg_write_marker(&jcinfo, JPEG_COM, (const JOCTET *)cmdstr, strlen(cmdstr));
  
  /* setup a pointer to each scanline */
  if( !invert ) {
    i = 0; 
    while( i < height ) {
      row_ptr[i] = &vid_buf[i * width * bpp];
      i++;
    }
  } else { //invert
    i = height-1; 
    while( i >= 0 ) {
      row_ptr[height-1-i] = &vid_buf[i * width * bpp];
      i--;
    }
  }
  
  /* write the scanlines to the shared memory */
  if( jpeg_write_scanlines( &jcinfo, row_ptr, height ) != (unsigned int)height )
    fprintf(stderr, "jpeg_write_scanlines did not write full image");

  jpeg_finish_compress( &jcinfo );
  fclose(outfile);
  return vindex;
}


///Grabs a frame.  assumes no u/d flip. Wraps grab_frame call.
int Grab_JPEG::grab_frame(unsigned char *vid_buf, 
                      int width, 
                      int height, 
                      int format )
{
  grab_frame( vid_buf, 
              width, 
              height, 
              format,
              false ); //assume no u/d flip
}

int Grab_JPEG::grab_frame(unsigned char *vid_buf, 
                      int width, 
                      int height, 
                      int format,
                      bool invert)
{

  FILE *outfile = NULL;
  char cmdstr[80];
  char pork[25];
  struct timeval curtime;
  int i,bpp;
  JSAMPROW row_ptr[1024];
  unsigned char *compress_buf;

  /* Mark time current jpeg was taken - used for aud+vid sync */
  gettimeofday(&curtime, NULL);

  outfile = get_next_file(0);
  //sprintf(msgstr,"v%07d.jpg\n",vindex-1);
  //totchars = strlen(msgstr);
  //redisplaytext = 1 ;
  //printf("Writing %s ", msgstr);
  fflush(stdout);
  bpp=3;
/*
    switch( format ) {
    case FORMAT_RGB24 :
      if( FLIPRGB )flip_rgb(vid_buf, width, height);
      jcinfo.in_color_space = JCS_RGB;
      compress_buf = vid_buf;
      bpp = 3;
      break;
    case FORMAT_YUV :
      jcinfo.in_color_space = JCS_YCbCr;
      compress_buf = vid_buf;
      bpp = 3;
      break;
    case FORMAT_YUYV :
      if( YUVbuf == NULL ) YUVbuf=(unsigned char *)malloc(width*height*3);
      YUYVtoYUV(vid_buf, YUVbuf, width, height);
      jcinfo.in_color_space = JCS_YCbCr;
      compress_buf = YUVbuf;
      bpp = 3;
      break;
    case FORMAT_RGB32 :
      if( RGBbuf == NULL ) RGBbuf=(unsigned char *)malloc(width*height*3);
      RGB32toRGB24_fliprgb(vid_buf, RGBbuf, width, height);
      compress_buf = RGBbuf;
      bpp = 3;
      break;
    default :
      fprintf(stderr, "grab_frame passed incorrect buffer type\n");
      return -1;
  }
*/
  compress_buf = vid_buf;
  
  jpeg_stdio_dest((j_compress_ptr)(&jcinfo), (FILE *)outfile);
  
  /* set image info */ 
  jcinfo.image_width = width;
  jcinfo.image_height = height;
  
  /* Rukkus time */
  sprintf(cmdstr,"time: %lu %lu           ", curtime.tv_sec, curtime.tv_usec);
  
  jpeg_start_compress( &jcinfo,  (bool)true);
  
  /* WRITE THE TIMESTAMP IN THE COMMENT FIELD */
  jpeg_write_marker(&jcinfo, JPEG_COM, (const JOCTET *)cmdstr, strlen(cmdstr));
  
  /* setup a pointer to each scanline */
/*
  i = 0; 
  while( i < height ) {
    row_ptr[i] = &vid_buf[i * width * bpp];
//    row_ptr[i] = &compress_buf[i * width * bpp];
    i++;
  }
*/
   /* setup a pointer to each scanline */
  if( !invert ) {
    i = 0; 
    while( i < height ) {
      row_ptr[i] = &vid_buf[i * width * bpp];
      i++;
    }
  } else { //invert
    i = height-1; 
    while( i >= 0 ) {
      row_ptr[height-1-i] = &vid_buf[i * width * bpp];
      i--;
    }
  }
  
  /* write the scanlines to the shared memory */
  if( jpeg_write_scanlines( &jcinfo, row_ptr, height ) != (unsigned int)height )
    fprintf(stderr, "jpeg_write_scanlines did not write full image");

  jpeg_finish_compress( &jcinfo );
  fclose(outfile);
  return vindex;
}


/* returns a file pointer to next available file
 * to write to */
FILE *Grab_JPEG::get_next_file(int fieldflag)
{
  int fd;
  FILE *outfile = NULL;
  char tempstr[14];

  /* find the next file to write to */
//  do {
    if( outfile != NULL ) fclose(outfile);
    if( fieldflag )
      sprintf(tempstr, "f%07d.jpg", vindex++);
    else
      sprintf(tempstr, "v%07d.jpg", vindex++);
//    outfile = fopen(tempstr, "r");
//  } while( outfile  != (FILE *) NULL ) ;

  /* try and create it */
/*
  if( (outfile = fopen(tempstr, "wb")) == (FILE *) NULL ) {
    fcntl( outfile, F_SETFL, O_NONBLOCK );
    fprintf(stderr, "Could not open file %s\n", tempstr );
    return  NULL;
  }
*/
//fd = open( tempstr, O_WRONLY | O_CREAT | O_NONBLOCK, S_IRWXU);
//fd = open( tempstr, O_WRONLY | O_CREAT | O_SYNC, S_IROTH); /* S_IRWXU); */

#ifdef USE_WINTV
  fd = open( tempstr, O_WRONLY | O_CREAT | O_NONBLOCK, S_IROTH | S_IRGRP| S_IRUSR | S_IWUSR);
#else
  //fd = open( tempstr, O_WRONLY | O_CREAT | O_SYNC, S_IROTH | S_IRGRP| S_IRUSR | S_IWUSR);
  fd = open( tempstr, O_WRONLY | O_CREAT | O_NONBLOCK, S_IROTH | S_IRGRP| S_IRUSR | S_IWUSR);
#endif
  if( fd == -1) perror("open");
  outfile = fdopen( fd, "w");
  if( outfile == NULL ) perror("fdopen");
  return outfile;
}

long Grab_JPEG::find_highest_vindex(char *dir, char *match){
  DIR            *d;
  struct dirent  *e;
  int             n = 0, len = strlen(match);
  //int is_integer;
  char *endpointer;
  long vindex;
  long vindex_max=-1;

  if (NULL == (d = opendir(dir))) {
    return 0;
  }
  while (NULL != (e = readdir(d))) {
    if (0 != strncmp(e->d_name, match, len))
    continue;
//    fprintf(stderr,"file that begins with v:  %s\n",e->d_name);
    n=strlen(e->d_name);
    if (0 == (n % 12)) {    // v???????.jpg is 12 characters long
      if (isdigit(e->d_name[1])){
        if (0 == strcmp(&(e->d_name[8]),".jpg")){
//          fprintf(stderr,"files that are v???????.jpg  %s\n",e->d_name);
          vindex=strtol(&(e->d_name[1]),&endpointer,10);
          if (endpointer == &(e->d_name[8])) {
//fprintf(stderr,"%s is considered to be file number %lud\n",e->d_name,vindex);
//          fprintf(stderr,"%s considered to be number %ld\n",e->d_name,vindex);
            if (vindex_max < vindex) vindex_max = vindex;
          }
        }
      }
    }
  }

  closedir(d);
  return vindex_max;
}

long Grab_JPEG::init_vindex(){
  vindex = (int) find_highest_vindex("./", "v") + 1;
  fprintf(stderr,"next frame to be captured will be %d\n",vindex);
  return vindex;
}
