/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

/* blablabla everything shall be GNU ... blablabla 
   (closest thing to a license we found)
 */

#include "GLTerm.h"

#include "nvidia.h" //for errcheck

#include "glf.h"
#include <glh/glh_extensions.h>
#include <iostream>
using namespace std;

//HACK FOR METHODS NOT IN CLASS
GLTerm *globalInstance;

//main.c

//glfunctions.c
float colorred[8]  ={0,1,0,1,0,1,0,1};
float colorgreen[8]={0,0,1,1,0,0,1,1};
float colorblue[8] ={0,0,0,0,1,1,1,1};
#ifdef wired
//NOTE: 3D is cool but it skews ... 
//#define draw_symbol(a) glfDraw3DWiredSymbol(a);
#define draw_symbol(a) glfDrawWiredSymbol(a);
#else
#define draw_symbol(a) glEnable(GL_TEXTURE_2D); glfDrawSolidSymbol(a);
#endif

#define getlastchar() line[lastline].chars[lastchar].character
#define islastchar(a,b) (lastline==a && lastchar==b)
#define getlastcharx() lastchar*(LETTERWIDTH+LETTERSPACEX)
#define getlastchary() lastline*(LETTERHEIGHT+LETTERSPACEY)

#define _curchar line[cline].chars[cchar]

#define char2redf(cline,cchar) colorred[_curchar.fgcolor]
#define char2greenf(cline,cchar) colorgreen[_curchar.fgcolor]
#define char2bluef(cline,cchar) colorblue[_curchar.fgcolor]

#define char2redb(cline,cchar) colorred[_curchar.bgcolor]
#define char2greenb(cline,cchar) colorgreen[_curchar.bgcolor]
#define char2blueb(cline,cchar) colorblue[_curchar.bgcolor]

//terminal.c
int term_addchar(char toprint);
int term_addstring(char *toprint);
void *terminal_main(void *_tosend);
int init_terminal();
int term_unload();
int DEBUG=0;

//console.c
void* thread_console(void *blubb);

GLTerm::GLTerm(int w, int h, int win) 
  : GenericDisplay(win)
{
  glterm_left=0.33;
  glterm_right=0.66;
  glterm_top=0.66;
  glterm_bottom=0.33;

  globalInstance=this;
  // original variables from glterm
  curfgcolor=DEFAULT_FGCOLOR;
  curbgcolor=DEFAULT_BGCOLOR;

  isansi=0;
  lastline=0;
  lastchar=0;
  isansi2=0;
  bottom=MAX_LINES-1;
  top=0;

  imageWinWidth = w;
  imageWinHeight = h;
  
   init_line();
   
  while(!init_terminal()) printf("failed opening pty => retry\n");
  //pthread_create(console_thread, NULL, (thread_console), NULL);
}

GLTerm::~GLTerm() {
  cout << "destroyed GLTerm"<<endl;
  // term_unload();
}


void GLTerm::initGL() {
  // init GLF
  glfInit();
  glfLoadFont(FONT);

  if( ImageHeight == -1 || ImageWidth == -1 ) {
    cerr<<"error, called initGL without having set image size!"<<endl;
    exit(1);
  }
#ifdef wired
  //do nothing
#else
  LoadTexture(TEXTURE);
  glfEnable(GLF_TEXTURING);
#endif

}

void GLTerm::init_texture(int id, int width, int height, void *data) {
  cout << "GLTerm -> init_texture" <<endl;
}


//bind textures to texturing units
void GLTerm::bindTextures() {
  cout << "GLTerm ->bindTextures"<<endl;
}

void GLTerm::idleFunc() {
  render();
}

void GLTerm::render() {
  //glMatrixMode(GL_MODELVIEW);  
  //glLoadIdentity();
  //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glClear(GL_DEPTH_BUFFER_BIT);

  errcheck();
  glMatrixMode(GL_PROJECTION);  
  glPushMatrix();
  //glRotatef( 45.0, 0.0, 0.0, 1.0);
/*
  float pmatrix[16]={0};
  glGetFloatv( GL_PROJECTION_MATRIX, pmatrix);
  printf("PROJECTION\n");
  printf("%5f %5f %5f %5f\n", pmatrix[0], pmatrix[4], pmatrix[8], pmatrix[12]);
  printf("%5f %5f %5f %5f\n", pmatrix[1], pmatrix[5], pmatrix[9], pmatrix[13]);
  printf("%5f %5f %5f %5f\n", pmatrix[2], pmatrix[6], pmatrix[10], pmatrix[14]); 
  printf("%5f %5f %5f %5f\n", pmatrix[3], pmatrix[7], pmatrix[11], pmatrix[15]);
*/
  
 //kludge: scaleing first seems to make it look right
/*
  float *c = getChirpMat() ;
  float tmp0 = c[0];
  float tmp5 = c[5]; 
  glScalef(tmp0,tmp5,1.0);
  c[0]=1.0; c[5] = 1.0; //undo scaling so not applied twice
 
  glMultMatrixf( c );
  c[0] = tmp0; c[5]=tmp5; //reinstate scaling so its back to normal
*/
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glMultMatrixf( getChirpMat() );
/*
  glGetFloatv( GL_MODELVIEW_MATRIX, pmatrix);
  printf("MODELVIEW\n");
  printf("%5f %5f %5f %5f\n", pmatrix[0], pmatrix[4], pmatrix[8], pmatrix[12]);
  printf("%5f %5f %5f %5f\n", pmatrix[1], pmatrix[5], pmatrix[9], pmatrix[13]);
  printf("%5f %5f %5f %5f\n", pmatrix[2], pmatrix[6], pmatrix[10], pmatrix[14]); 
  printf("%5f %5f %5f %5f\n", pmatrix[3], pmatrix[7], pmatrix[11], pmatrix[15]);
*/
  //glScalef(0.35, 0.35, 1.0);///makes text fit
/*(
  //debug
glShadeModel(GL_SMOOTH);
  glBegin(GL_QUADS);  
    glColor4f( 1.0 ,0.0,0.0,1.0);
    glVertex3f(0.0, 0.0, 1.0);
    glColor4f( 0.0 ,1.0,0.0,1.0);
    glVertex3f(1.0, 0.0, 1.0);
    glColor4f( 0.0 ,0.0,1.0,1.0);
    glVertex3f(1.0, 1.0, 1.0);
    glColor4f( 1.0 ,1.0,1.0,1.0);
    glVertex3f(0.0, 1.0, 1.0);
  glEnd();
*/
/*
    glColor4f( 1.0 ,0.0,0.0,1.0);
  glBegin(GL_LINES);  
    glVertex3f(0.0, 0.0, 1.0);
    glVertex3f(1.0, 0.0, 1.0);

    glVertex3f(1.0, 0.0, 1.0);
    glVertex3f(1.0, 1.0, 1.0);

    glVertex3f(1.0, 1.0, 1.0);
    glVertex3f(0.0, 1.0, 1.0);

    glVertex3f(0.0, 1.0, 1.0);
    glVertex3f(0.0, 0.0, 1.0);

    glColor4f( 0.0 ,1.0,0.0,1.0);
    glVertex3f(0.0, 0.0, 1.5);
    glVertex3f(1.0, 0.0, 1.5);

    glVertex3f(1.0, 0.0, 1.5);
    glVertex3f(1.0, 1.0, 1.5);

    glVertex3f(1.0, 1.0, 1.5);
    glVertex3f(0.0, 1.0, 1.5);

    glVertex3f(0.0, 1.0, 1.5);
    glVertex3f(0.0, 0.0, 1.5);

    glColor4f( 0.0 ,0.0,1.0,1.0);
    glVertex3f(0.0, 0.0, 0.5);
    glVertex3f(1.0, 0.0, 0.5);

    glVertex3f(1.0, 0.0, 0.5);
    glVertex3f(1.0, 1.0, 0.5);

    glVertex3f(1.0, 1.0, 0.5);
    glVertex3f(0.0, 1.0, 0.5);

    glVertex3f(0.0, 1.0, 0.5);
    glVertex3f(0.0, 0.0, 0.5);

   glColor4f( 1.0 ,1.0,1.0,1.0);
    glVertex3f(0.0, 0.0, 0.5);
    glVertex3f(0.0, 0.0, 1.5);

    glVertex3f(1.0, 0.0, 0.5);
    glVertex3f(1.0, 0.0, 1.5);

    glVertex3f(1.0, 1.0, 0.5);
    glVertex3f(1.0, 1.0, 1.5);

    glVertex3f(0.0, 1.0, 0.5);
    glVertex3f(0.0, 1.0, 1.5);



  glEnd();
*/



  if(gotnewdata) {
    regenerate_gllist();
    errcheck();
    //always regen coz texture overlays itgotnewdata=0;
  }

  //  glCallList(1);   // paint the world
  //glPushMatrix();
  //  rotate_letter();
  //  glCallList(2);   // paint the last character
  //glPopMatrix();
  //... from paint it

  glMatrixMode(GL_PROJECTION);
  glPopMatrix();

  glMatrixMode(GL_MODELVIEW);

}

int GLTerm::regenerate_gllist()
{
  static int c=0;
  double w=0.5;

  int cline;
  int cchar;
  float cury=0;
  float curx=0;
  char clastchar;
    
  //rosco
  float rot=-50.0;
  float x_vec=0.0;
  float y_vec=1.0;
  float z_vec=0.0;
  float x_trans=3.0;
  float y_trans=0.0;
  float z_trans=0.0;

    int char_counter=0;

    clastchar=getlastchar();
    
    //ROSCO
    glPushMatrix();
    static float x=0;
    //    x+=0.01;
    //cout<<x<<endl;
    //glRotatef(x,1.0,0.0,0.0);
    //    glTranslatef(-x/100,-x/100,-4);
    //glTranslatef(-x,0,0);
    //    glRotatef(rot,x_vec,y_vec,z_vec);
    //    glTranslatef(x_trans,y_trans,z_trans);
    
    // make a new list for all chars except the rotating one
    //XXX ROSCO SET_VIEWPOINT dist -3
    // Y VALUES ARE REVERSED FOR SOME REASON (-)
    // Plus 3 coz rotated around x-axis, so z->-z
    //int dist=-2;  //-1;
    int dist=1;  //-1;

    for(cline=0;cline<MAX_LINES;cline++){
      for(cchar=0;cchar<MAX_CHARACTERS;cchar++){
	glPushMatrix();
	/*	if(!islastchar(cline,cchar)) {
	    glColor3f(char2redb(cline,cchar), char2greenb(cline,cchar), char2blueb(cline,cchar));
	}else {
	  glColor3f(0, 0, 0);
	  }*/

	glScalef(0.35,0.35,1); // CURX goes 0->3
     glTranslatef(LETTERWIDTH,LETTERHEIGHT,0);//about 1 line off
	glTranslatef(curx,cury,dist);//cury-2 rosco rosco
	  //glTranslatef(curx, -cury, dist-1);//HACK ROSO ADDED -4 coz draw goes +1
	  // draw black box @ char. // ROSCO TODO XXX alpha blend blac
	/*	glColor4f(0,0,0,0.6);
	glBegin(GL_QUADS);
	glVertex3f(-.015           ,-LETTERHEIGHT,dist);   // lower left
	glVertex3f(0.15+LETTERWIDTH/2,-LETTERHEIGHT,dist);   // lower right
	glVertex3f(0.15+LETTERWIDTH/2,LETTERHEIGHT,dist);   // upper right
	glVertex3f(-.015           ,LETTERHEIGHT,dist);   // upper left
	glEnd();*/

	  if(line[cline].chars[cchar].character && line[cline].chars[cchar].character != ' '){
#ifdef wired
	    //	    glColor3f(char2redf(cline,cchar), char2greenf(cline,cchar), char2bluef(cline,cchar));
	    //glColor4f(1.0,0,0,0.6);
	    glColor4f(1.0,0.0,0.0,1.0);
#else
	    glEnable(GL_TEXTURE_2D);
#endif
	    glScalef(LETTERWIDTH,LETTERHEIGHT,1);
	    // get right way up
	    //	    glRotatef(180.0,1.0,0.0,0.0);
	    // correct left - right
	    //glRotatef(180.0,0.0,1.0,0.0);

	    char_counter++;
	    //glColor4f(255.0,255.0,255.0,1.0);
	    draw_symbol(line[cline].chars[cchar].character);
	    
#ifdef wired
	    //do nothing
#else
	    glDisable(GL_TEXTURE_2D);
#endif

	    /*	    w=1;
	    glColor3f(0.5,0.5,0.5);
	    glBegin(GL_QUADS);
	      glVertex3f( 1+0, 1+w, -3); //ad dist 3
	      glVertex3f( 1+0, 1+0, -3);
	      glVertex3f( 1+w, 1+0, -3);
	      glVertex3f( 1+w, 1+w, -3);
	      glEnd();*/

	    errcheck();
	  }
	glPopMatrix();
	curx+=LETTERWIDTH + LETTERSPACEX;
      }
      cury+=LETTERHEIGHT + LETTERSPACEY;
      curx=0;
    }

    c++;
    if(c>60) {
      c=0;
      if(DEBUG)      cout<<"drawn "<<char_counter<<" chars."<<endl;
    }
          
    curx=getlastcharx()+LETTERWIDTH+LETTERSPACEX;
    cury=-getlastchary()-LETTERHEIGHT;
    //last letter?
    /*    glPushMatrix();
      glRotatef(rot,x_vec,y_vec,z_vec);
      glTranslatef(x_trans,y_trans,z_trans); 
      glColor3f(1, 1, 1);
      glBegin(GL_QUADS);
	glVertex3f(curx-.02                 ,cury+0.01,1.8); // bottom left
	glVertex3f(curx-.02                 ,cury     ,1.8); // top    left
	glVertex3f(curx-.02+LETTERWIDTH+0.01,cury     ,1.8); // top    right
	glVertex3f(curx-.02+LETTERWIDTH+0.01,cury+0.01,1.8); // bottom right
      glEnd();
      glPopMatrix();*/
      
    //ROSCO
    glPopMatrix();
    //glFlush();
    errcheck();
}

void GLTerm::handle_key(unsigned char key) {
  char mykey=0;
  if(DEBUG) printf("key pressed: %d\n", key);
  if((char)key == 13) mykey=10;
  else mykey=key;
  if(mykey)
    term_addchar((char)mykey);
}

void GLTerm::grabDisplay(float *Dm, float *Dn, float *Dt,  float *Da,
                            int downsample_level  )
{
  cout << "GLTerm -> grabDisplay"<<endl;
}

void GLTerm::sumDisplay(float *R, float *G, float *B, float *A)
{
  cout << "GLTerm -> sumDisplay"<<endl;
}

void GLTerm::grabDisplay(unsigned char *Dm, unsigned char *Dn, unsigned char *Dt)
{
  cout << "GLTerm -> grabDisplay"<<endl;
}

void GLTerm::showstats(void) {
  cout << "GLTerm -> showstats"<<endl;
}

void GLTerm::init_line(void) {
  int i;
  for(i=0;i<MAX_LINES;i++){
    line[i].nextchar=0;
    clear_line(i);
  }
}

void GLTerm::clear_line(int lineid) {
  int i;
  for(i=0;i<MAX_CHARACTERS;i++) clear_char(lineid, i);
  line[lineid].nextchar=0;
}

void GLTerm::clear_char(int lineid, int charid)
{
    line[lineid].chars[charid].character=0;
    line[lineid].chars[charid].fgcolor=DEFAULT_FGCOLOR;
    line[lineid].chars[charid].bgcolor=DEFAULT_BGCOLOR;
}

int GLTerm::AddChar(char *_toadd)
{
    char *toadd;
    char curchar;

    gotnewdata=1;
    for(toadd=_toadd;toadd[0];toadd++) {
	curchar=toadd[0];
	if(DEBUG) printf("received: %.3d (", curchar);
	if(isansi) parseansi(curchar); else
	if(curchar>=127){
		// ?
	} else if (curchar<32) {
	    switch(curchar) {
		case 7:
		    if(DEBUG) printf("<BEEP>");
		    break;
		case 8:
		    if(DEBUG) printf("<BS>");
		    backspace();
		    break;
		case 27:
		    // ANSI
		    if(DEBUG) printf("<ESC>");
		    isansi=1;
		    break;
		case 10:
		    if(DEBUG) printf("<CR>");
		    line_is_full();
		    break;
		case 13:
		    if(DEBUG) printf("<LF>");
		    lastchar=-1;
		    line[lastline].nextchar=0;
		    break;
		default:
		    break;
	    }
	} else {
	    if(DEBUG) printf("%c", curchar);
	    add_char_append(curchar);
	}
	if(DEBUG) printf(")\n");
    }
    
}

t_line* GLTerm::line_is_full()
{
    t_line *pcurline=(t_line*)&line+lastline;
    lastline++;
//    curfgcolor=DEFAULT_FGCOLOR;
//    curbgcolor=DEFAULT_BGCOLOR;
    if(lastline>=MAX_LINES) {      // damn it ... our display is filled ... let's move everything upwards
	lastline=MAX_LINES-1;
	pcurline=(t_line*)&line+lastline;
        move_all_lines_up();
        clear_line(lastline);
	pcurline->nextchar=0;
//	init_line();lastline=0;
	gotnewdata=1;
    } else {
//        lastline++;
        pcurline=(t_line*)&line+lastline;
        pcurline->nextchar=0;
    }
    return pcurline;
}


int GLTerm::backspace()
{
    t_line *pcurline=(t_line*)&line+lastline;
    if(pcurline->nextchar>0){
//	pcurline->chars[pcurline->lastchar].character=0;
        pcurline->nextchar--;
	lastchar--;
    } else {
	lastchar=0;
    }
}

int GLTerm::parseansi(char curchar)
{
    printf("%c", curchar);
    if(isansi2==1){
	static char arg1[16]="";
	static char arg2[16]="";
	static char arg3[16]="";
	static char arg4[16]="";
	static char arg5[16]="";
	static char curindex=0;
	static char curarg=0;

	//HACK should it be char**
	static char *args[]={(char*)&arg1,(char*)&arg2,(char*)&arg3,(char*)&arg4,(char*)&arg5};
	
	switch(curchar){
	    case '0':
	    case '1':
	    case '2':
	    case '3':
	    case '4':
	    case '5':
	    case '6':
	    case '7':
	    case '8':
	    case '9': // we got an argument
		args[curarg][curindex]=curchar;
		curindex++; args[curarg][curindex]='\0';
		break;
	    case ';': // some arg is finished
		curarg++; curindex=0; args[curarg][0]='\0';
		break;
	    case 'J': // remove beginning from current cursor to end of screen
		remove_beginning_from_curpos();
		gotnewdata=1;
		break;
	    case 'K': // remove everything in line beginning from lastchar
		clear_line_after_lastchar();
		break;
	    case 'H': // move to position x=arg1 y=arg2
		if(arg1[0]) lastline=atoi(arg1)-1; else lastline=0;
		if(arg2[0]) lastchar=atoi(arg2)-1; else lastchar=-1;
		line[lastline].nextchar=lastchar;
		break;
	    case 'G': // move to position x=arg1 y=MAX
		if(arg1[0]) lastchar=atoi(arg1)-1; else lastchar=-1;
		lastline=bottom-1;
		line[lastline].nextchar=lastchar;
		break;
	    case 'd': // move to position x=MAX y=arg1
		if(arg1[0]) lastline=atoi(arg1)-1; else lastline=0;
		lastline=top+lastline;
		lastchar=MAX_CHARACTERS-1;
		line[lastline].nextchar=lastchar;
		break;
	    case 'm': // change graphic
		ansi_change_graphic(args);
		break;
	    case 'M': // Move memory in range ('r') one uo
		move_up_x_lines(arg1);
		break;
	    case 'L': // Move memory in range ('r') one down
		move_down_x_lines(arg1);
		break;
	    case 'l':
/*		RM -- Reset Mode
		
		ESC [ Ps ; Ps ; . . . ; Ps l                                                                                                          default value: none
		
		Resets one or more VT100 modes as specified by each selective parameter in the parameter string. Each mode to be reset is specified by a separate
		parameter. [See Set Mode (SM) control sequence]. (See Modes following this section).*/
		
		// mc only resets the '4' !?! => IRM (Insert/Replacement-Mode)
		// perhaps Set Cursor to Block mode ?
		break;
	    case 'r': // define scroll-range 
		if(arg1[0]) top=atoi(arg1); else top=0;
		if(arg2[0]) bottom=atoi(arg2); else bottom=0;
		line[lastline].nextchar=0;
		lastline=0; lastchar=0;
		break;
	    case 'a':
	    case 'C': // move x letters right
		    forward_x_letters(arg1);
		break;
	    case '?':
		isansi2=4;
		return 0;
	    default:
		printf("***unknown***");
	}
	if(!((curchar>='0' && curchar<='9') || curchar==';')){ // clean our args
	    args[0][0]='\0';
	    args[1][0]='\0';
	    args[2][0]='\0';
	    args[3][0]='\0';
	    args[4][0]='\0';
	    curindex=0;
	    curarg=0;
	    endansi();
	} 
    } else if(!isansi2) { 
	switch(curchar){
	    case '[': isansi2=1; break;
	    case '(': isansi2=2; break;
	    case ')': isansi2=3; break;
	    default:
		endansi();
		break;
	}
    } else if(isansi2==4){
	if(curchar>'9' || curchar<'0') endansi();
    } else {
	endansi();
    }
}

int GLTerm::add_char_append(char toappend)
{
    int shouldinc=1;
    t_line *pcurline=(t_line*)&line+lastline;
    if(pcurline->nextchar==MAX_CHARACTERS) { pcurline=line_is_full(); shouldinc=0; } // our line is full
    pcurline->chars[pcurline->nextchar].character=toappend;
    pcurline->chars[pcurline->nextchar].fgcolor=curfgcolor;
    pcurline->chars[pcurline->nextchar].bgcolor=curbgcolor;
    lastchar=pcurline->nextchar;
    if(shouldinc) pcurline->nextchar++;
}

int GLTerm::move_up_x_lines(char *arg)
{
    t_line *pfirstline;
    t_line *psecondline;
    t_line tmpline[MAX_LINES];
    int amount;
    int i;
    
    if(arg[0]) amount=atoi(arg); else amount=0;
    
    printf("moving up %d lines", amount);
    
    for(i=0;i<amount;i++){
    
	pfirstline=(t_line*)&line+lastline;
	psecondline=pfirstline+1;
    
	memcpy(&tmpline, psecondline, (bottom-top)*sizeof(struct line_struct));
	memcpy(pfirstline, &tmpline,  (bottom-top)*sizeof(struct line_struct));
    
    }
}


int GLTerm::move_down_x_lines(char *arg)
{
    t_line *pfirstline;
    t_line *psecondline;
    t_line tmpline[MAX_LINES];
    int amount;
    int i;
    
    if(arg[0]) amount=atoi(arg); else amount=0;
    
    printf("moving down %d lines", amount);
    
    for(i=0;i<amount;i++){
    
	pfirstline=(t_line*)&line+lastline;
	psecondline=pfirstline+1;
    
	memcpy(&tmpline, pfirstline, (bottom-top)*sizeof(struct line_struct));
	memcpy(psecondline, &tmpline,  (bottom-top)*sizeof(struct line_struct));
    
    }
}

int GLTerm::remove_beginning_from_curpos()
{
    int i,j=lastchar;
    for(i=lastline;i<MAX_LINES;i++) {
	for(;j<MAX_CHARACTERS;j++){
	    clear_char(i,j);
	}
	j=0;
    }
}

int GLTerm::forward_x_letters(char *arg1)
{
    int tmpint;t_line *pcurline;int i;
	tmpint=atoi(arg1);
	pcurline=(t_line*)&line+lastline;                                                                           
	for(i=0;i<tmpint;i++){
	    pcurline->nextchar++; lastchar++;
	    if(pcurline->nextchar==MAX_CHARACTERS) { pcurline=line_is_full(); } // our line is full
	    lastchar=pcurline->nextchar-1;
	}
}

int GLTerm::ansi_change_graphic(char **args)
{
    int curcol;
    int i;
    
    if (args[0][0]=='\0') {args[0][0]='0';args[0][1]='\0';}
    
    for(i=0;i<5;i++){
	if(args[i][0]){
	    curcol=atoi(args[i]);
	    if(curcol>=30 && curcol<38){
		curfgcolor=curcol-30;
	    } else if(curcol>=40 && curcol<48) {
		curbgcolor=curcol-40;
	    } else {
		switch(curcol){
		    case 49:
			curbgcolor=DEFAULT_BGCOLOR;
			break;
		    case 39:
			curbgcolor=DEFAULT_FGCOLOR;
			break;
		    case 0:
			curbgcolor=DEFAULT_BGCOLOR;
			curfgcolor=DEFAULT_FGCOLOR;
			break;
		    case 1:	// Bold or increased intensity
		    case 4:	// Underscore
		    case 5:	// Blink
		    case 7:	// Negative (reverse) image
		    case 10:	// primary font
		    case 11:	// alternate font
			break;
		    default:
			printf("*** don't know color-code %d\n", curcol);
			break;
		}
	    }
	}
    }
}

int GLTerm::move_all_lines_up()
{
    t_line *pfirstline=(t_line*)&line;
    t_line *psecondline=(t_line*)&line+1;
    t_line tmpline[MAX_LINES];
    
    memcpy(&tmpline, psecondline, (MAX_LINES-1)*sizeof(struct line_struct));
    memcpy(pfirstline, &tmpline, (MAX_LINES-1)*sizeof(struct line_struct));
}


int GLTerm::clear_line_after_lastchar()
{
    int i;
    for(i=lastchar;i<MAX_CHARACTERS;i++) clear_char(lastline, i);
}

int GLTerm::endansi()
{
    printf(" ending ansi %d!", isansi2);
    isansi=0;
    isansi2=0;
}

int GLTerm::LoadTexture(const char *fn)
{
  int texwid, texht;
  int texcomps;
 
  cout <<"read_tex"<<endl;
  teximage = read_texture(fn, &texwid, &texht, &texcomps);
  cout<<"done read_tex"<<endl;
  if (!teximage)
  {
    printf("Sorry, can't read texture file...\n");
    exit(0);
  }
  cout<<"about to pixelstore"<<endl;
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  cout<<"1"<<endl;
  cout<<texwid<<" "<<texht<<" "<<teximage<<endl;
  //BELOW SEGFAULTS
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, texwid, texht, 0, GL_RGBA, GL_UNSIGNED_BYTE, teximage);
  cout<<"2"<<endl;
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  cout<<"3"<<endl;
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
  cout<<"done LoadTexture()"<<endl;
}

////////////////////////////////////////////
// terminal.c
/////////////////////////////////////////////
struct utmp ut_entry;

int curtty,curpty;
pthread_t term_thread;

int term_addchar(char toprint)
{
  if(DEBUG) printf("sending: %.3d\n", toprint);
    write(curpty, &toprint, 1);
}

int term_addstring(char *toprint)
{
    char *ns;
    for(ns=toprint;ns[0];ns++){
	term_addchar(ns[0]);
    } // better method
}

void *terminal_main(void *_tosend)
{
int iscon=1,ret;
char *ns;
    while(iscon) {
	char buffer[1024];
	ret=read(curpty, &buffer, 1000);
	if(ret>0) { 
	 buffer[ret]='\0';
	 //ROSCO HACK -- GLOBAL INSTANCE
	 globalInstance->AddChar(buffer);
	}
	else  { 
	 printf("Connection to pty lost\n"); 
	 close(curpty); 
	 close(curtty); 
	 printf("********CONNECTION TO PTY LOST!*******\n");
	 sleep(1);
	 exit(0);
	}
    }
}

int init_terminal()
{
    int i;
    char buf[256];
    fd_set fds;
    int curtty,ret;
    struct timeval tv;
    int uid=0,gid=0,pid,iscon=1;
    char exe[]="/bin/sh";
    char curchar;
    char *disp;
    
    disp=getenv("DISPLAY");
    uid=getuid();
    gid=getgid();
    for(curchar='p'; curchar<'z';curchar++) {
     for(i=0;i < 16;i++) {
	sprintf(buf, "/dev/pty%c%x", curchar, i);
	curpty=open(buf, O_RDWR);
	if (curpty >= 0) {goto endloop;}
     }
    }
endloop:
    if(curpty < 0) { printf("Error opening pty\n"); return 0; }
    pid = fork();
    if(!pid) {
    char tmpstr[1024];
    buf[5]='t';
    curtty=open(buf, O_RDWR);
    if (curtty < 0) { printf("Error opening tty\n"); return 0; }
    setuid(uid);
    setgid(gid);
    if(setsid()<0) printf("ERROR (setsid)\n");
//    tcflush(curpty, TCIOFLUSH);
    if(ioctl(curtty, TIOCSCTTY, NULL)) printf("ERROR! (ttyflush)\n");;
    dup2(curtty, 0);
    dup2(curtty, 1);
    dup2(curtty, 2);
    sprintf(tmpstr, "%d", MAX_LINES-1);
    setenv("LINES", tmpstr, 1);
    sprintf(tmpstr, "%d", MAX_CHARACTERS-1);
    setenv("COLUMNS", tmpstr, 1);
    setenv("TERM", "rxvt", 1);
    execl(exe, exe, NULL);
   } else if(pid<0) {
    printf("Cant fork()\n");
   } else {
/*   struct passwd *curpasswd;

    ut_entry.ut_type = USER_PROCESS;                                                                                     
    ut_entry.ut_pid = pid;                                                                                              
    strcpy(ut_entry.ut_line, (char*)&buf+5);                                                                                
    strcpy(ut_entry.ut_id, (char*)&buf+8);                                                                                  
    time(&ut_entry.ut_time);                                                                                             
    curpasswd=(struct passwd*)getpwuid(getuid());
    strcpy(ut_entry.ut_user, curpasswd->pw_name);
    ut_entry.ut_addr = 0;                                                                                                
    setutent();                                                                                                          
    pututline(&ut_entry);                                                                                                
    endutent();*/


//   old  pthread_create(&term_thread, NULL, (void*)(thread_terminal), (char*)NULL);
     pthread_create(&term_thread, NULL, terminal_main, (char*)NULL);
     
 
   }
    return 1;
}

int term_unload()
{
    close(curpty);
    close(curtty);
}



/////////////////////////////////////////////////////////
// console.c
/////////////////////////////////////////////////////////
void *thread_console(void *blubb)
{
    char temp[1024];
    int temp_pos=0;
    char *syn;
    printf("# ");
    while(1) {
	temp[temp_pos]=getchar(); 
	if(temp[temp_pos]=='\n') {
	    temp[temp_pos]='\0';
	    syn=strchr(temp, ' ') ;
	    if(!syn) {
		printf("Help\n----------\n \nload <filename w/o .glf and in dir fonts>\n# ");
	    } else {
		syn[0]='\0'; syn++;
		if(!strcasecmp(temp, "load")) {
		  int curfont;
		  char curfonts[1024];
		    sprintf(curfonts, "fonts/%s.glf", syn);
		    printf("loading %s\n", curfonts);
		    curfont=glfLoadFont(curfonts);
		    printf("fontid: %d\n", curfont);
		    if(!glfSetCurrentFont(curfont))
			printf("*** done\n# ");
		    else printf("*** error\n# ");
		}
	    }
	    temp_pos=0;
	    temp[0]='\0';
	} else temp_pos++;
    }
}
