/**
 * This file is part of the OpenVIDIA project at http://openvidia.sf.net
 * Copyright (C) 2004, James Fung
 *
 * OpenVIDIA is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * OpenVIDIA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenVIDIA; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **/

#include "ProjPlane.h"
#include <iostream>
#include <strings.h>
using namespace std;

ProjPlane::ProjPlane(int w, int h, CGcontext context, CGprofile profile)
{
  width = w;
  height = h;
  planeName[0] = '\0';
  FPpassthru = new FragmentProgram( context,
                                 profile,
                                 "FPsamples/FP-nop.cg",
                                 0);
 

  P.setIdentity();
}

ProjPlane::ProjPlane(int w, int h, FragmentProgram *fp)
{
  width = w;
  height = h;
  planeName[0] = '\0';
  FPpassthru = fp;
 

  P.setIdentity();
}


ProjPlane::ProjPlane(int w, int h, float *p, CGcontext context, 
                     CGprofile profile) 
{
  width = w;
  height = h;
  planeName[0] = '\0';
  FPpassthru = new FragmentProgram( context,
                                 profile,
                                 "FP-nop.cg",
                                 0);

  P.set(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]);
}

ProjPlane::ProjPlane(int w, int h, float *p, FragmentProgram *fp) 
{
  width = w;
  height = h;
  planeName[0] = '\0';
  FPpassthru = fp;

  P.set(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]);
}


void ProjPlane::clear()
{
  glClearColor(0.0,0.0,1.0,0.0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void ProjPlane::draw(bool isFirst)
{
  int dist=0;
  float texwidth = 1.0;
  float texheight = 1.0;
  float origin = 0.0;
  float texdist= 1.0; ///NB. chirpmat has negative z axis,

  glActiveTextureARB(GL_TEXTURE1_ARB);
  glDisable(GL_TEXTURE_RECTANGLE_NV);
  glActiveTextureARB(GL_TEXTURE0_ARB);
  glEnable(GL_TEXTURE_RECTANGLE_NV);

  //blending done in 2 passes.  first, add the image, overwritting
  //any NaN background (where alpha=0) with the new data.
  //leave overlap undisturbed (i.e. still old image)
  //then on the second pass, render the same image,but
  //this time blend 50% with what is there (either prveious image, or
  //itself)

  glEnable(GL_BLEND);
  glEnable(GL_BLEND_COLOR_EXT);
  glBlendColorEXT(0.0, 0.0, 0.0, 0.5);
  //glBlendFunc(GL_DST_ALPHA, GL_DST_ALPHA);
  glBlendFunc(GL_ONE_MINUS_DST_ALPHA, GL_DST_ALPHA);
 
  //FPpassthru->activate();

  
  glColor4f(2.0, 2.0, 2.0, 1.0);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glMultMatrixf( P.getAsChirpMat() );

  if( false ) //debug
  {
    P.print();
    float *p = P.getAsChirpMat();
    cerr<<"P is "<<endl;
    for( int i=0; i<16; i++ ) cerr<<p[i]<<" ";
    cerr<<endl;
  }

 
   glBegin(GL_QUADS);
    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB, 0.0, height, dist);
    glTexCoord3f( 0.0, height, dist);
    glVertex3f( origin, (origin+texheight), texdist);

    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB, 0.0, 0.0, dist);
    glTexCoord3f( 0.0, 0.0, dist);
    glVertex3f( origin, origin, texdist);

    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB, width, 0.0, dist);
    glTexCoord3f( width, 0.0, dist);
    glVertex3f( origin+texwidth, origin, texdist);

    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB, width, height, dist);
    glTexCoord3f( width, height, dist);
    glVertex3f( origin+texwidth, (origin+texheight), texdist);
  glEnd();
  //FPpassthru->deactivate();


  glEnable(GL_BLEND);
  glEnable(GL_BLEND_COLOR_EXT);
  glBlendColorEXT(0.0, 0.0, 0.0, 0.5);
  glBlendFunc(GL_CONSTANT_ALPHA_EXT, GL_CONSTANT_ALPHA_EXT);

  glBegin(GL_QUADS);
    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB, 0.0, height, dist);
    glTexCoord3f( 0.0, height, dist);
    glVertex3f( origin, (origin+texheight), texdist);

    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB, 0.0, 0.0, dist);
    glTexCoord3f( 0.0, 0.0, dist);
    glVertex3f( origin, origin, texdist);

    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB, width, 0.0, dist);
    glTexCoord3f( width, 0.0, dist);
    glVertex3f( origin+texwidth, origin, texdist);

    //glMultiTexCoord3fARB(GL_TEXTURE0_ARB, width, height, dist);
    glTexCoord3f( width, height, dist);
    glVertex3f( origin+texwidth, (origin+texheight), texdist);
  glEnd();


 
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

void ProjPlane::setPlaneName(char *name)
{
  if( strlen(name) > NAME_LEN ) {
    cerr<<"Warning. Name too long. not storing"<<endl;
    planeName[0] = '\0'; 
    return;
  }
  strcpy(planeName, name);
}

char *ProjPlane::getPlaneName()
{
  return planeName;
}


