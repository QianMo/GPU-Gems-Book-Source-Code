This directory contains only the headers file for Feeling Software's FCollada

The entire source tree may be found here:
  ..\..\Source\Common\FCollada_302.zip

You may also download the latest version from Feeling Software's website:
  http://www.feelingsoftware.com
