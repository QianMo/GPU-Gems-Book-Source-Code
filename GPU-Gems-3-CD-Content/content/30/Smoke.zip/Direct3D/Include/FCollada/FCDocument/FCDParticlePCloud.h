/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/

#ifndef _FCD_PCLOUD_EMITTER_H_
#define _FCD_PCLOUD_EMITTER_H_

#ifndef _FCD_PARTICLE_COMPLEX_H_
#include "FCDocument/FCDParticleComplex.h"
#endif // _FCD_PARTICLE_COMPLEX_H_

#endif //_FCD_PCLOUD_EMITTER_H_
