#define W 512.0
#define H 512.0

#define N W*H
#define LOGN 18
